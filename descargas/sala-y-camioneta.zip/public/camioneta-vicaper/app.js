import {clockParts,timeLabel,dateAdd,dateLabel,durationLabel,validateReservation,interval,onDay,daySlice} from './domain.js';
import {initDatePickers,syncDatePickers} from './datepicker.js';
import {startCamioneta,saveReservation,camionetaAccess,watchInvitations} from './firebase-reservas.js';
import {renderMonth,shiftMonth} from './month-calendar.js';
export async function mountAgenda(root){
const $=s=>root.querySelector(s);
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const initials=name=>name.trim().split(/\s+/).slice(0,2).map(n=>n[0]).join('').toUpperCase();
let bookings=[],selectedDate=clockParts().date,calendarView='day',editId=null,editRevision=null,detailId=null,detailRevision=null,saving=false,toastTimer;
let invitationStates=new Map();
const canManage=b=>camionetaAccess.admin||b.userId===camionetaAccess.uid;
const times=b=>Number.isFinite(b.startAt)?b:({...b,...interval(b)});
const when=(date,m)=>`${dateLabel(date,{day:'numeric',month:'short',year:'numeric'})} · ${timeLabel(m)}`;
const tripPeriod=b=>`${when(b.startDate,b.start)} → ${when(b.endDate,b.end)}`;
const listFor=day=>bookings.filter(b=>onDay(b,day)).sort((a,b)=>daySlice(a,day).start-daySlice(b,day).start);
function notify(message){$('#toast').textContent=message;$('#toast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').hidden=true,6000);}
function invitationMessage(id){const s=invitationStates?.get(id);return invitationStates===null?'No se pudo comprobar el envío.':s?.status==='sent'?'Aviso simulado · Ver Correos demo.':s?.status==='error'?'Reserva guardada. Correo pendiente; se reintentará automáticamente.':'Preparando la simulación…';}
function candidate(){return {id:editId||undefined,revision:editRevision,destination:$('#trip-destination').value.trim(),notes:$('#trip-notes').value.trim(),startDate:$('#trip-start-date').value,endDate:$('#trip-end-date').value,start:Number($('#trip-start').value),end:Number($('#trip-end').value)};}
function setPeriod(date,start=540){const next=start+60;$('#trip-start-date').value=date;$('#trip-start').value=String(start);$('#trip-end-date').value=next>=1440?dateAdd(date,1):date;$('#trip-end').value=String(next%1440);syncDatePickers();updateSummary();}
function updateSummary(){const c=candidate(),{startAt,endAt}=interval(c);$('#reservation-summary').textContent=Number.isFinite(startAt)&&endAt>startAt?`${durationLabel((endAt-startAt)/60000)} · ${c.startDate===c.endDate?'Mismo día':'Viaje de varios días'}`:'La devolución debe ser posterior al retiro.';}
function renderProfile(){const u=camionetaAccess;$('#profile-initials').textContent=initials(u.name);$('#profile-name').textContent=u.name;$('#profile-role').textContent=u.admin?'Administrador':'Mis reservas';const owner=bookings.find(b=>b.id===editId);$('#form-user').textContent=owner?.ownerName||u.name;$('#form-avatar').textContent=initials(owner?.ownerName||u.name);$('#my-count').textContent=bookings.filter(b=>b.userId===u.uid&&times(b).endAt>Date.now()).length;}
function renderLive(){
 const now=Date.now(),all=bookings.map(times).sort((a,b)=>a.startAt-b.startAt),current=all.find(b=>b.startAt<=now&&b.endAt>now),next=all.find(b=>b.startAt>now);
 $('#header-date').textContent=dateLabel(clockParts().date,{day:'numeric',month:'long',year:'numeric'});
 $('#live-status').classList.toggle('busy',!!current);$('#live-status').innerHTML=`<span class="small-dot"></span> ${current?'EN VIAJE':'DISPONIBLE AHORA'}`;
 $('#status-description').textContent=current?`Reservada por ${current.ownerName}. Devolución: ${when(current.endDate,current.end)}.`:next?`Disponible hasta ${when(next.startDate,next.start)}.`:'La camioneta está disponible. Programa tu próximo viaje.';
 $('#next-meeting').innerHTML=next?`<div class="next-time">${esc(when(next.startDate,next.start))}</div><div class="next-title">${esc(next.destination)}</div><div class="next-person">${esc(next.ownerName)}</div>`:'<div class="next-time">Sin próximos viajes</div><div class="next-person">No hay reservas futuras.</div>';
}
function renderWeek(){
 const monday=dateAdd(selectedDate,-((new Date(selectedDate+'T12:00:00Z').getUTCDay()+6)%7));
 $('#calendar-month').textContent=dateLabel(selectedDate,{month:'long',year:'numeric'});$('#calendar-date').value=selectedDate;syncDatePickers();
 $('#week-strip').innerHTML=Array.from({length:7},(_,i)=>{const d=dateAdd(monday,i);return `<button class="week-day ${d===selectedDate?'selected':''} ${d===clockParts().date?'today':''} ${listFor(d).length?'has-events':''}" data-day="${d}" aria-pressed="${d===selectedDate}" aria-label="${esc(dateLabel(d,{weekday:'long',day:'numeric',month:'long'}))}"><span class="weekday">${dateLabel(d,{weekday:'short'}).replace('.','')}</span><strong>${Number(d.slice(-2))}</strong><span class="day-dot"></span></button>`;}).join('');
 $('#day-title').textContent=(selectedDate===clockParts().date?'Hoy, ':'')+dateLabel(selectedDate,{day:'numeric',month:'long'});
 const monthly=calendarView==='month';root.querySelectorAll('[data-calendar-view]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.calendarView===calendarView)));
 for(const s of ['#week-strip','.day-heading','#timeline-scroll','.agenda-foot'])$(s).hidden=monthly;
 $('#month-view').hidden=!monthly;$('#prev-week').setAttribute('aria-label',monthly?'Mes anterior':'Semana anterior');$('#next-week').setAttribute('aria-label',monthly?'Mes siguiente':'Semana siguiente');
 if(monthly)renderMonth($('#month-view'),{selectedDate,today:clockParts().date,bookings,userId:camionetaAccess.uid});
}
function renderTimeline(scroll=false){
 const all=$('#hours-range').value==='all',from=all?0:480,to=all?1440:1200,list=listFor(selectedDate),now=clockParts();
 const visible=list.filter(b=>{const s=daySlice(b,selectedDate);return s.start<to&&s.end>from;});
 $('#day-count').textContent=`${list.length} ${list.length===1?'reserva':'reservas'}${visible.length<list.length?' · ver todo el día':''}`;
 const timeline=$('#timeline');timeline.style.height=`${(to-from)/30*42}px`;
 timeline.innerHTML=Array.from({length:(to-from)/30},(_,i)=>{
  const m=from+i*30,taken=list.some(b=>{const s=daySlice(b,selectedDate);return s.start<m+30&&s.end>m;}),past=selectedDate<now.date||(selectedDate===now.date&&m<now.minutes);
  return `<div class="time-slot ${m%60?'half':''}"><span class="time-label">${timeLabel(m)}</span><button class="slot-button" data-time="${m}" ${taken||past?'disabled':''} aria-label="${taken?'Ocupado':past?'Horario pasado':'Reservar'} ${timeLabel(m)}">+ Reservar este horario</button></div>`;
 }).join('')+visible.map(b=>{
  const slice=daySlice(b,selectedDate),start=Math.max(slice.start,from),end=Math.min(slice.end,to);
  return `<button class="event ${b.userId===camionetaAccess.uid?'mine':''} ${end-start<=30?'short':''} ${times(b).endAt<=Date.now()?'past':''}" style="top:${(start-from)/30*42+3}px;height:${(end-start)/30*42-6}px" data-detail="${esc(b.id)}" aria-label="${esc(b.destination)}, ${esc(tripPeriod(b))}, ${esc(b.ownerName)}"><span class="trip-event-content"><span class="event-head"><span class="event-title">${esc(b.destination)}</span><span class="event-time">${b.startDate===selectedDate?timeLabel(b.start):'Desde '+dateLabel(b.startDate,{day:'numeric',month:'short'})} → ${b.endDate===selectedDate?timeLabel(b.end):dateLabel(b.endDate,{day:'numeric',month:'short'})}</span></span><span class="event-person"><span class="initial">${esc(initials(b.ownerName))}</span>${esc(b.ownerName)}${b.userId===camionetaAccess.uid?' · Tu reserva':''}</span></span></button>`;
 }).join('')+(selectedDate===now.date&&now.minutes>=from&&now.minutes<to?`<div class="now-line" style="top:${(now.minutes-from)/30*42}px"></div>`:'');
 if(scroll){const minute=selectedDate===now.date?now.minutes-60:visible.length?daySlice(visible[0],selectedDate).start-30:from;$('#timeline-scroll').scrollTop=Math.max(0,(minute-from)/30*42);}
}
function renderMine(){
 const all=bookings.filter(b=>b.userId===camionetaAccess.uid).map(times),future=all.filter(b=>b.endAt>Date.now()).sort((a,b)=>a.startAt-b.startAt),past=all.filter(b=>b.endAt<=Date.now()).sort((a,b)=>b.startAt-a.startAt);
 const cards=list=>list.map(b=>`<article class="my-booking"><div class="my-booking-date"><strong>${Number(b.startDate.slice(-2))}</strong><span>${dateLabel(b.startDate,{month:'short'})}</span></div><div><h3>${esc(b.destination)}</h3><p>${esc(tripPeriod(b))}</p></div><button class="button secondary" data-detail="${esc(b.id)}">Ver reserva ↗</button></article>`).join('');
 $('#my-bookings').innerHTML=(future.length?cards(future):'<div class="empty-state"><h3>Tu próximo viaje empieza aquí.</h3><p>Todavía no tienes reservas pendientes.</p><a href="#agenda" class="button secondary">Ir a la agenda →</a></div>')+(past.length?'<h3 class="history-title">Viajes anteriores</h3>'+cards(past):'');
}
function render(){if(!camionetaAccess)return;renderProfile();renderLive();renderWeek();renderTimeline();renderMine();updateSummary();}
function selectDate(day){if(!/^\d{4}-\d{2}-\d{2}$/.test(day))return;selectedDate=day;renderWeek();renderTimeline(true);}
function route(){const mine=location.hash==='#mis-reservas';if(!mine)calendarView='day';$('#agenda-view').hidden=mine;$('#my-view').hidden=!mine;$('#page-title').textContent=mine?'Tus viajes, en un solo lugar.':'Cada viaje, bien coordinado.';$('#page-description').textContent=mine?'Consulta tus próximas salidas y el registro de tus viajes.':'Reserva tu retiro y devolución. Indica el destino de tu viaje.';root.querySelectorAll('[data-nav]').forEach(n=>{const active=n.dataset.nav===(mine?'mis-reservas':'agenda');n.classList.toggle('active',active);if(active)n.setAttribute('aria-current','page');else n.removeAttribute('aria-current');});render();}
function showDetails(id){
 const b=bookings.find(b=>b.id===id);if(!b)return;detailId=id;detailRevision=b.revision;
 const own=canManage(b),future=times(b).startAt>=Date.now(),active=times(b).endAt>Date.now();
 $('#detail-content').innerHTML=`<h2 class="detail-title">${esc(b.destination)}</h2><div class="detail-row"><span><strong>Retiro</strong><p>${esc(when(b.startDate,b.start))}</p></span></div><div class="detail-row"><span><strong>Devolución</strong><p>${esc(when(b.endDate,b.end))}</p></span></div><div class="detail-row"><span><strong>Responsable</strong><p>${esc(b.ownerName)} · ${esc(b.ownerTeam)}</p></span></div>${b.notes?`<div class="detail-row"><span><strong>Notas del viaje</strong><p class="trip-text">${esc(b.notes)}</p></span></div>`:''}<p class="dialog-note">Horarios de Chile.</p>${own?`<p class="invitation-state" data-invitation-status="${esc(b.id)}">${esc(invitationMessage(b.id))}</p>`:''}${own&&(active||camionetaAccess.admin)?`<div class="detail-actions">${future?'<button class="button secondary" id="edit-booking">Editar reserva</button>':''}<button class="button danger" id="delete-booking">Cancelar reserva</button></div>`:`<p class="dialog-note">${own?'Este viaje ya terminó.':'Solo el responsable y Alexis Rodríguez pueden gestionar esta reserva.'}</p>`}`;
 $('#detail-dialog').showModal();
}
function cancelEdit(){editId=null;editRevision=null;$('#trip-destination').value='';$('#trip-notes').value='';$('#form-title').textContent='Reserva la camioneta';$('#reserve-button').textContent='Confirmar reserva';$('#cancel-edit').hidden=true;$('#form-error').hidden=true;renderProfile();}
$('#booking-form').addEventListener('submit',async e=>{
 e.preventDefault();if(saving)return;$('#form-error').hidden=true;const c=candidate();c.id=editId||crypto.randomUUID();const edited=!!editId;
 try{const error=validateReservation(c,bookings);if(error)throw Error(error);saving=true;$('#reserve-button').disabled=true;$('#booking-form').setAttribute('aria-busy','true');const result=await saveReservation(edited?'update':'create',c);bookings=bookings.filter(b=>b.id!==c.id).concat(result.booking);cancelEdit();selectedDate=c.startDate;notify(edited?'Reserva actualizada.':'La camioneta quedó reservada. El aviso por correo está en proceso.');}
 catch(error){$('#form-error').textContent=error.message;$('#form-error').hidden=false;}
 finally{saving=false;$('#reserve-button').disabled=false;$('#booking-form').removeAttribute('aria-busy');render();}
});
$('#detail-content').addEventListener('click',async e=>{
 const b=bookings.find(b=>b.id===detailId);if(!b||!canManage(b)||saving)return;
 if(e.target.closest('#edit-booking')){editId=b.id;editRevision=detailRevision;calendarView='day';selectedDate=b.startDate;$('#trip-destination').value=b.destination;$('#trip-notes').value=b.notes||'';$('#trip-start-date').value=b.startDate;$('#trip-end-date').value=b.endDate;$('#trip-start').value=String(b.start);$('#trip-end').value=String(b.end);$('#form-title').textContent='Editar reserva';$('#reserve-button').textContent='Guardar cambios';$('#cancel-edit').hidden=false;$('#form-error').hidden=true;$('#detail-dialog').close();location.hash='agenda';render();$('#trip-destination').focus();}
 if(e.target.closest('#delete-booking')){if(!confirm(`¿Cancelar el viaje a «${b.destination}» y liberar la camioneta?`))return;try{saving=true;await saveReservation('cancel',{id:b.id,revision:detailRevision});bookings=bookings.filter(x=>x.id!==b.id);$('#detail-dialog').close();if(editId===b.id)cancelEdit();render();notify('Reserva cancelada. La camioneta vuelve a estar disponible en ese período.');}catch(error){notify(error.message);}finally{saving=false;}}
});
for(const s of ['#trip-start-date','#trip-end-date','#trip-start','#trip-end'])$(s).addEventListener('change',()=>{syncDatePickers();updateSummary();});
$('#cancel-edit').addEventListener('click',cancelEdit);
$('#week-strip').addEventListener('click',e=>{const b=e.target.closest('[data-day]');if(b)selectDate(b.dataset.day);});
$('#prev-week').addEventListener('click',()=>selectDate(calendarView==='month'?shiftMonth(selectedDate,-1):dateAdd(selectedDate,-7)));
$('#next-week').addEventListener('click',()=>selectDate(calendarView==='month'?shiftMonth(selectedDate,1):dateAdd(selectedDate,7)));
$('#today-button').addEventListener('click',()=>selectDate(clockParts().date));$('#calendar-date').addEventListener('change',e=>selectDate(e.target.value));$('#hours-range').addEventListener('change',()=>renderTimeline(true));
$('.calendar-view-switch').addEventListener('click',e=>{const b=e.target.closest('[data-calendar-view]');if(b){calendarView=b.dataset.calendarView;renderWeek();if(calendarView==='day')renderTimeline(true);}});
$('#month-view').addEventListener('click',e=>{const b=e.target.closest('[data-month-day]');if(b){calendarView='day';selectDate(b.dataset.monthDay);}});
$('#timeline').addEventListener('click',e=>{const b=e.target.closest('[data-time]');if(!b)return;setPeriod(selectedDate,Number(b.dataset.time));$('#trip-destination').focus();if(innerWidth<780)$('#booking-form').scrollIntoView({behavior:'smooth',block:'center'});});
root.addEventListener('click',e=>{const b=e.target.closest('[data-detail]');if(b)showDetails(b.dataset.detail);const close=e.target.closest('[data-close]');if(close)close.closest('dialog').close();});
$('#demo-info').addEventListener('click',()=>$('#info-dialog').showModal());
$('#new-from-mine').addEventListener('click',()=>{cancelEdit();initialPeriod();location.hash='agenda';$('#trip-destination').focus();});
function initialPeriod(){const now=clockParts(),start=Math.max(540,Math.ceil((now.minutes+1)/30)*30);setPeriod(start>=1440?dateAdd(now.date,1):now.date,start>=1440?540:start);}
const options=Array.from({length:48},(_,i)=>`<option value="${i*30}">${timeLabel(i*30)}</option>`).join('');$('#trip-start').innerHTML=options;$('#trip-end').innerHTML=options;
initDatePickers(()=>bookings,root);initialPeriod();
bookings=await startCamioneta(rows=>{bookings=rows;render();if($('#detail-dialog').open){const current=rows.find(b=>b.id===detailId);if(!current||current.revision!==detailRevision){$('#detail-dialog').close();notify('La reserva cambió. Ábrela nuevamente para revisar su estado.');}}},root);
watchInvitations(states=>{invitationStates=states;root.querySelectorAll('[data-invitation-status]').forEach(el=>el.textContent=invitationMessage(el.dataset.invitationStatus));});
root.addEventListener('agenda:activate',route);route();renderTimeline(true);
setInterval(()=>{if(!root.isConnected)return;if(camionetaAccess){renderLive();renderTimeline();renderProfile();renderMine();}},30000);

}
