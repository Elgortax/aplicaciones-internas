import {dateAdd,dateLabel,timeLabel,onDay,daySlice} from './domain.js';

const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

export function shiftMonth(day,offset){
 const date=new Date(day+'T12:00:00Z');
 const target=new Date(Date.UTC(date.getUTCFullYear(),date.getUTCMonth()+offset,1,12));
 const last=new Date(Date.UTC(target.getUTCFullYear(),target.getUTCMonth()+1,0)).getUTCDate();
 target.setUTCDate(Math.min(date.getUTCDate(),last));
 return target.toISOString().slice(0,10);
}

export function monthDays(day){
 const first=day.slice(0,7)+'-01';
 const offset=(new Date(first+'T12:00:00Z').getUTCDay()+6)%7;
 const next=shiftMonth(first,1);
 const length=Number(dateAdd(next,-1).slice(-2));
 return Array.from({length:Math.ceil((offset+length)/7)*7},(_,i)=>dateAdd(first,i-offset));
}

export function renderMonth(container,{selectedDate,today,bookings,userId}){
 container.innerHTML=`<div class="month-weekdays" aria-hidden="true">${['Lun','Mar','Mié','Jue','Vie','Sáb','Dom'].map(day=>`<span>${day}</span>`).join('')}</div>
 <div class="month-grid">${monthDays(selectedDate).map(day=>{
  const list=bookings.filter(b=>onDay(b,day)).sort((a,b)=>daySlice(a,day).start-daySlice(b,day).start);
  const label=dateLabel(day,{weekday:'long',day:'numeric',month:'long',year:'numeric'});
  return `<div class="month-cell ${day.slice(0,7)!==selectedDate.slice(0,7)?'outside-month':''} ${day===today?'month-today':''} ${day===selectedDate?'month-selected':''}">
   <button type="button" class="month-date" data-month-day="${day}" aria-label="Ver horarios del ${esc(label)}, ${list.length} reservas" ${day===today?'aria-current="date"':''}><span>${Number(day.slice(-2))}</span><span class="month-count">${list.length?`${list.length} ${list.length===1?'reserva':'reservas'}`:''}</span></button>
   <div class="month-events">${list.slice(0,3).map(b=>`<button type="button" class="month-event ${b.userId===userId?'mine':''}" data-detail="${esc(b.id)}" title="${esc(b.destination)} · ${b.startDate===day?timeLabel(b.start):'Continúa'}–${b.endDate===day?timeLabel(b.end):'sigue'} · ${esc(b.ownerName)}" aria-label="${esc(b.destination)}, ${b.startDate===day?timeLabel(b.start):'Continúa'} a ${b.endDate===day?timeLabel(b.end):'sigue'}, ${esc(b.ownerName)}${b.userId===userId?', tu reserva':''}"><time>${b.startDate===day?timeLabel(b.start):'Continúa'}</time><span>${esc(b.destination)}</span></button>`).join('')}${list.length>3?`<button class="month-more" type="button" data-month-day="${day}">+${list.length-3} más</button>`:''}</div>
  </div>`;
 }).join('')}</div>
 <p class="month-help">Selecciona un día para ver sus horarios o una reserva para ver los detalles. Los viajes de varios días aparecen en cada día ocupado.</p>`;
}
