// Shared by the function and browser (the build emits ES module exports).
const ZONE = 'America/Santiago';
function clockParts(date = new Date()) {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-CA', {timeZone:ZONE,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(date).map(x=>[x.type,x.value]));
  return {date:`${p.year}-${p.month}-${p.day}`,minutes:Number(p.hour)*60+Number(p.minute)};
}
function timeLabel(n){return `${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;}
function dateAdd(day,n){const d=new Date(day+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10);}
function dateLabel(day,options={}){return new Intl.DateTimeFormat('es-CL',{timeZone:'UTC',...options}).format(new Date(day+'T12:00:00Z'));}
function validDate(d){return typeof d==='string' && /^20\d{2}-\d{2}-\d{2}$/.test(d) && Number.isFinite(Date.parse(d+'T12:00:00Z')) && new Date(d+'T12:00:00Z').toISOString().slice(0,10)===d;}
const offsetCache=new Map();
function toInstant(day,minutes){
  if(!validDate(day)||!Number.isInteger(minutes)||minutes<0||minutes>=1440)return NaN;
  const base=Date.parse(day+'T00:00:00Z')+minutes*60000;
  if(!offsetCache.has(day)){
    const offsets=new Set();
    for(const shift of [-36,0,36]){
      const sample=Date.parse(day+'T12:00:00Z')+shift*3600000,p=clockParts(new Date(sample));
      offsets.add(Date.parse(p.date+'T00:00:00Z')+p.minutes*60000-sample);
    }
    if(offsetCache.size>800)offsetCache.clear();
    offsetCache.set(day,[...offsets]);
  }
  const matches=offsetCache.get(day).map(offset=>base-offset).filter(ms=>{const p=clockParts(new Date(ms));return p.date===day&&p.minutes===minutes;});
  return matches.length===1?matches[0]:NaN;
}
function interval(b){return {startAt:toInstant(b.startDate,b.start),endAt:toInstant(b.endDate,b.end)};}
function wallKey(date,minutes){return date+'T'+timeLabel(minutes);}
function overlaps(a,b){return wallKey(a.startDate,a.start)<wallKey(b.endDate,b.end)&&wallKey(a.endDate,a.end)>wallKey(b.startDate,b.start);}
function onDay(b,day){return b.startDate<=day&&(b.endDate>day||(b.endDate===day&&b.end>0));}
function daySlice(b,day){return {start:b.startDate===day?b.start:0,end:b.endDate===day?b.end:1440};}
function durationLabel(n){const days=Math.floor(n/1440),hours=Math.floor(n%1440/60),mins=n%60;return [days?`${days} ${days===1?'día':'días'}`:'',hours?`${hours} h`:'',mins?`${mins} min`:''].filter(Boolean).join(' ')||'0 min';}
function validateReservation(c,bookings=[],now=new Date()){
  if(typeof c.destination!=='string'||!c.destination.trim()||c.destination.trim().length>160)return 'Indica el destino del viaje (hasta 160 caracteres).';
  if(typeof c.notes!=='string'||c.notes.length>2000)return 'Las notas pueden tener hasta 2.000 caracteres.';
  if(!validDate(c.startDate)||!validDate(c.endDate))return 'Selecciona fechas válidas de retiro y devolución.';
  if(![c.start,c.end].every(n=>Number.isInteger(n)&&n>=0&&n<1440&&n%30===0))return 'Elige horas en bloques de 30 minutos.';
  const {startAt,endAt}=interval(c);
  if(!Number.isFinite(startAt)||!Number.isFinite(endAt))return 'Ese horario coincide con un cambio de hora en Chile. Elige otra hora de retiro o devolución.';
  if(endAt<=startAt)return 'La devolución debe ser posterior al retiro.';
  if(startAt<Math.floor(now.getTime()/60000)*60000)return 'Ese horario de retiro ya pasó. Elige un horario futuro.';
  if(bookings.some(b=>b.id!==c.id&&overlaps(c,b)))return 'La camioneta ya está reservada durante parte de ese viaje. Elige otras fechas u horas.';
  return null;
}
export {ZONE,clockParts,timeLabel,dateAdd,dateLabel,validDate,toInstant,interval,wallKey,overlaps,onDay,daySlice,durationLabel,validateReservation};
