import {api,connect,subscribe,current} from '/demo-client.js';
export let camionetaAccess=null;
export async function listPeople(){return (await api('/api/people')).people;}
export async function startCamioneta(onChange,root=document){const {profile,state}=await connect();camionetaAccess=profile.user;root.querySelector('#sync-status').textContent='Demo local · Datos de ejemplo';const ds=root.querySelector('#display-sync-status');if(ds)ds.textContent='Demo local · Hora de Chile · Sin datos reales';root.classList?.remove('agenda-checking');document.documentElement.classList.remove('validando-acceso');subscribe(next=>onChange(next.trips));return current().trips;}
export function watchInvitations(callback){callback(new Map(current()?.invitations.camioneta||[]));return subscribe(state=>callback(new Map(state.invitations.camioneta)));}
export async function saveReservation(action,booking){return api('/api/camioneta/reservation',{...booking,action});}
