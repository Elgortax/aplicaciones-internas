let initial,events,last;const listeners=new Set();
export async function api(path,data){const response=await fetch(path,data===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const result=await response.json();if(!response.ok)throw Error(result.error||'No se pudo completar la operación.');return result;}
export async function connect(){
 if(!initial)initial=Promise.all([api('/api/profile'),api('/api/state')]).then(([profile,state])=>{last=state;events=new EventSource('/api/events');events.addEventListener('state',event=>{last=JSON.parse(event.data);for(const listener of listeners)listener(last);});events.addEventListener('reload',()=>location.reload());return {profile,state};});
 return initial;
}
export function subscribe(callback){listeners.add(callback);return ()=>listeners.delete(callback);}
export function current(){return last;}
