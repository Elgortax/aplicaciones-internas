import {api,connect,subscribe} from '/demo-client.js';
const {profile}=await connect();
const bar=document.createElement('aside');bar.className='demo-bar';bar.setAttribute('aria-label','Controles de demostración');
bar.innerHTML='<div class="demo-label"><b>VICAPER / DEMO</b><span>Datos de ejemplo · Sin correos reales</span></div><div class="demo-actions"><label>Ver como <select id="demo-profile" aria-label="Perfil de demostración"></select></label><button id="demo-mails">Correos demo <span id="demo-mail-count">0</span></button><a href="/guia.html" target="_blank" rel="noopener">Guía ↗</a><button id="demo-reset" title="Restablecer únicamente los datos de esta demo">Restablecer</button></div>';
const select=bar.querySelector('select');for(const person of profile.people){const option=document.createElement('option');option.value=person.uid;option.textContent=person.name+(person.admin?' · Admin':'');option.selected=person.uid===profile.user.uid;select.append(option);}
document.body.append(bar);
select.onchange=async()=>{select.disabled=true;try{await api('/api/profile',{uid:select.value});location.reload();}catch(error){alert(error.message);select.disabled=false;}};
bar.querySelector('#demo-reset').onclick=async()=>{if(confirm('¿Restablecer los datos de ejemplo? Se borrarán solo las reservas y correos simulados de esta demo.')){await api('/api/reset',{});location.reload();}};
const dialog=document.createElement('dialog');dialog.className='demo-mail-dialog';dialog.setAttribute('aria-label','Correos simulados');
dialog.innerHTML='<div class="demo-mail-heading"><div><span class="demo-kicker">BANDEJA DE DEMOSTRACIÓN</span><h2>Así se verían los avisos</h2><p>Simulación local: ninguno de estos mensajes se envía.</p></div><button aria-label="Cerrar correos">×</button></div><div class="demo-mail-list"></div>';
document.body.append(dialog);dialog.querySelector('button').onclick=()=>dialog.close();
bar.querySelector('#demo-mails').onclick=async()=>{
 const list=dialog.querySelector('.demo-mail-list');list.replaceChildren();const mails=await api('/api/mails');
 if(!mails.length){const p=document.createElement('p');p.className='demo-empty';p.textContent='Crea, edita o cancela una reserva para ver aquí los avisos que generaría la aplicación.';list.append(p);}
 for(const mail of mails.slice(0,60)){
  const card=document.createElement('article');card.className='demo-mail';const label=document.createElement('small');label.textContent=(mail.kind==='sala'?'SALAS':'CAMIONETA')+' · '+new Date(mail.createdAt).toLocaleString('es-CL');
  const title=document.createElement('h3');title.textContent=mail.subject;const to=document.createElement('p');to.className='demo-recipient';to.textContent='Para: '+mail.to+' · Simulado';const body=document.createElement('div');body.className='demo-mail-body';body.innerHTML=mail.html;
  card.append(label,title,to,body);list.append(card);
 }
 dialog.showModal();
};
subscribe(state=>bar.querySelector('#demo-mail-count').textContent=state.mailCount);
