import {ROOMS,timeLabel,dateLabel,kitchenBlocked} from './domain.js';
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

// Only bookable half-hour gaps are advertised, independently for each room.
export function roomDay(bookings,roomId,now){
  const meetings=bookings.filter(b=>b.date===now.date&&(b.roomId||'normal')===roomId).sort((a,b)=>a.start-b.start);
  const occupied=meetings.map(b=>({...b,kind:'meeting'}));
  if(roomId==='cocina')occupied.push({id:'kitchen-closure',kind:'closed',start:780,end:990,title:'Bloqueo diario',ownerName:'No se permiten reservas'});
  occupied.sort((a,b)=>a.start-b.start);
  const free=[];let cursor=Math.min(1440,Math.ceil(now.minutes/30)*30);
  for(const block of occupied){
    if(block.end<=cursor)continue;
    if(block.start>cursor)free.push({kind:'free',start:cursor,end:block.start});
    cursor=Math.max(cursor,block.end);
  }
  if(cursor<1440)free.push({kind:'free',start:cursor,end:1440});
  const current=meetings.find(b=>b.start<=now.minutes&&b.end>now.minutes);
  const blocked=kitchenBlocked(roomId,now.minutes,now.minutes+1);
  return {roomId,current,blocked,free,meetings,entries:[...occupied.filter(b=>b.end>now.minutes),...free].sort((a,b)=>a.start-b.start)};
}

export function renderRoomsDisplay(root,bookings,now){
  root.querySelector('#display-clock').textContent=timeLabel(now.minutes);
  root.querySelector('#display-date').textContent=dateLabel(now.date,{weekday:'long',day:'numeric',month:'long'});
  for(const roomId of Object.keys(ROOMS)){
    const day=roomDay(bookings,roomId,now),card=root.querySelector(`[data-display-room="${roomId}"]`);
    const mode=day.blocked?'closed':day.current?'busy':'free';
    const status=day.blocked?'No disponible':day.current?'En reunión':'Disponible';
    const subtitle=day.blocked?'Bloqueo diario · 13:00–16:30':day.current?`${day.current.title} · Hasta las ${timeLabel(day.current.end)}`:'La sala está libre ahora';
    const next=day.free[0];
    card.className=`room-display-card ${mode}`;
    card.innerHTML=`<header class="room-display-heading"><div><span class="eyebrow">${roomId==='normal'?'SALA 01':'SALA 02'}</span><h2>${esc(ROOMS[roomId])}</h2></div><span class="room-state"><i></i>${status}</span></header>
      <div class="room-display-status"><h3>${status}</h3><p>${esc(subtitle)}</p>${day.current?`<small>${esc(day.current.ownerName||'Usuario')}</small>`:''}</div>
      <div class="room-next-free"><span>Próximo horario para reservar</span><strong>${next?`${timeLabel(next.start)} – ${timeLabel(next.end)}`:'Sin horarios disponibles hoy'}</strong>${next?'<small>Reservas de 30 minutos a 3 horas</small>':''}</div>
      <div class="room-timeline-heading"><h3>De ahora en adelante</h3><span>${day.meetings.length} ${day.meetings.length===1?'reunión':'reuniones'} hoy</span></div>
      <div class="room-display-timeline" aria-label="Disponibilidad de ${esc(ROOMS[roomId])}">${day.entries.length?day.entries.map(item=>`<article class="room-agenda-row ${item.kind}"><div class="room-agenda-time">${timeLabel(item.start)}<small>${timeLabel(item.end)}</small></div><div><h4>${item.kind==='free'?'Horario libre':esc(item.title)}</h4><p>${item.kind==='free'?'Disponible para reservar':esc(item.ownerName||'Usuario')}</p></div><span class="room-row-label">${item.kind==='free'?'LIBRE':item.kind==='closed'?'BLOQUEADA':'RESERVADA'}</span></article>`).join(''):'<p class="room-day-over">La agenda de hoy ha terminado.</p>'}</div>`;
  }
}
