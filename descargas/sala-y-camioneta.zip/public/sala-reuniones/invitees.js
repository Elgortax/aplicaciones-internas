import {listPeople} from './firebase-reservas.js';
export function mountInvitees(root) {
  let people=[],selected=[];
  root.innerHTML='<label for="invitee-search">¿A quién invitar?</label><input id="invitee-search" placeholder="Buscar persona del panel" autocomplete="off"><div id="invitee-options" class="invitee-options" role="group" aria-label="Personas del panel"></div><div class="external-invite"><input id="invitee-email" type="email" placeholder="O escribe un correo externo" aria-label="Correo de invitado externo"><button type="button" id="add-invitee" class="button secondary">Agregar</button></div><div id="selected-invitees" class="selected-invitees" aria-live="polite"></div><p id="invitee-error" class="form-error" role="alert" hidden></p><p class="field-help">Selecciona una o varias personas. El creador recibe la invitación automáticamente, aunque no se seleccione aquí.</p>';
  const $=id=>root.querySelector('#'+id);
  const error=message=>{$('invitee-error').textContent=message;$('invitee-error').hidden=!message;};
  function render(){
    const term=$('invitee-search').value.trim().toLocaleLowerCase();
    $('invitee-options').replaceChildren();
    for(const p of people.filter(p=>(p.name+' '+p.email).toLocaleLowerCase().includes(term))){
      const label=document.createElement('label');label.className='invitee-option';
      const checkbox=document.createElement('input');checkbox.type='checkbox';checkbox.checked=selected.some(s=>s.email===p.email);checkbox.dataset.uid=p.uid;
      const text=document.createElement('span');text.textContent=p.name+' · '+p.email;
      checkbox.addEventListener('change',()=>{if(checkbox.checked){if(selected.length>=30){error('Máximo 30 invitados.');checkbox.checked=false;return;}selected.push(p);}else selected=selected.filter(s=>s.email!==p.email);error('');render();});
      label.append(checkbox,text);$('invitee-options').append(label);
    }
    if(!$('invitee-options').children.length)$('invitee-options').textContent='No hay personas que coincidan.';
    $('selected-invitees').replaceChildren();
    for(const p of selected){const chip=document.createElement('button');chip.type='button';chip.className='invitee-chip';chip.textContent=(p.name||p.email)+' ×';chip.title=p.email;chip.setAttribute('aria-label','Quitar a '+(p.name||p.email));chip.addEventListener('click',()=>{selected=selected.filter(s=>s.email!==p.email);render();});$('selected-invitees').append(chip);}
  }
  function addEmail(){const email=$('invitee-email').value.trim().toLowerCase();if(!/^[^\s@<>;,]+@[^\s@<>;,]+\.[^\s@<>;,]+$/.test(email)||email.length>254){error('Escribe un correo válido.');return;}if(selected.some(p=>p.email===email)){error('Esa persona ya está invitada.');return;}if(selected.length>=30){error('Máximo 30 invitados.');return;}selected.push(people.find(p=>p.email===email)||{email,name:email});$('invitee-email').value='';error('');render();}
  $('add-invitee').onclick=addEmail;$('invitee-email').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();addEmail();}});$('invitee-search').addEventListener('input',render);
  async function load(){try{$('invitee-options').textContent='Cargando personas…';people=await listPeople();error('');render();}catch{error('No pudimos cargar las personas. Puedes escribir un correo o reintentar.');$('invitee-options').innerHTML='<button type="button" id="retry-people" class="text-button">Reintentar carga</button>';$('retry-people').onclick=load;}}
  void load();
  return {get(){if($('invitee-email').value.trim())throw Error('Presiona Agregar para incluir el correo escrito.');return selected.map(p=>p.uid?{uid:p.uid}:{email:p.email});},set(value){selected=(value||[]).map(p=>({...p}));$('invitee-email').value='';error('');render();},reset(){this.set([]);}};
}
