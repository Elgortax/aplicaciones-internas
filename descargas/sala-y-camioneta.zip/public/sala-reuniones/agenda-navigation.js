// Keep each calendar's DOM, form and subscriptions alive for this browser visit.
const bases={sala:'/sala-reuniones/',camioneta:'/camioneta-vicaper/'};
const keyFor=url=>Object.keys(bases).find(key=>url.origin===location.origin&&[bases[key],bases[key]+'index.html'].includes(url.pathname));
const records=new Map(),pending=new Map();
let active,navigation=0;
const style=document.createElement('style');
style.textContent='.agenda-checking{visibility:hidden}#agenda-navigation-status{position:fixed;bottom:20px;left:50%;transform:translateX(-50%);z-index:2147483646;background:#252c20;color:white;padding:12px 18px;border-radius:8px;font:13px/1.5 Arial,sans-serif;visibility:visible!important;max-width:90vw}#agenda-navigation-status[hidden]{display:none!important}';
document.head.append(style);
const status=document.createElement('div');status.id='agenda-navigation-status';status.role='status';status.hidden=true;
function message(text){status.textContent=text;status.hidden=!text;}
function normalizeAssets(root,base){
 for(const node of root.querySelectorAll('[src]'))node.setAttribute('src',new URL(node.getAttribute('src'),base).href);
}
function createRecord(key,root,sheets=[],stylesReady=[]){
 const record={key,root,sheets,scroll:0,ready:null};records.set(key,record);
 root.dataset.agendaRoot=key;
 record.ready=Promise.all(stylesReady).then(()=>import(bases[key]+'app.js')).then(module=>{record.initialized=true;return module.mountAgenda(root);});
 return record;
}
const initialKey=keyFor(new URL(location.href));
const initialRoot=document.createElement('div');
initialRoot.append(...document.body.childNodes);
const initialSheets=[...document.head.querySelectorAll('link[rel="stylesheet"]')];
for(const sheet of initialSheets){
 sheet.href=new URL(sheet.getAttribute('href'),location.href).href;
}
normalizeAssets(initialRoot,new URL(bases[initialKey],location.origin));
document.body.append(initialRoot,status);
active=createRecord(initialKey,initialRoot,initialSheets);

async function getRecord(key){
 if(records.has(key))return records.get(key);
 if(!pending.has(key))pending.set(key,(async()=>{
  const response=await fetch(bases[key],{credentials:'same-origin'});
  if(!response.ok)throw Error('No se pudo abrir la agenda. Revisa tu conexión e inténtalo de nuevo.');
  const doc=new DOMParser().parseFromString(await response.text(),'text/html');
  if(!doc.querySelector('#booking-form'))throw Error('La agenda no está disponible. Inténtalo de nuevo.');
  const root=document.createElement('div'),sheets=[],stylesReady=[];
  for(const sheet of doc.querySelectorAll('link[rel="stylesheet"]')){
   const link=document.createElement('link');link.rel='stylesheet';link.href=new URL(sheet.getAttribute('href'),new URL(bases[key],location.origin)).href;link.media='not all';sheets.push(link);stylesReady.push(new Promise((resolve,reject)=>{link.onload=resolve;link.onerror=()=>{if(link.sheet?.cssRules.length)resolve();else reject(Error('No se pudo cargar el diseño de la agenda. Reintenta.'));};}));document.head.append(link);
  }
  root.append(...doc.body.childNodes);
  root.querySelectorAll('script').forEach(script=>script.remove());
  normalizeAssets(root,new URL(bases[key],location.origin));
  const record=createRecord(key,root,sheets,stylesReady);
  // Mark failure as handled during preloading; a click can retry the failed load.
  record.ready.catch(()=>{if(!record.initialized){records.delete(key);sheets.forEach(sheet=>sheet.remove());}});
  return record;
 })().finally(()=>pending.delete(key)));
 return pending.get(key);
}
async function navigate(url,push=false){
 const key=keyFor(url);if(!key)return;
 const ticket=++navigation;
 for(const record of records.values())record.root.dataset.requested='false';
 try{
  const record=await getRecord(key);if(ticket!==navigation)return;
  record.root.dataset.requested='true';
  record.root.dispatchEvent(new Event('agenda:request'));
  message('Abriendo agenda…');
  await record.ready;if(ticket!==navigation)return;
  if(push&&url.href!==location.href)history.pushState(null,'',url);
  const changed=active!==record;
  if(changed){
   active.scroll=scrollY;
   active.root.querySelectorAll('dialog[open]').forEach(dialog=>dialog.close());
   active.sheets.forEach(sheet=>sheet.media='not all');record.sheets.forEach(sheet=>sheet.media='all');
   active.root.replaceWith(record.root);active=record;
  }
  document.documentElement.classList.remove('validando-acceso');
  if(!record.root.classList.contains('agenda-checking'))document.getElementById('vicaper-access-recovery')?.remove();
  record.root.dispatchEvent(new Event('agenda:activate'));
  message('');
  if(changed){scrollTo({top:record.scroll,behavior:'instant'});record.root.querySelector('#page-title')?.setAttribute('tabindex','-1');record.root.querySelector('#page-title')?.focus({preventScroll:true});}
 }catch(error){if(ticket===navigation)message(error.message||'No se pudo abrir la agenda. Vuelve a intentarlo.');}
}
document.addEventListener('click',event=>{
 if(event.defaultPrevented||event.button!==0||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;
 const link=event.target.closest('a[href]');if(!link||link.target||link.hasAttribute('download'))return;
 const url=new URL(link.href);if(!keyFor(url))return;
 event.preventDefault();void navigate(url,true);
});
addEventListener('popstate',()=>void navigate(new URL(location.href)));
addEventListener('hashchange',()=>void navigate(new URL(location.href)));
message('Abriendo agenda…');
try{
 await active.ready;
 document.documentElement.classList.remove('validando-acceso');if(navigation===0)message('');
 const other=initialKey==='sala'?'camioneta':'sala';
 void getRecord(other).then(record=>record.ready).catch(()=>{});
}catch{message('No se pudo cargar la agenda. Recarga la página para reintentar.');}
