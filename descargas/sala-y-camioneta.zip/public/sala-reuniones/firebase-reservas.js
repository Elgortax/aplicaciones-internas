import {api,connect,subscribe,current} from '/demo-client.js';
export let salaAccess=null;
export async function listPeople(){return (await api('/api/people')).people;}
export async function startSala(onChange,root=document){const {profile,state}=await connect();salaAccess=profile.user;root.querySelector('#sync-status').textContent='Demo local · Datos de ejemplo';const ds=root.querySelector('#display-sync-status');if(ds)ds.textContent='Demo local · Hora de Chile · Sin datos reales';root.classList?.remove('agenda-checking');document.documentElement.classList.remove('validando-acceso');subscribe(next=>onChange(next.rooms));return current().rooms;}
export function watchInvitations(callback){callback(new Map(current()?.invitations.sala||[]));return subscribe(state=>callback(new Map(state.invitations.sala)));}
export async function saveReservation(action,booking){return api('/api/sala/reservation',{...booking,action});}
