import {clockParts,dateAdd,dateLabel} from './domain.js';

let scope=document;
export function syncDatePickers(){
  scope.querySelectorAll('[data-date-input]').forEach(button=>{
    const value=scope.querySelector('#'+button.dataset.dateInput).value;
    const label=button.querySelector('[data-date-label]');
    if(label)label.textContent=value?dateLabel(value,{day:'numeric',month:'long',year:'numeric'}):'Seleccionar fecha';
    button.setAttribute('aria-label',`${button.dataset.dateInput==='meeting-date'?'Fecha de la reunión':'Fecha de la agenda'}${value?': '+dateLabel(value,{day:'numeric',month:'long',year:'numeric'}):''}`);
  });
}

export function initDatePickers(getBookings,root=document){
  scope=root;
  const dialog=document.createElement('dialog');
  dialog.id='date-dialog';dialog.className='calendar-popover';dialog.setAttribute('aria-labelledby','picker-title');
  dialog.innerHTML=`<div class="picker-caption"><span id="picker-title">ELIGE UNA FECHA</span><button type="button" class="picker-close" aria-label="Cerrar calendario">×</button></div><div class="picker-monthbar"><div id="picker-month" aria-live="polite"></div><div><button type="button" data-month="-1" aria-label="Mes anterior"><svg class="icon"><use href="#i-arrow"/></svg></button><button type="button" data-month="1" aria-label="Mes siguiente"><svg class="icon"><use href="#i-arrow"/></svg></button></div></div><div class="picker-weekdays" aria-hidden="true"><span>L</span><span>M</span><span>M</span><span>J</span><span>V</span><span>S</span><span>D</span></div><div id="picker-days" class="picker-days" role="group" aria-label="Días del mes"></div><div class="picker-legend"><span><i></i> Con reservas</span><span>Hora de Chile</span></div><div class="picker-footer"><button type="button" id="picker-today">Ir a hoy <span>↗</span></button><span id="picker-hint">Selecciona un día</span></div>`;
  (scope===document?document.body:scope).append(dialog);
  let trigger,input,month,focusDay;
  const firstDay=day=>day.slice(0,7)+'-01';
  function shiftMonth(day,delta){const d=new Date(day+'T12:00:00Z');const original=d.getUTCDate();d.setUTCDate(1);d.setUTCMonth(d.getUTCMonth()+delta);const end=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0)).getUTCDate();d.setUTCDate(Math.min(original,end));return d.toISOString().slice(0,10);}
  function disabled(day){return input.id==='meeting-date'&&day<clockParts().date;}
  function render(focus=false){
    const today=clockParts().date;const selected=input.value;
    const weekday=new Date(month+'T12:00:00Z').getUTCDay();const start=dateAdd(month,-((weekday+6)%7));
    const count=new Map();for(const b of getBookings())count.set(b.date,(count.get(b.date)||0)+1);
    dialog.querySelector('#picker-month').textContent=dateLabel(month,{month:'long',year:'numeric'});
    dialog.querySelector('#picker-days').innerHTML=Array.from({length:42},(_,i)=>{
      const day=dateAdd(start,i),n=count.get(day)||0,off=disabled(day);
      return `<button type="button" data-date="${day}" class="picker-day ${day===selected?'selected':''} ${day===today?'is-today':''} ${day.slice(0,7)!==month.slice(0,7)?'outside':''}" ${off?'disabled':''} tabindex="${day===focusDay?0:-1}" aria-pressed="${day===selected}" ${day===today?'aria-current="date"':''} aria-label="${dateLabel(day,{weekday:'long',day:'numeric',month:'long',year:'numeric'})}${n?', '+n+(n===1?' reserva':' reservas'):''}"><span>${Number(day.slice(-2))}</span><i class="${n?'has-bookings':''}"></i></button>`;
    }).join('');
    dialog.querySelector('#picker-hint').textContent=selected===today?'Hoy seleccionado':selected?dateLabel(selected,{day:'numeric',month:'short'}):'Selecciona un día';
    if(focus)dialog.querySelector(`[data-date="${focusDay}"]`)?.focus({preventScroll:true});
  }
  function position(){
    if(!trigger||!dialog.open)return;
    const r=trigger.getBoundingClientRect(),width=dialog.offsetWidth,height=dialog.offsetHeight,gap=9;
    const left=Math.min(Math.max(12,r.right-width),Math.max(12,innerWidth-width-12));
    const below=r.bottom+gap;const top=below+height<=innerHeight-12?below:Math.max(12,Math.min(r.top-height-gap,innerHeight-height-12));
    dialog.style.left=`${left}px`;dialog.style.top=`${top}px`;
  }
  function open(button){
    trigger=button;input=scope.querySelector('#'+button.dataset.dateInput);
    focusDay=input.value||clockParts().date;if(disabled(focusDay))focusDay=clockParts().date;
    month=firstDay(focusDay);render();button.setAttribute('aria-expanded','true');dialog.showModal();position();dialog.querySelector(`[data-date="${focusDay}"]`)?.focus({preventScroll:true});
  }
  function choose(day){if(disabled(day))return;input.value=day;input.dispatchEvent(new Event('change',{bubbles:true}));syncDatePickers();dialog.close();}
  scope.querySelectorAll('[data-date-input]').forEach(button=>{button.setAttribute('aria-haspopup','dialog');button.setAttribute('aria-controls','date-dialog');button.setAttribute('aria-expanded','false');button.addEventListener('click',()=>open(button));});
  dialog.addEventListener('close',()=>{trigger?.setAttribute('aria-expanded','false');trigger?.focus({preventScroll:true});});
  dialog.querySelector('.picker-close').addEventListener('click',()=>dialog.close());
  dialog.addEventListener('click',e=>{const day=e.target.closest('[data-date]');if(day)choose(day.dataset.date);const nav=e.target.closest('[data-month]');if(nav){month=firstDay(shiftMonth(month,Number(nav.dataset.month)));focusDay=month;render();}if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();}});
  dialog.querySelector('#picker-today').addEventListener('click',()=>choose(clockParts().date));
  dialog.querySelector('#picker-days').addEventListener('keydown',e=>{
    const button=e.target.closest('[data-date]');if(!button)return;
    const day=button.dataset.date,weekday=(new Date(day+'T12:00:00Z').getUTCDay()+6)%7;
    let next;
    if(e.key==='ArrowLeft')next=dateAdd(day,-1);if(e.key==='ArrowRight')next=dateAdd(day,1);
    if(e.key==='ArrowUp')next=dateAdd(day,-7);if(e.key==='ArrowDown')next=dateAdd(day,7);
    if(e.key==='Home')next=dateAdd(day,-weekday);if(e.key==='End')next=dateAdd(day,6-weekday);
    if(e.key==='PageUp')next=shiftMonth(day,-1);if(e.key==='PageDown')next=shiftMonth(day,1);
    if(next){e.preventDefault();if(disabled(next))next=clockParts().date;focusDay=next;month=firstDay(next);render(true);}
  });
  addEventListener('resize',position);addEventListener('scroll',position,true);
  syncDatePickers();
}
