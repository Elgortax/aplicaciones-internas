export const ZONE = 'America/Santiago';
export function clockParts(date = new Date()) {
  const p=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:ZONE,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(date).map(x=>[x.type,x.value]));
  return {date:`${p.year}-${p.month}-${p.day}`,minutes:Number(p.hour)*60+Number(p.minute)};
}
export function timeLabel(n) {return `${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;}
export function dateAdd(day,n) {const d=new Date(day+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10);}
export function dateLabel(day,options={}) {return new Intl.DateTimeFormat('es-CL',{timeZone:'UTC',...options}).format(new Date(day+'T12:00:00Z'));}
export function durationLabel(n) {return n===30?'30 min':n%60===0?`${n/60} h`:`${Math.floor(n/60)} h 30 min`;}
export const ROOMS = { normal: 'Sala de Reuniones', cocina: 'Sala Cocina' };
export function kitchenBlocked(roomId,start,end) {return roomId==='cocina'&&start<990&&end>780;}
export function overlaps(a,b) {return (a.roomId||'normal')===(b.roomId||'normal') && a.date===b.date && a.start<b.end && a.end>b.start;}
export function validateReservation(candidate, bookings, now=clockParts()) {
  const c=candidate;
  if(!Object.hasOwn(ROOMS,c.roomId||'normal')) return 'Selecciona una sala válida.';
  if(kitchenBlocked(c.roomId,c.start,c.end)) return 'Sala Cocina no permite reservas de 13:00 a 16:30, todos los días.';
  if(!c.userId || !c.title?.trim()) return 'Escribe un nombre para la reunión.';
  if(c.title.trim().length>80) return 'El nombre puede tener hasta 80 caracteres.';
  if(c.participants!=null && (typeof c.participants!=='string'||c.participants.length>200)) return 'Los participantes pueden tener hasta 200 caracteres.';
  if(!/^\d{4}-\d{2}-\d{2}$/.test(c.date)||!Number.isFinite(Date.parse(c.date+'T12:00:00Z'))||new Date(c.date+'T12:00:00Z').toISOString().slice(0,10)!==c.date) return 'Selecciona una fecha válida.';
  if(!Number.isInteger(c.start)||!Number.isInteger(c.end)||c.start<0||c.end>1440||c.start%30!==0||c.end%30!==0||c.end<=c.start) return 'Elige un horario válido en bloques de 30 minutos.';
  if(c.end-c.start>180) return 'Cada reserva puede durar como máximo 3 horas.';
  if(c.date<now.date||(c.date===now.date&&c.start<now.minutes)) return 'Ese horario ya pasó. Elige un horario futuro.';
  if(bookings.some(b=>b.id!==c.id&&overlaps(c,b))) return 'La sala ya está reservada en ese horario. Elige otro bloque.';
  return null;
}
