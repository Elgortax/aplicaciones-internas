const { createHash, randomUUID } = require('node:crypto');
const { ROOMS } = require('./sala-reservas');
const escape = value => String(value || '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function localDateTime(date, minutes) {
  if (minutes === 1440) { const d = new Date(date+'T12:00:00Z'); d.setUTCDate(d.getUTCDate()+1); return d.toISOString().slice(0,10)+'T00:00:00'; }
  return `${date}T${String(Math.floor(minutes/60)).padStart(2,'0')}:${String(minutes%60).padStart(2,'0')}:00`;
}
function eventPayload(booking) {
  if (!booking) return null;
  const recipients = new Map();
  for (const person of booking.invitees || []) recipients.set(person.email.toLowerCase(), person);
  if (booking.ownerEmail) recipients.set(booking.ownerEmail.toLowerCase(), {email:booking.ownerEmail.toLowerCase(),name:booking.ownerName});
  if (!recipients.size) return null;
  return {
    subject: `${booking.title} · ${ROOMS[booking.roomId || 'normal']}`,
    body: { contentType:'HTML', content:`<p><strong>${escape(booking.title)}</strong></p><p>Sala: ${escape(ROOMS[booking.roomId || 'normal'])}<br>Reservado por: ${escape(booking.ownerName)}</p><p>${escape(booking.participants)}</p><p><a href="https://gtdch-cierre-mes.web.app/sala-reuniones/">Abrir agenda de salas</a></p>` },
    start:{dateTime:localDateTime(booking.date,booking.start),timeZone:'Pacific SA Standard Time'},
    end:{dateTime:localDateTime(booking.date,booking.end),timeZone:'Pacific SA Standard Time'},
    location:{displayName:ROOMS[booking.roomId || 'normal']},
    attendees:[...recipients.values()].map(p=>({emailAddress:{address:p.email,name:p.name},type:'required'})),
    responseRequested:true,isReminderOn:true,reminderMinutesBeforeStart:15
  };
}
function createInvitationWorker({db,requestEvent,clock=()=>Date.now()}) {
  return async id => {
    const ref=db.doc(`salaInvitations/${id}`),lease=randomUUID();
    const job=await db.runTransaction(async tx=>{
      const snap=await tx.get(ref),current=snap.data();
      if(!current || ['sent','cancelled','none'].includes(current.status) || current.leaseUntil>clock() || current.retryAt>clock())return null;
      const payload=eventPayload(current.booking);
      // Persist the exact first POST across a timeout and subsequent edits.
      const createPayload=!current.eventId && payload ? (current.createPayload || payload) : current.createPayload || null;
      const createRevision=current.createRevision || current.revision;
      tx.set(ref,{status:'sending',lease,leaseUntil:clock()+120000,createPayload,createRevision},{merge:true});
      return {...current,createPayload,createRevision,payload};
    });
    if(!job)return;
    let eventId=job.eventId||null, generation=job.generation||0;
    try {
      // A previous POST may have succeeded even if its response was lost.
      // Recover its ID before applying a later cancellation.
      if(!eventId && job.createPayload){
        const transactionId=createHash('sha256').update(`${id}:${generation}`).digest('hex');
        const event=await requestEvent('POST',null,{...job.createPayload,transactionId});
        if(!event?.id)throw Error('Microsoft 365 no devolvió el identificador de la invitación.');
        eventId=event.id;
        await ref.set({eventId,createPayload:null,createRevision:null},{merge:true});
        if(job.payload && job.createRevision!==job.revision)await requestEvent('PATCH',eventId,job.payload);
      } else if(eventId && job.payload) {
        await requestEvent('PATCH',eventId,job.payload);
      }
      if(!job.payload && eventId){await requestEvent('DELETE',eventId);eventId=null;generation++;}
      await db.runTransaction(async tx=>{
        const current=(await tx.get(ref)).data();if(!current||current.lease!==lease)return;
        tx.set(ref,{eventId,generation,createPayload:null,createRevision:null,leaseUntil:0,retryAt:0,
          status:current.revision===job.revision?(job.payload?'sent':'cancelled'):'pending',
          sentRevision:job.revision,message:job.payload?'Invitaciones enviadas por Microsoft 365.':'Cancelaciones enviadas.',updatedAt:new Date(clock()).toISOString()},{merge:true});
      });
    }catch(error){
      await db.runTransaction(async tx=>{
        const current=(await tx.get(ref)).data();if(!current||current.lease!==lease)return;
        tx.set(ref,{status:'error',leaseUntil:0,retryAt:clock()+300000,message:'La reserva está guardada. La invitación está pendiente; se reintentará automáticamente.',errorCode:String(error.status||'unavailable'),updatedAt:new Date(clock()).toISOString()},{merge:true});
      });
      console.error('sala-invitation-pending',{id,code:error.status||'unavailable'});
    }
  };
}
module.exports={localDateTime,eventPayload,createInvitationWorker};
