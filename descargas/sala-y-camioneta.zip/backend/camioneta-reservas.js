const {HttpsError}=require('./demo-errors');
const {validateReservation,interval}=require('./camioneta-domain');
const ADMIN_UID='demo-alexis';
const BASE='proyectosData/camioneta-vicaper';
const fail=(code,message)=>{throw new HttpsError(code,message);};
const emailOf=value=>typeof value==='string'&&value.length<=254&&/^[^\s@<>;,]+@[^\s@<>;,]+\.[^\s@<>;,]+$/.test(value.trim())?value.trim().toLowerCase():'';
function createReservationHandler({db,clock=()=>new Date()}){
 return async request=>{
  if(!request.auth||request.auth.token?.firebase?.sign_in_provider==='anonymous')fail('unauthenticated','Inicia sesión en el portal.');
  const {uid}=request.auth,data=request.data||{},{action,id}=data;
  if(!['create','update','cancel'].includes(action)||typeof id!=='string'||!/^[A-Za-z0-9_-]{1,80}$/.test(id))fail('invalid-argument','Operación de reserva inválida.');
  return db.runTransaction(async tx=>{
    const profileSnap=await tx.get(db.doc(`usuarios/${uid}`)),profile=profileSnap.data();
    if(!profileSnap.exists||profile.activo!==true||profile.eliminado===true||profile.radarOnlyTechnical===true)fail('permission-denied','Tu cuenta no tiene acceso a reservas.');
    // Every operation reads and writes this one vehicle lock. Concurrent
    // creates, moves and cancellations retry against a fresh overlap query.
    const lock=db.doc(`${BASE}/meta/lock`);await tx.get(lock);
    const ref=db.doc(`${BASE}/reservas/${id}`),snapshot=await tx.get(ref),previous=snapshot.data();
    const jobRef=db.doc(`camionetaInvitations/${id}`),job=await tx.get(jobRef);
    const admin=uid===ADMIN_UID,now=clock();
    if(action==='create'&&(snapshot.exists||job.exists))fail('already-exists','Esta operación ya se procesó. Actualiza la agenda.');
    if(action!=='create'&&!snapshot.exists)fail('not-found','Esta reserva ya no existe.');
    if(previous&&!admin&&previous.userId!==uid)fail('permission-denied','Solo puedes gestionar tus propias reservas.');
    if(previous&&data.revision!==previous.revision)fail('failed-precondition','La reserva cambió. Actualiza la agenda antes de continuar.');
    if(previous&&!admin&&(action==='cancel'?previous.endAt:previous.startAt)<=now.getTime())fail('failed-precondition','Este viaje ya comenzó o terminó y no admite ese cambio.');
    let booking=null;
    if(action!=='cancel'){
      const candidate={id,startDate:data.startDate,endDate:data.endDate,start:data.start,end:data.end,destination:data.destination,notes:data.notes??''};
      const error=validateReservation(candidate,[],now);if(error)fail('invalid-argument',error);
      const times=interval(candidate);
      const potential=await tx.get(db.collection(`${BASE}/reservas`).where('endAt','>',times.startAt));
      if(potential.docs.some(d=>d.id!==id&&d.data().startAt<times.endAt))fail('already-exists','La camioneta ya está reservada durante parte de ese viaje. Elige otras fechas u horas.');
      const ownerUid=previous?.userId||uid;
      const owner=ownerUid===uid?profile:(await tx.get(db.doc(`usuarios/${ownerUid}`))).data();
      const ownerEmail=emailOf(owner?.email)||emailOf(previous?.ownerEmail)||(ownerUid===uid?emailOf(request.auth.token.email):'');
      if(!ownerEmail)fail('failed-precondition','El responsable necesita un correo válido en el panel para recibir su reserva.');
      booking={...candidate,...times,destination:candidate.destination.trim(),...(previous?.route?{route:previous.route}:{}),notes:candidate.notes.trim(),userId:ownerUid,
        ownerName:previous?.ownerName||String(profile.nombre||request.auth.token.email||'Usuario'),ownerTeam:previous?.ownerTeam||String(profile.area||'Inversiones Vicaper'),ownerEmail,
        revision:(previous?.revision||0)+1,updatedBy:uid,updatedAt:now.toISOString(),createdAt:previous?.createdAt||now.toISOString()};
    }
    tx.set(lock,{updatedAt:now.toISOString(),reservationId:id});
    if(booking)tx.set(ref,booking);else tx.delete(ref);
    tx.set(jobRef,{booking,cancelledBooking:action==='cancel'?previous:null,ownerUid:previous?.userId||uid,revision:(job.data()?.revision||0)+1,status:'pending',updatedAt:now.toISOString()},{merge:true});
    return {ok:true,booking,id};
  });
 };
}
module.exports={ADMIN_UID,BASE,createReservationHandler};
