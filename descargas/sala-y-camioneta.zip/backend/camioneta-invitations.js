const { createHash, randomUUID } = require('node:crypto');
const MANAGER_EMAIL = 'equipo@example.invalid';
const escape = value => String(value || '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function localDateTime(date, minutes) {
  if (minutes === 1440) { const d = new Date(date+'T12:00:00Z'); d.setUTCDate(d.getUTCDate()+1); return d.toISOString().slice(0,10)+'T00:00:00'; }
  return `${date}T${String(Math.floor(minutes/60)).padStart(2,'0')}:${String(minutes%60).padStart(2,'0')}:00`;
}
function bookingDetails(booking) {
 const when=(day,minutes)=>day.split('-').reverse().join('/')+' '+localDateTime(day,minutes).slice(11,16);
 return '<p>Responsable: '+escape(booking.ownerName)+'</p><p>Destino: '+escape(booking.destination)+'</p>'+
  '<p>Retiro: '+escape(when(booking.startDate,booking.start))+'</p><p>Devolución: '+escape(when(booking.endDate,booking.end))+'</p><p>Horarios de Chile.</p>'+
  (booking.notes?'<p>Notas: '+escape(booking.notes).replace(/\n/g,'<br>')+'</p>':'')+
  '<p><a href="https://gtdch-cierre-mes.web.app/camioneta-vicaper/">Abrir agenda de la camioneta</a></p>';
}
function eventPayload(booking) {
 if(!booking?.ownerEmail)return null;
 const ownerEmail=booking.ownerEmail.trim().toLowerCase();
 const attendees=[{emailAddress:{address:ownerEmail,name:booking.ownerName},type:'required'}];
 const heading=booking.revision>1?'Actualizaste tu reserva de camioneta':'Reservaste la camioneta';
 return {subject:heading+' · '+booking.destination,
 body:{contentType:'HTML',content:'<p><strong>'+heading+'</strong></p>'+bookingDetails(booking)},
 start:{dateTime:localDateTime(booking.startDate,booking.start),timeZone:'Pacific SA Standard Time'},
 end:{dateTime:localDateTime(booking.endDate,booking.end),timeZone:'Pacific SA Standard Time'},
 location:{displayName:booking.destination},attendees,responseRequested:false,isReminderOn:true,reminderMinutesBeforeStart:30};
}
function managerMessage(booking,cancelled=false) {
 if(!booking?.ownerEmail||booking.ownerEmail.trim().toLowerCase()===MANAGER_EMAIL)return null;
 const heading=cancelled?'Se canceló la reserva de camioneta de '+booking.ownerName:
  booking.ownerName+(booking.revision>1?' actualizó su reserva de camioneta':' reservó la camioneta');
 return {recipient:{email:MANAGER_EMAIL,name:MANAGER_EMAIL},subject:heading+' · '+booking.destination,
  content:'<p><strong>'+escape(heading)+'</strong></p>'+bookingDetails(booking)};
}
const payloadHash=payload=>createHash('sha256').update(JSON.stringify(payload)).digest('hex');
function createInvitationWorker({db,requestEvent,sendNotice,clock=()=>Date.now()}) {
  return async id => {
    const ref=db.doc(`camionetaInvitations/${id}`),lease=randomUUID();
    const job=await db.runTransaction(async tx=>{
      const snap=await tx.get(ref),current=snap.data();
      if(!current || ['sent','cancelled','none'].includes(current.status) || current.leaseUntil>clock() || current.retryAt>clock())return null;
      const payload=eventPayload(current.booking);
      // Persist the exact first POST across a timeout and subsequent edits.
      const createPayload=!current.eventId && payload ? (current.createPayload || payload) : current.createPayload || null;
      const createRevision=current.createRevision || current.revision;
      tx.set(ref,{status:'sending',lease,leaseUntil:clock()+120000,createPayload,createRevision},{merge:true});
      return {...current,createPayload,createRevision,payload};
    });
    if(!job)return;
    let eventId=job.eventId||null, generation=job.generation||0,eventPayloadHash=job.eventPayloadHash||null;
    try {
      // A previous POST may have succeeded even if its response was lost.
      // Recover its ID before applying a later cancellation.
      if(!eventId && job.createPayload){
        const transactionId=createHash('sha256').update(`camioneta:${id}:${generation}`).digest('hex');
        const event=await requestEvent('POST',null,{...job.createPayload,transactionId});
        if(!event?.id)throw Error('Microsoft 365 no devolvió el identificador de la invitación.');
        eventId=event.id;
        eventPayloadHash=payloadHash(job.createPayload);
        await ref.set({eventId,eventPayloadHash,createPayload:null,createRevision:null},{merge:true});
      }
      if(eventId && job.payload && eventPayloadHash!==payloadHash(job.payload)) {
        await requestEvent('PATCH',eventId,job.payload);
        eventPayloadHash=payloadHash(job.payload);
        await ref.set({eventPayloadHash},{merge:true});
      }
      if(!job.payload && eventId){await requestEvent('DELETE',eventId);eventId=null;eventPayloadHash=null;generation++;
        await ref.set({eventId,eventPayloadHash,generation,createPayload:null,createRevision:null},{merge:true});}
      const notice=managerMessage(job.booking||job.cancelledBooking,!job.booking);
      if(notice)await sendNotice({collection:'camionetaNoticeMailDelivery',
        id:createHash('sha256').update(`${id}:${job.revision}:${MANAGER_EMAIL}`).digest('hex'),
        metadata:{reservationId:id,revision:job.revision,kind:job.booking?'reservation':'cancellation'},...notice});
      await db.runTransaction(async tx=>{
        const current=(await tx.get(ref)).data();if(!current||current.lease!==lease)return;
        tx.set(ref,{eventId,eventPayloadHash,generation,createPayload:null,createRevision:null,leaseUntil:0,retryAt:0,
          status:current.revision===job.revision?(job.payload?'sent':'cancelled'):'pending',
          sentRevision:job.revision,message:job.payload?'Invitaciones enviadas por Microsoft 365.':'Cancelaciones enviadas.',updatedAt:new Date(clock()).toISOString()},{merge:true});
      });
    }catch(error){
      await db.runTransaction(async tx=>{
        const current=(await tx.get(ref)).data();if(!current||current.lease!==lease)return;
        tx.set(ref,{status:'error',leaseUntil:0,retryAt:clock()+300000,message:'La reserva está guardada. La invitación está pendiente; se reintentará automáticamente.',errorCode:String(error.status||'unavailable'),updatedAt:new Date(clock()).toISOString()},{merge:true});
      });
      console.error('camioneta-invitation-pending',{id,code:error.status||'unavailable'});
    }
  };
}
module.exports={localDateTime,eventPayload,managerMessage,createInvitationWorker};
