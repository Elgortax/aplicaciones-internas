const { HttpsError } = require('./demo-errors');

const ADMIN_UID = 'demo-alexis';
const BASE = 'proyectosData/sala-reuniones';
const ROOMS = { normal: 'Sala de Reuniones', cocina: 'Sala Cocina' };
const emailOf = value => typeof value === 'string' && value.length <= 254 && /^[^\s@<>;,]+@[^\s@<>;,]+\.[^\s@<>;,]+$/.test(value.trim()) ? value.trim().toLowerCase() : '';
const fail = (code, message) => { throw new HttpsError(code, message); };
function nowInChile(date = new Date()) {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Santiago', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(date).map(x => [x.type, x.value]));
  return { date: `${p.year}-${p.month}-${p.day}`, minutes: Number(p.hour) * 60 + Number(p.minute) };
}
function validate(candidate, bookings, now) {
  if (typeof candidate.title !== 'string' || !candidate.title.trim() || candidate.title.trim().length > 80) fail('invalid-argument', 'Escribe un nombre de reunión de hasta 80 caracteres.');
  if (typeof candidate.participants !== 'string' || candidate.participants.length > 200) fail('invalid-argument', 'Los participantes pueden tener hasta 200 caracteres.');
  const { date, start, end } = candidate;
  const roomId = candidate.roomId || 'normal';
  if (!Object.hasOwn(ROOMS, roomId)) fail('invalid-argument', 'Selecciona una sala válida.');
  if (typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !Number.isFinite(Date.parse(date + 'T12:00:00Z')) || new Date(date + 'T12:00:00Z').toISOString().slice(0, 10) !== date) fail('invalid-argument', 'Selecciona una fecha válida.');
  if (!Number.isInteger(start) || !Number.isInteger(end) || start < 0 || end > 1440 || start % 30 || end % 30 || end <= start || end - start > 180) fail('invalid-argument', 'Reserva entre 30 minutos y 3 horas, en bloques de 30 minutos.');
  if (date < now.date || (date === now.date && start < now.minutes)) fail('failed-precondition', 'Ese horario ya pasó. Elige un horario futuro.');
  if (roomId === 'cocina' && start < 990 && end > 780) fail('failed-precondition', 'Sala Cocina no permite reservas entre las 13:00 y las 16:30, todos los días.');
  if (bookings.some(b => (b.roomId || 'normal') === roomId && b.id !== candidate.id && b.start < end && b.end > start)) fail('already-exists', 'La sala ya está reservada en ese horario. Elige otro bloque.');
}

async function resolveInvitees(input, tx, db) {
  if (!Array.isArray(input) || input.length > 30) fail('invalid-argument', 'Puedes invitar hasta 30 personas.');
  const result = new Map();
  for (const item of input) {
    if (!item || typeof item !== 'object') fail('invalid-argument', 'Invitado inválido.');
    let person;
    if (item.uid) {
      if (typeof item.uid !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/.test(item.uid)) fail('invalid-argument', 'Persona inválida.');
      const snap = await tx.get(db.doc(`usuarios/${item.uid}`));
      const profile = snap.data();
      if (!snap.exists || profile.activo !== true || profile.eliminado === true || !emailOf(profile.email)) fail('failed-precondition', 'Una persona invitada ya no tiene una cuenta activa con correo. Actualiza la lista.');
      person = { uid: item.uid, email: emailOf(profile.email), name: String(profile.nombre || profile.email).slice(0, 120) };
    } else {
      const email = emailOf(item.email);
      if (!email) fail('invalid-argument', 'Escribe un correo válido para cada invitado externo.');
      person = { email, name: email };
    }
    result.set(person.email, person);
  }
  return [...result.values()];
}

function createDirectoryHandler({ db }) {
  return async request => {
    if (!request.auth || request.auth.token?.firebase?.sign_in_provider === 'anonymous') fail('unauthenticated', 'Inicia sesión en el portal.');
    const actor = (await db.doc(`usuarios/${request.auth.uid}`).get()).data();
    if (actor?.activo !== true || actor.eliminado === true || actor.radarOnlyTechnical === true) fail('permission-denied', 'Tu cuenta no tiene acceso.');
    const users = await db.collection('usuarios').where('activo', '==', true).get();
    return { people: users.docs.filter(d => d.data().eliminado !== true && emailOf(d.data().email)).map(d => ({ uid: d.id, name: String(d.data().nombre || d.data().email), email: emailOf(d.data().email) })).sort((a,b) => a.name.localeCompare(b.name, 'es')) };
  };
}

function createReservationHandler({ db, clock = () => new Date() }) {
  return async request => {
    if (!request.auth || request.auth.token?.firebase?.sign_in_provider === 'anonymous') fail('unauthenticated', 'Inicia sesión en el portal.');
    const { uid } = request.auth;
    const data = request.data || {};
    const { action, id } = data;
    if (!['create', 'update', 'cancel'].includes(action) || typeof id !== 'string' || !/^[A-Za-z0-9_-]{1,80}$/.test(id)) fail('invalid-argument', 'Operación de reserva inválida.');
    // Read identity, existing reservation and both affected days in the same
    // transaction. The day documents serialize all overlapping room bookings.
    return db.runTransaction(async tx => {
      const profileSnap = await tx.get(db.doc(`usuarios/${uid}`));
      const profile = profileSnap.data();
      if (!profileSnap.exists || profile.activo !== true || profile.eliminado === true || profile.radarOnlyTechnical === true) fail('permission-denied', 'Tu cuenta no tiene acceso a reservas.');
      const admin = uid === ADMIN_UID;
      const ref = db.doc(`${BASE}/reservas/${id}`);
      const snapshot = await tx.get(ref);
      const previous = snapshot.data();
      if (action === 'create' && snapshot.exists) fail('already-exists', 'Esta reserva ya se guardó. Actualiza la agenda.');
      if (action !== 'create' && !snapshot.exists) fail('not-found', 'Esta reserva ya no existe.');
      if (previous && !admin && previous.userId !== uid) fail('permission-denied', 'Solo puedes gestionar tus propias reservas.');
      if (previous && data.revision !== previous.revision) fail('failed-precondition', 'La reserva cambió. Actualiza la agenda antes de continuar.');
      const now = nowInChile(clock());
      if (previous && !admin) {
        const cutoff = action === 'cancel' ? previous.end : previous.start;
        if (previous.date < now.date || (previous.date === now.date && cutoff <= now.minutes)) fail('failed-precondition', 'Esta reserva ya comenzó o terminó y no admite ese cambio.');
      }
      let booking = null;
      if (action !== 'cancel') {
        const invitees = data.invitees === undefined ? (previous?.invitees || []) : await resolveInvitees(data.invitees, tx, db);
        const ownerUid = previous?.userId || uid;
        const ownerProfile = ownerUid === uid ? profile : (await tx.get(db.doc(`usuarios/${ownerUid}`))).data();
        // Always notify the actual reservation owner, including edits by Alexis.
        // Client-supplied email and the editing administrator are not the owner.
        const ownerEmail = emailOf(ownerProfile?.email) || emailOf(previous?.ownerEmail)
          || (ownerUid === uid ? emailOf(request.auth.token.email) : '');
        if (!ownerEmail) fail('failed-precondition', 'El creador de la reserva necesita un correo válido en el panel para recibir su invitación.');
        booking = { id, title: data.title, participants: data.participants ?? '', date: data.date, start: data.start, end: data.end,
          ownerEmail,
          roomId: data.roomId ?? previous?.roomId ?? 'normal', invitees,
          userId: previous?.userId || uid,
          ownerName: previous?.ownerName || String(profile.nombre || request.auth.token.email || 'Usuario'),
          ownerTeam: previous?.ownerTeam || String(profile.area || 'Inversiones Vicaper'),
          revision: (previous?.revision || 0) + 1,
          updatedBy: uid, updatedAt: clock().toISOString(), createdAt: previous?.createdAt || clock().toISOString() };
        validate(booking, [], now);
      }
      // Durable desired calendar state, committed atomically with the booking.
      // A separate worker sends invitations and cancellations after commit.
      const jobRef = db.doc(`salaInvitations/${id}`);
      const jobSnap = await tx.get(jobRef);
      const dates = [...new Set([previous?.date, booking?.date].filter(Boolean))].sort();
      const days = [];
      for (const date of dates) {
        const dayRef = db.doc(`${BASE}/dias/${date}`);
        const day = await tx.get(dayRef);
        days.push({ date, ref: dayRef, bookings: day.data()?.bookings || [] });
      }
      if (booking) {
        validate(booking, days.find(d => d.date === booking.date).bookings, now);
        booking.title = booking.title.trim();
        booking.participants = booking.participants.trim();
      }
      for (const day of days) {
        const bookings = day.bookings.filter(b => b.id !== id);
        if (booking?.date === day.date) bookings.push(booking);
        tx.set(day.ref, { date: day.date, bookings, updatedAt: clock().toISOString() });
      }
      if (booking) tx.set(ref, booking); else tx.delete(ref);
      if (booking?.ownerEmail || booking?.invitees?.length || jobSnap.exists) {
        tx.set(jobRef, { booking, ownerUid: previous?.userId || uid, revision: (jobSnap.data()?.revision || 0) + 1,
          status: 'pending', updatedAt: clock().toISOString() }, { merge: true });
      }
      return { ok: true, booking, id };
    });
  };
}
module.exports = { ADMIN_UID, BASE, ROOMS, emailOf, nowInChile, validate, resolveInvitees, createDirectoryHandler, createReservationHandler };
