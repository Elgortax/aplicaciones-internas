param([switch]$SinNavegador)
$ErrorActionPreference = 'Stop'
try {
  $demoNode = (Get-Command node -ErrorAction SilentlyContinue).Source
  if (-not $demoNode) { $demoNode = 'C:\Program Files\nodejs\node.exe' }
  if (-not (Test-Path -LiteralPath $demoNode)) { throw 'Esta demo necesita Node.js 20.11 o posterior. No se necesita instalar paquetes adicionales.' }
  $demoScript = Join-Path $PSScriptRoot 'servidor.mjs'
  $demoLog = Join-Path $PSScriptRoot ('datos\inicio-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.log')
  $demoArguments = @(('"' + $demoScript + '"'))
  if (-not $SinNavegador) { $demoArguments += '--open' }
  Start-Process -FilePath $demoNode -ArgumentList $demoArguments -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -RedirectStandardOutput $demoLog -RedirectStandardError ($demoLog + '.errores')
} catch {
  Add-Type -AssemblyName PresentationFramework
  [System.Windows.MessageBox]::Show($_.Exception.Message, 'Demo Vicaper') | Out-Null
}
