import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {spawn} from 'node:child_process';
const require=createRequire(import.meta.url),root=import.meta.dirname,publicRoot=path.join(root,'public');
const sala=require('./backend/sala-reservas'),truck=require('./backend/camioneta-reservas');
const roomMail=require('./backend/sala-invitations'),truckMail=require('./backend/camioneta-invitations');
const domain=require('./backend/camioneta-domain');
const people=[{uid:'demo-carolina',name:'Carolina Pérez',email:'carolina@example.com',team:'Operaciones',admin:false},{uid:'demo-martin',name:'Martín Soto',email:'martin@example.com',team:'Proyectos',admin:false},{uid:'demo-sofia',name:'Sofía Rojas',email:'sofia@example.com',team:'Comercial',admin:false},{uid:'demo-alexis',name:'Alexis Rodríguez · Demo',email:'alexis@example.com',team:'Administración',admin:true}];
const dataFile=path.join(root,'datos','demo.json'),clients=new Set();
let rows=new Map(),mails=[],queue=Promise.resolve();
function persist(){fs.writeFileSync(dataFile+'.tmp',JSON.stringify({version:1,rows:[...rows],mails},null,2));for(let attempt=0;;attempt++){try{fs.renameSync(dataFile+'.tmp',dataFile);break;}catch(error){if(!['EPERM','EBUSY','EACCES'].includes(error.code)||attempt>=9)throw error;Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,40);}}}
function seed(){
 rows=new Map();mails=[];
 for(const p of people)rows.set('usuarios/'+p.uid,{activo:true,nombre:p.name,email:p.email,area:p.team});
 const now=domain.clockParts(),today=now.date,next=domain.dateAdd(today,1);
 const identity=uid=>{const p=people.find(p=>p.uid===uid);return {userId:uid,ownerName:p.name,ownerEmail:p.email,ownerTeam:p.team,revision:1,createdAt:new Date().toISOString()};};
 const roomBookings=[
  {id:'demo-reunion-hoy',roomId:'normal',title:'Coordinación de la semana',date:today,start:Math.min(1110,Math.max(570,Math.floor(now.minutes/30)*30)),userId:'demo-carolina'},
  {id:'demo-proyectos',roomId:'normal',title:'Revisión de proyectos',date:next,start:600,userId:'demo-martin'},
  {id:'demo-mi-reunion',roomId:'normal',title:'Planificación del equipo',date:next,start:900,userId:'demo-carolina'},
  {id:'demo-cocina',roomId:'cocina',title:'Encuentro de operaciones',date:today,start:1020,userId:'demo-sofia'},
  {id:'demo-cocina-manana',roomId:'cocina',title:'Café de coordinación',date:next,start:600,userId:'demo-carolina'}
 ].map(b=>({...b,end:b.start+60,participants:'Ejemplo de demostración',invitees:[],...identity(b.userId)}));
 for(const b of roomBookings){rows.set(sala.BASE+'/reservas/'+b.id,b);const key=sala.BASE+'/dias/'+b.date,day=rows.get(key)||{bookings:[]};day.bookings.push(b);rows.set(key,day);}
 const trips=[{id:'demo-viaje-actual',destination:'Visita de obra · Rancagua',startDate:today,start:540,endDate:next,end:1080,userId:'demo-martin'},{id:'demo-mi-viaje',destination:'Reunión de coordinación · Talca',startDate:domain.dateAdd(today,3),start:540,endDate:domain.dateAdd(today,5),end:1080,userId:'demo-carolina'}];
 for(const t of trips){const b={...t,...identity(t.userId),...domain.interval(t),notes:'Viaje ficticio para conocer la agenda.'};rows.set(truck.BASE+'/reservas/'+b.id,b);}
 persist();
}
if(fs.existsSync(dataFile)){const saved=JSON.parse(fs.readFileSync(dataFile,'utf8'));rows=new Map(saved.rows);mails=saved.mails||[];}else seed();
const clone=v=>v===undefined?undefined:structuredClone(v);
const snapshot=(key,source=rows)=>({id:key.split('/').at(-1),exists:source.has(key),data:()=>clone(source.get(key))});
function queryDocs(ref,source=rows){const docs=[...source].filter(([key,value])=>key.startsWith(ref.path+'/')&&!key.slice(ref.path.length+1).includes('/')&&ref.filters.every(([field,op,wanted])=>op==='=='?value[field]===wanted:op==='>'?value[field]>wanted:false)).map(([key])=>snapshot(key,source));return {docs,forEach:fn=>docs.forEach(fn)};}
const db={doc:key=>({path:key,get:async()=>snapshot(key)}),collection:key=>{
 const make=filters=>({path:key,filters,query:true,where:(...filter)=>make([...filters,filter]),get:async()=>queryDocs({path:key,filters}),doc:id=>db.doc(key+'/'+id)});return make([]);
},runTransaction:fn=>{
 const run=queue.then(async()=>{const draft=new Map([...rows].map(([k,v])=>[k,clone(v)]));
  const result=await fn({get:async ref=>ref.query?queryDocs(ref,draft):snapshot(ref.path,draft),set:(ref,value,options)=>draft.set(ref.path,clone(options?.merge?{...draft.get(ref.path),...value}:value)),delete:ref=>draft.delete(ref.path)});
  rows=draft;persist();return result;});queue=run.catch(()=>{});return run;
}};
const manage={sala:sala.createReservationHandler({db}),camioneta:truck.createReservationHandler({db})};
const directory=sala.createDirectoryHandler({db});
function userFor(req){const match=(req.headers.cookie||'').match(/(?:^|;\s*)demo_user=([^;]+)/);return people.find(p=>p.uid===match?.[1])||people[0];}
function bookings(kind){return [...rows].filter(([k])=>k.startsWith((kind==='sala'?sala.BASE:truck.BASE)+'/reservas/')).map(([,v])=>v);}
function state(){return {rooms:bookings('sala'),trips:bookings('camioneta'),invitations:{sala:[...rows].filter(([k])=>k.startsWith('salaInvitations/')).map(([k,v])=>[k.split('/').at(-1),{status:v.status}]),camioneta:[...rows].filter(([k])=>k.startsWith('camionetaInvitations/')).map(([k,v])=>[k.split('/').at(-1),{status:v.status}])},mailCount:mails.length};}
function broadcast(event='state'){for(const res of clients)res.write(`event: ${event}\ndata: ${JSON.stringify(event==='state'?state():{})}\n\n`);}
function simulate(kind,action,id,previous){
 const key=(kind==='sala'?'salaInvitations/':'camionetaInvitations/')+id,job=rows.get(key);if(!job)return;
 const booking=job.booking||previous;if(!booking)return;
 const payload=kind==='sala'?roomMail.eventPayload(booking):truckMail.eventPayload(booking);
 const add=(to,subject,html)=>mails.unshift({id:crypto.randomUUID(),kind,action,to,subject,html:html.replaceAll('https://gtdch-cierre-mes.web.app',''),createdAt:new Date().toISOString(),reservationId:id});
 if(payload)for(const person of payload.attendees||[])add(person.emailAddress.address,action==='cancel'?'Reserva cancelada · '+(booking.title||booking.destination):payload.subject,action==='cancel'?'<p><strong>Esta reserva fue cancelada en la demo.</strong></p>'+payload.body.content:payload.body.content);
 if(kind==='camioneta'){const notice=truckMail.managerMessage(booking,action==='cancel');if(notice)add(notice.recipient.email,notice.subject,notice.content);}
 rows.set(key,{...job,status:action==='cancel'?'cancelled':'sent',transport:'simulated'});persist();broadcast();
}
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.svg':'image/svg+xml','.woff2':'font/woff2'};
const json=(res,value,status=200)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(value));};
async function body(req){let value='';for await(const chunk of req){value+=chunk;if(value.length>50000)throw Error('Solicitud demasiado grande.');}return JSON.parse(value||'{}');}
const server=http.createServer(async(req,res)=>{
 res.setHeader('X-Demo-App','vicaper-agendas-local');res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');
 res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; object-src 'none'; frame-src 'none'; base-uri 'self'; frame-ancestors 'self'");
 try{
  const url=new URL(req.url,'http://127.0.0.1');
  if(req.method==='POST'&&req.headers.origin!==`http://${req.headers.host}`)return json(res,{error:'Abre la demo desde su enlace local.'},403);
  if(url.pathname==='/api/profile'&&req.method==='GET')return json(res,{user:userFor(req),people});
  if(url.pathname==='/api/profile'&&req.method==='POST'){const input=await body(req);if(!people.some(p=>p.uid===input.uid))throw Error('Perfil no válido.');res.setHeader('Set-Cookie',`demo_user=${input.uid}; Path=/; HttpOnly; SameSite=Strict`);json(res,{ok:true});broadcast('reload');return;}
  if(url.pathname==='/api/state')return json(res,state());
  if(url.pathname==='/api/people')return json(res,await directory({auth:{uid:userFor(req).uid,token:{}}}));
  if(url.pathname==='/api/mails')return json(res,mails);
  if(url.pathname==='/api/events'){
   res.writeHead(200,{'Content-Type':'text/event-stream','Connection':'keep-alive'});res.write(`event: state\ndata: ${JSON.stringify(state())}\n\n`);clients.add(res);
   const timer=setInterval(()=>res.write(': keepalive\n\n'),20000);req.on('close',()=>{clearInterval(timer);clients.delete(res);});return;
  }
  if(url.pathname==='/api/reset'&&req.method==='POST'){await queue;seed();json(res,{ok:true});broadcast('reload');return;}
  if(url.pathname==='/api/stop'&&req.method==='POST'){json(res,{ok:true});for(const client of clients)client.end();setTimeout(()=>process.exit(0),100);return;}
  const reserve=url.pathname.match(/^\/api\/(sala|camioneta)\/reservation$/);
  if(reserve&&req.method==='POST'){
   const kind=reserve[1],input=await body(req),user=userFor(req);const previous=clone(rows.get((kind==='sala'?sala.BASE:truck.BASE)+'/reservas/'+input.id));
   const result=await manage[kind]({auth:{uid:user.uid,token:{email:user.email,firebase:{sign_in_provider:'password'}}},data:input});simulate(kind,input.action,input.id,previous);return json(res,result);
  }
  if(url.pathname.startsWith('/api/'))return json(res,{error:'No encontrado'},404);
  const relative=decodeURIComponent(url.pathname.endsWith('/')?url.pathname+'index.html':url.pathname),file=path.resolve(publicRoot,'.'+relative);
  if(!file.startsWith(publicRoot+path.sep)||!types[path.extname(file)]||!fs.existsSync(file))return json(res,{error:'No encontrado'},404);
  res.writeHead(200,{'Content-Type':types[path.extname(file)]});fs.createReadStream(file).pipe(res);
 }catch(error){json(res,{error:error.message,code:error.code||'invalid-argument'},400);}
});
const open=url=>{if(process.argv.includes('--open'))spawn('cmd.exe',['/c','start','',url],{windowsHide:true,stdio:'ignore'});};
let port=Number(process.env.DEMO_PORT||4186);
server.on('error',async error=>{if(error.code!=='EADDRINUSE')throw error;try{const response=await fetch(`http://127.0.0.1:${port}/api/profile`);if(response.headers.get('X-Demo-App')==='vicaper-agendas-local'){open(`http://127.0.0.1:${port}/`);process.exit(0);}}catch{}if(++port>4206)throw Error('No hay un puerto local disponible.');server.listen(port,'127.0.0.1');});
server.listen(port,'127.0.0.1',()=>{const url=`http://127.0.0.1:${server.address().port}/`;console.log('Demo local: '+url);open(url);});
