import { PDFDocument, StandardFonts, rgb } from './pdf-lib-1.17.1.js';

const PAGE = [595.28, 841.89];
const MARGIN = 36;
const WIDTH = PAGE[0] - MARGIN * 2;
const BOTTOM = PAGE[1] - 48;
const INK = rgb(.08, .15, .26);
const MUTED = rgb(.29, .36, .47);
const BLUE = rgb(.12, .33, .73);
const RED = rgb(.74, .22, .29);
const LINE = rgb(.84, .88, .93);
const PALE = rgb(.94, .96, .99);
const ALT = rgb(.975, .983, .994);
const NUMBER = new Intl.NumberFormat('es-CL', { maximumFractionDigits: 1 });
const MONTH = new Intl.DateTimeFormat('es-CL', { month: 'long', year: 'numeric', timeZone: 'UTC' });
const fmt = value => NUMBER.format(value);
const percent = (value, total) => total ? fmt(value * 100 / total) + ' %' : '-';

export async function buildMetricsPdf(report) {
  const doc = await PDFDocument.create();
  const regular = await doc.embedFont(StandardFonts.Helvetica);
  const bold = await doc.embedFont(StandardFonts.HelveticaBold);
  const supported = new Set(regular.getCharacterSet());
  const month = MONTH.format(new Date(report.period.first));
  const cutoff = report.period.cutoff.split('-').reverse().join('/');
  const { total, pending } = report;
  doc.setTitle('Gestión mensual de tareas - ' + month);
  doc.setAuthor('VICAPER');
  doc.setSubject('Indicadores, atrasos y detalle de gestión del período');
  let page, y;

  function safe(value) {
    return [...String(value ?? '').normalize('NFC').replace(/[‐‑‒–—−]/gu, '-')
      .replace(/[\r\t]/g, ' ').replace(/\p{Extended_Pictographic}|[\u200d\ufe0f]/gu, '')]
      .map(ch => ch === '\n' || supported.has(ch.codePointAt(0)) ? ch : '?').join('');
  }

  function text(value, x, top, size = 9, font = regular, color = INK, align = 'left') {
    const label = safe(value).replace(/\n/g, ' ');
    const offset = align === 'right' ? font.widthOfTextAtSize(label, size) : 0;
    page.drawText(label, { x: x - offset, y: PAGE[1] - top - size, size, font, color });
  }

  function rect(x, top, width, height, color) {
    page.drawRectangle({ x, y: PAGE[1] - top - height, width, height, color });
  }

  function wrap(value, width, size = 9, font = regular) {
    const lines = [];
    const fits = str => font.widthOfTextAtSize(str, size) <= width;
    for (const paragraph of safe(value).split('\n')) {
      let line = '';
      for (let word of paragraph.trim().split(/\s+/)) {
        if (line && !fits(line + ' ' + word)) { lines.push(line); line = ''; }
        while (word && !fits(word)) {
          let length = 1;
          while (length < word.length && fits(word.slice(0, length + 1))) length++;
          lines.push(word.slice(0, length));
          word = word.slice(length);
        }
        if (word) line += (line ? ' ' : '') + word;
      }
      if (line || !paragraph.trim()) lines.push(line);
    }
    return lines;
  }

  function newPage() {
    page = doc.addPage(PAGE);
    rect(MARGIN, 27, 26, 3, BLUE);
    text('VICAPER  /  GESTIÓN DE TAREAS', MARGIN, 37, 9, bold, BLUE);
    text(month.toUpperCase(), PAGE[0] - MARGIN, 37, 9, bold, MUTED, 'right');
    rect(MARGIN, 55, WIDTH, .7, LINE);
    y = 70;
  }

  function ensure(height) { if (y + height > BOTTOM) newPage(); }

  function paragraph(value, size = 9, color = MUTED) {
    const step = size + 4;
    for (const line of wrap(value, WIDTH, size)) {
      ensure(step);
      text(line, MARGIN, y, size, regular, color);
      y += step;
    }
    y += 5;
  }

  function section(title, subtitle = '') {
    ensure(subtitle ? 54 : 44);
    text(title, MARGIN, y, 14, bold);
    y += 20;
    if (subtitle) paragraph(subtitle);
  }

  function table(title, columns, rows, subtitle = '') {
    if (!rows.length) {
      section(title, subtitle);
      paragraph('Sin registros para este período y estos filtros.');
      y += 9;
      return;
    }
    const size = 8.5;
    const step = 12;
    const widths = columns.map(c => c[1] * WIDTH / 100);
    const padding = 4;
    const measure = (values, font) => columns.map((_, i) => wrap(values[i], widths[i] - padding * 2, size, font));
    const headers = measure(columns.map(c => c[0]), bold);
    const height = lines => Math.max(1, ...lines.map(col => col.length)) * step + 10;
    const firstRow = measure(rows[0], regular);
    const intro = 20 + (subtitle ? wrap(subtitle, WIDTH).length * 13 + 5 : 0);
    const fullHeight = rows.length <= 6 ? rows.reduce((sum, row) => sum + height(measure(row, regular)), 0) : Infinity;
    const bodyPreview = fullHeight <= 235 ? fullHeight : Math.min(height(firstRow), 94);
    ensure(intro + height(headers) + bodyPreview);
    section(title, subtitle);
    function cells(lines, font, color, background) {
      const h = height(lines);
      if (background) rect(MARGIN, y, WIDTH, h, background);
      let x = MARGIN;
      for (let i = 0; i < columns.length; i++) {
        const right = columns[i][2] === 'right';
        for (let line = 0; line < lines[i].length; line++) {
          text(lines[i][line], x + (right ? widths[i] - padding : padding), y + 5 + line * step, size, font, color, right ? 'right' : 'left');
        }
        x += widths[i];
      }
      rect(MARGIN, y + h - .5, WIDTH, .5, LINE);
      y += h;
    }
    function continuation() { newPage(); section(title + ' (continuación)'); cells(headers, bold, BLUE, PALE); }
    if (y + height(headers) + step + 10 > BOTTOM) continuation();
    else cells(headers, bold, BLUE, PALE);
    rows.forEach((row, index) => {
      let lines = measure(row, regular);
      if (y + height(lines) > BOTTOM) continuation();
      while (y + height(lines) > BOTTOM) {
        const capacity = Math.floor((BOTTOM - y - 10) / step);
        cells(lines.map(col => col.slice(0, capacity)), regular, INK, index % 2 ? ALT : null);
        lines = lines.map(col => col.slice(capacity));
        continuation();
      }
      cells(lines, regular, INK, index % 2 ? ALT : null);
    });
    y += 17;
  }

  function backlogChart() {
    ensure(60 + report.trend.length * 24 + 12);
    section('Evolución de los pendientes', 'Al corte de los últimos seis meses. La línea roja indica cuántas de las pendientes estaban vencidas.');
    const width = 315;
    const max = Math.max(1, ...report.trend.map(item => item.open));
    for (const item of report.trend) {
      text(item.label, MARGIN, y, 9, item.month === report.period.month ? bold : regular);
      rect(MARGIN + 67, y + 1, width, 11, PALE);
      if (item.open) rect(MARGIN + 67, y + 1, width * item.open / max, 5, BLUE);
      if (item.overdue) rect(MARGIN + 67, y + 8, width * item.overdue / max, 3, RED);
      text(`${item.open} pendientes / ${item.overdue} vencidas`, MARGIN + WIDTH, y, 9, regular, INK, 'right');
      y += 24;
    }
    y += 8;
  }

  const r = 'right';
  newPage();
  text('Informe mensual de tareas', MARGIN, y, 25, bold);
  y += 34;
  paragraph(`Período: ${month}  |  Corte: ${cutoff}`, 11, INK);
  for (const [label, names] of report.filters) paragraph(`${label}: ${names.length ? names.join(', ') : 'Sin filtro'}`);
  y += 4;
  const cards = [
    ['Tasa de cierre', percent(total.closed, total.total)], ['Gestionadas', total.total],
    ['Cerradas', total.closed], ['Pendientes al corte', total.open], ['Cierres a tiempo', percent(total.onTime, total.timed)]
  ];
  ensure(61);
  const cardWidth = (WIDTH - 24) / 5;
  cards.forEach(([label, value], i) => {
    const x = MARGIN + i * (cardWidth + 6);
    rect(x, y, cardWidth, 49, PALE);
    text(label, x + 6, y + 6, 8.5, bold, MUTED);
    text(value, x + 6, y + 21, 16, bold, BLUE);
  });
  y += 57;
  paragraph(`${total.carry} pendientes iniciales, ${total.added} nuevas y ${total.reopened} reactivadas. De las ${total.open} pendientes al corte, ${total.overdue} estaban vencidas.`);
  if (total.unknown) paragraph(`${total.unknown} tareas quedaron fuera de los indicadores por historial insuficiente.`);
  y += 5;
  backlogChart();
  table('Entradas y cierres', [['Mes',17],['Nuevas y reactivadas',26,r],['Cerradas',16,r],['Pendientes',19,r],['Tasa de cierre',22,r]],
    report.trend.map(item => [item.label,item.entries,item.closed,item.open,percent(item.closed,item.workload)]));
  table('Pendientes por vencimiento', [['Tramo al corte',73],['Tareas',27,r]], [
    ['En plazo',pending.onTrack],['1 a 7 días',pending.firstWeek],['8 a 30 días',pending.firstMonth],
    ['31 días o más',pending.older],['Sin compromiso',pending.noDue]
  ]);
  table('Puntualidad de los cierres', [['Situación al cierre',52],['Tareas',20,r],['Del total cerrado',28,r]], [
    ['A tiempo',total.onTime],['Fuera de plazo',total.timed-total.onTime],['Sin compromiso',total.closed-total.timed]
  ].map(([label, value]) => [label,value,percent(value,total.closed)]));
  table('Radar de atrasos por área', [['Área',43],['Pendientes',18,r],['Vencidas',17,r],['% de vencidas',22,r]],
    report.radar.map(area => [area.area,area.pending,area.tasks.length,percent(area.tasks.length,area.pending)]));
  table('Responsables con más vencidas', [['Responsable',53],['Vencidas',19,r],['Mayor atraso (días)',28,r]],
    report.overduePeople.slice(0,8).map(({label,stats}) => [label,stats.overdue,stats.maxLate]));
  table('Tiempo de cierre por área', [['Área',53],['Mediana (días)',25,r],['Cierres',22,r]],
    report.areaTimes.slice(0,8).map(({label,value,count}) => [label,fmt(value),count]),
    'Días corridos entre creación y cierre, para tareas cerradas en el período.');
  table('Detalle por responsable', [['Responsable',26],['Inicio',7,r],['Nuevas',8,r],['Reab.',6,r],['Gest.',6,r],
    ['Cerr.',6,r],['Pend.',6,r],['Venc.',6,r],['% cierre',10,r],['% a tiempo',11,r],['Sin hist.',8,r]],
    report.personRows.map(({label,stats:s}) => [label,s.carry,s.added,s.reopened,s.total,s.closed,s.open,s.overdue,
      percent(s.closed,s.total),percent(s.onTime,s.timed),s.unknown]),
    'Inicio = pendientes al comienzo del mes. Reab. = reactivadas. Las tareas compartidas figuran para cada responsable y una sola vez en el total general.');
  if (report.dependencies === null) {
    section('Vencidas con subtareas pendientes');
    paragraph('El detalle se muestra para el mes actual. La bitácora disponible no permite reconstruir todas las dependencias de meses anteriores.');
  } else {
    const share = total.overdue ? `${report.dependencies.length} de ${total.overdue} vencidas con subtareas pendientes (${percent(report.dependencies.length,total.overdue)}).` :
      'Sin tareas vencidas al corte.';
    table('Vencidas con subtareas pendientes', [['Tarea principal / responsable',38],['Subtarea / responsable',39],['Compromiso / estado',23]],
      report.dependencies.flatMap(task => task.subtasks.map(sub => [
        task.title + '\n' + task.owners, sub.title + '\n' + sub.owner, [sub.due,sub.status].filter(Boolean).join('\n')
      ])), share);
  }
  table('Tareas estancadas', [['Tarea / responsable',51],['Área',18],['Prioridad',10],['Días',7,r],['Última actividad',14,r]],
    report.stalled.map(task => [task.title+'\n'+task.owners,task.area,task.priority,task.days,task.last]),
    `Pendientes con ${report.threshold} días o más sin actividad relevante, según el filtro seleccionado.`);
  table('Detalle de atrasos por área', [['Área',20],['Tarea / responsable',63],['Días de atraso',17,r]],
    report.radar.flatMap(area => area.tasks.map(task => [area.area,task.title+'\n'+task.owners,task.daysLate])));
  paragraph('El histórico usa la bitácora disponible y los responsables y compromisos que figuran actualmente en las tareas.');

  const pages = doc.getPages();
  for (let i = 0; i < pages.length; i++) {
    page = pages[i];
    rect(MARGIN, PAGE[1] - 39, WIDTH, .7, LINE);
    text('Tareas VICAPER  |  Corte ' + cutoff, MARGIN, PAGE[1] - 29, 8, regular, MUTED);
    text(`Página ${i + 1} de ${pages.length}`, PAGE[0] - MARGIN, PAGE[1] - 29, 8, regular, MUTED, 'right');
  }
  return doc.save();
}

export async function downloadPdf(report) {
  const bytes = await buildMetricsPdf(report);
  const url = URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = `vicaper-metricas-${report.period.month}.pdf`;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}
