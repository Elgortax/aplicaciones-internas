const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');

const port = 4175;
const root = __dirname;
const files = new Set([
  'index.html', 'guia.html', 'favicon.svg', 'modern.css', 'responsive.css',
  'demo-theme.css', 'demo-runtime.js', 'monthly-management.js',
  'management-pdf.js', 'pdf-lib-1.17.1.js', 'enhancements.js', 'responsive.js'
]);
const types = { '.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript', '.svg': 'image/svg+xml' };
const server = http.createServer((request, response) => {
  const pathname = new URL(request.url, 'http://127.0.0.1').pathname;
  const filename = pathname === '/' ? 'index.html' : decodeURIComponent(pathname.slice(1));
  if (!files.has(filename)) { response.writeHead(404); response.end('No encontrado'); return; }
  fs.readFile(path.join(root, filename), (error, data) => {
    if (error) { response.writeHead(404); response.end('No encontrado'); return; }
    response.writeHead(200, {
      'Content-Type': `${types[path.extname(filename)] || 'application/octet-stream'}; charset=utf-8`,
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      'Content-Security-Policy': "default-src 'self' data: blob:; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self' data: blob:; object-src 'none'; base-uri 'self'"
    });
    response.end(data);
  });
});

server.on('error', error => {
  console.error(error.code === 'EADDRINUSE'
    ? 'La demo ya está abierta o el puerto 4175 está en uso. Revisa http://127.0.0.1:4175/'
    : `No se pudo iniciar la demo: ${error.message}`);
  process.exitCode = 1;
});
server.listen(port, '127.0.0.1', () => {
  const url = `http://127.0.0.1:${port}/`;
  console.log(`Tareas Vicaper Demo: ${url}`);
  console.log('Deja esta ventana abierta mientras usas la demo. Ciérrala para detenerla.');
  if (process.env.VICAPER_DEMO_NO_BROWSER !== '1') {
    const browser = spawn('rundll32.exe', ['url.dll,FileProtocolHandler', url], { detached: true, stdio: 'ignore', windowsHide: true });
    browser.on('error', () => console.log(`Abre manualmente ${url}`));
    browser.unref();
  }
});
