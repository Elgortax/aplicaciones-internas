(function () {
  'use strict';
  window.VICAPER_DEMO = true;
  window.VICAPER_ACCESS = {
    projectId: 'tareas-vicaper',
    user: { uid: 'local-preview', email: 'p_fcastro@demo.local' },
    profile: { nombre: 'Alba Demo', email: 'p_fcastro@demo.local', rol: 'admin', activo: true, proyectos: { 'tareas-vicaper': 'admin' } },
    role: 'admin', readOnly: false, canEdit: true, canCollaborate: false
  };
  window.VICAPER_OUTLOOK_STATUS = { available: true, status: 'demo' };

  const DB_NAME = 'tareas-vicaper-demo-files-v1';
  const STORE = 'files';
  let database;
  function openDatabase() {
    if (database) return database;
    database = new Promise((resolve, reject) => {
      if (!window.indexedDB) return reject(new Error('Este navegador no permite guardar archivos locales.'));
      const request = indexedDB.open(DB_NAME, 1);
      request.onupgradeneeded = () => request.result.createObjectStore(STORE);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(new Error('No se pudo abrir el almacenamiento local de archivos.'));
    });
    return database;
  }
  async function fileOperation(mode, action) {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE, mode);
      const request = action(transaction.objectStore(STORE));
      let result;
      request.onsuccess = () => { result = request.result; };
      transaction.oncomplete = () => resolve(result);
      transaction.onerror = () => reject(new Error('No se pudo guardar o leer el archivo de la demo.'));
      transaction.onabort = () => reject(new Error('No se pudo completar el archivo de la demo.'));
    });
  }
  async function storeFile(path, file) {
    await fileOperation('readwrite', store => store.put(file, path));
    return path;
  }
  async function getFile(path) {
    const blob = await fileOperation('readonly', store => store.get(path));
    if (!blob) throw new Error('El archivo ya no está en este navegador.');
    return blob;
  }
  function downloadBlob(blob, name) {
    const url = URL.createObjectURL(blob), link = document.createElement('a');
    link.href = url;
    link.download = name || 'archivo';
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 3000);
  }

  window.VICAPER_ATTACHMENTS = {
    async upload(file, attachmentId) {
      const storagePath = await storeFile(`task/${attachmentId}`, file);
      return { storagePath, dataUrl: '' };
    },
    async download(path, name) { downloadBlob(await getFile(path), name); }
  };
  window.VICAPER_CHAT_ATTACHMENTS = {
    async upload(file, ids) {
      const storagePath = await storeFile(`chat/${ids.groupId}/${ids.messageId}/${ids.attachmentId}`, file);
      return { storagePath, dataUrl: '', ownerUid: 'local-preview' };
    },
    async objectUrl(_messageId, attachment) { return URL.createObjectURL(await getFile(attachment.storagePath)); },
    async download(_messageId, attachment) { downloadBlob(await getFile(attachment.storagePath), attachment.name); },
    async remove(path) { if (path) await fileOperation('readwrite', store => store.delete(path)); }
  };
  window.VICAPER_PERSON_ACCESS = {
    async ensure(person) { window.dispatchEvent(new CustomEvent('vicaper-person-access-result', { detail: { type: 'single', status: 'preview', person } })); return { preview: true }; },
    async remove() { return { preview: true }; },
    async syncAll() { window.dispatchEvent(new CustomEvent('vicaper-person-access-result', { detail: { type: 'batch', status: 'done', created: 0, linked: 0, existing: 0, errors: 0 } })); },
    async changePassword() { throw new Error('La demo no crea ni cambia contraseñas reales.'); }
  };

  const notify = message => { if (typeof window.toast === 'function') window.toast(message); };
  window.addEventListener('vicaper-tasks-ready', () => {
    const status = document.getElementById('vicaper-sync-status');
    if (status) { status.dataset.tone = 'synced'; status.querySelector('.sync-label').textContent = 'Demo local · guardado aquí'; }
    window.dispatchEvent(new CustomEvent('vicaper-access-ready', { detail: window.VICAPER_ACCESS }));
    window.dispatchEvent(new CustomEvent('vicaper-chat-attachments-ready'));
  });
  window.addEventListener('vicaper-task-assignment-changed', () => notify('Demo: asignación guardada. No se envió correo.'));
  window.addEventListener('vicaper-task-notify-request', () => notify('Demo: aviso de tarea simulado. No se envió correo.'));
  window.addEventListener('vicaper-task-opened', event => {
    window.VICAPER_OUTLOOK_STATUS = { taskId: String(event.detail?.taskId || ''), available: true, status: 'demo', message: 'Simulación local: no se envían invitaciones.' };
    window.dispatchEvent(new CustomEvent('vicaper-outlook-status', { detail: window.VICAPER_OUTLOOK_STATUS }));
  });
  window.addEventListener('vicaper-person-account-request', () => notify('Demo: persona guardada solo en este navegador.'));
  window.addEventListener('vicaper-person-delete-request', () => notify('Demo: persona eliminada solo de la muestra.'));
})();
