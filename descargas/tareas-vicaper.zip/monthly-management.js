(() => {
  'use strict';

  const DONE = 'Completada';
  const OPEN = new Set(['Por hacer', 'En progreso', 'En revisión', 'Bloqueada']);
  const DAY_MS = 86400000;
  const CL_DATE = new Intl.DateTimeFormat('sv-SE', {
    timeZone: 'America/Santiago', year: 'numeric', month: '2-digit', day: '2-digit'
  });
  const NUMBER = new Intl.NumberFormat('es-CL', { maximumFractionDigits: 1 });
  const MONTH = new Intl.DateTimeFormat('es-CL', { month: 'short', year: '2-digit', timeZone: 'UTC' });
  const PRIORITY = { Alta: 0, Media: 1, Baja: 2 };

  function dateKey(value) {
    if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value)) {
      const parsed = new Date(value);
      return Number.isFinite(+parsed) && parsed.toISOString().startsWith(value) ? value : '';
    }
    if (!(value instanceof Date) && (typeof value !== 'string' || !value.includes('T'))) return '';
    const parsed = new Date(value);
    return Number.isFinite(+parsed) ? CL_DATE.format(parsed) : '';
  }

  function periodFor(month, now) {
    const today = dateKey(now);
    const activeMonth = today.slice(0, 7);
    const first = dateKey(month + '-01');
    if (!first || month > activeMonth) month = activeMonth;
    const [year, number] = month.split('-').map(Number);
    const last = new Date(Date.UTC(year, number, 0)).toISOString().slice(0, 10);
    return { month, first: month + '-01', cutoff: month === activeMonth ? today : last, activeMonth };
  }

  function taskHistory(task, created) {
    const entries = (task.log || []).flatMap(entry => {
      if (entry?.to !== DONE && !OPEN.has(entry?.to)) return [];
      const day = dateKey(entry.ts);
      if (!day || day < created) return [];
      return [{ day, time: Date.parse(entry.ts), closed: entry.to === DONE }];
    }).sort((a, b) => a.time - b.time);

    const currentlyClosed = task.status === DONE;
    const last = entries.at(-1);
    const explicitDay = dateKey(task.completedAt);
    if (currentlyClosed && !last?.closed && explicitDay && explicitDay >= created &&
        (!last || Date.parse(task.completedAt) >= last.time)) {
      entries.push({ day: explicitDay, closed: true });
    }
    if (Boolean(entries.at(-1)?.closed) !== currentlyClosed) return null;
    return entries;
  }

  function classify(task, period) {
    const created = dateKey(task.createdAt);
    if (!created) return 'unknown';
    if (created > period.cutoff) return null;
    const history = taskHistory(task, created);
    if (!history) return 'unknown';

    const newTask = created >= period.first;
    let closed = false;
    let lastClose = '';
    let reactivated = false;
    let pendingAtStart = !newTask;
    for (const event of history) {
      if (event.day > period.cutoff) break;
      if (event.day < period.first) {
        closed = event.closed;
        lastClose = closed ? event.day : '';
        pendingAtStart = !closed;
        continue;
      }
      if (event.closed === closed) continue;
      if (closed && !event.closed && !newTask && !pendingAtStart) reactivated = true;
      closed = event.closed;
      lastClose = closed ? event.day : '';
    }
    const source = newTask ? 'added' : pendingAtStart ? 'carry' : reactivated ? 'reopened' : '';
    if (!source) return null;

    const due = dateKey(task.due);
    const daysLate = due ? (Date.parse(period.cutoff) - Date.parse(due)) / DAY_MS : null;
    return {
      source, closed,
      daysLate,
      daysToClose: closed ? (Date.parse(lastClose) - Date.parse(created)) / DAY_MS : null,
      overdue: !closed && daysLate > 0,
      timed: closed && Boolean(due),
      onTime: closed && Boolean(due && lastClose <= due)
    };
  }

  function tally() {
    return { carry: 0, added: 0, reopened: 0, total: 0, closed: 0, open: 0, overdue: 0, timed: 0, onTime: 0, unknown: 0 };
  }

  function count(target, result) {
    if (result === 'unknown') {
      target.unknown++;
      return;
    }
    target.total++;
    target[result.source]++;
    target[result.closed ? 'closed' : 'open']++;
    target.overdue += Number(result.overdue);
    target.timed += Number(result.timed);
    target.onTime += Number(result.onTime);
  }

  function pendingByArea(tasks, period) {
    const areas = new Map();
    const open = [];
    for (const task of tasks) {
      const result = classify(task, period);
      if (!result || result === 'unknown' || result.closed) continue;
      const areaId = task.areaId || task.teamId || null;
      if (!areas.has(areaId)) areas.set(areaId, { total: 0, late: [] });
      const area = areas.get(areaId);
      const item = { task, daysLate: result.daysLate };
      open.push(item);
      area.total++;
      if (result.overdue) area.late.push(item);
    }
    return { areas, open };
  }

  function inactivityAt(task, cutoff, isMeaningfulLog) {
    const created = dateKey(task.createdAt);
    const logDays = (task.log || []).filter(isMeaningfulLog).map(entry => dateKey(entry.ts));
    const last = [created, dateKey(task.updatedAt), ...logDays]
      .filter(day => day && day >= created && day <= cutoff)
      .sort().at(-1);
    return last ? { last, days: (Date.parse(cutoff) - Date.parse(last)) / DAY_MS } : null;
  }

  function stalledTasks(open, cutoff, threshold, isMeaningfulLog) {
    return open.flatMap(item => {
      const activity = inactivityAt(item.task, cutoff, isMeaningfulLog);
      return activity && activity.days >= threshold ? [{ ...item, ...activity }] : [];
    }).sort((a, b) => (PRIORITY[a.task.priority] ?? 3) - (PRIORITY[b.task.priority] ?? 3) ||
      b.days - a.days || String(a.task.title || '').localeCompare(String(b.task.title || ''), 'es'));
  }

  function pendingDependencies(task, cutoff) {
    return (task.subtasks || []).filter(item => !item.done).map(item => {
      const due = dateKey(item.due);
      const daysLate = due ? (Date.parse(cutoff) - Date.parse(due)) / DAY_MS : null;
      return { item, due, daysLate };
    }).sort((a, b) => (b.daysLate ?? -Infinity) - (a.daysLate ?? -Infinity));
  }

  function tasksWithPendingDependencies(open, cutoff) {
    return open.filter(item => item.daysLate > 0)
      .map(item => ({ ...item, dependencies: pendingDependencies(item.task, cutoff) }))
      .filter(item => item.dependencies.length).sort((a, b) => b.daysLate - a.daysLate);
  }

  function summarize(tasks, month, now = new Date(), selectedPeople = []) {
    const period = periodFor(month, now);
    const total = tally();
    const people = new Map();
    const areas = new Map();
    const pending = { onTrack: 0, firstWeek: 0, firstMonth: 0, older: 0, noDue: 0 };
    const selected = new Set(selectedPeople);
    for (const task of tasks) {
      const result = classify(task, period);
      if (!result) continue;
      count(total, result);
      if (result !== 'unknown' && !result.closed) {
        const { daysLate } = result;
        const bucket = daysLate === null ? 'noDue' : daysLate <= 0 ? 'onTrack' :
          daysLate <= 7 ? 'firstWeek' : daysLate <= 30 ? 'firstMonth' : 'older';
        pending[bucket]++;
      }
      if (result !== 'unknown' && result.closed) {
        const areaId = task.areaId || task.teamId || null;
        if (!areas.has(areaId)) areas.set(areaId, []);
        areas.get(areaId).push(result.daysToClose);
      }
      const assignees = [...new Set((task.assignees || []).filter(Boolean))];
      const ids = assignees.length ? assignees : [null];
      for (const id of ids) {
        if (selected.size && !selected.has(id)) continue;
        if (!people.has(id)) people.set(id, { ...tally(), maxLate: 0 });
        const stats = people.get(id);
        count(stats, result);
        if (result.overdue) stats.maxLate = Math.max(stats.maxLate, result.daysLate);
      }
    }
    return { period, total, people, pending, areas };
  }

  function percent(numerator, denominator) {
    return denominator ? NUMBER.format(numerator * 100 / denominator) + ' %' : '—';
  }

  function shortDay(day) {
    return day.split('-').reverse().join('/');
  }

  function historyByMonth(tasks, current, now) {
    const end = new Date(current.period.first);
    return Array.from({ length: 6 }, (_, index) => {
      const monthStart = new Date(end);
      monthStart.setUTCMonth(monthStart.getUTCMonth() + index - 5);
      const month = monthStart.toISOString().slice(0, 7);
      const report = index === 5 ? current : summarize(tasks, month, now);
      return {
        month,
        label: MONTH.format(monthStart),
        entries: report.total.added + report.total.reopened,
        closed: report.total.closed,
        open: report.total.open,
        overdue: report.total.overdue,
        workload: report.total.total
      };
    });
  }

  function chartBar(value, max, color, seriesLabel = '') {
    const width = max ? 100 * value / max : 0;
    return `<span class="management-chart-bar">
      <span class="management-chart-track ${color}" aria-hidden="true"><i class="management-chart-fill" style="--width:${width}%"></i></span>
      <span class="management-chart-value"${seriesLabel ? ` aria-label="${seriesLabel} ${value}"` : ''}>${value}</span>
    </span>`;
  }

  function renderTrend(node, data, selected) {
    const max = Math.max(...data.flatMap(item => [item.entries, item.closed]));
    const legend = '<div class="management-series"><span><i class="management-key management-in"></i>Nuevas y reactivadas</span><span><i class="management-key management-good"></i>Cerradas</span></div>';
    const months = data.map(item => {
      const rate = percent(item.closed, item.workload);
      return `<li class="management-chart-row management-month-row"${item.month === selected ? ' aria-current="true"' : ''}>
        <span>${item.label}</span>
        <div class="management-chart-bars">${chartBar(item.entries, max, 'management-in', 'Entradas')}${chartBar(item.closed, max, 'management-good', 'Cerradas')}</div>
        <span class="management-rate" title="Tasa de cierre" aria-label="Tasa de cierre ${rate}">${rate}</span>
      </li>`;
    }).join('');
    node.innerHTML = legend + '<ul class="management-chart-list">' + months + '</ul>';
  }

  function renderPendingTrend(node, data, selected) {
    const max = Math.max(...data.map(item => item.open));
    const rows = data.map(item => `<li class="management-chart-row management-month-row"${item.month === selected ? ' aria-current="true"' : ''}>
      <span>${item.label}</span>
      <div class="management-chart-bars">${chartBar(item.open, max, 'management-in', 'Pendientes')}${chartBar(item.overdue, max, 'management-late', 'Vencidas')}</div>
      <span class="management-rate" title="Porcentaje de pendientes vencidas">${percent(item.overdue, item.open)}</span>
    </li>`).join('');
    node.innerHTML = '<div class="management-series"><span><i class="management-key management-in"></i>Pendientes al corte</span><span><i class="management-key management-late"></i>De ellas, vencidas</span></div>' +
      '<ul class="management-chart-list">' + rows + '</ul>';
  }

  function taskLine(task, labelForPerson, escape, detail) {
    const title = escape(task.title || 'Tarea sin título');
    const code = task.code ? escape(task.code) + ' · ' : '';
    const names = (task.assignees || []).map(labelForPerson).filter(Boolean).join(', ') || 'Sin responsable';
    return `<div class="management-task-line">
      <div><button type="button" class="management-task-link" data-management-task="${escape(String(task.id))}">${code}${title}</button>
        <small>${escape(names)}</small></div>
      <small>${escape(detail)}</small>
    </div>`;
  }

  function renderRadar(node, areas, labelForArea, labelForPerson, escape) {
    const expanded = new Set([...node.querySelectorAll('details[open]')].map(el => el.dataset.managementExpand));
    const rows = [...areas].map(([id, area]) => ({ key: id === null ? 'sin-area' : 'area-' + id, label: id ? labelForArea(id) : 'Sin área', ...area }))
      .sort((a, b) => b.late.length - a.late.length || b.late.length / b.total - a.late.length / a.total ||
        a.label.localeCompare(b.label, 'es'));
    node.innerHTML = rows.length ? rows.map(({ key, label, total, late }) => {
      const heading = `<span>${escape(label)}</span><strong>${late.length} de ${total} · ${percent(late.length, total)}</strong>
        <span class="management-chart-track management-radar-track management-late" aria-hidden="true"><i class="management-chart-fill" style="--width:${100*late.length/total}%"></i></span>`;
      if (!late.length) return `<div class="management-area-summary">${heading}</div>`;
      const details = [...late].sort((a,b) => b.daysLate - a.daysLate).map(({ task, daysLate }) =>
        taskLine(task, labelForPerson, escape, `${daysLate} días de atraso`)).join('');
      return `<details class="management-area-detail" data-management-expand="${escape(key)}"${expanded.has(key) ? ' open' : ''}><summary class="management-area-summary">${heading}</summary><div class="management-task-list">${details}</div></details>`;
    }).join('') : '<p class="management-chart-empty">Sin tareas pendientes al corte.</p>';
  }

  function dependencyShareMessage(count, overdue) {
    const share = overdue ?
      `<strong>${count} de ${overdue}</strong> ${overdue === 1 ? 'vencida' : 'vencidas'} ${count === 1 ? 'tenía' : 'tenían'} subtareas pendientes <strong>(${percent(count, overdue)})</strong>` :
      'Sin tareas vencidas al corte';
    return `<p class="management-dependency-message">${share}</p>`;
  }

  function renderDependencies(node, open, period, overdue, labelForPerson, escape) {
    const expanded = new Set([...node.querySelectorAll('details[open]')].map(el => el.dataset.managementExpand));
    if (period.month !== period.activeMonth) {
      node.innerHTML = '<p class="management-chart-empty">El detalle de subtareas está disponible para el mes actual. La bitácora anterior no permite reconstruir todas las dependencias al corte.</p>';
      return;
    }
    const parents = tasksWithPendingDependencies(open, period.cutoff);
    const shareMessage = dependencyShareMessage(parents.length, overdue);
    if (!parents.length) {
      node.innerHTML = '<p class="management-chart-empty">No hay tareas vencidas con subtareas pendientes.</p>' + shareMessage;
      return;
    }
    node.innerHTML = `<p class="management-action-count">${parents.length} ${parents.length === 1 ? 'tarea principal vencida' : 'tareas principales vencidas'} con subtareas pendientes</p>` + shareMessage +
      parents.map(({ task, daysLate, dependencies }) => {
        const subtasks = dependencies.map(({ item, due, daysLate: subLate }) => {
          const status = subLate === null ? 'Sin fecha' : subLate > 0 ? `Vencida hace ${subLate} d` : 'En plazo';
          const owner = item.assignee ? labelForPerson(item.assignee) : 'Sin responsable';
          return `<li><div><b>${escape(item.text || 'Subtarea')}</b><small>${escape(owner)}</small></div>
            <small>${due ? shortDay(due) + ' · ' : ''}${status}</small></li>`;
        }).join('');
        const id = String(task.id);
        return `<details class="management-area-detail" data-management-expand="${escape(id)}"${expanded.has(id) ? ' open' : ''}>
          <summary class="management-area-summary"><span>${escape(task.title || 'Tarea sin título')}</span><strong>${dependencies.length} pend.</strong></summary>
          ${taskLine(task, labelForPerson, escape, `${daysLate} días de atraso`)}
          <ul class="management-dependency-list">${subtasks}</ul>
        </details>`;
      }).join('');
  }

  function renderStalled(node, open, period, threshold, isMeaningfulLog, labelForPerson, escape) {
    const stalled = stalledTasks(open, period.cutoff, threshold, isMeaningfulLog);
    node.innerHTML = stalled.length ? `<p class="management-action-count">${stalled.length} ${stalled.length === 1 ? 'tarea sin movimiento' : 'tareas sin movimiento'}</p><div class="management-task-list">` +
      stalled.map(({ task, last, days }) => taskLine(task, labelForPerson, escape,
        `${task.priority || 'Sin prioridad'} · ${days} d sin movimiento · ${shortDay(last)}`)).join('') + '</div>' :
      '<p class="management-chart-empty">No hay tareas pendientes con ese tiempo sin movimiento.</p>';
  }

  function renderBreakdown(node, rows, emptyText) {
    const total = rows.reduce((sum, [, value]) => sum + value, 0);
    node.innerHTML = total ? '<ul class="management-chart-list">' + rows.map(([label, value, color]) =>
      `<li class="management-chart-row"><span>${label}</span>${chartBar(value, total, color)}</li>`
    ).join('') + '</ul>' : `<p class="management-chart-empty">${emptyText}</p>`;
  }

  function renderDonut(node, rows, centerLabel, emptyText) {
    const total = rows.reduce((sum, row) => sum + row.value, 0);
    if (!total) {
      node.innerHTML = `<p class="management-chart-empty">${emptyText}</p>`;
      return;
    }
    let cursor = 0;
    const stops = rows.filter(row => row.value).map(row => {
      const start = cursor;
      cursor += row.value;
      return `var(--${row.color}) ${100 * start / total}% ${100 * cursor / total}%`;
    }).join(', ');
    const legend = rows.map(({ label, value, color }) =>
      `<li><i style="--series:var(--${color})" class="management-key" aria-hidden="true"></i>
        <span>${label}</span><strong>${NUMBER.format(value)}</strong><small>${percent(value, total)}</small></li>`
    ).join('');
    node.innerHTML = `<div class="management-donut-layout">
      <div class="management-donut" style="--segments:${stops}" aria-hidden="true">
        <div class="management-donut-hole"><strong>${NUMBER.format(total)}</strong><span>${centerLabel}</span></div>
      </div>
      <ul class="management-donut-legend">${legend}</ul>
    </div>`;
  }

  function rankOverdue(people) {
    return people.filter(({ id, stats }) => id !== null && stats.overdue)
      .sort((a, b) => b.stats.overdue - a.stats.overdue || b.stats.maxLate - a.stats.maxLate ||
        a.label.localeCompare(b.label, 'es'));
  }

  function rankAreas(areas, labelForArea) {
    return [...areas].map(([id, days]) => {
      const sorted = [...days].sort((a, b) => a - b);
      const midpoint = (sorted.length - 1) / 2;
      const value = (sorted[Math.floor(midpoint)] + sorted[Math.ceil(midpoint)]) / 2;
      return { label: id ? labelForArea(id) : 'Sin área', value, count: sorted.length };
    }).sort((a, b) => b.value - a.value || b.count - a.count || a.label.localeCompare(b.label, 'es'));
  }

  function renderRanking(node, rows, color, unit, emptyText, escape) {
    if (!rows.length) {
      node.innerHTML = `<p class="management-chart-empty">${emptyText}</p>`;
      return;
    }
    const limit = 8;
    const visible = rows.slice(0, limit);
    const max = visible[0].value;
    const items = visible.map(({ label, value, detail }) => `<li class="management-rank-row">
      <div class="management-rank-label"><span>${escape(label)}</span><strong>${NUMBER.format(value)} ${unit}</strong></div>
      <div class="management-rank-meta"><span class="management-chart-track ${color}" aria-hidden="true">
        <i class="management-chart-fill" style="--width:${max ? 100 * value / max : 0}%"></i></span><small>${detail}</small></div>
    </li>`).join('');
    const summary = rows.length > limit ? `<p class="management-notes">Mostrando ${limit} de ${rows.length}.</p>` : '';
    node.innerHTML = `<ol class="management-chart-list management-ranking">${items}</ol>${summary}`;
  }

  function reportPeople(people, labelForPerson) {
    return Array.from(people, ([id, stats]) => ({
      id, label: id ? labelForPerson(id) : 'Sin responsable', stats
    })).sort((a, b) => Number(a.id === null) - Number(b.id === null) ||
      b.stats.total - a.stats.total || a.label.localeCompare(b.label, 'es'));
  }

  function pdfReportData({ tasks, month, selectedPeople, threshold, filters, labelForPerson, labelForArea, isMeaningfulLog, now = new Date() }) {
    const scoped = summarize(tasks, month, now, selectedPeople);
    const { period, total, pending, areas, people } = scoped;
    const actionable = pendingByArea(tasks, period);
    const personRows = reportPeople(people, labelForPerson);
    const areaLabel = id => id ? labelForArea(id) : 'Sin área';
    const taskInfo = task => ({
      title: [task.code, task.title || 'Tarea sin título'].filter(Boolean).join(' - '),
      owners: (task.assignees || []).map(labelForPerson).filter(Boolean).join(', ') || 'Sin responsable',
      area: areaLabel(task.areaId || task.teamId),
      priority: task.priority || 'Sin prioridad'
    });
    const radar = [...actionable.areas].map(([id, group]) => ({
      area: areaLabel(id), pending: group.total,
      tasks: group.late.map(({ task, daysLate }) => ({ ...taskInfo(task), daysLate }))
        .sort((a, b) => b.daysLate - a.daysLate)
    })).sort((a, b) => b.tasks.length - a.tasks.length || a.area.localeCompare(b.area, 'es'));
    const dependencies = period.month === period.activeMonth ?
      tasksWithPendingDependencies(actionable.open, period.cutoff).map(({ task, daysLate, dependencies }) => ({
        ...taskInfo(task), daysLate,
        subtasks: dependencies.map(({ item, due, daysLate: late }) => ({
          title: item.text || 'Subtarea', owner: item.assignee ? labelForPerson(item.assignee) : 'Sin responsable',
          due: due ? shortDay(due) : '', status: late === null ? 'Sin fecha' : late > 0 ? `Vencida hace ${late} d` : 'En plazo'
        }))
      })) : null;
    const stalled = stalledTasks(actionable.open, period.cutoff, threshold, isMeaningfulLog)
      .map(({ task, last, days }) => ({ ...taskInfo(task), days, last: shortDay(last) }));
    return { period, filters, threshold, total, pending, personRows, radar, dependencies, stalled,
      trend: historyByMonth(tasks, scoped, now), areaTimes: rankAreas(areas, labelForArea), overduePeople: rankOverdue(personRows) };
  }

  function render(section, tasks, selectedPeople, labelForPerson, labelForArea, escape, isMeaningfulLog) {
    const input = section.querySelector('input[type=month]');
    const now = new Date();
    const report = summarize(tasks, input.value, now, selectedPeople);
    const { period, total, people, pending, areas } = report;
    input.max = period.activeMonth;
    input.value = period.month;
    const dateLabel = new Intl.DateTimeFormat('es-CL', {
      dateStyle: 'long', timeZone: 'UTC'
    }).format(new Date(period.cutoff));
    section.querySelector('[data-management-cutoff]').textContent = 'Al ' + dateLabel;

    const metrics = [
      ['Tasa de cierre', percent(total.closed, total.total), `${total.closed} de ${total.total} gestionadas`],
      ['Gestionadas', total.total, `${total.carry} iniciales · ${total.added} nuevas · ${total.reopened} reactivadas`],
      ['Cerradas', total.closed, 'Cerradas durante el período'],
      ['Pendientes al corte', total.open, `${total.overdue} vencidas`],
      ['Cierres a tiempo', percent(total.onTime, total.timed), `${total.onTime} de ${total.timed} con compromiso`]
    ];
    section.querySelector('[data-management-metrics]').innerHTML = metrics.map(([label, value, detail]) =>
      `<div class="management-metric"><span>${label}</span><strong>${value}</strong><small>${detail}</small></div>`
    ).join('');

    const history = historyByMonth(tasks, report, now);
    renderTrend(section.querySelector('[data-management-trend]'), history, period.month);
    renderPendingTrend(section.querySelector('[data-management-pending-trend]'), history, period.month);
    const actionable = pendingByArea(tasks, period);
    renderRadar(section.querySelector('[data-management-radar]'), actionable.areas, labelForArea, labelForPerson, escape);
    renderDependencies(section.querySelector('[data-management-dependencies]'), actionable.open, period, total.overdue, labelForPerson, escape);
    const threshold = Number(section.querySelector('#managementStalledDays').value);
    renderStalled(section.querySelector('[data-management-stalled]'), actionable.open, period, threshold, isMeaningfulLog, labelForPerson, escape);
    renderBreakdown(section.querySelector('[data-management-pending]'), [
      ['En plazo', pending.onTrack, 'management-in'],
      ['1–7 días', pending.firstWeek, 'management-soon'],
      ['8–30 días', pending.firstMonth, 'management-mid'],
      ['31 días o más', pending.older, 'management-late'],
      ['Sin compromiso', pending.noDue, 'management-neutral']
    ], 'No hay tareas pendientes al corte.');
    renderDonut(section.querySelector('[data-management-workload]'), [
      { label: 'Cerradas', value: total.closed, color: 'metric-good' },
      { label: 'Pendientes en plazo', value: pending.onTrack, color: 'metric-in' },
      { label: 'Pendientes vencidas', value: total.overdue, color: 'metric-late' },
      { label: 'Pendientes sin fecha', value: pending.noDue, color: 'metric-neutral' }
    ], 'gestionadas', 'No hay tareas gestionadas en este período.');
    renderDonut(section.querySelector('[data-management-timing]'), [
      { label: 'A tiempo', value: total.onTime, color: 'metric-good' },
      { label: 'Fuera de plazo', value: total.timed - total.onTime, color: 'metric-late' },
      { label: 'Sin compromiso', value: total.closed - total.timed, color: 'metric-neutral' }
    ], 'cerradas', 'No hay cierres registrados para el período.');

    const rows = reportPeople(people, labelForPerson);

    const overdue = rankOverdue(rows).map(({ label, stats }) => ({
      label, value: stats.overdue, detail: `Mayor atraso: ${NUMBER.format(stats.maxLate)} d`
    }));
    renderRanking(section.querySelector('[data-management-overdue-ranking]'), overdue, 'management-late',
      'venc.', 'No hay tareas vencidas asignadas al corte.', escape);
    const unassigned = people.get(null)?.overdue || 0;
    const unassignedNote = section.querySelector('[data-management-unassigned]');
    unassignedNote.hidden = !unassigned;
    unassignedNote.textContent = unassigned ? `Vencidas sin responsable: ${NUMBER.format(unassigned)}.` : '';

    const areaTimes = rankAreas(areas, labelForArea).map(({ label, value, count }) => ({
      label, value, detail: count === 1 ? '1 cierre' : `${NUMBER.format(count)} cierres`
    }));
    renderRanking(section.querySelector('[data-management-area-times]'), areaTimes, 'management-in',
      'd', 'No hay cierres con fechas para comparar las áreas.', escape);

    const body = section.querySelector('tbody');
    body.innerHTML = rows.length ? rows.map(({ label, stats: s }) =>
      `<tr><th scope="row">${escape(label)}</th><td>${s.carry}</td><td>${s.added}</td><td>${s.reopened}</td><td>${s.total}</td><td>${s.closed}</td><td>${s.open}</td><td>${s.overdue}</td><td><strong>${percent(s.closed, s.total)}</strong></td><td>${percent(s.onTime, s.timed)} <small>(${s.onTime}/${s.timed})</small></td><td>${s.unknown}</td></tr>`
    ).join('') : '<tr><td colspan="11" class="management-empty">Sin tareas para este período y estos filtros.</td></tr>';

    const notice = section.querySelector('[data-management-notice]');
    notice.hidden = !total.unknown;
    notice.textContent = total.unknown ?
      `${total.unknown} ${total.unknown === 1 ? 'tarea quedó fuera' : 'tareas quedaron fuera'} de los indicadores por falta de fechas o historial de estado.` : '';
  }

  window.VICAPER_MONTHLY_MANAGEMENT = { summarize, historyByMonth, rankOverdue, rankAreas,
    pendingByArea, stalledTasks, pendingDependencies, pdfReportData, render };
})();
