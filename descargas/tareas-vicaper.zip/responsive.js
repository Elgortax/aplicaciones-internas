(function(){
  'use strict';
  const body=document.body;
  const filterToggle=document.getElementById('mobileFilterToggle');
  const filterCount=document.getElementById('mobileFilterCount');
  let viewportFrame=0,filterFrame=0;
  let restingHeight=window.innerHeight,restingWidth=window.innerWidth;

  // The visual viewport shrinks when the phone keyboard or browser bars open.
  // Keep the chat composer and modal actions inside the visible screen.
  function updateViewport(){
    viewportFrame=0;
    const viewport=window.visualViewport;
    const height=viewport?.height||window.innerHeight;
    body.style.setProperty('--mobile-viewport-height',height+'px');
    body.style.setProperty('--mobile-viewport-top',(viewport?.offsetTop||0)+'px');
    body.style.setProperty('--mobile-header-height',document.querySelector('.topbar').getBoundingClientRect().height+'px');
    const editing=document.activeElement?.matches('input:not([type="checkbox"]):not([type="radio"]),textarea,[contenteditable="true"]');
    if(!editing||Math.abs(window.innerWidth-restingWidth)>80){restingHeight=window.innerHeight;restingWidth=window.innerWidth;}
    body.classList.toggle('mobile-keyboard-open',Boolean(editing&&Math.max(restingHeight,window.innerHeight)-height>120));
  }
  function queueViewport(){if(!viewportFrame)viewportFrame=requestAnimationFrame(updateViewport);}
  window.addEventListener('resize',queueViewport);
  window.visualViewport?.addEventListener('resize',queueViewport);
  window.visualViewport?.addEventListener('scroll',queueViewport);
  document.addEventListener('focusin',queueViewport);
  document.addEventListener('focusout',queueViewport);
  new ResizeObserver(queueViewport).observe(document.querySelector('.topbar'));

  function updateFilters(){
    filterFrame=0;
    const count=activeFilterChips().length;
    const label=count?`${count} activo${count===1?'':'s'}`:'';
    if(filterCount.textContent!==label)filterCount.textContent=label;
  }
  function queueFilters(){if(!filterFrame)filterFrame=requestAnimationFrame(updateFilters);}
  filterToggle.addEventListener('click',()=>{
    const open=body.classList.toggle('mobile-filters-open');
    filterToggle.setAttribute('aria-expanded',String(open));
    if(!open)document.querySelectorAll('.msel.open').forEach(el=>{el.classList.remove('open');el.querySelector('.msel-btn')?.setAttribute('aria-expanded','false');});
    queueFilters();
  });
  document.getElementById('filters').addEventListener('input',queueFilters);
  document.getElementById('filters').addEventListener('change',queueFilters);
  document.addEventListener('click',queueFilters);

  document.getElementById('sidebar').addEventListener('click',event=>{
    if(event.target.closest('#btnConfig'))closeMobileMenu();
  });
  document.addEventListener('keydown',event=>{
    if(!body.classList.contains('mobile-nav-open'))return;
    if(event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();closeMobileMenu(true);return;}
    if(event.key!=='Tab')return;
    const controls=[...document.querySelectorAll('#sidebar button,#sidebar a[href]')].filter(el=>!el.disabled&&el.getClientRects().length);
    const first=controls[0],last=controls[controls.length-1];
    if(event.shiftKey&&document.activeElement===first){event.preventDefault();last?.focus();}
    else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first?.focus();}
  },true);
  const modalObserver=new MutationObserver(()=>{
    const open=Boolean(document.querySelector('.overlay.show'));
    body.classList.toggle('mobile-modal-open',open);
    if(open)closeMobileMenu();
  });
  document.querySelectorAll('.overlay').forEach(el=>modalObserver.observe(el,{attributes:true,attributeFilter:['class']}));
  updateViewport();updateFilters();
})();
