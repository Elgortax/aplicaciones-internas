@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Esta demo necesita Node.js para abrirse. Consulta la GUIA.md.
  pause
  exit /b 1
)
node server.cjs
if errorlevel 1 pause
