(function(){
  const icons={
    metricas:'<svg viewBox="0 0 24 24"><path d="M4 4v16h16M8 16v-3m5 3V9m5 7V6"/></svg>',
    dashboard:'<svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/></svg>',
    mistareas:'<svg viewBox="0 0 24 24"><path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-2.9-5.6 2.9 1.1-6.2L3 9.6l6.2-.9L12 3Z"/></svg>',
    chat:'<svg viewBox="0 0 24 24"><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4v8Z"/></svg>',
    tareas:'<svg viewBox="0 0 24 24"><rect x="4" y="3" width="16" height="18" rx="3"/><path d="m8 9 2 2 4-4M8 16h8"/></svg>',
    calendario:'<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M8 3v4m8-4v4M3 10h18M8 14h.01M12 14h.01M16 14h.01"/></svg>',
    proyectos:'<svg viewBox="0 0 24 24"><path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5M3 16l9 5 9-5"/></svg>',
    equipos:'<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3"/><path d="M3 20v-2a5 5 0 0 1 5-5h2a5 5 0 0 1 5 5v2M16 5.5a3 3 0 0 1 0 5.8M17 14a5 5 0 0 1 4 5v1"/></svg>',
    equipo:'<svg viewBox="0 0 24 24"><circle cx="12" cy="5" r="2.5"/><circle cx="6" cy="17" r="2.5"/><circle cx="18" cy="17" r="2.5"/><path d="M12 7.5V11M6 14.5V11h12v3.5"/></svg>'
  };
  const applyIcons=()=>document.querySelectorAll('.navitem[data-view]').forEach(button=>{
    const icon=button.querySelector('.ic'),svg=icons[button.dataset.view];
    if(icon&&svg){icon.innerHTML=svg;icon.querySelector('svg').style.cssText='width:16px;height:16px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round';}
  });

  /* Selectores modernos --------------------------------------------------
     El <select> original permanece en el DOM para conservar toda la lógica,
     validaciones y eventos existentes. Esta capa solo reemplaza su interfaz. */
  const selectIcons={
    alertDays:'<path d="M12 3v3m0 12v3M4.2 7.5l2.6 1.5m10.4 6 2.6 1.5M4.2 16.5 6.8 15m10.4-6 2.6-1.5"/><circle cx="12" cy="12" r="3"/>',
    tDescSize:'<path d="M3 19 9 5l6 14M5.5 14h7M17 7h5M19.5 4.5v5"/>',
    tProject:'<path d="M4 20V8l8-5 8 5v12M9 20v-6h6v6"/>',
    tArea:'<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5m-18 4 9 5 9-5"/>',
    tTeam:'<circle cx="9" cy="8" r="3"/><path d="M3 20v-2a5 5 0 0 1 5-5h2a5 5 0 0 1 5 5v2M16 5.5a3 3 0 0 1 0 5.8M17 14a5 5 0 0 1 4 5v1"/>',
    tPrio:'<path d="M5 21V4m0 1h11l-2 4 2 4H5"/>',
    tStatus:'<circle cx="12" cy="12" r="8"/><path d="m8.5 12 2.2 2.2 4.8-5"/>',
    tRecFreq:'<path d="M20 7h-5V2M4 17h5v5"/><path d="M18.5 9A7 7 0 0 0 6.1 6.1L4 8m16 8-2.1 1.9A7 7 0 0 1 5.5 15"/>',
    cfgTheme:'<path d="M20.5 14.2A8 8 0 0 1 9.8 3.5 8.5 8.5 0 1 0 20.5 14.2Z"/>',
    cfgStart:'<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
    cfgWeek:'<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M8 3v4m8-4v4M3 10h18"/>',
    cfgDefArea:'<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5"/>',
    cfgDefPrio:'<path d="M5 21V4m0 1h11l-2 4 2 4H5"/>',
    uRole:'<path d="M12 3 5 6v5c0 4.5 2.8 8.3 7 10 4.2-1.7 7-5.5 7-10V6l-7-3Z"/><path d="m9 12 2 2 4-4"/>',
    prArea:'<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5"/>',
    loginUser:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'
  };
  const defaultSelectIcon='<path d="M5 7h14M5 12h9M5 17h6"/><circle cx="18" cy="12" r="2"/>';
  const chevron='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m7 10 5 5 5-5"/></svg>';
  const enhanced=new Set();
  let activeSelect=null,activeWrap=null,menu=null,searchInput=null,refreshQueued=false;

  function svgFor(select){return `<svg viewBox="0 0 24 24" aria-hidden="true">${selectIcons[select.id]||defaultSelectIcon}</svg>`;}
  function optionText(select){const option=select.options[select.selectedIndex];return option?option.textContent.trim():'Seleccionar…';}
  function fieldLabel(select){
    const labelled=select.getAttribute('aria-label');if(labelled)return labelled;
    const field=select.closest('.field');const label=field&&field.querySelector(':scope > label');
    return label?label.textContent.trim():'Selector';
  }
  function syncSelect(select){
    const wrap=select.closest('.vc-select');if(!wrap)return;
    const trigger=wrap.querySelector('.vc-select-trigger');if(!trigger)return;
    const value=trigger.querySelector('.vc-select-value'),label=optionText(select);
    if(value.textContent!==label)value.textContent=label;
    trigger.disabled=select.disabled;
    trigger.setAttribute('aria-label',`${fieldLabel(select)}: ${optionText(select)}`);
    wrap.classList.toggle('is-disabled',select.disabled);
  }
  function syncAll(){enhanced.forEach(select=>{if(select.isConnected)syncSelect(select);else enhanced.delete(select);});}
  function closeMenu(restoreFocus){
    if(!activeSelect)return;
    const trigger=activeWrap&&activeWrap.querySelector('.vc-select-trigger');
    if(trigger)trigger.setAttribute('aria-expanded','false');
    activeWrap&&activeWrap.classList.remove('is-open');
    menu.hidden=true;menu.innerHTML='';
    activeSelect=null;activeWrap=null;searchInput=null;
    if(restoreFocus&&trigger)trigger.focus();
  }
  function positionMenu(){
    if(!activeWrap||menu.hidden)return;
    positionPopover(menu,activeWrap,340,Math.max(activeWrap.getBoundingClientRect().width,220));
  }
  // Fixed popovers must fit the visual viewport, including the phone keyboard.
  function positionPopover(panel,anchor,preferredHeight,preferredWidth){
    const viewport=window.visualViewport,rect=anchor.getBoundingClientRect();
    const x=viewport?.offsetLeft||0,y=viewport?.offsetTop||0;
    const vw=viewport?.width||document.documentElement.clientWidth,vh=viewport?.height||window.innerHeight;
    const width=Math.min(preferredWidth,Math.max(0,vw-24));
    const below=y+vh-rect.bottom-19,above=rect.top-y-19;
    const useAbove=below<preferredHeight&&above>below;
    const available=Math.max(above,below),height=Math.min(preferredHeight,Math.max(0,vh-24),Math.max(Math.min(150,vh-24),available));
    panel.style.width=width+'px';panel.style.maxHeight=height+'px';panel.style.bottom='auto';
    panel.style.left=Math.max(x+12,Math.min(rect.left,x+vw-width-12))+'px';
    // Read actual height after setting width/max-height, so a short menu does
    // not leave an empty gap above its trigger.
    const actual=panel.getBoundingClientRect().height;
    const top=useAbove?rect.top-actual-7:rect.bottom+7;
    panel.style.top=Math.max(y+12,Math.min(top,y+vh-actual-12))+'px';
    panel.classList.toggle('opens-up',useAbove);
  }
  function focusOption(step){
    const options=[...menu.querySelectorAll('.vc-select-option:not(:disabled)')];if(!options.length)return;
    const current=document.activeElement;let index=options.indexOf(current);
    if(step==='home')index=0;else if(step==='end')index=options.length-1;else index=Math.max(0,Math.min(options.length-1,index+(step||1)));
    options[index].focus();
  }
  function renderOptions(query=''){
    if(!activeSelect)return;
    const list=menu.querySelector('.vc-select-options');if(!list)return;
    const needle=query.trim().toLocaleLowerCase('es');list.innerHTML='';
    let shown=0;
    [...activeSelect.options].forEach((option,index)=>{
      const label=option.textContent.trim();if(needle&&!label.toLocaleLowerCase('es').includes(needle))return;
      const button=document.createElement('button');button.type='button';button.className='vc-select-option';button.role='option';
      button.disabled=option.disabled;button.dataset.index=String(index);button.setAttribute('aria-selected',String(index===activeSelect.selectedIndex));
      button.innerHTML=`<span class="vc-select-option-label"></span><span class="vc-select-check" aria-hidden="true">✓</span>`;
      button.querySelector('.vc-select-option-label').textContent=label;
      button.addEventListener('click',()=>{
        const changed=activeSelect.selectedIndex!==index;activeSelect.selectedIndex=index;
        if(changed){activeSelect.dispatchEvent(new Event('input',{bubbles:true}));activeSelect.dispatchEvent(new Event('change',{bubbles:true}));}
        syncSelect(activeSelect);closeMenu(true);
      });
      button.addEventListener('keydown',event=>{
        if(event.key==='ArrowDown'){event.preventDefault();focusOption(1);}
        else if(event.key==='ArrowUp'){event.preventDefault();focusOption(-1);}
        else if(event.key==='Home'){event.preventDefault();focusOption('home');}
        else if(event.key==='End'){event.preventDefault();focusOption('end');}
      });
      list.appendChild(button);shown++;
    });
    if(!shown){const empty=document.createElement('div');empty.className='vc-select-empty';empty.textContent='Sin coincidencias';list.appendChild(empty);}
  }
  function openMenu(select,wrap){
    if(activeSelect===select){closeMenu(true);return;}
    if(activeSelect)closeMenu(false);
    if(activeDate)closeDateMenu(false);
    syncSelect(select);activeSelect=select;activeWrap=wrap;
    wrap.classList.add('is-open');wrap.querySelector('.vc-select-trigger').setAttribute('aria-expanded','true');
    menu.innerHTML='';menu.hidden=false;
    const options=[...select.options];
    if(options.length>8){
      const searchWrap=document.createElement('div');searchWrap.className='vc-select-search-wrap';
      searchWrap.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg>';
      searchInput=document.createElement('input');searchInput.type='search';searchInput.className='vc-select-search';searchInput.placeholder='Buscar…';searchInput.autocomplete='off';
      searchInput.addEventListener('input',()=>renderOptions(searchInput.value));searchWrap.appendChild(searchInput);menu.appendChild(searchWrap);
    }
    const list=document.createElement('div');list.className='vc-select-options';list.setAttribute('role','listbox');menu.appendChild(list);
    renderOptions();positionMenu();
    requestAnimationFrame(()=>{
      positionMenu();
      if(searchInput)searchInput.focus();
      else{const selected=menu.querySelector('[aria-selected="true"]');(selected||menu.querySelector('.vc-select-option'))?.focus();}
      menu.querySelector('[aria-selected="true"]')?.scrollIntoView({block:'nearest'});
    });
  }
  function enhanceSelect(select){
    if(enhanced.has(select)||select.multiple||select.size>1||select.closest('.vc-select'))return;
    const wrap=document.createElement('div');wrap.className='vc-select';
    if(select.id==='alertDays'||select.closest('.cl-item'))wrap.classList.add('is-compact');
    if(select.id==='tDescSize')wrap.classList.add('is-rich-size');
    if(select.closest('.loginbox'))wrap.classList.add('is-login');
    select.parentNode.insertBefore(wrap,select);wrap.appendChild(select);select.classList.add('vc-select-native');
    const trigger=document.createElement('button');trigger.type='button';trigger.className='vc-select-trigger';trigger.innerHTML=`<span class="vc-select-leading">${svgFor(select)}</span><span class="vc-select-value"></span><span class="vc-select-chevron">${chevron}</span>`;
    trigger.setAttribute('aria-haspopup','listbox');trigger.setAttribute('aria-expanded','false');
    trigger.addEventListener('click',()=>{if(!select.disabled)openMenu(select,wrap);});
    trigger.addEventListener('keydown',event=>{if((event.key==='ArrowDown'||event.key==='ArrowUp')&&!select.disabled){event.preventDefault();openMenu(select,wrap);}});
    wrap.appendChild(trigger);select.addEventListener('change',()=>syncSelect(select));enhanced.add(select);syncSelect(select);
  }
  function enhanceAll(){document.querySelectorAll('select').forEach(enhanceSelect);document.querySelectorAll('input[type="date"]').forEach(enhanceDate);syncAll();syncAllDates();}
  function queueRefresh(){if(refreshQueued)return;refreshQueued=true;requestAnimationFrame(()=>{refreshQueued=false;enhanceAll();});}
  function initModernSelects(){
    menu=document.createElement('div');menu.className='vc-select-menu';menu.hidden=true;document.body.appendChild(menu);
    menu.addEventListener('click',event=>event.stopPropagation());
    enhanceAll();
    new MutationObserver(queueRefresh).observe(document.body,{childList:true,subtree:true});
    document.addEventListener('click',event=>{if(activeSelect&&!event.target.closest('.vc-select')&&!event.target.closest('.vc-select-menu'))closeMenu(false);queueRefresh();});
    window.addEventListener('resize',()=>activeSelect&&positionMenu());
    document.addEventListener('scroll',event=>{if(activeSelect&&!menu.contains(event.target))closeMenu(false);},true);
    window.addEventListener('keydown',event=>{if(activeSelect&&event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();closeMenu(true);}},true);
  }

  /* Calendarios modernos ------------------------------------------------
     Todos los input[type=date] conservan su valor y eventos originales.
     El calendario visual se aplica también a fechas creadas dinámicamente,
     como los compromisos de las subtareas. */
  const enhancedDates=new Set();
  let activeDate=null,activeDateWrap=null,dateMenu=null,dateMonth=null;
  const dateIcon='<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M8 3v4m8-4v4M3 10h18M8 14h.01M12 14h.01M16 14h.01"/></svg>';
  const dateChevron='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m7 10 5 5 5-5"/></svg>';
  function parseDate(value){if(!/^\d{4}-\d{2}-\d{2}$/.test(value||''))return null;const [y,m,d]=value.split('-').map(Number),date=new Date(y,m-1,d);return Number.isNaN(date.getTime())?null:date;}
  function isoDate(date){const pad=n=>String(n).padStart(2,'0');return `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())}`;}
  function dateText(value){const date=parseDate(value);return date?date.toLocaleDateString('es-CL',{day:'2-digit',month:'short',year:'numeric'}).replace(/\./g,''):'Seleccionar fecha';}
  function dateFieldLabel(input){const field=input.closest('.field,.fg,label'),label=field&&field.querySelector(':scope > label,:scope > span');return input.getAttribute('aria-label')||(label&&label.textContent.trim())||'Fecha';}
  function syncDate(input){const wrap=input.closest('.vc-date');if(!wrap)return;const trigger=wrap.querySelector('.vc-date-trigger'),value=trigger&&trigger.querySelector('.vc-date-value');if(!trigger||!value)return;const label=dateText(input.value);if(value.textContent!==label)value.textContent=label;value.classList.toggle('is-placeholder',!input.value);trigger.disabled=input.disabled;trigger.setAttribute('aria-label',`${dateFieldLabel(input)}: ${label}`);wrap.classList.toggle('is-disabled',input.disabled);}
  function syncAllDates(){enhancedDates.forEach(input=>{if(input.isConnected)syncDate(input);else enhancedDates.delete(input);});}
  function closeDateMenu(restoreFocus){if(!activeDate)return;const trigger=activeDateWrap&&activeDateWrap.querySelector('.vc-date-trigger');activeDateWrap&&activeDateWrap.classList.remove('is-open');if(dateMenu){dateMenu.hidden=true;dateMenu.innerHTML='';}activeDate=null;activeDateWrap=null;if(restoreFocus&&trigger)trigger.focus();}
  function positionDateMenu(){if(!activeDateWrap||!dateMenu||dateMenu.hidden)return;dateMenu.style.overflowY='auto';positionPopover(dateMenu,activeDateWrap,390,310);}
  function setDateValue(value){if(!activeDate)return;const changed=activeDate.value!==value;activeDate.value=value;syncDate(activeDate);if(changed){activeDate.dispatchEvent(new Event('input',{bubbles:true}));activeDate.dispatchEvent(new Event('change',{bubbles:true}));}closeDateMenu(true);}
  function renderDateMenu(){if(!activeDate||!dateMenu)return;const selected=activeDate.value,today=isoDate(new Date()),year=dateMonth.getFullYear(),month=dateMonth.getMonth(),first=new Date(year,month,1),offset=(first.getDay()+6)%7,start=new Date(year,month,1-offset),min=activeDate.min||'',max=activeDate.max||'';
    dateMenu.innerHTML=`<div class="vc-date-head"><button type="button" class="vc-date-nav" data-date-prev aria-label="Mes anterior">‹</button><div class="vc-date-title">${dateMonth.toLocaleDateString('es-CL',{month:'long',year:'numeric'})}</div><button type="button" class="vc-date-nav" data-date-next aria-label="Mes siguiente">›</button></div><div class="vc-date-dows">${['Lun','Mar','Mié','Jue','Vie','Sáb','Dom'].map(day=>`<div class="vc-date-dow">${day}</div>`).join('')}</div><div class="vc-date-days"></div><div class="vc-date-actions"><button type="button" class="vc-date-action clear" data-date-clear>Limpiar</button><button type="button" class="vc-date-action" data-date-today>Hoy</button></div>`;
    const days=dateMenu.querySelector('.vc-date-days');for(let i=0;i<42;i++){const date=new Date(start);date.setDate(start.getDate()+i);const value=isoDate(date),button=document.createElement('button');button.type='button';button.className='vc-date-day';button.textContent=String(date.getDate());button.dataset.date=value;button.classList.toggle('other',date.getMonth()!==month);button.classList.toggle('today',value===today);button.classList.toggle('selected',value===selected);button.disabled=Boolean((min&&value<min)||(max&&value>max));button.setAttribute('aria-label',date.toLocaleDateString('es-CL',{weekday:'long',day:'numeric',month:'long',year:'numeric'}));button.addEventListener('click',()=>setDateValue(value));days.appendChild(button);}
    dateMenu.querySelector('[data-date-prev]').onclick=()=>{dateMonth.setMonth(dateMonth.getMonth()-1);renderDateMenu();positionDateMenu();};dateMenu.querySelector('[data-date-next]').onclick=()=>{dateMonth.setMonth(dateMonth.getMonth()+1);renderDateMenu();positionDateMenu();};dateMenu.querySelector('[data-date-clear]').onclick=()=>setDateValue('');dateMenu.querySelector('[data-date-today]').onclick=()=>{if((min&&today<min)||(max&&today>max))return;setDateValue(today);};
  }
  function openDateMenu(input,wrap){if(activeDate===input){closeDateMenu(true);return;}if(activeSelect)closeMenu(false);if(activeDate)closeDateMenu(false);activeDate=input;activeDateWrap=wrap;const selected=parseDate(input.value)||new Date();dateMonth=new Date(selected.getFullYear(),selected.getMonth(),1);wrap.classList.add('is-open');dateMenu.hidden=false;renderDateMenu();positionDateMenu();}
  function enhanceDate(input){if(enhancedDates.has(input)||input.closest('.vc-date'))return;const wrap=document.createElement('div');wrap.className='vc-date';input.parentNode.insertBefore(wrap,input);wrap.appendChild(input);input.classList.add('vc-date-native');const trigger=document.createElement('button');trigger.type='button';trigger.className='vc-date-trigger';trigger.innerHTML=`<span class="vc-date-leading">${dateIcon}</span><span class="vc-date-value"></span><span class="vc-date-chevron">${dateChevron}</span>`;trigger.setAttribute('aria-haspopup','dialog');trigger.addEventListener('click',()=>{if(!input.disabled)openDateMenu(input,wrap);});wrap.appendChild(trigger);input.addEventListener('change',()=>syncDate(input));enhancedDates.add(input);syncDate(input);}
  function initModernDates(){dateMenu=document.createElement('div');dateMenu.className='vc-date-menu';dateMenu.style.position='fixed';dateMenu.style.zIndex='10060';dateMenu.hidden=true;document.body.appendChild(dateMenu);dateMenu.addEventListener('click',event=>event.stopPropagation());document.addEventListener('click',event=>{if(activeDate&&!event.target.closest('.vc-date')&&!event.target.closest('.vc-date-menu'))closeDateMenu(false);});window.addEventListener('resize',()=>activeDate&&positionDateMenu());document.addEventListener('scroll',event=>{if(activeDate&&!dateMenu.contains(event.target))closeDateMenu(false);},true);window.addEventListener('keydown',event=>{if(activeDate&&event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();closeDateMenu(true);}},true);}
  function applyAccess(access){
    document.body.classList.toggle('rol-visor',Boolean(access?.readOnly));
    document.body.classList.toggle('rol-admin',Boolean(access?.canEdit));
    if(typeof window.applyUser==='function')window.applyUser();
  }
  window.addEventListener('vicaper-access-ready',event=>applyAccess(event.detail));
  if(window.VICAPER_ACCESS)applyAccess(window.VICAPER_ACCESS);
  document.addEventListener('click',event=>{
    if(!window.VICAPER_ACCESS?.readOnly)return;
    const blocked=event.target.closest('#btnImport,#btnConfig,#btnNew,#btnNewProj,#btnNewTeam,#btnNewPerson,.save,.del,.dangerbtn,[data-edit],[data-del],[data-ea],[data-da],[data-et],[data-dt]');
    if(!blocked)return;
    event.preventDefault();event.stopImmediatePropagation();
    if(typeof window.toast==='function')window.toast('Tu acceso es de solo lectura');
  },true);
  applyIcons();
  initModernSelects();
  initModernDates();
  window.visualViewport?.addEventListener('resize',()=>{positionMenu();positionDateMenu();});
  window.visualViewport?.addEventListener('scroll',()=>{positionMenu();positionDateMenu();});
  enhanceAll();
})();
