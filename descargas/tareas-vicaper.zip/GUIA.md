# Tareas Vicaper · versión demo

## Abrir la aplicación

1. Haz doble clic en **Abrir demo.cmd**. Se abrirá la demo en el navegador.
2. Mantén abierta la ventana negra mientras la uses. Ciérrala para detener la demo.
3. También puedes abrir **Guía de la demo** desde el menú lateral de la aplicación.

La demo usa Node.js, instalado en este computador. Si el navegador no se abre automáticamente, entra a `http://127.0.0.1:4175/` mientras la ventana de la demo esté abierta.

## Qué hace

- **Dashboard:** resume carga de tareas, estados, vencimientos y responsables.
- **Mis tareas:** muestra las tareas donde la persona es responsable y permite filtrar por activas, atrasadas, próximas y completadas.
- **Tareas:** permite crear, duplicar, editar, buscar, filtrar y ordenar tareas; usar descripciones con formato; asignar responsables; añadir checklist, subtareas, archivos y entradas de bitácora. Las subtareas comienzan ocultas en la tabla y se muestran con el botón de cada tarea.
- **Calendario:** muestra compromisos y ocurrencias de tareas repetitivas.
- **Chat:** agrupa conversaciones, adjuntos y solicitudes que pueden transformarse en tareas.
- **Proyectos y organigrama:** organizan el trabajo por proyecto, área y persona.
- **Métricas:** muestra indicadores mensuales, atrasos, carga por responsable y permite descargar un PDF.
- **Configuración:** permite adaptar marca, preferencias, áreas y exportar o importar un respaldo JSON.

## Qué problema resuelve

Centraliza los pendientes del equipo, deja claro quién responde por cada entrega, hace visibles los atrasos y conserva el contexto de cada tarea. Así, las reuniones, archivos, actualizaciones y compromisos no quedan dispersos entre mensajes y planillas.

## Datos de muestra y diferencias con producción

La demo conserva el motor de interfaz y reglas de la aplicación publicada. Usa **tareas y correos de ejemplo**; los nombres de áreas y personas sirven para mostrar cómo se asigna el trabajo. Los cambios se guardan solo en el navegador donde se abre la demo; los adjuntos se guardan localmente en ese navegador. No se conecta a la base de tareas de producción.

Los correos, recordatorios automáticos, permisos reales del portal y convocatorias de Outlook necesitan los servicios de producción: aquí se simulan y **no se envían**. Para volver a los ejemplos iniciales, abre `http://127.0.0.1:4175/guia.html` y pulsa **Reiniciar datos de ejemplo**.

## Recorrido sugerido

1. Revisa el dashboard y las métricas.
2. Entra a **Tareas**, busca una tarea y despliega sus subtareas.
3. Crea una tarea con responsable, fecha, checklist y subtarea.
4. Adjunta un archivo, descárgalo y agrega una nota en la bitácora.
5. Mira la misma información en **Mis tareas**, **Calendario** y **Chat**.

Esta carpeta es independiente del portal publicado. Para que otra persona use la demo, copia la carpeta completa a su equipo; cada navegador comenzará con sus propios datos de muestra.
