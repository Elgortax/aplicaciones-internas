(function (global) {
  "use strict";

  var money = new Intl.NumberFormat("es-CL", { maximumFractionDigits: 0 });
  var number1 = new Intl.NumberFormat("es-CL", { minimumFractionDigits: 1, maximumFractionDigits: 1 });

  function n(value) {
    value = Number(value);
    return Number.isFinite(value) ? value : 0;
  }

  function esc(value) {
    return String(value == null ? "" : value).replace(/[&<>"']/g, function (char) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char];
    });
  }

  function clp(value) {
    var amount = Math.round(n(value));
    return (amount < 0 ? "-$" : "$") + money.format(Math.abs(amount));
  }

  function compact(value) {
    var amount = n(value);
    var absolute = Math.abs(amount);
    if (absolute >= 1000000) return (amount < 0 ? "-$" : "$") + money.format(Math.round(absolute / 1000000)) + " MM";
    return clp(amount);
  }

  function pct(value) {
    return number1.format(n(value)) + "%";
  }

  function month(value) {
    var current = Math.max(1, Math.round(n(value) || 1));
    return "M" + current;
  }

  function share(amount, total) {
    return total ? n(amount) / total * 100 : 0;
  }

  function normalize(input) {
    var data = Object.assign({
      mode: "internal",
      projectName: "Proyecto sin nombre",
      location: "Ubicación no informada",
      company: "Tierras de Chile",
      scenarioLabel: "Escenario base",
      lots: 0,
      hectares: 0,
      saleTotal: 0,
      saleMonths: 0,
      horizonMonths: 0,
      landCost: 0,
      landCostBasis: "",
      commercialCost: 0,
      worksCost: 0,
      netProfit: 0,
      resultAmount: 0,
      resultLabel: "Resultado total",
      resultPct: 0,
      resultPctLabel: "Rentabilidad estimada",
      annualReturnPct: 0,
      annualReturnYears: 0,
      remainingReturnPct: 0,
      remainingReturnMonths: 0,
      pvp: 0,
      unitSalePrice: 0,
      waterUnit: 0,
      waterIncome: 0,
      buildingIncome: 0,
      extraIncomeTotal: 0,
      piePct: 0,
      pieAmount: 0,
      balanceAmount: 0,
      balanceWithInterest: 0,
      annualInterestRate: 0,
      interestPerLot: 0,
      interestIncome: 0,
      installments: 0,
      installmentAmount: 0,
      scenarios: [],
      timeline: [],
      alerts: [],
      glossary: [],
      disclaimer: "Modelo de estimación para análisis y negociación. Las cifras son referenciales y deben validarse antes de asumir compromisos."
    }, input || {});

    ["lots", "hectares", "saleTotal", "saleMonths", "horizonMonths", "landCost", "commercialCost", "worksCost", "netProfit", "resultAmount", "resultPct", "annualReturnPct", "annualReturnYears", "remainingReturnPct", "remainingReturnMonths", "pvp", "unitSalePrice", "waterUnit", "waterIncome", "buildingIncome", "extraIncomeTotal", "piePct", "pieAmount", "balanceAmount", "balanceWithInterest", "annualInterestRate", "interestPerLot", "interestIncome", "installments", "installmentAmount"].forEach(function (key) {
      data[key] = n(data[key]);
    });
    data.saleMonths = Math.max(0, Math.ceil(data.saleMonths));
    data.horizonMonths = Math.max(data.saleMonths, Math.ceil(data.horizonMonths || data.saleMonths));
    data.scenarios = Array.isArray(data.scenarios) ? data.scenarios.slice(0, 3) : [];
    data.timeline = Array.isArray(data.timeline) ? data.timeline.slice(0, 6) : [];
    data.alerts = Array.isArray(data.alerts) ? data.alerts.slice(0, 3) : [];
    return data;
  }

  function returnBreakdown(data) {
    var parts = [];
    var fullYears = Math.max(0, Math.floor(data.annualReturnYears));
    var remainingMonths = Math.max(0, data.remainingReturnMonths);
    if (fullYears > 0) {
      parts.push(pct(data.annualReturnPct) + ' anual · años 1 a ' + money.format(fullYears));
    }
    if (remainingMonths > 0) {
      var roundedMonths = Math.round(remainingMonths * 10) / 10;
      var monthsLabel = Math.abs(roundedMonths - Math.round(roundedMonths)) < 1e-9
        ? money.format(Math.round(roundedMonths))
        : number1.format(roundedMonths);
      parts.push(pct(data.remainingReturnPct) + ' · ' + monthsLabel + (roundedMonths === 1 ? ' mes final' : ' meses finales'));
    }
    return parts.length ? parts.join('<br>') : 'Según el escenario seleccionado';
  }

  function distributionItems(data) {
    var margin = n(data.netProfit);
    return [
      { label: "Costo del predio", description: "Valor considerado para adquirir o remunerar el terreno" + (data.landCostBasis ? " · Precio informado: " + data.landCostBasis : ""), amount: data.landCost, tone: "land" },
      { label: "Comercialización", description: "Marketing, corretaje, administración y costos comerciales", amount: data.commercialCost, tone: "commercial" },
      { label: "Habilitación y obras", description: "Urbanización, estudios, caminos, servicios y otros trabajos", amount: data.worksCost, tone: "works" },
      { label: data.mode === "broker" ? "Margen neto del propietario" : "Ganancia neta proyectada", description: data.mode === "broker" ? "Utilidad adicional sobre el valor del terreno" : "Resultado después de terreno, comercialización y obras", amount: margin, tone: margin >= 0 ? "profit" : "risk" }
    ];
  }

  function flowRows(data) {
    return distributionItems(data).map(function (row) {
      var rowShare = share(row.amount, data.saleTotal);
      return '<div class="es-flow-row ' + row.tone + '">' +
        '<div><strong>' + esc(row.label) + '</strong><small>' + esc(row.description) + '</small></div>' +
        '<div class="es-flow-value"><b>' + compact(row.amount) + '</b><span>' + pct(rowShare) + '</span></div>' +
      '</div>';
    }).join("");
  }

  function segmentBar(data) {
    var colors = ["#57728e", "#92a4b7", "#c9a32a", data.netProfit >= 0 ? "#9b6c00" : "#b8412b"];
    var values = distributionItems(data).map(function (item) { return Math.max(0, item.amount); });
    return values.map(function (value, index) {
      return '<i style="width:' + Math.max(0, share(value, data.saleTotal)).toFixed(2) + '%;background:' + colors[index] + '"></i>';
    }).join("");
  }

  function onePesoDistribution(data) {
    var items = distributionItems(data);
    return '<div class="es-one-peso" data-section="one-peso">' +
      '<img src="data:image/jpeg;base64,/9j/4gIcSUNDX1BST0ZJTEUAAQEAAAIMbGNtcwIQAABtbnRyUkdCIFhZWiAH3AABABkAAwApADlhY3NwQVBQTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9tYAAQAAAADTLWxjbXMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAApkZXNjAAAA/AAAAF5jcHJ0AAABXAAAAAt3dHB0AAABaAAAABRia3B0AAABfAAAABRyWFlaAAABkAAAABRnWFlaAAABpAAAABRiWFlaAAABuAAAABRyVFJDAAABzAAAAEBnVFJDAAABzAAAAEBiVFJDAAABzAAAAEBkZXNjAAAAAAAAAANjMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB0ZXh0AAAAAEZCAABYWVogAAAAAAAA9tYAAQAAAADTLVhZWiAAAAAAAAADFgAAAzMAAAKkWFlaIAAAAAAAAG+iAAA49QAAA5BYWVogAAAAAAAAYpkAALeFAAAY2lhZWiAAAAAAAAAkoAAAD4QAALbPY3VydgAAAAAAAAAaAAAAywHJA2MFkghrC/YQPxVRGzQh8SmQMhg7kkYFUXdd7WtwegWJsZp8rGm/fdPD6TD////bAEMABAMDBAMDBAQDBAUEBAUGCgcGBgYGDQkKCAoPDRAQDw0PDhETGBQREhcSDg8VHBUXGRkbGxsQFB0fHRofGBobGv/bAEMBBAUFBgUGDAcHDBoRDxEaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGv/AABEIAPQA+gMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAAAQIEBQYDBwj/xABFEAACAQMDAgQEAgYIBQQBBQABAgMEBREAEiEGMRMiQVEHFDJhcYEVI0JSkaEWJDNiscHh8ENygtHxFyVTkkQ0ZHODov/EABoBAAMBAQEBAAAAAAAAAAAAAAABAgMEBQb/xAAvEQACAgEDAwIEBgMBAQAAAAAAAQIRIQMSMQRB8FFhInGRoRMygcHR4RRSsULx/9oADAMBAAIRAxEAPwD7+0aM6M6ADRozpM6AF0aTOjOlYC6NJnRnRYC6NJnSZ0WA7RpudGiwHaNQau7UFA2yuraanc9lkmVSfyJzqnfryxrGJFqZXQyGMN8u6gsDjA3AbufbOpc1HljSb4NNo1lx1rA5HhWu6ON2CflwMDGc43ZxrkOtwNvi2e4xkuE27Axyew4P+n31n+Ppf7I0/C1P9Wa3OjOsqeuaONVNRRXCLMrRN+pDBGHfJB7ff09dTV6utGF8Sr8Lc4Qb0IycZ/hg9+2qWrCXEkS4TXKZe50Z1Gp6ymq0D0tRFMp4BRwdd9aWQOzozpujRYDs6M6bo0WA7OjOm6NFgOzo03RosB2jTdKvroAXRo0aYDdGjRqQDRo0aADRo0aADRo0yaaKmhkmqJEhhjUs8jsFVVHcknsNAD9Q7jdaO0wia41CQIThc8s59lUcsfsAdZe8dXTvTyyW947Vb0XJuFYuHk78RRNj0HDvgdiFcHXjNT8Ra++VVRb/AIa29uo6syEVN7rWIpkOMEbz9WP3VAX2Ud9cer1UIYWWdOn08p5eEexVfXdRUBP0PRLSQSMAKy6N4SgZPIiB3nOOzFDzryXqb43WT5+W3Nebh1LUAlVpLKJM5+5ix69slvx1Hpvg/LfXWo+I1+rb9M4J+UhkNPSr9gq+Zh/zHB9teh2fpu12Gl+Us1HTW+m24MVNCqA/Y7R/jrzp6+tqd6O2OlpQ7X8zy2lvnXtfGI+jugbd01T8YqLxUKjyKCcExr5j+f8Anon6P+JF6lWe+9bWu2nPH6MsyM8YPB2yycjXr+2OFfDQN5vtnP30vLLsWMSA/Ufbvj89c+y+TdTrg8iqPhHfp0xdPiT1TXwOMsY6nwx/AfgPXTKb4EUjx4bqrq7xGPJF2ZTn3IOdeuqxeVVhGVOWYgcZwR29TrpT7BCrpxG2Tg+3roUELe6PIZfgfMBI9J1v1okjA72W4CTccdyCPfjXP/03+INBKJLT8Ramr2lWC3a1xVPI5Xkc8e+vZQW8M4Qqcg+vA10GJAMLtUgk457Hj/xp7EG9njAuXxS6aaR6rpTp7qFnVWNTaqh6WfA4G2OXMYPrj8dWtl+PEdi+VoOrqi+dI1IZgy9S2sfLOxJIVamHKgcgZP469g+UEpKLIGxjy44OScf4ah1NngrlaGqp4Z4ZF80U0YdAp9Cp4wca1i5w/KzN7Z/mRZWjrylrqaKoqUjNLNkpXUUwqaUgDuZF+n28wGtRT1UNXEstLKk0TfS6NkHXgdV8CbTbqpq/4f1tf0NddwPi2iUiKTnP6ynbMbDPpga5f01646Fqi3XNGLlRKdxvVhgLKAOGapou/bHmTJGuvT6uUcaiOaXTRlmDPobRrNdH9aWzq60Q19ruFFcI34aWjkLxhv3eeVP91gDnWl16UZRmricUouLpho0aNUSGjRo0AGlHrpNA0AO0aNGqAbo0aNSAaNGjQAaNGoF1ui22FdsZqaqUlaenVgGlbGTyewA5J9APXsVdcgF2vFLZaYTVjMWdtkMMY3STP+6i+p4z7AAkkAE68i+IPxAordBRi9Ri8XKpkDUNnpAZQHB8oI7u+QDuIwP2QPqNP1v13W1Nzey9PIl26irAUQIu1UiByck/REp7n14yScAXnQnw6prA7XGvlS536oU/MV7LtCjHKRA/2cY5+7dyfQeVq68tb4YcHo6eitPMuTO0nQF767mFw+J9S607ndFZaeY7B9pnH1n+4vHux7a3TVlh6faOzwzxLUUyAC22+naeWJfT9TEDsHbvgahm4z9VQbrTWTWLpUtsW4Qrtq7pnj+rnvFDz/aY3v8As4GGMW81kPRlngtHTdrgWur5PBt1pjUgPIeTJM31PgAuxJ9Dk656Ufc1tyL+muVHWFY1M9DWOGZKKtQRVDxr3kCAk7OcZOOeO+pUahM4yAB3OMn31T2OyRWemmlnmetuleytX3CcbZal/Qf3IxyEQcKPuSTdohUgAjaDxpNoEqGCAsGLMdjdmPZQfT76Uwqm4OP1ZJJA7kEEY0+P6BtO7bjuOM/fUVjsqCFkLK7DIY5C8+x9eP4aRRKC74mWIlVTsQMbcD76x9VdrveOpqyydHSUNJR2dUW73WspzOsdS4DLSRRhhucIdzt2GVHfOrTq3qio6do6a39NxR13VV43Q2ilLAgOB5p5B6QxDzMTwTtUctrv0l07H0hYoLRTyvUnxZpqipclpKiokYvJK7HlmLHvxwOABrSkuSFbI9vmrqa4U9qvNUtdWVUEs61MFIKaJVj25TbuJYksDk4wAPc6mqfNtb1yCec+uBj21AuUph6+6YTeyRvR1iM4H/JgfyOraWEpJlP3mBKqSG+3+GpeVZSwydFKFZmTbggc55xx3OpEG6NMAkSNwxAGe55++oUTM0IVfKNuTwBgA549Oe2pjslQyDcDKASA2AT9tNCKWG/lr/XW2fw6CCjjjkjaR3aSoicf2wUDAjD5QnJII5xkZtX3TqtRGsdRCRnxaeTcu3H1cDI/h+eqrqfp57xRq1slWgvNHI01BUsnl8RhtMb4+qKQDa49sHuo1nenb7PXW6SusqPb6qhlMF2te47qKcDlSO+09ww7gg5I7vHDJV8pkPqL4aI1ynvXRFY/S99Zf1tTTx/qKwH9meIECQf3h5vvq56J+KNS92p+musaAWK/Km2KnLZp61Qf7SllP1feM8gfhzpLfUU12y9OPl7gBteM8KTnnIHAJPZhgH1weNUXVnSdp6ttsts6kpzLGWzEwOyWCQftIw5Vx7j+ehOWk90OB41FtkepQzRzxiSFw6H1Gn68J6V6wvnRN6ouneuKs1VPUN4dpvTbRFXAdoKg48s4A4YcN7HsPb6SrirIfEhLYBKsrKVZWHcEHsdero60dVe5wamk9N+x30aNGtzENGjRoAdo0Dto1QDdGjRqQDRo0aAIlyuMNqoZquq3mOIfSi7mck4CqPVicAD3OvD+vusruK2O12mBZup7mwiphE2VhQjcRv8ARYx5mf1Y57AAaT4jddwW2119S5GyKN0o03gmRjlfEUA87ssq/YE/tayXStirenMmoRKvr++Qiao8cF4rbS54MpByI1x9IIMrjaMKpYeV1Gr+I9keEehoaexbnz5ktOlenLV8PKJY6mZ7nfriu+aSOPxKir2jkqufJCnuxCjuTuOrO91cN9ems8E/i2WppPnrtIm5DLRk7YoQcZAnfIPqY43A751Gu9DBa7NUxLVTfOXjbBPcpUL1NR3DyMFH0qoYpEuFGMAD1pYeoZIzIbHTxw1VbIahJp4TL4cCoI4Vhp15cJGgHiuyRb2kIY51zWksGtNvJrb71ZR9OUJuN2ykjkR0lOindyPKiIM5Y+wHHAHbVV0nYq2Otl6m6m2x32sQxwUzDf8AI05OShb/AORsAsR24UepNP05TPTdSUlRV04ut4qqR53raqpMktDDu2iTgCOMORtVI183mJcqvO+ps7EMjODkpnGFOD7HU33ZddkdCeWzgmM8qBxnv39ONKPOu9H8rDKtgfT9s86eBJtAC4HcAHOD/npu8IJGWPBUsA2Rj7n7f6aQzi8scTIVKs2GxlsY54wPudVdwvzW2SlpbdQS3m+XFZGoqFCIwRGRvlllPEcSl0BY5JLAKCcDU5wS2/KFtx25QKduO2CedZa/2y/S3yzX7o+stlNcaSimoZILpTyyRSRyukhOYiChDRjvkdtCdMKtUXXS3TslmmuN6vkpuPU9yVYqyr8MIkaLyIKYd1gB5APmY+Zue2hJBZC6kqQBy2MZ+3+++vPrRf8ArOh64tFp62l6emo74tRT05tVNJG0EsUfjZJkYkgqCMfca30MQSaSWIMs0hVZFB/dzjg8Zwf5ad2KqM/XuW6x6VYKQoWsXeAcA+FwPb341dTHw5XbJVRk5Odv8j9tUHU529S9MyZPllqFxn3iY/5e+tAAgkjdQgG7bjvgbeONF9grNkmE4iYBi+5RljgYzrurASM9OEaQHb27j01H2ZhbwEVtyZUY5Xj/AM66KMSETKQqnj9XtA/3/npoR1ZXZShBYcEl1xnHrj8tZTqLpaesuSdQdMVK2rqinjEIlm//AE9dGORDUKOSvorjlSfUca1br4hBd1EZ4K7ecY9P8edR3GFPLbjIcBxgjPb8O2m2JIxtv6qivtwitdYs/TfV1KpD22tY7JVP1NA30zIf7p/gdXVxvLzWCpuboyV1vYCsh8M72jRw7YB7gxq659ePbVTehRXu8TWbqyihuNulhFRa4pYdxYov64pJyyyISDhceUgj11a0Vuqun1+ZtFXWdT2J49lRR1R8arii/eil+qUD1RyxwTgg+U1G3ZMqRL6j6ctvVlsrKCen+doJlxNROu2RRzteM+4+pSOR6ayfRHU106UvcHS/U9Qa6eWM/oe6O+FucS8eBIey1KAjH7wGrbpa4G39PpAkpnNoLUhkAw4gDZp5Dkk4MRTOcEEH2OpvWHTVD1vY5qStlaFuKh5adRvSRPpqIj6Mp+oDuD9+Wud0OQ7bZcHo9PURVcKzU7h427EfzB9iPbXXXlHwz6vnf5q3X9UhvVHOlPc4g20MzcQ1Manusq9/uNer69XR1Vqxs4NTTenKg0aNGtjIUeul0g9dLqkA3Ro0akA1mus70ltt5pgWWWpikJcEqEjUeYlgPKTkKPXLcdjrS6+ffjFf6u4XKntdmqHqKytmWCjp1+gMx2qxxyT5mYn0GNc3Uaj04Y5ZtowU5Z4RT2d4b7dLt1z1PAJunOlUxR00agLU1aAYCj12kqqj951/d16n07Yqi226VrwIpr5XutbfZ1JbdMfphQn/AIcagIoHZVz3JJpLzYKTprp/oXpmilJoP0zDJVurcTCmikqmJ+7SxKT9jrt1Rfauls8VJaRNJd7ovjyJE+Wp4nIQMCeA7MypH7sc4wra8ytnw+ef2dye52/PP4K+eqquruoblDRtHEsUJpo6lowY6WlDlZag54LOyGKNeM+FIx8oIMqqax9J9OVVyqVkp7PB+uCuxee4ODgSSMfNIzEhUU9uMAAACRQ0Vss3Tk0VdU0tDaKBS93q38kUzoNvh7z+wuAvOSQoGMk6zNvpZ/iBd6HqC600tB05QuHsdBKpR6mTnbVSJ+yoHEannB3HHGobVYLivU0PR1srBQz3HqGP/wB1vDitrIy2TGO0UI9xGgA/Hd760yCKMhAMKxO3cOc55xj3PYaWN/l0QzeIXjc5JPI49T6+3GuZqvCULAPCBfaoZcDbn2HbU8DFJ2AKGZDwAh82Pxz2zzqLIGlQLKAig7gOcgdjyO+eddXkaYsqSDHBLFuG9OR7f665SKKePcdkiDPiMo7fgPbUlI5GNX2TOiuynhsg7Meo4/npBE4ztj8PCkgdiD+Xc66IUjQsgyiDlFAyR3x9xz/hodQEUrjIAJ4wR30IDMXiJYviT8NgWDbKy5uASTwKFu337/w1tahvDI2ne2/HlOPw/wDOsReiZviX8NlPOai6tEQu3b/UBwffudbUmETcuyujqrANgAk8Hn/fOmnj9f4F389zNdV8XrpVh5mNbKMK+3gwPzz+Gr0MuUIYozEHOMn+GqDq1Sty6aYBWP6QZImU8kmCUHIP25/HWhjT9VgsSiuMt7gf66O4+x13mWPbt2gkl+R254x7ca6RygtNuZWUgA5GOex/DUYKS5Iz5TnGRzkHkj2118GQxRnczl2UHjgc/wCQ5zppiokROI1cRhnbgZzyeOSfwOmzb4xgMqnyjIXI/wDOin8yCUqWDt4RdAAR68fwGpEsJKO4CCRsMMseD+QzjTrBN5M91PbJb1bAbZU/K3SlkFVb6jb/AGdQmdvH7rcqw9VY6gWHqZLhQG8WyGWmmEphulBnzUVUo84AHpzn2IIPY60VZEJwIlaRWQ8OoKN3GSD3HHGRrHdTdPV8V5h6p6QgWqubKI7navE8KO5QAEAFsjbKoztbgHseDotjSXcurvTVMtTH1P0zBHJe46crW0KAbLnTZJIUf/KhJK575IPDcdqK5U1RT0dwsEwkpKoeJRVQ/wCGR3jZe6gY2kd+SD21V9NXq03WL5/pISgUcm2ttsylKugk5zuiJJX/AAOeMjT73DDQSm62CnWa3XYl6uljbak9QAcvF/8AHPhc88SDg4IDau21ffzJNZrt5gp+u6J7PUUvWFgpzJW2eEyzUyHLVFvcnxqcj1aM7mX8Pvr1jpK8JeLRTzR1aVyPEssFQp5nhYAo5Hvg4OOMg/hrz22VyVFykkgk+YjNFFMJCpAcszKePvt5Hocg6zXRF3XoLqqXpXcVoYav522MfpFuqCfEiPsIpl7+zD31ehq/h6nsxaum5w9z6F0aNGvaPKFHbS6B20apAN0aNGpArb9WNRWqeSN1iY4QO2cKCcE8A8gZI++NfPnTlet06t6h6vqI5JI7TTSCnjjTLvIyMSFHusSgDHrJr1D4vXb5Hp6SLxY4wyk4J85JBAx7YGf46ynw5gjsFlsAqJFiqrhUB1RlyZJpgXVcjOMRoOfTbryepk5alL5fU9HQiowv9foW9yuUVfD0v8u1LU11NdoA6RszwgVFNMo2vgFgVYHsPTjnWZudStJd446eSK519LLF83PLUmmgirHBVElnUElv1nkijVnACgBASzTzFHaVhjMIpqOwXOsrbgIlXeZihSjCp3Zm8YbQBjMWPTGqOqsUMrW+kuddVWmpjK11FTW9kke3ICxernkdSq923SYy7EhS+OMG7o0jizWU/wAOVeugqevK2K7tRur0drp0MNtomHYrExPiPk58SQsc9gNb8U6yPKQcSKoC5GTk89/4cfbWUtFJ4FLTUlRurhAm0y1DmWSXDE7yx5JPfJ9/TV9SSSxwrGZDNIByzLjJ+w/DRCUbeAadcjaunKS4kPk3Bd+c4P8AvjUOVZFDYfwmHL7QDu+xP+Wrp6htu2UBy3bOM/7/AO2q6ppj4sRhZdqPmTbjng+mnJLsEW+5CgZpd8ixybSo2g+Uj8Qe3bP56SV1j2hJVcAArgZB7jAPY9u321Yim3LKScjgnnGPTA/LUasi8OHyhsLgkA4yTwANZU6LTyVbkTGTcQgcgBwCcH1P213WGWRF2ShguDlM/wAedNFPmM+IGRfcknH2/kNWcKeHM0jDysB2yCxGckD2xqUijD39NnxP+F0h5D1F2QYz2+S7n/64/hrbz+bkqvh7j9fvuyP8tYrql1T4h/DLyCNzWXQHIJwTQPgZPrx6a2SKd69sdsbc5/D255zpx489hd785Zl+rmZa3ptjCjst0xgNzzDLlfY54760dNkxwrgqWQZ8vIx9u3Gs31Yd0/TokJK/poZIX6sxScE+mPf8tbO2xB8+QArgkJ+eO+nFWweEPEXiRlhuwRgZA9Rj+Hr+WpEMJQLs2OMDJz7DUjwSxYYCL3yBz/H8tP8ACwzSceGBggr6fbXQodzFyIDROiwwoSd77ssPNgk57euNQBUEum1j4SkjYTnOBjv7A6uJ325ZcDOFAz6fhqFPGhji2ecLwp2j1HGdRJehUXfJGdlqVZpF8zfUQM/x+2o7RIGLrsAzyRnOR2P+v306JmZ5A67wrBQI+7g8/lzqQ7xlDLKdj8hlJH7IPBI9tYvJosGV6gstkuc7Xa9B6SrtsDsLnQyvT1VNGqlm86csuFJ2sGH251BoaS9T9HxXK31Ml5t92gWdqG5wRJVtnzJioi2qk2NrLuU84BIPOtRKBG6rEsb+OCHOQQFI578t3xjVJ0b0zbqeC9ydHUUNgraK6VFLUw0S7C4T6CVOVcFGVtrDA3YXBHN6acm/P/pMsIj11zR6Wpv9hCyRV1A1VHOYQrBt43gp28RFVyVPdwQe51met6ukp6O19Z2+nc0vT1YPmBUJh6y3yERVLEHHlPEgXj6ScDOtO8tTBar7aIaeKa4NULcVmiciExTO26URtkqAVkV48kc5B82B1ltVFcrU9vq0aptsxkts2/gSgRgM33xllJ/eQgds6Ur5Q4eh6B0hXieiqaFpTNLbZzT7mOS0eA0bH8UZdaDXifwRvEi01soK+QCvip5rPWLtOXqKJ9quT7mIg/f8Ne2a9jp579NHm60ds2OHbRpB20uupGI3Ro0DUgeFfGFqu5XIW8okkNRIsCbSSUDFU59Ac7vuRrpWVYS/boBEtHYbW8zlmIxU1XkiUY/aWCKQ9uBID66gdQTfpXr+ihWLaVqgwYDGeHcH7d9SulU/SPRVZcXO+bqm+PVKRnPgGUQQDPfHgQqfzPvrwZPdO/m/uevFKMa+S+xN6yZ6K4mppkhq7pcJqSlpaaUkoaqMTRxFyO6h3aRj6Kh7nUVrWtDaa6lpqyatlqKqKmq6x4wZ6yoeRRLKR2yEyqp2RcKMAHN88W7qs1p/WNQxVlQXLkGNnZY02D0GGl541U1lTMtmtBnL/N1NbLXOxCgKBHK2QB9lH3+2dDefuJLBf21zPG87kANmQuR2OfcemrcusMbyFDFIvf1ycdx/pqisqN8vCBIf1Uextx8oyQc47E+X+etDCjeGXGzYBgEOcZ7gY+2s4mkuTmCyRM0kjJ+1x3zx2Prz6412aRKePARvDQjIXB59TjjPfS7d2Cx24zt2kHTJIh4QZYgx4BPt7H+OryjPkfTkOkjCMx7jkqwB2nHYaZWtKYwELF2BHGCB99OgP9ow5HdGB+r30szRNGHXHlyBhsZPbB9+dPsCwyHFGykvHkbfqxnn8BqYjxhsqwZjgtk84z66hzxzyoxiZoZOAG7kDPt+WmSq0YlcnDY27woBC88Z/HnUXRdWZPrCRZuvPhgyNv8ABvFcSqt2/wDb5uRjvj27c62rrG24HeshBxznB/HXnfULRf0++FqwqrK95rR5VxwbfL/LXpLSESsJedzEAZ/37aI5XnoJ4dLzkx/VrKlb04W+p7xGMcnH6uTnj7a3FlVVpQIyCuBl/U59ftrDdYsqVvTyknKXRGU5O4nY/b0/7a2dmmD0+6TcHI5Hrjn+eq03UwkrgXB5bP7GfqHbjUaedY/qQhM5A7Y9ydLLOrKAWCADKqwzn7nXDw2kZVmZyG/a9B98fj210SleEYRjWWMUDLkjGcHkg+v+/wAtK7nMbNvXHpxk9/T8dRpHbxsjzx7MEMNvm9AP5/46WSRJoSfDJZvpZhtYkE8Y/L+GsUzSjiziklaWmTO8KNx/Z47402NjhUj27c42uOynj/vorAsaRuVKBMgE9gcc9v8AfOuNFVIAkUiosjO23aDgAH19Px/HWd5o0XFnSojldSSFMYJAAAypHY/y/lrK2Sqmo+putPl5PDFPfKOaXHG6OahhBPf95c611QTt+lics2AAVXjvz76wsESn4k9YW13aOK7WK31cZjfaWaMyxNj27poi6EXd/WqtvUtLeqQRCGaiqqRlZcqkxXxPN/dOwsPu51Gs1AlJaZrPC7TGMK1M87ZkklRdzbif2pCZT+LalXeSWq6Euio6iVbbJMp+klkQ7gB/yFh+WoJrBRXKoqqc7languKiMkg7dme3urHWjebfD8ZKVKlyvEZvp+ohsPxB6qbIiieS236A9yyzZpqggexwpP4jX0Jr5w68tbxfESyRUbRolwt9woBIRnyRvFVockH9lSB7c6+h7fVLW0FLUo25Z4UkBHqCM67OieJRfY5+qV1L1JI0ukHrpdemjhG641chipJ5FGSkbMPyB13I1Gr1D0FUp5BhcfyOpA8EpopH66JkfMizSLG2crt8NAMeucsRqd0AFl+G/QaAbgnyqupPrGrgjB9dyk/jrlGZ4epI5JAGEVZMcK2VztTBz3HAwFP3126OpzbYKzp+dmFT0/1EoQKQP6pUSF4XAHcYmZf+k+2vne6+SPa7P5sv55ovE6llgLh4oo4mCnnJMrcfnj811S9QM73W125VUijtzSNjII3lY1H8BLptoqJJa++K8i/196QxKVxlDNUruP5KPtrjZKgX67XS9J5rfVTrHSkjAkhjBUOB7FjIwPtobGl6mytNOI6PY0avIxB5Pb3HA9tWcMgE0aORtbzBu4z9h6H+euNHH4cCAbNpHdf2eOP5DUlIjUhnbIVAFyCCG/3/AJ6cV6EtnXwl2AthT3Ge4OeNO8YFn34A7Zx+edN2zIGKbZlAxhuDx2H30rEAZcHdICefTWiMxsitFFuyCMH7E5/2dc5Az7BG6tHk78EHdwQAPz03cUwztHsQAe2PTnPB12iBLMhjBYk5C4Hc5P8Alzpcj4HRRGSIEqquy5JYcqfQaj1AMMcbMyqgJ3bhnj3z6e41NEggQeLtXLFUycZPt/I6jVFUPDKxjd5clR3z+Gm6SBXZ5v1VLn4k/CpQoLvc7jLjuMChcbifX6v469Bq2KOccFjglj3+32158Y47z8Z7RTQjxIel7DV1NWU4WKqq2RI42I4DmJJH298EH11vawq/hmAqwLgceUBCCPz9PvrNYiX3Mn1S8jy2QO2cXJcEnb5gCMgev/bJ1r7XBEaFFZiVQKS2edwOR21n73Z5riLPHFHlkqxJ5QMjaGOACRySMevfV1bKxYlwAUXIyEA9M8fbnSVLLDlOidHUJOP6ukgO1TuH1EEnjB9fx1MYypHiIDdwW4zkew++osVQjESDarsBkKoye/sPv66nrGhDq+zzeYgDHH/f11tBWjOTohSI0sDM+xe/0jdnB+3OdRRAXr4WilcAq6yDDYfnIwMYGPf8dTqobSgjQo2Qni/u5Pt799RMNGajxZZRsyNzAZ4GR6YP+upapjTwMKibErFVYnBX0HcZz6Hk6h0MShQkbgAZLbgD27DOpZYiEbm3Ngb1yBt++PTUGMfKSTyIwMLkbsrwnHfPrrJ8mi4OsshkifwyWcJnbj6vwzxyeNYPqLNv6/6IvTeSGu8Sy1AJA8NnHiRZPb+0TA/HW6O51kyFZwp2rG55Hfn0z66zvVNjqOpun6uzxzQRV+EqKOZhgxVcT+JCxHqNygHHox0lyVwibhqukr7fD4awh6qnkwOTvhkxjP2wT+WqSgd6qksk8kkn9asKGQbTnd8uuD/rpKTqSO+WiOt8D5WavroVrYnGGpJ40ZamFscgqU49wynkHUWa6fo3pqKVM+JS0ElLTwkYLy+O0UcY9fQD8tVeKJXLZE6mmS4Xz4b3VgVWW9/JSqvlXEtE8RAz/wAv/bXtHRcpm6UtJZgxWmWMkDH0+XH5YxrxK/0hpH+GdE7xvMvVlN4hWPCl1hlZzj8Qca9p6EYN0nbinC7XA4xwHYa7eidzl+v7HL1KqKXoaIeul0g0uvWR54h7aZIgkjdDkhlIODj0109NNGgDw2qpVguc08UinfUpIp+xTGCTwf5c67dRhrTVUXViwZSkhFHeApwZKLxAyzAD9qF/P/ylxqw6jiRr58jEVXdFMdoIAOz6V57kYb+I1xoOpkp781HXymBJBTx26AR7fnHkXDN4jDDFWynhZHGTySNfPuPxJfp9D11L4W/MlfdrM9TVW2mgmakprjAaSaSmYENSRsXZg/Ybh5Q3IxI346h9D9RU11tywJR1VPVRFXqAKUx0VIjfRTpI31yBSpJGRnOccDS1lDBarL1JYy0qxWqqUUJVlDLSVKbo4NxGQoczRDHCgZx5dXFFVPbr/YrZAVNBabYlVWbf+NJUzfLpkccbVnbnuT9tKlwFvk2VMxeM7GAaTJwGyQOQMHXCmimSqMbOPDlyTn0xnynVZSNVWqompKs4ljO3crbgQeVYdsAjn8cj01bQTFnjGxpRMnBYhQCDwCO/8NSuaZVd0W5mUx5CBNgBx6DQ0fk3kBV7/wCuuUMYZUaMsFH7Dgg9/vpFkKoRuAyDwSW+/Prrov1MiGzoZ3hlVHBHmUgkFfv99ARaIMKdvEHcBz9+2fb/ALa4TSLDCXk3OC+MRgfh27/9tQ552VFUb02kMxSMv+WsW6NFGy4mqFCb5Cdh7j0/lrx7pG8WK9dHWm4dTdf1sV0qoVmr6ZeoUpP1hyDFsQqyKOQFBB4516VT1MSHd52YAbmYeYe3GB31Dqun7ZNN40drpJpmYl2W3xucn1PlOR7n7ajc7tFKK4ZBtF4+H/TtrNvsN96do6QSGVkS7xZeU/U7uzlnckAFiScY1Jo7/ZalxJL1DZzIVZ/1NxQAOcD3IIHoPX8tJN0lZpkcVdjty5O3L2uJWPH3Q+mq9vhh0nOqNP03ZagkAFjbof48J20m22NRVcmjprlaXULDcrfK0L/qm+bQspHYrk8kc6iXWOWskjamvVPHMT4jiniiDTjGOe/PGcgDv7dqiD4W9KLtcdG2SaIDa7G2Jx6ZUhefw0D4ZdExIJZukbMi7CcGhCj7nH+/TTTltFUbLixX1bzRCtSL5SmMkoVA+8CNGZS5b8VJOtZBULFThnUptUEjk8fj69tUNJTU1tpoqK3xwQU8aLHFBGnhxoufpAAx/AabW3WiSaKnr6yCGSo3KYWqkRuxyNuc/wAs6qMtrbJcU8F48ixR/qt2GPoNxH5fj/PUUieN3eeRTGSMIo9PXg8f79dU6XJt8UqogjUhMiUcI2O45H37841biQyyqN5kiZQCQOzAjA+51W5SFtcR7qvhkh/FDL3254wT39uNVEkBMIDzHk8KQSpOcg49NW+HjV0PbdjI7Hk/4dtQK6JUxOGIVfIBu8uT6/f89TJDicBOxgllZmZjgcDA+xHpnnWQ6zob9LTWw9OslVLT3KGqqre9V8n8/CnIiExBCncFJBADDI1pdjP4iq779oUrnGPUDjvnWb6WuxuX9Ir0kqS269XBaSi3SHK0lOfl45FGMDdUGV8nuDpQVsqTpDImla60lSRBUx9YWl5ZRSjbGlZEVdGGexMZaM55PgrnVZYKVL7Xpc3kM9ntkskdCQvlq6gu5kqsfuBmaOP3ALeo1Pnbwqa7JhjLQzNDQoJNgBuQjZh28pU+Jg+gftojmnorvDF05SJPFRUIio0lqsU1ExZ1eRx/xfIFRMgklXxgbm1bz8iFaRH6qmVutfhjSDxNkd2rq1yMbiIaKXBG7juw/DXs3SC7el7QNwfNJGQQc5BGRzrwm7vFW/FC1xgn/wBl6Srq12J25epkSFDx9g+voe3UvyVvpKXAHgQpHwMDyqB/lrq6FO2/PMGHVYSRKGl00adr1keeGm6dpuhgeddYww097pKmoKrClQizHA3CGXAP/wDpTz+OuFLRpNQ1lpuXngVzC8ZbaQQchgR2YHBDDkHBGrT4h08kMdJX0kLzTbvCYKcAgAsM8H0Drn+/76h1BjqLpTV0autHdKVJ1DKRiQDBGCM5xtOvF6iFNtev/f7PS0JWkn6f8/ozlbTir6lioeoKhaeuuFvkohUqmyO4BHEkMw42rNGTIWQjJ3ll4ziNQM9z6n6ygQb6tbBag/OCJIpqvcB9wwGtBV0UvV9mq6ejmigudDWytRK31RVFNKfCl5HOdvmA9JCOdUf6QiX4h9M38Qmih6it9Ra6uFxtMVUriRUYjud6ygH1Lfcayabps0TSteY/ovro6yUUF2hRXESh9pGc0zkHJ/8A45D+SsdT7PUxwLsmCiZ2wecEnnA49Mf5aiWuoWh+Zt0wDJQyss8bMxLU0nJGD34J/hqupIpqUzUi1EnzFNI8QIiG1irZBJPfcMH/AKtQ3xJeefsXFcxNvBIhC5JMQGwZ755/lx/hpKt9sRMXKkZyD2Oq6mqMuVdgoXAKb+Vz6nA9P89SZXSop5ePMBjhipHqPuO3560UriRtpmA+KLyx9HXCvoasw1NpT59PDdkD+EC0kTFSDtdCykZ9c+movUNkka/fJdMUlqpo46KKokkudVXS7t7thVWOVQAMZJOc51N+IyifoDqoYDMbRV4KcZ/Ut7/fTLr1JV0bW+gsvT0t4r3tVNVVFTHVU0DRxlcKqmXIYkhuAPz51lF1fnqXKN0SunOpWtllvlF1JQRQmxLG0q09Q8sXhSK0gniaTzjOGzG54KYBII1DhtlvXr0S1VJBUJdrLNVv4wJaOWnMaBkPdQ0cgBHbKg++aiO0X+/QyW+5UMFjs9bVLU3QyXE11bcWXAWOSRVWOKPCquFz5VwMZJ1pTn/1H6dLKrKLHdCcHn+0phj8OcDT3uTWRKG2LwZ2ySdRQpQXCKlsM1z8I1Rt58ekqoAdoYo0skivgOoO5VBLYyM63NvndqA1LW+aOoaN5ZKOQ5bxQpPh5UkDJGOCRzrEQ1HUPUFXZbncrVbJYq2qinkq6SVxUUcKOWEcpkJ8RSAP7PA3Y8uOdb6Nvl5jJCreKwzkHBIBzkg/j30NgkYiw9M3DqDp/pq+W96G4XK4UK3C63a5NNUiOUhcQwU6SIEQFmHGAqoMhmOdW9oq7tSXb5K728xmuYK9ZQtLV0lQUQ7TufL0xXHKt5TnhmPGiOy3jo2onq+h1hqKGeRqiaxVM3gqJHOWkppsHwyxOTGwMbE5BXOr609TW3q2jneNZrbcoJxTz088fhTQzkZEcqjykkeZXB2sCCNapJ8YZlde6Mx1HXVdde6Hpq01cls+Yp5a263CEDfS0UeFIjz2kkkYIG52qHbuBrO9OdONeaVq7pSk6dsFslYihWtsv6QqamLkeLUzvIrecAsFXkKRzk41bNI1F8QL20qoIrj0t4cUh4k/Uyyl9voeZUyPuNa+xQtQ26OkUOyxQoiB0xgbBjj8CP4650n2OjHch2i40976NmSqtkdlu1nrDQ1dPSEtGk8JBCqxALI6srKSM4cDg51eUxYwI8hxIwyAvZQ3cc+vr/LXnNXczbqD4qVkMjBpb7SUNGVG3xKoU1NGwXHfzHH5HPIOvQopFCJtWMpuIkXtsx3x76uUtzT70RFUmvc6zTOJURm2KfKcHufsO4PGuMy+NTDCqMNuO45wfvg6WaVY6kxSpKyTAck8AZxn8BpjIHnYRZAUlBjGF98j10h8GT62rauG0C2Wfw479fqn9GW6TP8AYb1JlqG9xFEskn4hR66lXihprN0tLSWCnMdNQpQUNGhJyqLMixoDjudoye/m1DtLC7/EO+XfI+R6YpFtlMSmR83MqzVUmB3KxiFPfzMNSuqri9FQWmMEyTvWNcZsKUDR0yeIox380ngKB6l8apYollPLJPV1letukRWvF0qHaRkR/l6OmVaTegx9bMrhSeBkn05u6K3Q2uh+Wt8YjXsPNuLMRjczHvwB+AwBgcaoUp620zrQ2yAVVctPBTPPOSsFJGqszPIe8sryPLJ4aHgFdzLq3qupKSg6fqOpJoHpKCjoXrHEzAt4YXcu4DjcwwcA4BfA7amX5SocmS6a33r4l9UTwbJKaru1usSndtLJRQ+POBj03SH8SuvpTXhvwE6fqaa3WtrogFZTUTXCsZhhzW1rtI4IIz5V8uf8hr3LXqdFHbp36nF1UrnXoKNLpF9dLrvRxhpunaT10AV17oGuVqqaaFtkzKGhb2kU7lP/ANgNYe3IlRaTTElq2jzcKXcWJMbfWuT68tke516Rrzq+VNV0p1R81Tq0lLVK04QMANgI8ZOfUEhx2zub21x9RFVufHD89mdGjJ3S+aKOnNQ9+vFNbnCVjSxXWiKPtD+JGqSJz6M0TDHplTkas7zZqf4gdPNDRyiiq5ZfFgkVNslLUxtuD47eIrDzr+0Bkeua7q5DbpqXqC0ETQUKfNRtEmTLb5ceJtHqY2CyAewx66npUJQ11PeIplFtuQRqt4n8sM/aKf8A5WyFJ+4z668yL2txkdzW5bolZa+q/wBKQ09xucIpq+Jza75BHyqTYysi+pRgQyn2Yeuu6Tl7hOhV/ELRB0IOQwQDkf8AQCfz++uXWPTxpamW+2qAvFND4F1pYRw6qd2B7OrEvEexJZCRvXEG01cMdZNWyVEVQKyWn8CVpQFnaSLgqPc84B9ATxqJKSdMuO2rRuqaINvMjFGkB8vZmGBluO+lCmGF8K2WJZie+eASfftpnjzUX6lqdxKjhNpb1x3P2/D8tcxUSTJIXaQRMv1bcYJ/veuPfRaQlkyXXFNX3LpC+0FhpjVVdRSyU0KM4j3CQbGwWwAQrMR2BOOcai2aumrrgiSdIXGyJHQxUsVVNcqWZVji4VDGjE85PI9cemtcUfa6QsNybcmU7iV7cj3wD+eNVZXwGl8WeVweRkjgYx2AH8PfWeUapJkiNRgsiM2TjAbgfc/541nK1r3SdaS3aHpma8UkNvNBQNTXKnh2+KyvO7iRgdxKIoUDACE5JbjQKzRS00QK/LPGzFiM4b0BPbtpKe50ldcJoqcy/LU8wo/nBgxS1u7BgQZyxU5DNwoI25JzhxTfBMmlyUcdxvkNGKdOjKm3ooARaS70QMSYwFUuze3fAOTxqx6Ugq4KOSG8wvTwvPIiUhrPmjTwMACGl/bdiWdiCeWxk41X1HXVopDFU1hhpbNMzinqp6krJVKhKtLHGqNtiDceJIUBzntgm7udULS9Dlo6umrJzsn8RYUihSNnkklZuFVAvPfJZcd9aVJoz+EobNeurbJ0vbbdcukZKyG10iUZlpLjSyPIEXAlSOTBGQoON4PJ8uqyjoLxep54FobtaY62enkud0u80AqHhhyUihihLAHzFSxIADE8nAGopr7YVoTc6urpzb/HaA1tLWRVce7YWKkRN7A+mQBk4A1T2zq8mph+atlRBTMqSy0tDQy1k9NBIu6N5mT9XGzAA+GNzANoe68sFtzSLTqmzVF2hp6yyVa2+9W6ZqigqCN0e5uHikXuY3XhvUYBHI1V3HqvqGqpvla/prqK0VwQLJU2SlhuKzL7JLvG3+6XQEAjPbWqSvoZqVKqRp6WF1Df1mExSAHsSvcatIKZXpy8L5TGC4b6x340leUPHJ57aOk6+tkt7XW3GxWWzu89stMtSKionqmJLVdXIuQZMsxCgnBYknsBvQ5kMZCKSoJTcnYn1/HGNSo0VGIkZFZyQr5OW9dRKmNVJchVdTxvJIz7cc6T9Rp9iPLUSGRy2EXxQow3Ye5/HUmk2mUPlY4CQWBUnn1z/wCPTUOOXzu8f7XOMgZwO2fv/LU221FNXwXFKCohqZqNjDUxrIH8CYpnw2PocEHHpnnGdOKbFJpIx/w5hEnRtrkwRUdQVtRdH2g+bxZ2kXP/AEeEPwXXahb+kt7q7iicSbUtzsAfBo45Dmce5mmDeGD3ESvyF1WWSakpeirLaUqJoIYen6VrlPGzE00BiVniTn+3l3YCjkK271QHQ0dBU0tF8tLGlNc7oyS1iRjy0qYCJCgHAEcYWMY43b29dWvhVkvLpETqCd5bbUw0+DJVFbZbjnlmlbwy4+wy5+4TPrrNdbJBdbrZOlIBstbyfpK74HlW3UuCiN9pJRGn351oGqKa5X2qrXZaeydOCSNZC+IzV7CHbngiGHdz+849V1kPh9C3W17muZGyq6lmjqXQHPylmg/sIiBwGlLeIQe3iLxqFFzkorzz/hdqKbZ7j0LQS01hSrrtprrkxq52Hu/KjPsFwNaXSKoUBVAAAwAB20uvfhFQiorseRKTk22KO2l0Dto1oiQ0h0ukOkAmqy+203KhxAsTVcDeNTeKMrvAIwfswJU/Zjqz0alpNUxp1wefdM1C3C1GihDQ1MMsklEkw2tGckPCw/ZwdykZPY+gGsdFJF0K1TT3SAS9EzllJcFv0PI2Q0coHPgE52t2QnBwMHW36ztT2+YXSiZoKeWZWqXVsCml+lajH7p4V8dvKx4DHUydP0nSy11KjCZAYq6BowS+BgnaMgn7eo/DXkauk1juvuv6PQ09RP8AX7Mo6K4zdPVC0NS5ngeA/Jzk+JHVwY3BGPILqP8A7KeOQdZW92WnoOnnuVsllpKeK4pNS1FPKcwq8hGBkfSYp5EwRjIIPpqSnR8lAskHRt4jttA4WRrTUQfN0iPniSJdyyQ85PkbGeQBrhDNeqGlq7hU08N7slcj01ylsm9xvH/5C00oLOdo8xjdtwAYAkawT3KuyNmtr9y9ttdTWepqLPcpKtqaGmgnoalz4sqREeG5kJ5bEq5Y9x4g7Dtf/KrNTq9JIlWrxh1WI+ZkJxu2dyCR6Z1XV9u/pHa7ffOkayleqpy09HJuJhcOMSQyEZPhSYwT3UhTjK41U2yvp7iJZLVDLQVtFITcbLV/2lPKRkEY7KcErIh2sORntqnj8yIjnhlw8ciTHLqvnyQMjIGe/wCeoLwSyIwyxByf1igDB9Dz31PgvkNVJT013jlWolUiImPM2R3ww4lHYYwGGDrtV0Bg2O0qNBISYpowSG+2fQ/bvrNwxcco0jPsyLSwCMgSp5gcKM5xx3449MazUMQob91BFRL4MbdR2uRgnABlp4zIwx9JY5J9ySfXWshRpFBZmwfTAwPf76zKWvqKG/XiqW22asoK+609UszXN4njjhRI4x4fhHJCrk+bljxgaUUErZmqHqK09NdPz0XUYe13qiojal+bppVpa2kQybZEdVIKkMHbucqQQODq0qqWz0UFNBfNl9tXTdjpqyEygNHI6xlVkC9izqgAzkcj11ZXZOp4f0rbVoKXqO0V9ZJOsrXtqF1ibH9XlUxt5ABt/VkZXuMkkxKzp+5S2O5mpejr7/cKumq6pMtDSskMsbJSxEglUCIVDEckkkDOAcAsszN/tE1FYupRXiOKopaNai5tGnkFbWMnzD7R6R06iJcc7Sfc60926iuVu6oulVbKS3Gisxoo6pQriaoSoKgshB8MBSQdhU5x9S8asLdTzXeO/N1Lb6eA3aqcVNJBUmZVi8JYypkAXJIBJ44yNVcVm6lpLfT2jxrPe6GlqEliqquWeCpYxtmITpGhE+3Ck8ruKgkd9O6doKxTNjDVxVtTWrChhkp6poKiNGJQyLgnbn0IZTj0zj01awRw09BHBKrSYBHcPgfu59vuNUVioEtdAKeeZ615XaeepdcGeZzlnwD5fYL6AAc99Tpaultlsqam6VkcNvp0ZqieZtixg98nv9v4AaE8iqkd4445KzMHiEjACjzZXvgnHYZHHfVJduo7VaapqGrq/HujEbaGlQzTnPYGNfpH/MRqHUT3C/U6maoqukul3TyRxKI7lcFPr/8At4z6D+0P93RDHbelLTVPBBR9G9PxKWqZBHipmGf23OWJbnlssSQACdOkuQtshVt8ulLAK/5eKgCzxU1PQVKrNPVTzNsTxMHbHgEvsUlvJliBkGmoqSK2X3qyutLVTSSVslHaqH5nEElxqV2ySBMcEmMuWOdq+IQNWFFWS116pLtcKGeMUqsLDYlA+YQMMNV1I7Ruy+UFyBGhP7bFQ+iq6KlBt/TFPNebpTwtFXVkNUIaSmmcZmlaoYEK5HHlV3CKBhcnLVCaLOgtttoEoqO1hrjFQbQI4/8A8mqGMEg5wikB2J9VhH7ABZHU1t4q6iydJzpJc5H23e743wUH91M8NLj6U/ZzufGcHhbrB+l7RQVFbd3ls9RFtSC1KaSCZFOCpkOZ3XPruUN3xjUu7dRf0MtNttnSlqgnvFezU1htcK+FBvAy8sm36YYwQzt3PAzk6azL4uA4jgputqG11Bp/h5aVaLpqzUqVnU8wy7GnL70pCw5MtQ4LOe+wMf2xn0joLp9rdS1d1ro0juV3dZ5UWPZ4MeMJEB6YH+OPTWI+H3RtPWSiMztdLdS1Xz1wuhcg3m6FgWlIHBjTaAq9gNoGQNey69Hp9O29R9+PPPucWrOlsQaNGjXacw7Ro0aoA0h0ukOkAmjRo0gGyRpLG8cqLJG4KsrDIYHuCPUa83niqehL3SpG00ttqpFho5CAwC84pZDkcjJ8Jz34QnIBf0rUa426lu1DUUNygSqpKhCksTjIYHWc4b17lwltZlpqKnqIjc7OviQyc1FMV5jJHPl7/iv3yNY5aKDpxLatJdL+aepmWjpWW6KIqYYJjiww2sDjau8FicLu7A2lRU3H4e1qLXTRyWqaQJBdKknbgkbYalv2JCcBZj5W4DYbBe7rqC1dV0tfS00KTLKuyut86+GXHHI/dIPZl4yMggjOvKnpNSuKp+n7o7o6iaqXHr/JlKaGpsglns3UNXQed5HFbaYpYpHJy29owrEk9yDkn3xjT3ai6yeOe6L+h79RQ76a9WmUkIhOSCHUEofWORSPz51VVMtw6RJmv5r7na6c4ivUAJraNR2SqjHMgA/4ygkj6h+0byhr6m5061VpqaG+0Mqlg4IUkH0Dp3Pvx+OsFOlXbzzBtsbz558ygqbtNSwyWvquGnr2ODHdLaPEV8ZwWgY70b7qX/LGtB09eUmqPk/nEuNuqsMSsmZon/vgkNwRwSA3oc8HRLLAwY3S0VcbYI3JFHWKOBkFSM449u3tqoa19KXGVTWQQUrrx5RJGoU84aN+w/5CPwPbQmk7TBptVRe3i6L0/W26krTHDJW1hgaSaTZGoVdxCnHMjD6E/aOeeOZi1STQpLSo7wnJVpFMZI3YwVPmBPfnUGopxPZ6WyV0c1woZoBCtYo8ZHjHODg53KcFfpYEcE6s6WnkkpUNfKJbhCNk74WMTFcgSqc43MoUsuR6/nW28IlSrLI8m+dGG1wpAA82Oc66RoWaQEqMMSrIDkceoPrx6akSUjxASGOQQsoO/buU59cjXBkXxPEDNxuLenOP/H8dRta5LTT4OUVM8RfPLOzPkc5J9h6DTzAhcRSoz7gudxIXjnPHrp00kdNAlVW1EVHRqPNLM4VQTnB3Egds8aqYOp/0mIU6Qt9VfJnxsqhA0FAnu7zuAGUeybi3Ye4FGwcqO9kv9Jcq2ekcLFc/nJ4YqRGLyBIW2NJNxiMElSoychl5JJAoEvlDeLhBdrxW0MVqgqZFsUdZMqo2zKvXMhOZGLBhEMYCjcOW1JIpretworTfaeWoqpAtxNvdKi5THHmUAELB9T5dicFieCRhaIRWarEzWimscTRr4aLunmOOFyqDJO0ADHlGMbjjVPHBCy2WqXyCqqHnsFHVX6pUZFbUf1emU54JmcYIH9xXOs9P05crzdqevvt5WvqKd90C0ke2CjkP7canI3448V97DPlCauUulPMrTQ2y79RTOx/XViJDCuPRFkIAA452k/c6r6q6dQ17ThP0ZZKdMIzsDVyDHcr2QEe+cfw1LaLSZCqrBURf2laYqIktJHaKr5YH+9NVzHxJDyT5Qo9DqM1RS1EtNb61blV2138Ok23VphMgI3NH5VJQYG5yQq+hJwNMp7pRVUhTpmnl6sq6fy/O10w+Spm9csoEYI/dRXb8O+uFTcxZK5qGiMvU3WVxUGTz7PKOQZG7U1MgOQvcjnDMc6V+hSj6kyv/AEd0dumi/TN6ul0mWnoqRqx56irdVO2CPdwsagksxGFHLE8DSdO9O1N8v13oaiVau/VUaR9QXOMEU9FACGSgpAf+GDu3ZwXILNngCJ0z09WX2vrYKCqFwvlSTDd76gAipIAc/LU6g5jT+5w7nzPgd/dOn7BQ9M2uK3WqMpDHyzOdzyOe7ufVj6n8hgADXX03T7/ilwcutrbfhiS6ChprZRxUlvhSnpoV2xxoMAD/AHzqRo0a9c88NGjRoAdo0aNUAaQ6XSHSATRo0aQBo0aNAHKopoaynmpqyKOop5kMcsUiBkdSMFWB4IIOCDrzKu6Tr+iJlq+nUq7pZI1CinhPiVtvQchYiTmeAf8AxE71HCFgQg9S0aznpxmslRk48GCtvWlrvtPTz+OQHUxxXKnU7ZHBOV24yp90YAqcggYzrPXr4d2pKuS5U9PU2WrmJzdLBUmm3+7SIAYz2H1KfxOthf8A4f0dzrpLtZZ3sV+baXrKdcpUbfpE8WQswHucMBwGGsRW3nqboxqmTqJjaIS29bhTxNVWxuclSAPEpgSe7jaCThzrg1dF8y+q/dHXpai7fR/sco7D1PGYxQdfNPDnyCusEExX7lkZMn7402627qm3Wa43C5dbtPTUVO9TLDbbBCszKoyVDSO4HbjjjudaOr6ksk9JT3OZZqKnqpFihqaMePHI7euI9ysPXIwcfft2o45JAKi01UVypt2zdTtg5HcFDyD+frri/DkuMr2/jk6t6fLr5+UecUthh6r8MWurivYjjQ1N2rri9bFFIcnZAsXhxsQuCSFX6sFvTWwpeiIPC/rF+6gnqNq7ZILo9GkYA4WOGHagUexDfcnVqZTSAQvCKOPlRGEEQBPfjAH3/PXO4XGsgtVbLZKb5ysijzBC692yACRkZA77cjOMeupTiU1Izl4qb10DTG4/0yp56WRgkVLfqfM0z/uxTU4WRzzgAxv+GnX74i01PYra/UdRQ9G3y4Royw10qyVKbjg7oRhR34Z8AcbgNZu32m/3S4TS0VEbfVSSATdT3uBZq+Nc52UsJJVcehwiL3wx1tunulrH03TVKUVIZp67K19ZXsKqprSeMzSuMsP7vCj0GrU3tpMjZm2ir/oFfa6dKmkmt7IwRjdrmgulWAB5TBBxBAP2srvznJGrST4c2qrxP1Hcr51BV4y09VdpYSpP7kUJSOMf8q6pp+nK7pR3q/hlUxUURctLYKmcijbk5enbvTuf3R+rbsQO+tBaeqrhdY4aW8WS401XuZnrKiKJECYzyUZlbJ4G3P3xydO4NV3FUuSFU9IUlup3WSz23q63KmTR1tFEa1UUdoptoEpA7CTDMf29UdksfSN4p2l6Cu94smI1lnSz3J/Ag35KI8cm+PxAB5kwCp4Pca3QqnmLBNzN2GzJ/wBNYrqL4ldN9Phqe63ykinYn+qxEyzs3qfDQFixxzxqHNPBag1yzrJ0xeiRHL13d3RQMN+iqTf+O4Lj+Wq6t6X6etNC1w6tuM90hiOWnvNZiAf/ANKhY2P2wTqun6u6ivk8cdjtIsNPUA7Lhf42QtGvDSJSqC2BngucE4GM6g9PdP03UVYKq0xVvX98WTwzdbkgWjo2GQwRGHhxY9MCRuOAO+pjpym6iinOMFbZNl6kr+oKEN06v9G+mVjbF3nhWOSVFOD8pTnHH99gFH21YdGfD6s6iprpQUdFN050lVSLIbi05evuwIBLlz5gc5O84XkbEOAw9E6d+GccEsVf1jWNfrkp3iNyxpomxgEI2S5A7M5OO4C63+vT0ekUczOHV6lzxErbD0/a+l7TT2rp6hgt1vpxiOCFNoHqSfUsTyWOSSSSSTqy0aNegcYaNGjQAaNGjQA4dtGgdtGqQBpDpdGgBujS40Y1ICaNLjSY0AGjRo0AGjRo0AYK7fCDp2srXuVjWo6Xu7HcayzuIN7c8vFgxv35LKT99ZCs6D6xsj7oaKx9VwJkLPSk2quG7udvmhfuQQSgOe2vbNGsZ6OnPlGkdSUMJnhVT1nPbZaf9Oy9TdNxwU/gNHd7UZaXcMYJmpwyOvcZLAg88jjXNesoq5YHs/U/TF4qZ8/1f5iODYM/SeQ8nZsdid2ey+b3ntqkuvRvTt8cve7BarlIe71VDHK38WBOsZdM3/6+uS46tdvpg8nluV9lt0UlFQ0rTyyEIpqsJgD1bb5SR2B9sZOdc56nrBK6qpKey2iRopIg0k1dJGG3AbFK7CMg5ztODjuNbWo+Bnw8qBID0tRQCT6xTM8Ab8kYacnwT6Kjzst1coP7IvVbj+Hi41h/hv2Nv8n5/U88pq3rOrmZnl6Zo4UkcSyJFVVGdhwRtZV9eR6Y7dtF0W4UESzdSdeU1sjaPxDFardTwbx9nqGPmyR6YH469GPwV6GkcvUWIVTZB/rNXPOMj7O5Grq2/D3pO0SLJbOmbPSzL2ljoIw//wBsZ/noXRPu19AfU+i+54DUUPTV+2Gkfqjr+o8RWlieuqXRODnAp1WIHkDJYD762XT/AEPf6VlHSXSXT/REGV3VM6K9SyfhES2cY7yD1yOde3gYAAGAOANGNbw6SEecmT15vjB55bfhDbMB+qq6t6lkzuMNTIY6UHOc+Ap2t/1l9b+np4aSCOCkijggjUKkcahVUDsABwBrrjRjXVGKiqijBtt2xNGlxpcauhDdGnY0Y0UA3Rp2jRQCY0Y0ujRQBo0aNMA0aNGgA0aNGgA0aNGgA0aNGgA0aNGgA0aNGgA0aNGgA0aNGgA0aNGgA0aNGgA0aNGgA0aNGgA0aNGgA0aNGgA0aNGgA0aNGgD/2Q==" alt="Moneda chilena de un peso de 1976" style="display:block;width:76px;height:76px;border-radius:50%;object-fit:cover;border:1px solid #b6a17b;box-shadow:0 4px 10px rgba(71,57,34,.25)">' +
      '<div class="es-coin-arrow"><span>SE REPARTE EN</span><b>→</b></div>' +
      '<div class="es-peso-items">' + items.map(function (item) {
        return '<div class="' + item.tone + '"><strong>' + pct(share(item.amount, data.saleTotal)) + '</strong><span>' + esc(item.label) + '</span></div>';
      }).join('') + '</div></div>';
  }

  function detailedDistribution(data) {
    var items = distributionItems(data);
    var colors = ["#57728e", "#ef6b3b", "#2aa876", data.netProfit >= 0 ? "#d49a00" : "#b8412b"];
    return '<div class="es-distribution-detail" data-section="distribution-detail">' +
      '<div class="es-distribution-bar">' + items.map(function (item, index) {
        var itemShare = share(item.amount, data.saleTotal);
        return '<i style="width:' + Math.max(0, itemShare).toFixed(2) + '%;background:' + colors[index] + '"><small>' + pct(itemShare) + '</small></i>';
      }).join('') + '</div>' +
      '<div class="es-distribution-cards">' + items.map(function (item) {
        return '<div class="' + item.tone + '"><b>' + compact(item.amount) + '</b><span>' + esc(item.label) + ' · ' + pct(share(item.amount, data.saleTotal)) + '</span></div>';
      }).join('') + '</div></div>';
  }

  function paymentJourney(data) {
    var receiver = data.mode === "broker" ? "EL PROPIETARIO RECIBE" : "RESULTADO ESTIMADO";
    var sourceDetail = "Venta de " + money.format(data.lots) + " lotes" + (data.extraIncomeTotal > 0 ? " + ingresos adicionales" : "");
    var resultDetail = data.mode === "broker" ? "valor del predio + margen neto" : "resultado después de costos";
    return '<div class="es-flow" data-section="payment-journey">' +
      '<div><div class="es-flow-source"><b>EL CLIENTE PAGA</b><strong>' + compact(data.saleTotal) + '</strong><span>' + esc(sourceDetail) + '</span></div><div class="es-segments">' + segmentBar(data) + '</div></div>' +
      '<div class="es-flow-arrow">→</div>' +
      '<div class="es-flow-rows">' + flowRows(data) + '</div>' +
      '<div class="es-flow-arrow">→</div>' +
      '<div class="es-flow-result"><small>' + receiver + '</small><b>' + compact(data.resultAmount) + '</b><span>' + esc(resultDetail) + '</span><strong>' + pct(data.resultPct) + '</strong></div>' +
    '</div>';
  }

  function scenarios(data) {
    var list = data.scenarios.length ? data.scenarios : [{ label: "Base", result: data.resultAmount, months: data.saleMonths, detail: "Datos actuales del proyecto" }];
    return list.map(function (item, index) {
      return '<tr class="' + (index === 1 || list.length === 1 ? "is-base" : "") + '">' +
        '<td><strong>' + esc(item.label || "Escenario") + '</strong><small>' + esc(item.detail || "") + '</small></td>' +
        '<td>' + compact(item.result) + '</td><td>' + Math.ceil(n(item.months)) + ' meses</td>' +
      '</tr>';
    }).join("");
  }

  function timeline(data) {
    var points = data.timeline.length ? data.timeline : [
      { month: 1, label: "Inicio del proyecto", detail: "Preparación y lanzamiento" },
      { month: Math.max(1, Math.ceil(data.saleMonths / 2)), label: "Venta en régimen", detail: "Avance comercial proyectado" },
      { month: Math.max(1, data.saleMonths), label: "Último lote vendido", detail: "Fin de la colocación" },
      { month: Math.max(1, data.horizonMonths), label: "Último cobro", detail: "Cierre del horizonte" }
    ];
    return points.map(function (item, index) {
      return '<div class="es-time-point ' + esc(item.tone || "") + '"><span>' + month(item.month) + '</span><b>' + esc(item.label) + '</b><small>' + esc(item.detail || "") + '</small>' + (index < points.length - 1 ? '<i></i>' : '') + '</div>';
    }).join("");
  }

  function alerts(data) {
    var list = data.alerts.length ? data.alerts : [
      { tone: "ok", title: "Modelo completo", body: "No se detectaron alertas críticas con los datos actuales." }
    ];
    return list.map(function (item, index) {
      return '<div class="es-alert ' + esc(item.tone || "warn") + '"><b>' + (index + 1) + ' · ' + esc(item.title || "Punto a revisar") + '</b><p>' + esc(item.body || "") + '</p></div>';
    }).join("");
  }

  function glossary(data) {
    var terms = data.glossary.length ? data.glossary : [
      ["PVP unitario", "El precio de venta de cada lote."],
      ["Velocidad de venta", "Cuántos lotes se espera vender por mes."],
      ["Margen bruto", "Venta total menos el valor del terreno, antes de otros gastos."],
      ["Margen neto", "Lo que queda después de descontar todos los costos informados."],
      ["Pie", "La parte que el comprador paga al inicio."],
      ["Caja acumulada", "El dinero disponible que va quedando mes a mes."],
      ["Hito", "Una obra o pago relevante ubicado en un mes del proyecto."],
      ["Escenario", "El mismo negocio con supuestos distintos de precio o velocidad."]
    ];
    return terms.slice(0, 8).map(function (term) {
      return '<div class="es-term"><b>' + esc(term[0]) + '</b><span>' + esc(term[1]) + '</span></div>';
    }).join("");
  }

  function pageTwo(data) {
    var broker = data.mode === "broker";
    var subject = broker ? "usted" : "el proyecto";
    var idea = broker
      ? "Usted aporta el terreno y la empresa se encarga de dividirlo, habilitarlo y venderlo. Con la recaudación se cubren los costos y se le paga el valor acordado más el margen proyectado."
      : "El proyecto transforma el terreno en lotes comercializables, financia sus costos con las ventas y busca obtener una ganancia neta al final del horizonte proyectado.";
    var steps = broker ? [
      ["Se aporta el terreno y se fija su valor", "El predio se valoriza en " + compact(data.landCost) + (data.landCostBasis ? " a partir de " + data.landCostBasis : "") + ". Ese valor se paga con la recaudación según las condiciones acordadas."],
      ["Se divide y se habilita", "Se proyectan " + money.format(data.lots) + " lotes y obras por " + compact(data.worksCost) + "."],
      ["Se vende al ritmo estimado", "A un promedio de " + number1.format(data.lots / Math.max(1, data.saleMonths)) + " lotes al mes, la colocación tomaría cerca de " + data.saleMonths + " meses."],
      ["Cada venta se reparte en el mismo orden", "Se cubren comercialización, obras y pagos del predio; el excedente forma el margen del propietario."],
      ["Al cierre se liquida el saldo", "El resultado estimado para el propietario es " + compact(data.resultAmount) + ", sujeto al cumplimiento del escenario."]
    ] : [
      ["Se adquiere y prepara el terreno", "El costo informado del predio es " + compact(data.landCost) + " y constituye la base de la evaluación."],
      ["Se estructura la habilitación", "Las obras y costos operacionales informados suman " + compact(data.worksCost) + "."],
      ["Se comercializan los lotes", "Se proyectan " + money.format(data.lots) + " lotes a un PVP promedio de " + clp(data.pvp) + "."],
      ["La recaudación cubre los costos", "Los ingresos llegan mediante el pie y las cuotas durante un horizonte de hasta " + data.horizonMonths + " meses."],
      ["Se obtiene el resultado final", "La ganancia neta proyectada es " + compact(data.netProfit) + ", equivalente a " + pct(data.resultPct) + "."]
    ];
    var faq = broker ? [
      ["¿Tengo que poner dinero?", "El modelo supone que el aporte principal es el terreno y que los gastos se financian con la recaudación. Si la caja queda negativa, debe acordarse cómo cubrirla."],
      ["¿Por qué podría convenir más que vender el predio?", "Porque el resultado proyectado incorpora el valor del predio y un margen adicional, a cambio de plazo y riesgo comercial."],
      ["¿Y si se vende más lento?", "El escenario conservador muestra el impacto: normalmente se alarga el plazo y puede cambiar el saldo disponible."],
      ["¿Cuándo empiezo a recibir pagos?", "Depende de la modalidad acordada con el aportante y del inicio de ventas cargado en el modelo."],
      ["¿Cuál es el punto más delicado?", "Los meses con caja baja, las obras sobre presupuesto y cualquier saldo pendiente al cierre."]
    ] : [
      ["¿Cuánto hay que invertir?", "El modelo considera el costo del predio y todos los gastos comerciales y de obras informados."],
      ["¿Cuándo se recupera el dinero?", "El plazo depende del ritmo de ventas, el pie, las cuotas y el calendario de pagos del predio."],
      ["¿Y si se vende más lento?", "El escenario conservador permite revisar cómo se extiende el plazo y cambia la rentabilidad."],
      ["¿La ganancia es segura?", "No. Es una estimación basada en los supuestos actuales y debe actualizarse cuando cambien precios, costos o velocidad."],
      ["¿Qué dato mueve más el resultado?", "Normalmente el PVP, la velocidad de venta y los costos del terreno y las obras."]
    ];

    return '<section class="es-page es-page-two">' +
      '<header class="es-header"><div><h1>Cómo funciona este negocio, explicado paso a paso</h1><p>Guía de lectura del resumen anterior · sin tecnicismos</p></div><span>PÁGINA EXPLICATIVA</span></header>' +
      '<h2>LA IDEA EN UNA FRASE</h2><div class="es-idea">' + esc(idea) + '</div>' +
      '<h2>EL RECORRIDO DEL PROYECTO, EN CINCO PASOS</h2><div class="es-steps">' + steps.map(function (step, index) {
        return '<div class="es-step"><i>' + (index + 1) + '</i><div><b>' + esc(step[0]) + '</b><p>' + esc(step[1]) + '</p></div></div>';
      }).join("") + '</div>' +
      '<h2>LAS PALABRAS DEL INFORME, EN SIMPLE</h2><div class="es-glossary">' + glossary(data) + '</div>' +
      '<h2>LAS PREGUNTAS QUE TODOS HACEN</h2><div class="es-faq">' + faq.map(function (item) {
        return '<div><b>' + esc(item[0]) + '</b><p>' + esc(item[1]) + '</p></div>';
      }).join("") + '</div>' +
      '<footer>' + esc(data.disclaimer) + ' Este documento resume el escenario seleccionado y no constituye una oferta, promesa de venta ni asesoría financiera o legal. Las cifras estimadas varían si cambian los supuestos.</footer>' +
    '</section>';
  }

  function buildHtml(input, options) {
    var data = normalize(input);
    var resultNote = data.mode === "broker"
      ? "valor del predio + margen neto"
      : "después de los costos informados";
    var unitSalePrice = data.unitSalePrice || data.pvp;
    var conditionRows = [["Precio base por lote", clp(data.pvp)]];
    if (data.waterUnit > 0) conditionRows.push(["Venta de agua por lote", clp(data.waterUnit)]);
    conditionRows.push(["Pie inicial (" + pct(data.piePct) + ")", clp(data.pieAmount)]);
    conditionRows.push(["Saldo base financiado", clp(data.balanceAmount)]);
    if (data.annualInterestRate > 0) {
      conditionRows.push(["Tasa de interés anual", pct(data.annualInterestRate)]);
      conditionRows.push(["Interés por lote", clp(data.interestPerLot)]);
      conditionRows.push(["Saldo total con interés", clp(data.balanceWithInterest)]);
    }
    conditionRows.push(["Cuotas mensuales", data.installments > 0 ? money.format(data.installments) + " x " + clp(data.installmentAmount) : "Sin cuotas"]);
    if (data.buildingIncome > 0) conditionRows.push(["Edificación · ingreso aparte", clp(data.buildingIncome)]);
    conditionRows.push(["Recaudación por lote", clp(unitSalePrice)]);
    var subtitle = money.format(data.lots) + " lotes" + (data.hectares ? " · " + number1.format(data.hectares) + " ha" : "") + " · " + data.location + " | " + data.company;
    var returnBreakdownHtml = returnBreakdown(data);
    var saleDetail = money.format(data.lots) + " lotes a " + clp(data.pvp) + " cada uno" + (data.extraIncomeTotal > 0 ? " · adicionales " + compact(data.extraIncomeTotal) : "");

    var html = '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Resumen Ejecutivo · ' + esc(data.projectName) + '</title><style>' + styles() + '</style></head><body>' +
      '<section class="es-page es-page-one">' +
        '<header class="es-header"><div><h1>' + esc(data.projectName) + ' · Resumen Ejecutivo del Negocio</h1><p>' + esc(subtitle) + '</p></div><span>' + esc(data.scenarioLabel.toUpperCase()) + '</span></header>' +
        '<h2>LO ESENCIAL, EN UNA MIRADA</h2><div class="es-kpis">' +
          '<article><small>VENTA TOTAL ESTIMADA</small><b>' + compact(data.saleTotal) + '</b><p>' + esc(saleDetail) + '</p></article>' +
          '<article><small>TIEMPO DE VENTA</small><b>' + money.format(data.saleMonths) + ' meses</b><p>Horizonte total de cobros: ' + money.format(data.horizonMonths) + ' meses</p></article>' +
          '<article class="gold"><small>' + esc(data.resultLabel.toUpperCase()) + '</small><b>' + compact(data.resultAmount) + '</b><p>' + esc(resultNote) + '</p></article>' +
          '<article class="gold"><small>' + esc(data.resultPctLabel.toUpperCase()) + '</small><b>' + pct(data.resultPct) + '</b><p class="es-return-breakdown">' + returnBreakdownHtml + '</p></article>' +
        '</div>' +
        '<h2>DEL PAGO DEL CLIENTE AL RESULTADO DEL PROPIETARIO <em>En qué se reparte la venta / ingreso</em></h2>' +
        paymentJourney(data) +
        '<h2>EN QUÉ SE REPARTE CADA PESO DE LA VENTA <em>Lectura porcentual, sin montos</em></h2>' +
        onePesoDistribution(data) +
        '<div class="es-two-cols"><div><h2>CÓMO SE PAGA CADA LOTE</h2><table class="es-simple-table">' + conditionRows.map(function (row, index) { return '<tr class="' + (index === conditionRows.length - 1 ? "total" : "") + '"><td>' + esc(row[0]) + '</td><td>' + esc(row[1]) + '</td></tr>'; }).join("") + '</table></div>' +
        '<div><h2>LOS TRES ESCENARIOS</h2><table class="es-scenario-table"><thead><tr><th>Escenario</th><th>Resultado</th><th>Plazo</th></tr></thead><tbody>' + scenarios(data) + '</tbody></table></div></div>' +
        '<h2 style="margin-top:10px">LÍNEA DE TIEMPO DEL PROYECTO <em>horizonte total ' + data.horizonMonths + ' meses</em></h2><div class="es-timeline" style="padding:8px 18px 0;transform:scale(.88);transform-origin:top center;margin-bottom:-7px">' + timeline(data) + '</div>' +
        '<h2 style="margin-top:8px">TRES PUNTOS QUE HAY QUE REVISAR ANTES DE FIRMAR</h2><div class="es-alerts" style="transform:scale(.92);transform-origin:top center;margin-bottom:-5px">' + alerts(data) + '</div>' +
        '<footer>' + esc(data.disclaimer) + '</footer>' +
      '</section>' + pageTwo(data) +
      ((options && options.autoPrint === false) ? '' : '<script>window.addEventListener("load",function(){setTimeout(function(){window.focus();window.print();},450);});<\/script>') + '</body></html>';
    return html;
  }

  function styles() {
    return '*{box-sizing:border-box}html,body{margin:0;background:#e8edf3;color:#253346;font-family:Arial,Helvetica,sans-serif}body{padding:20px}.es-page{width:210mm;min-height:297mm;margin:0 auto 18px;background:#fff;padding:12mm 13mm 9mm;position:relative;page-break-after:always}.es-page:last-of-type{page-break-after:auto}.es-header{display:flex;justify-content:space-between;gap:16px;align-items:flex-start;border-bottom:2px solid #183657;padding-bottom:10px;margin-bottom:17px}.es-header h1{font-size:22px;line-height:1.1;color:#183657;margin:0 0 5px}.es-header p{font-size:10px;color:#637184;margin:0}.es-header>span{background:#183657;color:#fff;padding:6px 12px;border-radius:4px;font-size:8px;letter-spacing:1.5px;white-space:nowrap}.es-page h2{font-size:10px;letter-spacing:1.6px;color:#183657;margin:13px 0 8px;padding-bottom:5px;border-bottom:1px solid #d3dce6}.es-page h2 em{font-style:normal;font-weight:400;letter-spacing:0;color:#93a0b0;margin-left:8px}.es-kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.es-kpis article{border:1px solid #d6dee8;border-top:4px solid #183657;border-radius:5px;padding:12px 13px;min-height:92px;background:#fbfcfd}.es-kpis article.gold{border-top-color:#b68100}.es-kpis small{display:block;font-size:7.5px;letter-spacing:.8px;color:#6d7b8d;min-height:19px}.es-kpis b{display:block;font-size:17px;color:#173657;margin:5px 0}.es-kpis .gold b{color:#946700}.es-kpis p{font-size:7.5px;line-height:1.35;color:#728096;margin:0}.es-flow{display:grid;grid-template-columns:130px 20px 1fr 20px 145px;align-items:center;gap:8px;min-height:180px}.es-flow-source,.es-flow-result{padding:16px 10px;border-radius:6px;background:#183657;color:#fff;text-align:center}.es-flow-source>b,.es-flow-result small{display:block;font-size:7px;letter-spacing:1px;color:#bed0e1}.es-flow-source strong,.es-flow-result b{display:block;font-size:17px;margin:6px 0}.es-flow-source span,.es-flow-result span{display:block;font-size:7.5px;line-height:1.4;color:#dce5ee}.es-flow-result{background:#956900}.es-flow-result strong{font-size:9px;display:block;margin-top:9px}.es-flow-arrow{font-size:20px;text-align:center;color:#9aa8b7}.es-flow-rows{display:grid;gap:7px}.es-flow-row{display:flex;align-items:center;justify-content:space-between;gap:12px;border:1px solid #cad5e0;border-left:5px solid #57728e;background:#f3f6f9;border-radius:5px;padding:7px 10px}.es-flow-row.commercial{border-left-color:#92a4b7}.es-flow-row.works{border-left-color:#c9a32a}.es-flow-row.profit{border-left-color:#b68100;background:#fff8e7}.es-flow-row.risk{border-left-color:#b8412b;background:#fff0ed}.es-flow-row strong{font-size:8.5px;color:#183657}.es-flow-row small{display:block;font-size:6.7px;color:#6d7b8d;margin-top:2px}.es-flow-value{text-align:right;min-width:80px}.es-flow-value b{display:block;font-size:9px;color:#183657}.es-flow-value span{font-size:7px;color:#7a8796}.es-segments{display:flex;height:7px;margin-top:12px;background:#dfe6ed}.es-segments i{display:block}.es-one-peso{display:grid;grid-template-columns:82px 58px 1fr;gap:13px;align-items:center;min-height:82px;padding:4px 7px}.es-coin{width:76px;height:76px;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;background:radial-gradient(circle at 35% 30%,#fff2a8 0,#e5b83a 38%,#b77c00 100%);border:4px double #8f6300;box-shadow:inset 0 0 0 3px rgba(255,255,255,.35),0 4px 10px rgba(111,78,0,.18);color:#513600}.es-coin small{font-size:5.4px;letter-spacing:.8px;font-weight:700}.es-coin b{font-size:24px;line-height:1;margin:3px 0}.es-coin span{font-size:5.8px;line-height:1.15;max-width:58px}.es-coin-arrow{text-align:center;color:#8492a3}.es-coin-arrow span{display:block;font-size:5.8px;letter-spacing:.7px}.es-coin-arrow b{display:block;font-size:24px;line-height:1}.es-peso-items{display:grid;grid-template-columns:repeat(4,1fr);gap:7px}.es-peso-items>div{min-height:56px;border:1px solid #d4dde7;border-top:4px solid #57728e;border-radius:5px;padding:8px 7px;background:#f7f9fb;text-align:center}.es-peso-items>div.commercial{border-top-color:#ef6b3b}.es-peso-items>div.works{border-top-color:#2aa876}.es-peso-items>div.profit{border-top-color:#d49a00;background:#fff9e9}.es-peso-items>div.risk{border-top-color:#b8412b;background:#fff0ed}.es-peso-items strong{display:block;font-size:14px;color:#183657}.es-peso-items span{display:block;font-size:6.4px;line-height:1.25;color:#637184;margin-top:4px}.es-distribution-detail{padding:7px 0 1px}.es-distribution-bar{display:flex;height:11px;margin:15px 0 12px;background:#e1e7ed;border-radius:2px;overflow:visible}.es-distribution-bar i{display:block;position:relative;min-width:0}.es-distribution-bar i:first-child{border-radius:2px 0 0 2px}.es-distribution-bar i:last-child{border-radius:0 2px 2px 0}.es-distribution-bar small{position:absolute;left:50%;top:-13px;transform:translateX(-50%);font-size:5.8px;font-style:normal;color:#5e6d7f;white-space:nowrap}.es-distribution-cards{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.es-distribution-cards>div{border:1px solid #d6dee8;border-radius:5px;background:#fbfcfd;padding:7px 9px;min-height:43px}.es-distribution-cards>div.profit{background:#fff9e9}.es-distribution-cards>div.risk{background:#fff0ed}.es-distribution-cards b{display:block;font-size:9px;color:#183657}.es-distribution-cards span{display:block;font-size:6.7px;line-height:1.3;color:#657386;margin-top:3px}.es-two-cols{display:grid;grid-template-columns:1fr 1fr;gap:22px}.es-simple-table,.es-scenario-table{width:100%;border-collapse:collapse;font-size:8.2px}.es-simple-table td,.es-scenario-table td,.es-scenario-table th{border-bottom:1px solid #dce3ea;padding:6px 7px}.es-simple-table td:last-child,.es-scenario-table td:not(:first-child),.es-scenario-table th:not(:first-child){text-align:right;font-weight:700;color:#183657}.es-simple-table tr.total{background:#edf2f7;font-weight:700}.es-scenario-table th{font-size:7px;color:#718094;text-transform:uppercase}.es-scenario-table td small{display:block;font-size:6.8px;color:#92a0af;margin-top:2px;font-weight:400}.es-scenario-table tr.is-base{background:#edf2f7}.es-timeline{display:flex;align-items:flex-start;justify-content:space-between;padding:14px 10px 2px}.es-time-point{width:18%;text-align:center;position:relative}.es-time-point>span{display:inline-flex;align-items:center;justify-content:center;width:27px;height:27px;border-radius:50%;background:#183657;color:#fff;font-size:7px;font-weight:700;position:relative;z-index:2}.es-time-point.warn>span{background:#b68100}.es-time-point.risk>span{background:#b8412b}.es-time-point i{position:absolute;top:13px;left:57%;width:100%;height:2px;background:#b7c3cf}.es-time-point b{display:block;font-size:7.5px;color:#183657;margin-top:5px}.es-time-point small{display:block;font-size:6.5px;line-height:1.3;color:#7b8795;margin-top:2px}.es-alerts{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.es-alert{background:#fff8e9;border-left:4px solid #c69c25;border-radius:3px;padding:9px;min-height:62px}.es-alert.risk{background:#fff0ed;border-color:#b8412b}.es-alert.ok{background:#eef8f1;border-color:#268455}.es-alert b{font-size:8px;color:#6e5100}.es-alert.risk b{color:#9b2d1f}.es-alert.ok b{color:#1e6d46}.es-alert p{font-size:7.2px;line-height:1.4;color:#617084;margin:5px 0 0}.es-page>footer{position:absolute;left:13mm;right:13mm;bottom:7mm;border-top:1px solid #d9e1e8;padding-top:6px;font-size:6.5px;line-height:1.35;color:#99a5b3}.es-page-two .es-header{margin-bottom:13px}.es-idea{border-left:4px solid #183657;background:#edf2f7;padding:15px 18px;font-size:11px;line-height:1.7;color:#35465b}.es-steps{display:grid;gap:9px}.es-step{display:flex;gap:12px;align-items:flex-start}.es-step>i{display:flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:50%;background:#183657;color:#fff;font-style:normal;font-weight:700;font-size:11px;flex:none}.es-step b{font-size:10px;color:#183657}.es-step p{font-size:8.5px;line-height:1.45;color:#5e6b7d;margin:3px 0 0}.es-glossary{display:grid;grid-template-columns:1fr 1fr;gap:8px}.es-term{border:1px solid #d8e0e9;background:#fbfcfd;border-radius:5px;padding:9px 11px;min-height:47px}.es-term b{display:block;font-size:8.5px;color:#183657}.es-term span{display:block;font-size:7.5px;line-height:1.35;color:#687689;margin-top:3px}.es-faq{display:grid;gap:7px}.es-faq b{font-size:8.5px;color:#183657}.es-faq p{font-size:7.5px;line-height:1.4;color:#5d6a7b;margin:2px 0 0}@media print{html,body{background:#fff}body{padding:0}.es-page{margin:0;width:210mm;height:297mm;min-height:297mm;overflow:hidden;box-shadow:none;-webkit-print-color-adjust:exact;print-color-adjust:exact}}@page{size:A4;margin:0}';
  }

  function open(input) {
    var win = global.open("", "_blank", "width=1050,height=820");
    if (!win) {
      global.alert("Tu navegador bloqueó la ventana del resumen. Permite ventanas emergentes y vuelve a intentarlo.");
      return false;
    }
    win.document.open();
    win.document.write(buildHtml(input));
    win.document.close();
    return true;
  }

  global.VicaperExecutiveSummary = { buildHtml: buildHtml, open: open };
})(window);
