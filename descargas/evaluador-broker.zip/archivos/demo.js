"use strict";

(() => {
  const spaces = {
    simulacion: { label: "Simulación editable", canEdit: true, projects: ["canelo", "terrazas"] },
    presentacion: { label: "Vista de presentación", canEdit: false, projects: ["quillay"] }
  };
  const requested = new URLSearchParams(location.search).get("espacio");
  const spaceId = Object.hasOwn(spaces, requested) ? requested : "simulacion";
  const space = spaces[spaceId];
  const storagePrefix = "mesaLoteos.demo.v1.";
  const storageKey = storagePrefix + spaceId;
  const canelo = {
    nombre: "Lomas del Canelo",
    region: "La Araucanía · Freire",
    ha: 27.6,
    lotes: 48,
    precio: 590000000,
    uf: 41500,
    pvp: 25500000,
    vel: 3.5,
    com: 21,
    hab: 8,
    usarListaPrecios: true,
    categoriasPrecios: [
      { nombre: "Interior", cant: 28, precio: 24500000 },
      { nombre: "Vista al valle", cant: 14, precioModoUF: true, precioUF: 675 },
      { nombre: "Acceso principal", cant: 6, precio: 29900000 }
    ],
    vendeAgua: true,
    precioVentaAgua: 900000,
    pie: 35,
    cuotas: 24,
    tasaInteresAnual: 9.5,
    propPct: 65,
    hitos: [
      { n: "Planos y subdivisión", c: 7500000, m: "auto" },
      { n: "Caminos de acceso", c: 28500000, m: "auto" },
      { n: "Vialidad y habilitación interior", c: 42000000, m: "auto" }
    ]
  };
  const examples = {
    canelo,
    terrazas: {
      ...canelo,
      nombre: "Terrazas del Sur",
      region: "Los Ríos · Paillaco",
      ha: 14.2,
      lotes: 24,
      precioModo: "uf_m2",
      precioEntrada: 0.045,
      pvp: 22900000,
      vel: 4,
      usarListaPrecios: false,
      categoriasPrecios: [],
      vendeAgua: false,
      vendeEdificacion: true,
      valorEdificacion: 19500000,
      pie: 45,
      cuotas: 18,
      tasaInteresAnual: 0,
      hitos: [
        { n: "Estudios y subdivisión", c: 6500000, m: "auto" },
        { n: "Mejoras de acceso", c: 18500000, m: "auto" }
      ]
    },
    quillay: {
      ...canelo,
      nombre: "Valle del Quillay",
      region: "Maule · San Javier",
      lotes: 36,
      ha: 20.4,
      precio: 480000000,
      usarListaPrecios: false,
      categoriasPrecios: [],
      pvp: 25900000,
      vendeAgua: false,
      tasaInteresAnual: 8,
      propPct: 67
    }
  };

  window.MesaDemo = {
    storageKey,
    storagePrefix,
    defaults: { nombre: "Predio de ejemplo", region: "La Araucanía", ha: 28, lotes: 48, precio: 590000000, pvp: 25500000 },
    seeds: space.projects.map(id => ({ id: `demo-${id}`, state: examples[id] })),
    texts: { empresa: "Demo · Datos ficticios", tAportante: "propietario", tPropietario: "propietario", lAportante: "Pago al propietario",
      sPagos: "Pagos al propietario", kResultado: "Resultado total propietario" }
  };
  window.VICAPER_ACCESS = { canEdit: space.canEdit, readOnly: !space.canEdit, workspaceId: spaceId };

  document.addEventListener("DOMContentLoaded", () => {
    const status = document.getElementById("vicaper-sync-status");
    const select = document.getElementById("mesaWorkspaceSelect");
    const rail = document.querySelector(".rail");
    const topbar = document.querySelector(".topbar");
    const projectSelect = document.getElementById("projSelect");
    const projectTitle = document.getElementById("demoProjectName");

    select.replaceChildren(...Object.entries(spaces).map(([id, item]) => new Option(item.label, id, false, id === spaceId)));
    select.hidden = false;
    document.getElementById("mesaWorkspaceBadge").hidden = true;
    document.getElementById("mesaWorkspaceControl").hidden = false;

    function persist() {
      try {
        localStorage.setItem(storageKey, JSON.stringify(window.VICAPER_MESA_API.getData()));
        return true;
      } catch {
        return false;
      }
    }

    select.addEventListener("change", () => {
      persist();
      const url = new URL(location.href);
      url.hash = "";
      if (select.value === "simulacion") url.searchParams.delete("espacio");
      else url.searchParams.set("espacio", select.value);
      location.assign(url);
    });
    const stored = persist();
    window.addEventListener("pagehide", persist);
    status.textContent = stored ? "Guardado local" : "Sesión sin guardado";
    status.dataset.tone = stored ? "ok" : "error";

    function refreshProjectName() {
      projectTitle.textContent = projectSelect.selectedOptions[0]?.textContent || "Evaluación del proyecto";
    }
    new MutationObserver(refreshProjectName).observe(projectSelect, { childList: true, subtree: true, characterData: true });
    projectSelect.addEventListener("change", refreshProjectName);
    refreshProjectName();

    new ResizeObserver(() => document.documentElement.style.setProperty("--demo-bar-height", `${topbar.offsetHeight}px`)).observe(topbar);
    document.querySelectorAll('a[href="#parametros"]').forEach(link => link.addEventListener("click", () => {
      if (rail.closest(".shell").classList.contains("norail")) document.getElementById("btnRail").click();
    }));
  });
})();
