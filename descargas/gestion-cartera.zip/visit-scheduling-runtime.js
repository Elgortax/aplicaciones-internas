(function(){
  'use strict';

  var VIEW_ID='agendamiento-visita';
  var UNASSIGNED_TERRAIN_FILTER='Sin asignar';
  var STATUS_OPTIONS=['Agenda Visita','Visita Confirmada','Visita Concretada','Visita No Concretada','Reservada','Cancelada'];
  var MEDIA_OPTIONS=['WhatsApp','Llamada','Pagina WEB','Facebook','Instagram','Referido','Presencial','Otro'];
  var VISIT_REQUIRED_FIELDS=[['cliente','cliente'],['telefono','telefono'],['proyecto','proyecto'],['fechaVisita','fecha'],['horaVisita','hora'],['estado','estado'],['remoto','ejecutiva']];
  var editingVisitId='';
  var pendingNewVisit=null;
  var editorOpenRequest=0;
  var editingCreationDateVisitId='';
  var editingObservationContext=null;
  var reserveVisitId='';
  var selectedQuoteId='';
  var pendingDocuments=[];
  var availableQuotes=[];
  var visitsPage=1;
  var scheduleViewMode='list';
  var selectedProjectFilters=[];
  var VISITS_PAGE_SIZE=100;
  var runtimeSearchTimers={};
  var cachedAllVisits=null;
  var cachedVisibleVisits=null;
  var cachedCalendarVisits=null;
  var cachedVisibilityKey='';
  var EDITABLE_VISIT_FIELDS=['cliente','rut','telefono','email','proyecto','lote','fechaVisita','horaVisita','estado','subEstado','remoto','terreno','medio','observacion'];
  var TERRAIN_OBSERVATION_FIELDS=['observacionesTerreno','observacionTerrenoAt','observacionTerrenoPor'];
  var REMOTE_OBSERVATION_FIELDS=['observacionesRemoto','observacionRemotoAt','observacionRemotoPor'];
  var EDITOR_LOCKED_FIELDS=['av-client','av-rut','av-phone','av-email','av-medium','av-project','av-lot','av-date','av-time-hour','av-time-minute','av-status','av-substatus','av-remote','av-terrain'];
  var CALENDAR_MULTI_FILTERS={
    'vis-cal-fil-proyecto':{all:'Todos los proyectos',title:'Seleccionar proyectos',plural:'proyectos'},
    'vis-cal-fil-terreno':{all:'Todas las personas de terreno',title:'Seleccionar terreno',plural:'personas de terreno'},
    'vis-cal-fil-estado':{all:'Todos los estados',title:'Seleccionar estados',plural:'estados'}
  };
  var LIST_MULTI_FILTERS={
    'av-filter-status':{all:'Todos los estados',title:'Seleccionar estados',plural:'estados'},
    'av-filter-agent':{all:'Todas las ejecutivas',title:'Seleccionar ejecutivas',plural:'ejecutivas'},
    'av-filter-terrain':{all:'Terreno',title:'Seleccionar terreno',plural:'de terreno'}
  };

  function scheduleRuntimeSearch(key,renderFn){
    clearTimeout(runtimeSearchTimers[key]);
    runtimeSearchTimers[key]=setTimeout(function(){
      delete runtimeSearchTimers[key];
      if(typeof requestAnimationFrame==='function')requestAnimationFrame(renderFn);
      else renderFn();
    },180);
  }

  function escapeHtml(value){
    if(typeof esc==='function')return esc(String(value==null?'':value));
    return String(value==null?'':value).replace(/[&<>"']/g,function(char){
      return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char];
    });
  }

  function normalize(value){
    if(typeof normalizeLookupText==='function')return normalizeLookupText(value||'');
    return String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
  }

  function unique(values){
    var seen={};
    return (values||[]).filter(function(value){
      var text=String(value||'').trim();
      var key=normalize(text);
      if(!key||seen[key])return false;
      seen[key]=true;
      return true;
    }).sort(function(a,b){return a.localeCompare(b,'es');});
  }

  function todayIso(){
    var now=new Date();
    return now.getFullYear()+'-'+String(now.getMonth()+1).padStart(2,'0')+'-'+String(now.getDate()).padStart(2,'0');
  }

  function nowIso(){return new Date().toISOString();}

  function visitStore(target){
    target=target||state;
    if(!Array.isArray(target.agendamientosVisita))target.agendamientosVisita=[];
    return target.agendamientosVisita;
  }

  function mondayVisitStore(){
    return typeof visitasMondayCache!=='undefined'&&Array.isArray(visitasMondayCache)?visitasMondayCache:[];
  }

  function manualVisitStore(){
    return typeof visitasManualCache!=='undefined'&&Array.isArray(visitasManualCache)?visitasManualCache:[];
  }

  function isMondayVisit(visit){
    return !!visit&&(visit.source==='monday'||!!visit.mondaySourceId);
  }

  function mondayOverlay(sourceId){
    return visitStore().find(function(item){return item&&item.mondaySourceId===sourceId;})||null;
  }

  function mondayBase(sourceId){
    return mondayVisitStore().find(function(item){return item&&item.id===sourceId;})||null;
  }

  function mergeMondayVisit(base,overlay){
    var snapshot=base||(overlay&&overlay.mondaySnapshot)||{};
    var previousSnapshot=overlay&&overlay.mondaySnapshot||{};
    var localOverrides=overlay&&overlay.localOverrides||{};
    var applicableOverrides={};
    Object.keys(localOverrides).forEach(function(field){
      // Una corrección local puede mantenerse mientras Monday no cambie ese
      // mismo campo. En cuanto la fuente cambia —incluso a vacío— Monday manda.
      var mondayChanged=!!base&&String(base[field]||'')!==String(previousSnapshot[field]||'');
      if(!mondayChanged)applicableOverrides[field]=localOverrides[field];
    });
    var merged=Object.assign({},snapshot,applicableOverrides);
    ['reservaId','reservaIds','cotizacionId','cotizacionFolio','reservadoAt'].concat(TERRAIN_OBSERVATION_FIELDS,REMOTE_OBSERVATION_FIELDS).forEach(function(field){
      if(overlay&&overlay[field]!==undefined)merged[field]=overlay[field];
    });
    merged.id=(base&&base.id)||(overlay&&overlay.mondaySourceId)||merged.id;
    merged.source='monday';
    merged.mondaySourceId=merged.id;
    merged.localOverlayId=overlay&&overlay.id||'';
    merged.localEdited=!!overlay;
    return merged;
  }

  function unifiedVisitKeys(visit){
    if(typeof visitaDuplicateKeys==='function'){
      var sharedKeys=visitaDuplicateKeys(visit)||[];
      if(visit&&visit.id)sharedKeys.unshift('id|'+String(visit.id));
      return sharedKeys;
    }
    var phone=String(visit&&visit.telefono||'').replace(/\D/g,'');
    var contact=phone||normalize(visit&&visit.cliente||'');
    var date=String(visit&&visit.fechaVisita||'');
    var project=normalize(visit&&visit.proyecto||'');
    var time=String(visit&&visit.horaVisita||'');
    var keys=[];
    if(visit&&visit.id)keys.push('id|'+String(visit.id));
    if(contact||date||project||time)keys.push([contact,project,date,time].join('|'));
    return keys.length?keys:['ref|'+String(visit||'')];
  }

  function unifiedVisitDayProjectKey(visit){
    var phone=String(visit&&visit.telefono||'').replace(/\D/g,'');
    var contact=phone||normalize(visit&&visit.cliente||'');
    var project=normalize(visit&&visit.proyecto||'');
    var date=String(visit&&visit.fechaVisita||'');
    return contact&&project&&date?[contact,project,date].join('|'):'';
  }

  function isReservedVisit(visit){
    return !!(visit&&visit.reservaId)||normalize(visit&&visit.estado||'').indexOf('reserv')>=0;
  }

  function deduplicateVisits(visits){
    var seen={};
    var scheduledByDayProject={};
    var ordered=(visits||[]).map(function(visit,index){return {visit:visit,index:index};}).sort(function(a,b){
      return Number(isReservedVisit(b.visit))-Number(isReservedVisit(a.visit))||a.index-b.index;
    }).map(function(entry){return entry.visit;});
    return ordered.filter(function(visit){
      if(!visit)return false;
      var keys=unifiedVisitKeys(visit);
      if(keys.some(function(key){return seen[key];}))return false;
      var historical=isHistoricalVisit(visit);
      var dayProjectKey=unifiedVisitDayProjectKey(visit);
      if(historical&&!String(visit.horaVisita||'').trim()&&dayProjectKey&&scheduledByDayProject[dayProjectKey])return false;
      keys.forEach(function(key){seen[key]=true;});
      if(!historical&&dayProjectKey)scheduledByDayProject[dayProjectKey]=true;
      return true;
    });
  }

  function visibilityCacheKey(user){
    user=user||{};
    var projectScope=user.proyectosAsignados||user.proyectos||user.proyecto||user.projects||user.project||'';
    if(Array.isArray(projectScope))projectScope=projectScope.slice().sort().join('|');
    else if(projectScope&&typeof projectScope==='object'){
      try{projectScope=JSON.stringify(projectScope);}catch(error){projectScope=String(projectScope);}
    }
    return [user.uid||'',user.id||'',user.email||'',user.user||'',user.nombre||'',user.rol||'',projectScope].join('::');
  }

  function invalidateVisitCaches(){
    cachedAllVisits=null;
    cachedVisibleVisits=null;
    cachedCalendarVisits=null;
    cachedVisibilityKey='';
    if(typeof window!=='undefined')window.__visitasFilterOptionsCache=null;
  }

  function ensureVisibilityCache(){
    var key=visibilityCacheKey(currentUser);
    if(key===cachedVisibilityKey)return;
    cachedVisibilityKey=key;
    cachedVisibleVisits=null;
    cachedCalendarVisits=null;
  }

  function allVisits(){
    if(cachedAllVisits)return cachedAllVisits;
    var local=visitStore().filter(function(item){return item&&!item.mondaySourceId;});
    // Desde la migración de cierre, la agenda propia de Firebase es la fuente
    // oficial. Los overlays antiguos de Monday quedan fuera porque su versión
    // final ya fue convertida y guardada en visitas_propias.
    cachedAllVisits=deduplicateVisits(local.concat(manualVisitStore()));
    return cachedAllVisits;
  }

  function findVisit(id){
    return allVisits().find(function(item){return item&&item.id===id;})||null;
  }

  // Los registros de Reserva son la fuente real del vínculo. Los IDs guardados
  // en la visita conservan compatibilidad con visitas creadas antes de este cambio.
  function linkedReservations(visit){
    if(!visit)return [];
    var ids=[visit.reservaId].concat(Array.isArray(visit.reservaIds)?visit.reservaIds:[]).filter(Boolean).map(String);
    var seen={};
    return (state.registros||[]).filter(function(record){
      if(!record||!record.id||seen[record.id])return false;
      var recordVisit=String(record.visitaAgendamientoId||'');
      var linked=recordVisit?recordVisit===String(visit.id||''):ids.indexOf(String(record.id))>=0;
      if(linked)seen[record.id]=true;
      return linked;
    }).sort(function(a,b){
      var ai=ids.indexOf(String(a.id)),bi=ids.indexOf(String(b.id));
      return (ai<0?ids.length:ai)-(bi<0?ids.length:bi);
    });
  }

  function ensureMondayOverlay(visit){
    var sourceId=visit.mondaySourceId||visit.id;
    var overlay=mondayOverlay(sourceId);
    if(overlay)return overlay;
    var timestamp=nowIso();
    overlay={
      id:'avm_'+String(sourceId).replace(/[^a-zA-Z0-9_-]/g,'_'),
      mondaySourceId:sourceId,
      mondayBoardId:visit.mondayBoardId||'',
      mondayItemId:visit.mondayItemId||'',
      source:'local-overlay',
      mondaySnapshot:Object.assign({},mondayBase(sourceId)||visit),
      localOverrides:{},
      creadoAt:timestamp,
      actualizadoAt:timestamp,
      creadoPor:currentUser&&currentUser.nombre||'',
      creadoPorUid:(typeof currentFirebaseUser!=='undefined'&&currentFirebaseUser&&currentFirebaseUser.uid)||(currentUser&&currentUser.uid)||'',
      actividad:[]
    };
    visitStore().push(overlay);
    return overlay;
  }

  function saveMondayOverlay(visit,data,timestamp){
    var sourceId=visit.mondaySourceId||visit.id;
    var base=mondayBase(sourceId)||(mondayOverlay(sourceId)&&mondayOverlay(sourceId).mondaySnapshot)||visit;
    var overlay=ensureMondayOverlay(visit);
    var overrides={};
    EDITABLE_VISIT_FIELDS.forEach(function(field){
      if(String(data[field]||'')!==String(base[field]||''))overrides[field]=data[field]||'';
    });
    overlay.localOverrides=overrides;
    overlay.mondaySnapshot=Object.assign({},base);
    overlay.actualizadoAt=timestamp;
    overlay.actualizadoPor=currentUser&&currentUser.nombre||'';
    overlay.actividad=overlay.actividad||[];
    overlay.actividad.push({ts:typeof nowTs==='function'?nowTs():timestamp,user:currentUser&&currentUser.nombre||'',msg:'Visita de Monday actualizada localmente'});
    return mergeMondayVisit(base,overlay);
  }

  function linkReservation(id,details){
    var visit=findVisit(id);
    if(!visit)return null;
    var target=visit;
    var previous=JSON.parse(JSON.stringify(visit));
    var linked=linkedReservations(target);
    var ids=linked.map(function(record){return String(record.id);});
    if(details.reservaId&&ids.indexOf(String(details.reservaId))<0)ids.push(String(details.reservaId));
    target.reservaIds=ids;
    var primary=linked[0];
    if(primary){
      target.reservaId=primary.id;
      target.cotizacionId=primary.cotizacionId||target.cotizacionId||'';
      target.cotizacionFolio=primary.cotizacionFolio||target.cotizacionFolio||'';
      target.reservadoAt=target.reservadoAt||details.reservadoAt||nowIso();
    }else{
      target.reservaId=details.reservaId||'';
      target.cotizacionId=details.cotizacionId||'';
      target.cotizacionFolio=details.cotizacionFolio||'';
      target.reservadoAt=details.reservadoAt||nowIso();
    }
    target.actualizadoAt=details.reservadoAt||nowIso();
    target.actividad=target.actividad||[];
    target.actividad.push({ts:details.ts||target.reservadoAt,user:details.user||'',msg:details.message||'Visita vinculada manualmente a una Reserva'});
    target.estado='Reservada';
    invalidateVisitCaches();
    persistOwnVisit(target,previous).catch(function(error){
      console.error('La Reserva quedó creada, pero no se pudo guardar el vínculo en la visita:',error);
      toast('La Reserva quedó creada; el vínculo con la visita se reintentará al editarla.','error');
    });
    return target;
  }

  function refreshOwnVisits(force){
    if(typeof ensureVisitasLoaded!=='function')return Promise.resolve(allVisits());
    return ensureVisitasLoaded(!!force).then(function(){return allVisits();});
  }

  function removeLegacyStateVisit(id){
    var store=visitStore();
    var before=store.length;
    state.agendamientosVisita=store.filter(function(item){
      return item&&item.id!==id&&item.mondaySourceId!==id;
    });
    if(state.agendamientosVisita.length!==before){invalidateVisitCaches();saveState();return true;}
    return false;
  }

  function persistOwnVisit(visit,previous){
    if(typeof window.upsertVisitaPropia!=='function'){
      invalidateVisitCaches();
      saveState();
      return Promise.resolve(visit);
    }
    return window.upsertVisitaPropia(visit,previous&&previous.fechaVisita).then(function(saved){
      removeLegacyStateVisit(visit.id);
      invalidateVisitCaches();
      return saved;
    });
  }

  function isSeller(user){
    return typeof isReadOnlySellerUser==='function'&&isReadOnlySellerUser(user||currentUser);
  }

  function currentRole(user){
    user=user||currentUser;
    return typeof getRoleKey==='function'?getRoleKey(user):String(user&&user.rol||'');
  }

  function isRemoteUser(user){
    user=user||currentUser;
    return currentRole(user)==='Remoto'||(isSeller(user)&&typeof getSellerScopeField==='function'&&getSellerScopeField(user)==='remoto');
  }

  function isTerrainUser(user){
    user=user||currentUser;
    return currentRole(user)==='Terreno'||(isSeller(user)&&typeof getSellerScopeField==='function'&&getSellerScopeField(user)==='terreno');
  }

  function canSeeVisit(visit){
    if(!currentUser)return false;
    if(typeof isKatherineUser==='function'&&isKatherineUser(currentUser))return true;
    return !isSeller(currentUser)||(typeof userOwnsRecord==='function'&&userOwnsRecord(visit,currentUser));
  }

  function canFullyEditVisit(visit){
    if(!currentUser)return false;
    if(typeof puedeEditarVista==='function'&&!puedeEditarVista(VIEW_ID))return false;
    if(visit&&isHistoricalVisit(visit))return false;
    if(isTerrainUser(currentUser))return false;
    return !visit||!isSeller(currentUser)||canSeeVisit(visit);
  }

  function canEditVisit(visit){
    if(!currentUser)return false;
    if(typeof puedeEditarVista==='function'&&!puedeEditarVista(VIEW_ID))return false;
    if(visit&&isHistoricalVisit(visit))return false;
    if(isTerrainUser(currentUser))return !!visit&&canSeeVisit(visit);
    return canFullyEditVisit(visit);
  }

  function canEditCreationDate(visit){
    return !!visit&&currentRole(currentUser)==='Administrador'&&canSeeVisit(visit)
      &&(typeof puedeEditarVista!=='function'||puedeEditarVista(VIEW_ID));
  }

  function isHistoricalVisit(visit){
    return false;
  }

  function visibleVisits(){
    ensureVisibilityCache();
    if(!cachedVisibleVisits)cachedVisibleVisits=allVisits().filter(canSeeVisit);
    return cachedVisibleVisits;
  }

  // Estas ejecutivas coordinan los horarios de Jocelyn entre proyectos. Este
  // acceso adicional es solo para el calendario; no amplía la lista ni la edición.
  function hasJocelynCalendarAccess(user){
    return ['contacto-demo-c12bc808@example.invalid','contacto-demo-813310ff@example.invalid','contacto-demo-1e9bf843@example.invalid']
      .indexOf(normalize(user&&user.email))>=0;
  }

  function canSeeJocelynAgenda(visit){
    return hasJocelynCalendarAccess(currentUser)&&personMatches(visit&&visit.terreno,'Jocelyn Faundez');
  }

  function sharedCalendarProjectNames(user){
    var access=projectAccess(user);
    var names=access.restricted?access.names.slice():[];
    // Alejandra coordina terreno compartido con Valle Monte Patria. Esta
    // excepción no cambia projectAccess: solo permite consultar el calendario.
    if(isRemoteUser(user)&&normalize(user&&user.email)==='contacto-demo-1e9bf843@example.invalid')names.push('Valle Monte Patria');
    return unique(names.map(canonicalProjectName).filter(Boolean));
  }

  // La lista sigue siendo privada para cada ejecutiva, pero el calendario de
  // una Remoto comparte las visitas de sus proyectos asignados. Las tres
  // coordinadoras también ven toda la agenda de Jocelyn para evitar cruces.
  function canSeeCalendarVisit(visit){
    if(canSeeVisit(visit))return true;
    if(!currentUser||!isRemoteUser(currentUser))return false;
    if(canSeeJocelynAgenda(visit))return true;
    var projects=sharedCalendarProjectNames(currentUser);
    var project=normalize(canonicalProjectName(visit&&visit.proyecto));
    return !!project&&projects.some(function(name){return normalize(name)===project;});
  }

  function calendarVisibleVisits(){
    ensureVisibilityCache();
    if(cachedCalendarVisits)return cachedCalendarVisits;
    var own=visibleVisits();
    if(!currentUser||!isRemoteUser(currentUser)||own.length===allVisits().length){
      cachedCalendarVisits=own;
      return cachedCalendarVisits;
    }
    var projects=sharedCalendarProjectNames(currentUser);
    var hasSharedProjects=projects.length>0;
    var seesJocelynAgenda=hasJocelynCalendarAccess(currentUser);
    if(!hasSharedProjects&&!seesJocelynAgenda){
      cachedCalendarVisits=own;
      return cachedCalendarVisits;
    }
    var ownVisits=typeof Set==='function'?new Set(own):null;
    var ownIds={};
    own.forEach(function(visit){if(visit&&visit.id)ownIds[String(visit.id)]=true;});
    var allowedProjects={};
    if(hasSharedProjects)projects.forEach(function(name){allowedProjects[normalize(name)]=true;});
    cachedCalendarVisits=allVisits().filter(function(visit){
      if((ownVisits&&ownVisits.has(visit))||visit&&visit.id&&ownIds[String(visit.id)])return true;
      if(seesJocelynAgenda&&canSeeJocelynAgenda(visit))return true;
      return !!(hasSharedProjects&&allowedProjects[normalize(canonicalProjectName(visit&&visit.proyecto))]);
    });
    return cachedCalendarVisits;
  }

  function selectedValue(id){
    var element=document.getElementById(id);
    return element?String(element.value||'').trim():'';
  }

  function numberOptions(limit,step,placeholder){
    var html='<option value="">'+placeholder+'</option>';
    for(var value=0;value<limit;value+=step){
      var padded=String(value).padStart(2,'0');
      html+='<option value="'+padded+'">'+padded+'</option>';
    }
    return html;
  }

  function setVisitTime(value){
    var match=String(value||'').match(/^(\d{1,2}):(\d{2})/);
    var hour=document.getElementById('av-time-hour');
    var minute=document.getElementById('av-time-minute');
    if(!hour||!minute)return;
    hour.value=match?String(Number(match[1])).padStart(2,'0'):'';
    if(match&&!Array.prototype.some.call(minute.options,function(option){return option.value===match[2];})){
      minute.insertAdjacentHTML('beforeend','<option value="'+escapeHtml(match[2])+'">'+escapeHtml(match[2])+'</option>');
    }
    minute.value=match?match[2]:'';
  }

  function selectedVisitTime(){
    var hour=selectedValue('av-time-hour');
    var minute=selectedValue('av-time-minute');
    return hour&&minute?hour+':'+minute:'';
  }

  function missingVisitFields(data){
    return VISIT_REQUIRED_FIELDS.reduce(function(missing,pair){
      if(!data[pair[0]])missing.push(pair[1]);
      return missing;
    },[]);
  }

  function setOptions(id,values,placeholder,current){
    var element=document.getElementById(id);
    if(!element)return;
    element.innerHTML='<option value="">'+escapeHtml(placeholder)+'</option>'+unique(values).map(function(value){
      return '<option value="'+escapeHtml(value)+'">'+escapeHtml(value)+'</option>';
    }).join('');
    if(current&&!Array.prototype.some.call(element.options,function(option){return option.value===current;})){
      element.insertAdjacentHTML('beforeend','<option value="'+escapeHtml(current)+'">'+escapeHtml(current)+'</option>');
    }
    if(current)element.value=current;
  }

  function selectedProjectValues(){
    var element=document.getElementById('av-filter-project');
    if(!element)return selectedProjectFilters.slice();
    var selected=[];
    if(Array.isArray(element.__avProjectSelection)){
      selected=element.__avProjectSelection.slice();
    }else if(element.options&&typeof element.options.length==='number'){
      Array.prototype.forEach.call(element.options,function(option){
        if(option.selected&&option.value)selected.push(String(option.value).trim());
      });
    }else if(element.value){
      selected.push(String(element.value).trim());
    }
    if(selected.length)selectedProjectFilters=unique(selected);
    return selectedProjectFilters.slice();
  }

  function updateProjectFilterLabel(){
    var label=document.getElementById('av-filter-project-label');
    if(!label)return;
    var selected=selectedProjectFilters;
    label.textContent=!selected.length?'Todos los proyectos':selected.length===1?selected[0]:selected.length+' proyectos';
    label.title=selected.length?selected.join(', '):'Todos los proyectos';
  }

  function setProjectFilterSelection(values,shouldRender){
    selectedProjectFilters=unique(values);
    var selectedKeys=selectedProjectFilters.map(normalize);
    var element=document.getElementById('av-filter-project');
    if(element)element.__avProjectSelection=selectedProjectFilters.slice();
    if(element&&element.options&&typeof element.options.length==='number'){
      Array.prototype.forEach.call(element.options,function(option){option.selected=selectedKeys.indexOf(normalize(option.value))>=0;});
    }else if(element){
      element.value=selectedProjectFilters[0]||'';
    }
    var options=document.getElementById('av-filter-project-options');
    if(options&&typeof options.querySelectorAll==='function'){
      Array.prototype.forEach.call(options.querySelectorAll('[data-av-project-option]'),function(input){
        input.checked=selectedKeys.indexOf(normalize(input.value))>=0;
      });
    }
    updateProjectFilterLabel();
    if(shouldRender!==false)renderVisits(true);
  }

  function setProjectFilterOptions(values){
    var available=unique(values);
    var availableKeys=available.map(normalize);
    var selected=selectedProjectValues().filter(function(value){return availableKeys.indexOf(normalize(value))>=0;});
    selectedProjectFilters=unique(selected);
    var selectedKeys=selectedProjectFilters.map(normalize);
    var element=document.getElementById('av-filter-project');
    if(element){
      element.__avProjectSelection=selectedProjectFilters.slice();
      element.innerHTML=available.map(function(value){
        return '<option value="'+escapeHtml(value)+'"'+(selectedKeys.indexOf(normalize(value))>=0?' selected':'')+'>'+escapeHtml(value)+'</option>';
      }).join('');
    }
    var options=document.getElementById('av-filter-project-options');
    if(options){
      options.innerHTML=available.map(function(value){
        var checked=selectedKeys.indexOf(normalize(value))>=0?' checked':'';
        return '<label class="av-project-filter-option"><input type="checkbox" value="'+escapeHtml(value)+'" data-av-project-option'+checked+'><span>'+escapeHtml(value)+'</span></label>';
      }).join('')||'<div class="av-project-filter-empty">No hay proyectos disponibles.</div>';
    }
    updateProjectFilterLabel();
  }

  function setProjectFilterOpen(open){
    var menu=document.getElementById('av-filter-project-menu');
    var button=document.getElementById('av-filter-project-button');
    if(menu)menu.hidden=!open;
    if(button)button.setAttribute('aria-expanded',open?'true':'false');
  }

  function listMultiFilterValues(id){
    var element=document.getElementById(id);
    if(!element)return [];
    if(Array.isArray(element.__avListSelection))return element.__avListSelection.slice();
    var selected=[];
    if(element.options&&typeof element.options.length==='number'){
      Array.prototype.forEach.call(element.options,function(option){if(option.selected&&option.value)selected.push(String(option.value).trim());});
    }else if(element.value){
      selected.push(String(element.value).trim());
    }
    return unique(selected);
  }

  function updateListMultiFilterLabel(id){
    var config=LIST_MULTI_FILTERS[id],label=document.getElementById(id+'-label');
    if(!config||!label)return;
    var selected=listMultiFilterValues(id);
    label.textContent=!selected.length?config.all:selected.length===1?selected[0]:selected.length+' '+config.plural;
    label.title=selected.length?selected.join(', '):config.all;
  }

  function setListMultiFilterSelection(id,values,shouldRender){
    var element=document.getElementById(id);
    if(!element)return;
    var selected=unique(values),selectedKeys=selected.map(normalize);
    element.__avListSelection=selected.slice();
    if(element.options&&typeof element.options.length==='number'){
      Array.prototype.forEach.call(element.options,function(option){option.selected=selectedKeys.indexOf(normalize(option.value))>=0;});
    }else{
      element.value=selected[0]||'';
    }
    var options=document.getElementById(id+'-options');
    if(options&&typeof options.querySelectorAll==='function'){
      Array.prototype.forEach.call(options.querySelectorAll('[data-av-list-option]'),function(input){input.checked=selectedKeys.indexOf(normalize(input.value))>=0;});
    }
    updateListMultiFilterLabel(id);
    if(shouldRender!==false)renderVisits(true);
  }

  function setListMultiFilterOptions(id,values){
    var element=document.getElementById(id),config=LIST_MULTI_FILTERS[id];
    if(!element||!config)return;
    var available=unique(values),availableKeys=available.map(normalize);
    var selected=listMultiFilterValues(id).filter(function(value){return availableKeys.indexOf(normalize(value))>=0;});
    var selectedKeys=selected.map(normalize);
    element.__avListSelection=selected.slice();
    element.innerHTML=available.map(function(value){return '<option value="'+escapeHtml(value)+'"'+(selectedKeys.indexOf(normalize(value))>=0?' selected':'')+'>'+escapeHtml(value)+'</option>';}).join('');
    var options=document.getElementById(id+'-options');
    if(options){
      options.innerHTML=available.map(function(value){return '<label class="av-calendar-filter-option"><input type="checkbox" value="'+escapeHtml(value)+'" data-av-list-option="'+id+'"'+(selectedKeys.indexOf(normalize(value))>=0?' checked':'')+'><span>'+escapeHtml(value)+'</span></label>';}).join('')||'<div class="av-project-filter-empty">No hay opciones disponibles.</div>';
    }
    updateListMultiFilterLabel(id);
  }

  function setListMultiFilterOpen(id,open){
    Object.keys(LIST_MULTI_FILTERS).forEach(function(filterId){
      var menu=document.getElementById(filterId+'-menu'),button=document.getElementById(filterId+'-button');
      var active=filterId===id&&!!open;
      if(menu)menu.hidden=!active;
      if(button)button.setAttribute('aria-expanded',active?'true':'false');
    });
  }

  function calendarFilterValues(id){
    var element=document.getElementById(id);
    if(!element)return [];
    if(Array.isArray(element.__avCalendarSelection))return element.__avCalendarSelection.slice();
    var selected=[];
    if(element.options&&typeof element.options.length==='number'){
      Array.prototype.forEach.call(element.options,function(option){if(option.selected&&option.value)selected.push(String(option.value).trim());});
    }else if(element.value){
      selected.push(String(element.value).trim());
    }
    return unique(selected);
  }

  function updateCalendarFilterLabel(id){
    var config=CALENDAR_MULTI_FILTERS[id];
    var label=document.getElementById(id+'-label');
    if(!config||!label)return;
    var selected=calendarFilterValues(id);
    label.textContent=!selected.length?config.all:selected.length===1?selected[0]:selected.length+' '+config.plural;
    label.title=selected.length?selected.join(', '):config.all;
  }

  function setCalendarFilterSelection(id,values,shouldRender){
    var element=document.getElementById(id);
    if(!element)return;
    var selected=unique(values),selectedKeys=selected.map(normalize);
    element.__avCalendarSelection=selected.slice();
    if(element.options&&typeof element.options.length==='number'){
      Array.prototype.forEach.call(element.options,function(option){option.selected=selectedKeys.indexOf(normalize(option.value))>=0;});
    }else{
      element.value=selected[0]||'';
    }
    var options=document.getElementById(id+'-options');
    if(options&&typeof options.querySelectorAll==='function'){
      Array.prototype.forEach.call(options.querySelectorAll('[data-av-calendar-option]'),function(input){input.checked=selectedKeys.indexOf(normalize(input.value))>=0;});
    }
    updateCalendarFilterLabel(id);
    if(shouldRender!==false&&typeof renderVisitasCalendario==='function')renderVisitasCalendario();
  }

  function setCalendarFilterOptions(id,values){
    var element=document.getElementById(id),config=CALENDAR_MULTI_FILTERS[id];
    if(!element||!config)return;
    var available=unique(values),availableKeys=available.map(normalize);
    var selected=calendarFilterValues(id).filter(function(value){return availableKeys.indexOf(normalize(value))>=0;});
    var selectedKeys=selected.map(normalize);
    element.__avCalendarSelection=selected.slice();
    element.innerHTML=available.map(function(value){
      return '<option value="'+escapeHtml(value)+'"'+(selectedKeys.indexOf(normalize(value))>=0?' selected':'')+'>'+escapeHtml(value)+'</option>';
    }).join('');
    var options=document.getElementById(id+'-options');
    if(options){
      options.innerHTML=available.map(function(value){
        return '<label class="av-calendar-filter-option"><input type="checkbox" value="'+escapeHtml(value)+'" data-av-calendar-option="'+id+'"'+(selectedKeys.indexOf(normalize(value))>=0?' checked':'')+'><span>'+escapeHtml(value)+'</span></label>';
      }).join('')||'<div class="av-project-filter-empty">No hay opciones disponibles.</div>';
    }
    updateCalendarFilterLabel(id);
  }

  function setCalendarFilterOpen(id,open){
    Object.keys(CALENDAR_MULTI_FILTERS).forEach(function(filterId){
      var menu=document.getElementById(filterId+'-menu');
      var button=document.getElementById(filterId+'-button');
      var active=filterId===id&&!!open;
      if(menu)menu.hidden=!active;
      if(button)button.setAttribute('aria-expanded',active?'true':'false');
    });
  }

  function enhanceCalendarMultiFilter(id){
    var element=document.getElementById(id),config=CALENDAR_MULTI_FILTERS[id];
    if(!element||!config||document.getElementById(id+'-button'))return;
    var wrapper=document.createElement('div');
    wrapper.className='av-calendar-multi';
    wrapper.setAttribute('data-av-calendar-filter',id);
    element.parentNode.insertBefore(wrapper,element);
    wrapper.innerHTML='<button type="button" class="filter-sel av-calendar-filter-button" id="'+id+'-button" aria-haspopup="listbox" aria-expanded="false"><span id="'+id+'-label">'+escapeHtml(config.all)+'</span><span class="av-project-filter-chevron" aria-hidden="true">⌄</span></button>'+ 
      '<div class="av-calendar-filter-menu" id="'+id+'-menu" role="listbox" aria-multiselectable="true" hidden><div class="av-project-filter-head"><strong>'+escapeHtml(config.title)+'</strong><button type="button" id="'+id+'-clear">Limpiar</button></div><div class="av-project-filter-options" id="'+id+'-options"></div></div>';
    element.multiple=true;
    element.hidden=true;
    element.setAttribute('aria-hidden','true');
    wrapper.appendChild(element);
  }

  function enhanceCalendarDateFilter(){
    var input=document.getElementById('vis-cal-fil-dia');
    if(!input||input.closest&&input.closest('.av-calendar-date'))return;
    var wrapper=document.createElement('label');
    wrapper.className='av-calendar-date';
    wrapper.setAttribute('for','vis-cal-fil-dia');
    input.parentNode.insertBefore(wrapper,input);
    wrapper.innerHTML='<span class="av-calendar-date-caption"><span aria-hidden="true">▣</span> Ir a fecha</span>';
    wrapper.appendChild(input);
    input.setAttribute('data-date-placeholder','Seleccionar día');
    input.setAttribute('aria-label','Ir a una fecha del calendario de visitas');
    if(input._flatpickr&&input._flatpickr.altInput)wrapper.appendChild(input._flatpickr.altInput);
  }

  function enhanceCalendarFilters(){
    enhanceCalendarDateFilter();
    Object.keys(CALENDAR_MULTI_FILTERS).forEach(enhanceCalendarMultiFilter);
  }

  function canonicalProjectName(value){
    var text=String(value||'').trim();
    if(!text)return '';
    if(window.PruebaLotes&&typeof window.PruebaLotes.repairProjectName==='function')text=window.PruebaLotes.repairProjectName(text);
    try{
      var canonical=Object.keys(getLotesData()||{}).find(function(name){
        return window.PruebaLotes&&typeof window.PruebaLotes.sameProject==='function'
          ?window.PruebaLotes.sameProject(name,text)
          :normalize(name)===normalize(text);
      });
      if(canonical)return canonical;
    }catch(error){}
    return text;
  }

  function allProjectNames(){
    // Catálogo vigente más visitas históricas; no revivir nombres de la lista
    // administrativa antigua. Los permisos de cada perfil se aplican después.
    var names=typeof getProjectFilterOptions==='function'?getProjectFilterOptions(allVisits()):[];
    if(typeof getProjectFilterOptions!=='function'){
      try{Object.keys(DB||{}).forEach(function(id){if(DB[id]&&DB[id].nombre)names.push(DB[id].nombre);});}catch(error){}
      allVisits().forEach(function(visit){if(visit.proyecto)names.push(visit.proyecto);});
    }
    return unique(names.map(canonicalProjectName).filter(Boolean));
  }

  function projectAccess(user){
    var all=allProjectNames();
    user=user||currentUser;
    if(!isSeller(user))return {restricted:false,names:all};
    var bridge=window.cotizadorGestionSso;
    var status=null;
    try{status=bridge&&typeof bridge.status==='function'?bridge.status():null;}catch(error){}
    var ids=status&&Array.isArray(status.visibleProjectIds)?status.visibleProjectIds:[];
    var names=ids.map(function(id){
      try{return DB&&DB[id]&&DB[id].nombre?DB[id].nombre:id;}catch(error){return id;}
    }).map(canonicalProjectName).filter(Boolean);
    return {restricted:true,names:unique(names)};
  }

  function projectNames(){
    return projectAccess(currentUser).names;
  }

  function projectAllowed(project,existing){
    var access=projectAccess(currentUser);
    if(!access.restricted)return true;
    var canonical=canonicalProjectName(project);
    if(existing&&normalize(canonicalProjectName(existing.proyecto))===normalize(canonical))return true;
    return access.names.some(function(name){return normalize(name)===normalize(canonical);});
  }

  function defaultRemoteAgent(user){
    if(!user)return '';
    var role=typeof getRoleKey==='function'?getRoleKey(user):String(user.rol||'');
    return role==='Remoto'||(role==='Vendedor'&&(typeof getSellerScopeField!=='function'||getSellerScopeField(user)==='remoto'))?String(user.nombre||'').trim():'';
  }

  function remoteAgents(){
    var names=(state.agentesRemoto||[]).slice();
    (state.registros||[]).forEach(function(record){names.push(record.remoto);});
    (state.usuarios||[]).forEach(function(user){
      var role=typeof getRoleKey==='function'?getRoleKey(user):user.rol;
      if(role==='Remoto'||role==='Ej. Adm. Ventas'||(role==='Vendedor'&&typeof getSellerScopeField==='function'&&getSellerScopeField(user)==='remoto'))names.push(user.nombre);
    });
    allVisits().forEach(function(visit){names.push(visit.remoto);});
    if(currentUser&&typeof getSellerScopeField==='function'&&getSellerScopeField(currentUser)==='remoto')names.push(currentUser.nombre);
    return unique(names);
  }

  function terrainAgents(){
    var names=(state.agentesTerreno||[]).slice();
    (state.registros||[]).forEach(function(record){names.push(record.terreno);});
    (state.usuarios||[]).forEach(function(user){
      var role=typeof getRoleKey==='function'?getRoleKey(user):user.rol;
      if(role==='Terreno'||(user.scopeField||user.campoAgente)==='terreno')names.push(user.nombre);
    });
    allVisits().forEach(function(visit){names.push(visit.terreno);});
    if(currentUser&&typeof getSellerScopeField==='function'&&getSellerScopeField(currentUser)==='terreno')names.push(currentUser.nombre);
    return unique(names);
  }

  // Para asignar nuevas visitas, el catálogo del Cotizador es la única fuente.
  // terrainAgents() sigue incluyendo históricos para los filtros de consulta.
  function projectTerrainAgents(project){
    var key=normalize(canonicalProjectName(project));
    if(!key)return [];
    var projects=typeof DB!=='undefined'&&DB?DB:{};
    var assignments=typeof VENDEDOR_PROY_DB!=='undefined'&&VENDEDOR_PROY_DB?VENDEDOR_PROY_DB:{};
    var sellers=typeof VENDEDORES_PROY_DB!=='undefined'&&Array.isArray(VENDEDORES_PROY_DB)?VENDEDORES_PROY_DB:[];
    var names=[];
    Object.keys(projects).forEach(function(id){
      if(normalize(canonicalProjectName(projects[id]&&projects[id].nombre))!==key)return;
      var assigned=assignments[id];
      // Compatibilidad con configuraciones antiguas que guardaban un nombre.
      if(typeof assigned==='string'){names.push(assigned);return;}
      (Array.isArray(assigned)?assigned:[]).forEach(function(sellerId){
        var seller=sellers.find(function(item){return item&&String(item.id)===String(sellerId);});
        if(seller&&seller.nombre)names.push(String(seller.nombre).trim());
      });
    });
    return unique(names);
  }

  function isCurrentTerrainAssignment(project,terrain,existing){
    return !!(existing&&existing.id&&terrain&&String(terrain)===String(existing.terreno||'')
      &&normalize(canonicalProjectName(project))===normalize(canonicalProjectName(existing.proyecto)));
  }

  function terrainAllowed(project,terrain,existing){
    return !terrain||isCurrentTerrainAssignment(project,terrain,existing)
      ||projectTerrainAgents(project).some(function(name){return normalize(name)===normalize(terrain);});
  }

  function refreshTerrainOptions(current,existing){
    var select=document.getElementById('av-terrain');
    if(!select)return;
    var project=selectedValue('av-project');
    var names=projectTerrainAgents(project);
    var previous=current===undefined?selectedValue('av-terrain'):String(current||'');
    if(existing===undefined)existing=editingVisitId?findVisit(editingVisitId):null;
    var assigned=names.find(function(name){return normalize(name)===normalize(previous);});
    var historical=!assigned&&isCurrentTerrainAssignment(project,previous,existing);
    var selected=assigned||(historical?previous:'');
    setOptions('av-terrain',names,'Sin terreno asignado',selected);
    if(historical){
      var option=Array.prototype.find.call(select.options,function(item){return item.value===previous;});
      if(option)option.textContent=previous+' (asignación actual)';
    }
    var note=document.getElementById('av-terrain-note');
    if(note)note.textContent=!project?'Selecciona un proyecto para ver sus vendedoras de terreno.'
      :historical?'Se conserva la asignación actual. Para cambiarla, elige una persona asignada al proyecto en el Cotizador.'
      :!names.length?'Este proyecto no tiene terreno asignado en el Cotizador. Puedes guardar sin asignar y configurarlo allí.'
      :previous&&!selected?'Se quitó la selección anterior porque no está asignada a este proyecto en el Cotizador.'
      :'Solo personas asignadas a este proyecto en el Cotizador.';
  }

  function formatDate(value){
    return typeof fmtDate==='function'?(fmtDate(value)||'Sin fecha'):(value||'Sin fecha');
  }

  function createdAtDisplay(value){
    if(/^\d{4}-\d{2}-\d{2}$/.test(String(value||'')))return {date:formatDate(value),time:''};
    var date=value?new Date(value):null;
    if(!date||isNaN(date.getTime()))return {date:'Sin registro',time:''};
    var iso=date.getFullYear()+'-'+String(date.getMonth()+1).padStart(2,'0')+'-'+String(date.getDate()).padStart(2,'0');
    var time=String(date.getHours()).padStart(2,'0')+':'+String(date.getMinutes()).padStart(2,'0');
    return {date:formatDate(iso),time:time};
  }

  function creationDateForInput(value){
    var raw=String(value||'').trim();
    if(/^\d{4}-\d{2}-\d{2}$/.test(raw))return raw;
    var date=raw?new Date(raw):null;
    if(!date||isNaN(date.getTime()))return '';
    return date.getFullYear()+'-'+String(date.getMonth()+1).padStart(2,'0')+'-'+String(date.getDate()).padStart(2,'0');
  }

  function creationTimestampWithDate(value,selectedDate){
    var match=String(selectedDate||'').match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if(!match)return '';
    var year=Number(match[1]),month=Number(match[2])-1,day=Number(match[3]);
    var valid=new Date(year,month,day,12);
    if(valid.getFullYear()!==year||valid.getMonth()!==month||valid.getDate()!==day)return '';
    var raw=String(value||'').trim();
    var original=raw&&!/^\d{4}-\d{2}-\d{2}$/.test(raw)?new Date(raw):null;
    var updated=original&&!isNaN(original.getTime())?original:valid;
    updated.setFullYear(year,month,day);
    return creationDateForInput(updated.toISOString())===selectedDate?updated.toISOString():'';
  }

  function statusClass(value){
    var key=normalize(value);
    if(key.indexOf('reserv')>=0)return 'reserved';
    if(key.indexOf('no concretada')>=0||key.indexOf('cancel')>=0)return 'cancelled';
    if(key.indexOf('concretada')>=0)return 'done';
    if(key.indexOf('confirm')>=0)return 'confirmed';
    return 'scheduled';
  }

  function stateBadge(value){
    return '<span class="av-status '+statusClass(value)+'">'+escapeHtml(value||'Sin estado')+'</span>';
  }

  function stripQuoteReservationAction(html){return String(html||'');}

  function openVisitSchedulingFromQuote(){
    if(typeof cerrarCotModal==='function')cerrarCotModal();
    var button=document.getElementById('tbtn-'+VIEW_ID);
    if(button&&typeof setTab==='function')setTab(VIEW_ID,button);
    if(typeof toast==='function')toast('Crea la Reserva desde la visita correspondiente.','success');
  }

  function injectNavigation(){
    ['tbtn-visitas','tbtn-cal-visitas'].forEach(function(id){
      var legacyButton=document.getElementById(id);
      if(legacyButton)legacyButton.remove();
    });
    var signaturesCalendar=document.getElementById('tbtn-calendario');
    if(signaturesCalendar){
      var signaturesLabel=signaturesCalendar.querySelector('.snav-label');
      if(signaturesLabel)signaturesLabel.textContent='Calendario de firmas';
      signaturesCalendar.title='Calendario de firmas';
    }
    if(document.getElementById('tbtn-'+VIEW_ID))return;
    var cotizador=document.getElementById('tbtn-ventas');
    if(!cotizador)return;
    cotizador.insertAdjacentHTML('beforebegin',
      '<button class="snav-btn" id="tbtn-'+VIEW_ID+'" onclick="setTab(\''+VIEW_ID+'\',this)">'+
        '<span class="snav-ico" aria-hidden="true">🗓️</span><span class="snav-label">Agendamiento de visita</span><span class="tab-count" id="cnt-'+VIEW_ID+'">0</span>'+
      '</button>');
  }

  function injectPanel(){
    if(document.getElementById('panel-'+VIEW_ID))return;
    var reservations=document.getElementById('panel-cartera');
    if(!reservations)return;
    var legacyVisits=document.getElementById('panel-visitas');
    if(legacyVisits){legacyVisits.hidden=true;legacyVisits.setAttribute('aria-hidden','true');}
    var legacyCalendar=document.getElementById('panel-cal-visitas');
    reservations.insertAdjacentHTML('beforebegin',
      '<div id="panel-'+VIEW_ID+'" class="tab-panel av-panel">'+
        '<div class="av-heading">'+
          '<div><div class="av-heading-title">Agendamiento de visita</div><div class="av-heading-sub">Agenda comercial conectada con cotizaciones, lotes y reservas.</div></div>'+
          '<div class="av-heading-actions"><div class="av-view-switch" role="tablist" aria-label="Vista de agendamiento">'+
            '<button type="button" class="av-view-button active" id="av-view-list" role="tab" aria-selected="true"><span aria-hidden="true">☷</span> Lista</button>'+
            '<button type="button" class="av-view-button" id="av-view-calendar" role="tab" aria-selected="false"><span aria-hidden="true">▦</span> Calendario</button>'+
          '</div><button type="button" class="btn btn-ghost av-export-button" id="av-export-excel" title="Descargar las visitas visibles en Excel"><span aria-hidden="true">↓</span> Excel</button><button type="button" class="btn btn-ghost av-export-button" id="av-export-pdf" title="Descargar las visitas visibles en PDF"><span aria-hidden="true">↓</span> PDF</button><button type="button" class="btn btn-primary av-new-button" id="av-new-button"><span aria-hidden="true">＋</span> Nueva visita</button></div>'+ 
        '</div>'+
        '<div class="kpi-row" id="av-kpis"></div>'+
        '<div class="av-status-breakdown" id="av-status-breakdown" aria-live="polite"></div>'+
        '<div class="av-view-pane" id="av-list-view">'+
        '<div class="toolbar av-toolbar">'+
          '<div class="av-search-field"><label class="av-filter-caption" for="av-search">Buscar visita</label><div class="search-wrap"><input type="search" id="av-search" placeholder="Nombre, teléfono o proyecto..." title="Buscar cliente, teléfono, proyecto o agente"></div></div>'+
          '<div class="av-date-range" role="group" aria-label="Fecha de visita">'+
            '<span class="av-date-range-caption">Fecha de visita</span>'+
            '<label class="av-date-range-field" for="av-filter-desde"><span>Desde</span><input type="date" class="filter-sel" id="av-filter-desde" data-date-placeholder="Fecha inicio" aria-label="Desde" title="Desde"></label>'+
            '<label class="av-date-range-field" for="av-filter-hasta"><span>Hasta</span><input type="date" class="filter-sel" id="av-filter-hasta" data-date-placeholder="Fecha término" aria-label="Hasta" title="Hasta"></label>'+
          '</div>'+
          '<div class="av-created-field"><span class="av-filter-caption" aria-hidden="true">Creación</span><details class="av-created-filter" id="av-created-filter"><summary class="filter-sel av-created-filter-button" aria-label="Filtrar por fecha de creación">Elegir fechas <span class="av-created-filter-dot" aria-hidden="true"></span></summary>'+
            '<div class="av-created-filter-menu"><div class="av-created-filter-head"><strong>Fecha de creación</strong><button type="button" id="av-created-clear">Limpiar</button></div>'+
              '<label>Desde<input type="date" class="filter-sel" id="av-created-desde" aria-label="Creada desde"></label>'+
              '<label>Hasta<input type="date" class="filter-sel" id="av-created-hasta" aria-label="Creada hasta"></label>'+
            '</div></details></div>'+
          '<div class="av-project-multi" id="av-project-filter">'+
            '<span class="av-filter-caption" aria-hidden="true">Proyecto</span>'+
            '<button type="button" class="filter-sel av-project-filter-button" id="av-filter-project-button" aria-haspopup="listbox" aria-expanded="false"><span id="av-filter-project-label">Todos los proyectos</span><span class="av-project-filter-chevron" aria-hidden="true">⌄</span></button>'+
            '<div class="av-project-filter-menu" id="av-filter-project-menu" role="listbox" aria-multiselectable="true" hidden>'+
              '<div class="av-project-filter-head"><strong>Seleccionar proyectos</strong><button type="button" id="av-filter-project-clear">Limpiar</button></div>'+
              '<div class="av-project-filter-options" id="av-filter-project-options"></div>'+
            '</div>'+
            '<select id="av-filter-project" multiple hidden aria-hidden="true"></select>'+
          '</div>'+
          '<div class="av-list-multi av-calendar-multi" id="av-filter-status-control">'+
            '<span class="av-filter-caption" aria-hidden="true">Estado</span>'+
            '<button type="button" class="filter-sel av-calendar-filter-button" id="av-filter-status-button" aria-haspopup="listbox" aria-expanded="false"><span id="av-filter-status-label">Todos los estados</span><span class="av-project-filter-chevron" aria-hidden="true">⌄</span></button>'+ 
            '<div class="av-calendar-filter-menu" id="av-filter-status-menu" role="listbox" aria-multiselectable="true" hidden><div class="av-project-filter-head"><strong>Seleccionar estados</strong><button type="button" id="av-filter-status-clear">Limpiar</button></div><div class="av-project-filter-options" id="av-filter-status-options"></div></div>'+ 
            '<select id="av-filter-status" multiple hidden aria-hidden="true"></select>'+ 
          '</div>'+ 
          '<div class="av-list-multi av-calendar-multi" id="av-filter-agent-control">'+
            '<span class="av-filter-caption" aria-hidden="true">Ejecutiva</span>'+
            '<button type="button" class="filter-sel av-calendar-filter-button" id="av-filter-agent-button" aria-haspopup="listbox" aria-expanded="false"><span id="av-filter-agent-label">Todas las ejecutivas</span><span class="av-project-filter-chevron" aria-hidden="true">⌄</span></button>'+ 
            '<div class="av-calendar-filter-menu" id="av-filter-agent-menu" role="listbox" aria-multiselectable="true" hidden><div class="av-project-filter-head"><strong>Seleccionar ejecutivas</strong><button type="button" id="av-filter-agent-clear">Limpiar</button></div><div class="av-project-filter-options" id="av-filter-agent-options"></div></div>'+ 
            '<select id="av-filter-agent" multiple hidden aria-hidden="true"></select>'+ 
          '</div>'+ 
          '<div class="av-list-multi av-calendar-multi" id="av-filter-terrain-control">'+
            '<span class="av-filter-caption" aria-hidden="true">Terreno</span>'+
            '<button type="button" class="filter-sel av-calendar-filter-button" id="av-filter-terrain-button" aria-haspopup="listbox" aria-expanded="false"><span id="av-filter-terrain-label">Terreno</span><span class="av-project-filter-chevron" aria-hidden="true">⌄</span></button>'+ 
            '<div class="av-calendar-filter-menu" id="av-filter-terrain-menu" role="listbox" aria-multiselectable="true" hidden><div class="av-project-filter-head"><strong>Seleccionar terreno</strong><button type="button" id="av-filter-terrain-clear">Limpiar</button></div><div class="av-project-filter-options" id="av-filter-terrain-options"></div></div>'+ 
            '<select id="av-filter-terrain" multiple hidden aria-hidden="true"></select>'+ 
          '</div>'+ 
          '<button type="button" class="btn btn-ghost btn-sm" id="av-clear-filters">Limpiar</button>'+
        '</div>'+
        '<div class="table-wrap av-table-wrap">'+
          '<div class="table-header"><span class="table-header-title" id="av-count">0 visitas</span></div>'+
          '<div class="table-scroll"><table class="av-table">'+
            '<thead><tr><th>Creada</th><th>Fecha de visita</th><th>Cliente</th><th>Proyecto / lote</th><th>Contacto</th><th>Ejecutiva</th><th>Terreno</th><th>Estado</th><th>Acciones</th></tr></thead>'+ 
            '<tbody id="av-tbody"></tbody>'+
          '</table></div><div class="av-pagination" id="av-pagination"></div>'+
          '</div>'+ 
        '</div>'+ 
      '</div>');
    var schedulePanel=document.getElementById('panel-'+VIEW_ID);
    if(legacyCalendar&&schedulePanel){
      legacyCalendar.classList.remove('tab-panel');
      legacyCalendar.classList.add('av-view-pane','av-calendar-view');
      legacyCalendar.hidden=true;
      legacyCalendar.setAttribute('aria-hidden','true');
      schedulePanel.appendChild(legacyCalendar);
    }
  }

  function setScheduleView(mode){
    scheduleViewMode=mode==='calendar'?'calendar':'list';
    setProjectFilterOpen(false);
    setCalendarFilterOpen('',false);
    setListMultiFilterOpen('',false);
    var list=document.getElementById('av-list-view');
    var calendar=document.getElementById('panel-cal-visitas');
    var listButton=document.getElementById('av-view-list');
    var calendarButton=document.getElementById('av-view-calendar');
    var showCalendar=scheduleViewMode==='calendar';
    if(list){list.hidden=showCalendar;list.setAttribute('aria-hidden',showCalendar?'true':'false');}
    if(calendar){calendar.hidden=!showCalendar;calendar.setAttribute('aria-hidden',showCalendar?'false':'true');}
    if(listButton){listButton.classList.toggle('active',!showCalendar);listButton.setAttribute('aria-selected',showCalendar?'false':'true');}
    if(calendarButton){calendarButton.classList.toggle('active',showCalendar);calendarButton.setAttribute('aria-selected',showCalendar?'true':'false');}
    var panel=document.getElementById('panel-'+VIEW_ID);
    var panelActive=!!(panel&&panel.classList.contains('active'));
    if(showCalendar&&typeof renderVisitasCalendario==='function'){
      if(typeof visitasLoaded!=='undefined'&&!visitasLoaded){
        showVisitLoadingState();
        if(typeof ensureVisitasLoaded==='function')ensureVisitasLoaded();
      }else renderVisitasCalendario();
    }else if(!showCalendar&&panelActive){
      if(typeof visitasLoaded!=='undefined'&&!visitasLoaded){
        showVisitLoadingState();
        if(typeof ensureVisitasLoaded==='function')ensureVisitasLoaded();
      }else renderVisits();
    }
  }

  function showVisitLoadingState(){
    var count=document.getElementById('av-count');
    var body=document.getElementById('av-tbody');
    if(count)count.textContent='Cargando visitas...';
    if(body)body.innerHTML='<tr><td colspan="9"><div class="av-empty">Preparando la agenda. Esto tomará sólo un momento...</div></td></tr>';
  }

  function renderActiveScheduleView(resetPage){
    if(scheduleViewMode==='calendar'&&typeof renderVisitasCalendario==='function')renderVisitasCalendario();
    else renderVisits(resetPage);
  }

  function injectModals(){
    if(document.getElementById('modal-av-editor'))return;
    var anchor=document.getElementById('toast-container');
    if(!anchor)return;
    anchor.insertAdjacentHTML('beforebegin',
      '<div class="modal-overlay" id="modal-av-editor">'+
        '<div class="modal av-modal">'+
          '<div class="modal-head"><h3 id="av-editor-title">Nueva visita</h3><button type="button" class="modal-close" id="av-editor-close" aria-label="Cerrar">✕</button></div>'+
          '<form id="av-editor-form"><div class="modal-body">'+
            '<div class="av-form-section"><div class="av-section-title">Cliente</div><div class="av-form-grid">'+
              '<div class="form-group av-span-2"><label for="av-client">Nombre completo *</label><input id="av-client" autocomplete="off"></div>'+
              '<div class="form-group"><label for="av-rut">RUT</label><input id="av-rut" autocomplete="off"></div>'+
              '<div class="form-group"><label for="av-phone">Telefono *</label><input id="av-phone" inputmode="tel" autocomplete="off"></div>'+
              '<div class="form-group av-span-2"><label for="av-email">Correo electronico</label><input id="av-email" type="email" autocomplete="off"></div>'+
              '<div class="form-group"><label for="av-medium">Medio</label><select id="av-medium"></select></div>'+
            '</div></div>'+
            '<div class="av-form-section"><div class="av-section-title">Visita</div><div class="av-form-grid">'+
              '<div class="form-group"><label for="av-project">Proyecto *</label><select id="av-project"></select></div>'+
              '<div class="form-group"><label for="av-lot">Lote de interes <span class="av-optional">(opcional)</span></label><select id="av-lot"><option value="">Sin lote definido</option></select><div class="av-field-note" id="av-lot-note"></div></div>'+ 
              '<div class="form-group"><label for="av-date">Fecha visita *</label><input id="av-date" type="date"></div>'+ 
              '<div class="form-group"><label id="av-time-label">Hora *</label><div class="av-time-picker" aria-labelledby="av-time-label">'+
                '<select id="av-time-hour" aria-label="Hora">'+numberOptions(24,1,'Hora')+'</select><span class="av-time-separator" aria-hidden="true">:</span><select id="av-time-minute" aria-label="Minutos">'+numberOptions(60,5,'Min')+'</select>'+ 
              '</div></div>'+ 
              '<div class="form-group"><label for="av-status">Estado *</label><select id="av-status"></select></div>'+
              '<div class="form-group"><label for="av-substatus">Subestado</label><input id="av-substatus" autocomplete="off" placeholder="Detalle opcional"></div>'+
              '<div class="form-group"><label for="av-remote">Ejecutiva / remoto *</label><select id="av-remote"></select></div>'+
              '<div class="form-group"><label for="av-terrain">Vendedora de terreno <span class="av-optional">(opcional)</span></label><select id="av-terrain" aria-describedby="av-terrain-note"></select><div class="av-field-note" id="av-terrain-note"></div></div>'+ 
              '<div class="form-group av-span-3"><div id="av-observation-mode" class="av-observation-mode" hidden><span class="av-observation-mode-icon">●</span><span><strong>Modo observaciones de terreno</strong><small>Los datos de la visita están bloqueados. Puedes agregar, editar o eliminar tus propias observaciones.</small></span></div><div id="av-notes-history" class="av-notes-history" hidden></div><div id="av-note-editing" class="av-note-editing" hidden><span><strong>Editando observación</strong><small>Se conservarán su autor y fecha original.</small></span><button type="button" class="btn btn-ghost btn-sm" id="av-note-edit-cancel">Cancelar edición</button></div><label for="av-notes" id="av-notes-label">Observaciones</label><textarea id="av-notes" rows="3" placeholder="Indicaciones, punto de encuentro u otra informacion relevante"></textarea></div>'+ 
            '</div></div>'+
          '</div><div class="modal-footer"><button type="button" class="btn btn-ghost" id="av-editor-cancel">Cancelar</button><button type="submit" class="btn btn-primary" id="av-editor-save">Guardar visita</button></div></form>'+ 
        '</div>'+ 
      '</div>'+ 
      '<div class="modal-overlay" id="modal-av-created-date">'+
        '<div class="modal av-modal" style="max-width:440px">'+
          '<div class="modal-head"><h3>Corregir fecha de creación</h3><button type="button" class="modal-close" id="av-created-close" aria-label="Cerrar">✕</button></div>'+
          '<form id="av-created-form"><div class="modal-body">'+
            '<div id="av-created-context" style="font-size:11px;font-weight:700;color:var(--text);margin-bottom:12px"></div>'+
            '<div class="form-group"><label for="av-created-date">Fecha de creación</label><input id="av-created-date" type="date" required></div>'+
            '<p style="font-size:10px;color:var(--text3);margin:10px 0 0">Solo cambia el día de creación; se conserva la hora original cuando existe. La fecha agendada de la visita no cambia.</p>'+
          '</div><div class="modal-footer"><button type="button" class="btn btn-ghost" id="av-created-cancel">Cancelar</button><button type="submit" class="btn btn-primary" id="av-created-save">Guardar fecha</button></div></form>'+
        '</div>'+
      '</div>'+
      '<div class="modal-overlay" id="modal-av-reserve">'+
        '<div class="modal av-modal av-reserve-modal">'+
          '<div class="modal-head"><h3>Revisar y pasar a Reserva</h3><button type="button" class="modal-close" id="av-reserve-close" aria-label="Cerrar">✕</button></div>'+ 
          '<div class="modal-body">'+
            '<div class="av-review" id="av-review"></div>'+ 
            '<div class="av-form-section"><div class="av-section-title">Datos de la Reserva</div><div class="av-section-help">Ingreso manual; no se completan desde la visita ni desde la cotizacion.</div><div class="av-form-grid">'+
              '<div class="form-group"><label for="av-reserve-age">Edad <span class="av-optional">(opcional)</span></label><input id="av-reserve-age" type="number" min="0" max="120" step="1" inputmode="numeric" placeholder="Ej: 35"></div>'+ 
              '<div class="form-group"><label for="av-reserve-children">Cantidad de hijos <span class="av-optional">(opcional)</span></label><input id="av-reserve-children" type="number" min="0" step="1" inputmode="numeric" placeholder="Ej: 2"></div>'+ 
            '</div></div>'+ 
            '<div class="av-form-section"><div class="av-section-head"><div><div class="av-section-title">Cotizacion obligatoria</div><div class="av-section-help">Solo aparecen cotizaciones creadas por la ejecutiva de esta visita.</div></div><button type="button" class="btn btn-ghost btn-sm" id="av-refresh-quotes">Actualizar</button></div>'+ 
              '<input type="search" id="av-quote-search" class="av-quote-search" placeholder="Buscar por folio, cliente, proyecto o lote...">'+ 
              '<div id="av-quote-list" class="av-quote-list"><div class="av-empty">Cargando cotizaciones...</div></div>'+ 
              '<div id="av-quote-detail"></div>'+ 
            '</div>'+ 
            '<div class="av-form-section"><div class="av-section-title">Comprobante de pago *</div><div class="av-section-help">Se enviara junto con la Reserva a Validacion de Reserva.</div>'+ 
              '<label class="btn btn-ghost av-upload-button" for="av-reserve-files"><span aria-hidden="true">＋</span> Adjuntar archivos</label><input id="av-reserve-files" type="file" multiple hidden>'+ 
              '<div id="av-file-list" class="av-file-list"><div class="av-empty compact">Sin archivos adjuntos.</div></div>'+ 
            '</div>'+ 
            '<div id="av-reserve-validation" class="av-validation" hidden></div>'+ 
          '</div>'+ 
          '<div class="modal-footer"><button type="button" class="btn btn-ghost" id="av-reserve-cancel">Cancelar</button><button type="button" class="btn btn-primary" id="av-reserve-confirm" disabled>Crear Reserva</button></div>'+ 
        '</div>'+ 
      '</div>');
  }

  function populateEditorLists(visit){
    visit=visit||{};
    var access=projectAccess(currentUser);
    var currentProject=canonicalProjectName(visit.proyecto);
    var names=access.names.slice();
    if(visit.id&&currentProject&&!names.some(function(name){return normalize(name)===normalize(currentProject);}))names.push(currentProject);
    setOptions('av-project',names,access.restricted&&!names.length?'Sin proyectos asignados':'Seleccionar proyecto',currentProject);
    setOptions('av-remote',remoteAgents(),'Seleccionar ejecutiva',visit.remoto);
    refreshTerrainOptions(visit.terreno||'',visit);
    setOptions('av-medium',MEDIA_OPTIONS,'Seleccionar medio',visit.medio);
    setOptions('av-status',STATUS_OPTIONS,'Seleccionar estado',visit.estado||'Agenda Visita');
    refreshLotOptions(visit.lote||'');
  }

  function lotIsUnavailable(project,lot,editing){
    var blocker=null;
    try{blocker=getBloqueoLote(project,lot);}catch(error){}
    if(blocker)return true;
    return (state.registros||[]).some(function(record){
      return record.id!==editing&&record.proyecto===project&&typeof sameLote==='function'&&sameLote(record.name,lot)&&typeof registroOcupaLote==='function'&&registroOcupaLote(record);
    });
  }

  function refreshLotOptions(current){
    var project=selectedValue('av-project');
    var select=document.getElementById('av-lot');
    var note=document.getElementById('av-lot-note');
    if(!select)return;
    var lots=[];
    try{lots=getLotesDeProyecto(project)||[];}catch(error){}
    select.innerHTML='<option value="">Sin lote definido</option>'+lots.map(function(lot){
      var unavailable=lotIsUnavailable(project,String(lot),'');
      return '<option value="'+escapeHtml(lot)+'"'+(unavailable?' disabled':'')+'>'+escapeHtml(lot)+(unavailable?' - no disponible':'')+'</option>';
    }).join('');
    if(current&&!Array.prototype.some.call(select.options,function(option){return option.value===current;})){
      select.insertAdjacentHTML('beforeend','<option value="'+escapeHtml(current)+'">'+escapeHtml(current)+'</option>');
    }
    select.value=current||'';
    if(note)note.textContent=project?(lots.length?lots.length+' lotes disponibles. Puedes guardar sin elegir uno.':'Proyecto sin lotes configurados. Puedes guardar igualmente.'):'Selecciona un proyecto; el lote puede quedar sin definir.';
  }

  function terrainObservationHistory(visit){
    var history=Array.isArray(visit&&visit.observacionesTerreno)?visit.observacionesTerreno.filter(function(item){return item&&String(item.texto||'').trim();}):[];
    if(!history.length&&visit&&visit.observacionTerrenoAt&&String(visit.observacion||'').trim()){
      history=[{texto:String(visit.observacion).trim(),autor:visit.observacionTerrenoPor||visit.actualizadoPor||visit.terreno||'',at:visit.observacionTerrenoAt}];
    }
    return history;
  }

  function hasTerrainObservation(visit){
    return terrainObservationHistory(visit).length>0;
  }

  function remoteObservationHistory(visit){
    var history=Array.isArray(visit&&visit.observacionesRemoto)?visit.observacionesRemoto.filter(function(item){return item&&String(item.texto||'').trim();}):[];
    if(!history.length&&visit&&visit.observacionRemotoAt&&String(visit.observacion||'').trim()){
      history=[{texto:String(visit.observacion).trim(),autor:visit.observacionRemotoPor||visit.actualizadoPor||visit.remoto||'',at:visit.observacionRemotoAt}];
    }
    // Compatibilidad con observaciones antiguas: antes se guardaban sólo en
    // `observacion`, por eso dejaron de verse al separar las notas de terreno.
    if(!history.length&&visit&&String(visit.observacion||'').trim()&&!hasTerrainObservation(visit)){
      history=[{texto:String(visit.observacion).trim(),autor:visit.actualizadoPor||visit.creadoPor||visit.remoto||'Ejecutiva remota',at:visit.actualizadoAt||visit.creadoAt||visit.fechaCreacion||''}];
    }
    return history;
  }

  function hasRemoteObservation(visit){
    return remoteObservationHistory(visit).length>0;
  }

  function appendVisitObservation(visit,kind,value,author,timestamp){
    if(!visit)return null;
    var text=String(value||'').trim();
    if(!text)return null;
    var terrain=kind==='terrain';
    var history=(terrain?terrainObservationHistory(visit):remoteObservationHistory(visit)).slice();
    var at=timestamp||nowIso();
    var entry={
      id:(terrain?'avnote_':'avrnote_')+Date.now()+Math.random().toString(36).slice(2,7),
      texto:text,
      autor:author||(terrain?visit.terreno:visit.remoto)||(terrain?'Terreno':'Ejecutiva remota'),
      autorUid:(typeof currentFirebaseUser!=='undefined'&&currentFirebaseUser&&currentFirebaseUser.uid)||(currentUser&&currentUser.uid)||'',
      at:at,
      ts:typeof nowTs==='function'?nowTs():at
    };
    if(terrain){
      visit.observacionesTerreno=history.concat([entry]);
      visit.observacionTerrenoAt=at;
      visit.observacionTerrenoPor=entry.autor;
    }else{
      visit.observacionesRemoto=history.concat([entry]);
      visit.observacionRemotoAt=at;
      visit.observacionRemotoPor=entry.autor;
    }
    // `observacion` se mantiene como la nota más reciente para las vistas
    // antiguas, mientras los arreglos anteriores conservan el historial real.
    visit.observacion=text;
    return entry;
  }

  function observationDate(value){
    var date=value?new Date(value):null;
    if(!date||isNaN(date.getTime()))return '';
    return date.toLocaleString('es-CL',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'});
  }

  function currentObservationUserUid(){
    return (typeof currentFirebaseUser!=='undefined'&&currentFirebaseUser&&currentFirebaseUser.uid)||(currentUser&&currentUser.uid)||'';
  }

  function canEditVisitObservation(visit,kind,item){
    if(!visit||!item||!currentUser||!canEditVisit(visit))return false;
    if(kind==='terrain'&&!isTerrainUser(currentUser))return false;
    if(kind==='remote'&&isTerrainUser(currentUser))return false;
    var uid=currentObservationUserUid();
    if(item.autorUid&&uid)return item.autorUid===uid;
    return !!item.autor&&normalize(item.autor)===normalize(currentUser.nombre||'');
  }

  function beginObservationEdit(kind,index){
    var visit=editingVisitId?findVisit(editingVisitId):null;
    var history=kind==='terrain'?terrainObservationHistory(visit):remoteObservationHistory(visit);
    var item=history[index];
    if(!canEditVisitObservation(visit,kind,item)){toast('Sólo puedes editar observaciones creadas por ti.','error');return;}
    editingObservationContext={kind:kind,index:index};
    var banner=document.getElementById('av-note-editing');
    var notes=document.getElementById('av-notes');
    var label=document.getElementById('av-notes-label');
    var save=document.getElementById('av-editor-save');
    if(banner)banner.hidden=false;
    if(notes){notes.value=item.texto||'';notes.focus();notes.setSelectionRange(notes.value.length,notes.value.length);}
    if(label)label.textContent='Editar observación *';
    if(save)save.textContent='Guardar cambios en nota';
  }

  function cancelObservationEdit(){
    editingObservationContext=null;
    var visit=editingVisitId?findVisit(editingVisitId):null;
    setEditorAccessMode(visit);
    var notes=document.getElementById('av-notes');
    if(notes)notes.focus();
  }

  async function saveObservationEdit(existing){
    var context=editingObservationContext;
    var text=selectedValue('av-notes');
    if(!context||!text){toast('Escribe la observación antes de guardar.','error');return false;}
    var history=(context.kind==='terrain'?terrainObservationHistory(existing):remoteObservationHistory(existing)).slice();
    var item=history[context.index];
    if(!canEditVisitObservation(existing,context.kind,item)){toast('Sólo puedes editar observaciones creadas por ti.','error');return false;}
    var previous=JSON.parse(JSON.stringify(existing));
    var timestamp=nowIso();
    var editor=currentUser.nombre||item.autor||'';
    var oldText=String(item.texto||'');
    history[context.index]=Object.assign({},item,{texto:String(text).trim(),editadoAt:timestamp,editadoPor:editor,editadoPorUid:currentObservationUserUid()});
    if(context.kind==='terrain')existing.observacionesTerreno=history;
    else existing.observacionesRemoto=history;
    if(String(existing.observacion||'')===oldText)existing.observacion=history[context.index].texto;
    existing.actualizadoAt=timestamp;
    existing.actualizadoPor=editor;
    existing.actividad=existing.actividad||[];
    existing.actividad.push({ts:typeof nowTs==='function'?nowTs():timestamp,user:editor,msg:(context.kind==='terrain'?'Observación de terreno':'Observación remota')+' editada'});
    try{
      await persistOwnVisit(existing,previous);
    }catch(error){
      Object.keys(existing).forEach(function(key){delete existing[key];});
      Object.assign(existing,previous);
      console.error('No se pudo editar la observación de la visita:',error);
      toast('No se pudo editar la observación. Inténtalo nuevamente.','error');
      return false;
    }
    editingObservationContext=null;
    setEditorAccessMode(existing);
    renderVisits();
    updateVisitCount();
    toast('Observación actualizada.','success');
    return true;
  }

  function removeVisitObservationFromDraft(visit,kind,index){
    if(!visit)return null;
    var terrain=kind==='terrain';
    var history=(terrain?terrainObservationHistory(visit):remoteObservationHistory(visit)).slice();
    if(index<0||index>=history.length)return null;
    var removed=history.splice(index,1)[0];
    if(terrain){
      visit.observacionesTerreno=history;
      var latestTerrain=history.length?history[history.length-1]:null;
      visit.observacionTerrenoAt=latestTerrain?(latestTerrain.at||latestTerrain.ts||''):'';
      visit.observacionTerrenoPor=latestTerrain?(latestTerrain.autor||''):'';
    }else{
      visit.observacionesRemoto=history;
      var latestRemote=history.length?history[history.length-1]:null;
      visit.observacionRemotoAt=latestRemote?(latestRemote.at||latestRemote.ts||''):'';
      visit.observacionRemotoPor=latestRemote?(latestRemote.autor||''):'';
    }
    var remaining=[];
    (visit.observacionesRemoto||[]).forEach(function(item,order){if(item&&String(item.texto||'').trim())remaining.push({item:item,order:order});});
    var terrainOffset=remaining.length;
    (visit.observacionesTerreno||[]).forEach(function(item,order){if(item&&String(item.texto||'').trim())remaining.push({item:item,order:terrainOffset+order});});
    remaining.sort(function(a,b){
      var aTime=new Date(a.item.at||a.item.ts||0).getTime();
      var bTime=new Date(b.item.at||b.item.ts||0).getTime();
      if(!isFinite(aTime))aTime=0;
      if(!isFinite(bTime))bTime=0;
      return aTime===bTime?a.order-b.order:aTime-bTime;
    });
    visit.observacion=remaining.length?String(remaining[remaining.length-1].item.texto||'').trim():'';
    return removed;
  }

  async function deleteVisitObservation(kind,index){
    var visit=editingVisitId?findVisit(editingVisitId):null;
    var history=kind==='terrain'?terrainObservationHistory(visit):remoteObservationHistory(visit);
    var item=history[index];
    if(!canEditVisitObservation(visit,kind,item)){toast('Sólo puedes eliminar observaciones creadas por ti.','error');return false;}
    if(!confirm('¿Eliminar esta observación?\n\nEsta acción no se puede deshacer.'))return false;
    var previous=JSON.parse(JSON.stringify(visit));
    var removed=removeVisitObservationFromDraft(visit,kind,index);
    if(!removed)return false;
    var timestamp=nowIso();
    var editor=currentUser.nombre||removed.autor||'';
    visit.actualizadoAt=timestamp;
    visit.actualizadoPor=editor;
    visit.actividad=visit.actividad||[];
    visit.actividad.push({ts:typeof nowTs==='function'?nowTs():timestamp,user:editor,msg:(kind==='terrain'?'Observación de terreno':'Observación remota')+' eliminada'});
    try{
      await persistOwnVisit(visit,previous);
    }catch(error){
      Object.keys(visit).forEach(function(key){delete visit[key];});
      Object.assign(visit,previous);
      console.error('No se pudo eliminar la observación de la visita:',error);
      toast('No se pudo eliminar la observación. Inténtalo nuevamente.','error');
      return false;
    }
    editingObservationContext=null;
    setEditorAccessMode(visit);
    renderVisits();
    updateVisitCount();
    toast('Observación eliminada.','success');
    return true;
  }

  function renderObservationHistory(visit){
    var container=document.getElementById('av-notes-history');
    if(!container)return;
    var remoteHistory=remoteObservationHistory(visit);
    var terrainHistory=terrainObservationHistory(visit);
    container.hidden=!remoteHistory.length&&!terrainHistory.length;
    function section(title,history,kind,fallback){
      if(!history.length)return '';
      var entries=history.map(function(item,index){return {item:item,index:index};}).reverse();
      return '<div class="av-notes-history-title '+kind+'"><span class="av-note-dot"></span> '+title+'</div>'+entries.map(function(entry){
        var item=entry.item;
        var edited=item.editadoAt?('Editada '+observationDate(item.editadoAt)+(item.editadoPor?' por '+item.editadoPor:'')):'';
        var meta=[item.autor||fallback,observationDate(item.at||item.ts),edited].filter(Boolean).join(' · ');
        var noteActions=canEditVisitObservation(visit,kind,item)?'<div class="av-note-entry-actions"><button type="button" class="av-note-edit-button" data-av-note-edit data-kind="'+kind+'" data-index="'+entry.index+'" title="Editar esta observación" aria-label="Editar esta observación">✎ Editar</button><button type="button" class="av-note-delete-button" data-av-note-delete data-kind="'+kind+'" data-index="'+entry.index+'" title="Eliminar esta observación" aria-label="Eliminar esta observación">🗑 Eliminar</button></div>':'';
        return '<div class="av-note-entry '+kind+'"><div class="av-note-entry-head"><div class="av-note-entry-text">'+escapeHtml(item.texto||'')+'</div>'+noteActions+'</div><small>'+escapeHtml(meta)+'</small></div>';
      }).join('');
    }
    container.innerHTML=section('Observaciones de la ejecutiva remota',remoteHistory,'remote','Ejecutiva remota')+section('Observaciones de terreno',terrainHistory,'terrain','Terreno');
  }

  function setEditorAccessMode(visit){
    var terrainMode=!!visit&&isTerrainUser(currentUser);
    var existingMode=!!visit;
    EDITOR_LOCKED_FIELDS.forEach(function(id){
      var element=document.getElementById(id);
      if(typeof setReadOnlyField==='function')setReadOnlyField(element,terrainMode);
      else if(element)element.disabled=terrainMode;
    });
    var banner=document.getElementById('av-observation-mode');
    var label=document.getElementById('av-notes-label');
    var save=document.getElementById('av-editor-save');
    var editingBanner=document.getElementById('av-note-editing');
    if(banner)banner.hidden=!terrainMode;
    if(label)label.textContent=terrainMode?'Nueva observación *':(existingMode?'Nueva observación (opcional)':'Observaciones iniciales (opcional)');
    if(save)save.textContent=terrainMode?'Guardar observación':'Guardar visita';
    if(editingBanner)editingBanner.hidden=true;
    document.getElementById('av-editor-title').textContent=terrainMode?'Observaciones de la visita':(visit?'Editar visita':'Nueva visita');
    renderObservationHistory(visit||{});
    var notes=document.getElementById('av-notes');
    if(notes){
      if(existingMode)notes.value='';
      notes.placeholder=terrainMode?'Escribe aquí lo ocurrido en terreno...':(existingMode?'Escribe una nueva observación; el historial anterior no se reemplazará.':'Indicaciones, punto de encuentro u otra información relevante');
    }
  }

  async function openEditor(id){
    if(!CarteraSaveGuard.canClose('modal-av-editor'))return;
    var visit=id?findVisit(id):null;
    if(visit&&!canEditVisit(visit)){toast('No puedes editar esta visita.','error');return;}
    if(!visit&&!canEditVisit(null)){toast('No tienes permiso para crear visitas.','error');return;}
    var request=++editorOpenRequest;
    try{
      if(typeof _configRemotaPromesa!=='undefined'&&_configRemotaPromesa)await _configRemotaPromesa;
      else if(typeof iniciarConfigCentralizada==='function')await iniciarConfigCentralizada();
    }catch(error){
      console.error('No se pudo actualizar el catálogo de terreno para visitas:',error);
      toast('No se pudo actualizar el Cotizador. Se usará la última configuración disponible.','info');
    }
    if(request!==editorOpenRequest||!canEditVisit(visit))return;
    editingVisitId=visit?visit.id:'';
    pendingNewVisit=null;
    editingObservationContext=null;
    var values=visit||{};
    populateEditorLists(values);
    document.getElementById('av-client').value=values.cliente||'';
    document.getElementById('av-rut').value=values.rut||'';
    document.getElementById('av-phone').value=values.telefono||'';
    document.getElementById('av-email').value=values.email||'';
    // Una visita nueva comienza hoy; una visita existente sin fecha permanece
    // vacía hasta que el usuario seleccione una, evitando inventar fechas.
    syncDateAltInput('av-date',normalizeVisitaDate(values.fechaVisita)||(visit?'':todayIso()));
    setVisitTime(values.horaVisita||'');
    document.getElementById('av-substatus').value=values.subEstado||'';
    document.getElementById('av-notes').value=values.observacion||'';
    if(!visit&&isSeller(currentUser)){
      var remoteAgent=defaultRemoteAgent(currentUser);
      var field=remoteAgent?'remoto':(typeof getSellerScopeField==='function'?getSellerScopeField(currentUser):'remoto');
      var agent=remoteAgent||(currentUser.nombre||'');
      var target=document.getElementById(field==='terreno'?'av-terrain':'av-remote');
      if(target&&Array.prototype.some.call(target.options,function(option){return option.value===agent;}))target.value=agent;
    }
    setEditorAccessMode(visit);
    openModal('modal-av-editor');
    if(visit&&isTerrainUser(currentUser))setTimeout(function(){var notes=document.getElementById('av-notes');if(notes)notes.focus();},40);
  }

  function closeEditor(){
    if(!CarteraSaveGuard.canClose('modal-av-editor'))return;
    editorOpenRequest++;
    editingVisitId='';
    pendingNewVisit=null;
    editingObservationContext=null;
    closeModal('modal-av-editor');
  }

  function openCreationDateEditor(id){
    var visit=findVisit(id);
    if(!canEditCreationDate(visit)){toast('Solo un administrador puede corregir la fecha de creación.','error');return;}
    editingCreationDateVisitId=visit.id;
    document.getElementById('av-created-context').textContent=(visit.cliente||'Visita sin cliente')+' · '+(visit.proyecto||'Sin proyecto');
    syncDateAltInput('av-created-date',creationDateForInput(visit.creadoAt||visit.fechaCreacion));
    openModal('modal-av-created-date');
  }

  function closeCreationDateEditor(){
    editingCreationDateVisitId='';
    closeModal('modal-av-created-date');
  }

  async function saveCreationDateEditor(event){
    event.preventDefault();
    var visit=findVisit(editingCreationDateVisitId);
    if(!canEditCreationDate(visit)){toast('Solo un administrador puede corregir la fecha de creación.','error');return;}
    var selected=selectedValue('av-created-date');
    var original=visit.creadoAt||visit.fechaCreacion||'';
    var corrected=creationTimestampWithDate(original,selected);
    if(!corrected){toast('Selecciona una fecha de creación válida.','error');return;}
    var previousDate=creationDateForInput(original);
    if(previousDate===selected){closeCreationDateEditor();return;}
    var previous=JSON.parse(JSON.stringify(visit));
    var saveButton=document.getElementById('av-created-save');
    if(saveButton)saveButton.disabled=true;
    var timestamp=nowIso();
    visit.creadoAt=corrected;
    if(visit.fechaCreacion!==undefined)visit.fechaCreacion=selected;
    if(visit.createdAt!==undefined)visit.createdAt=corrected;
    visit.actualizadoAt=timestamp;
    visit.actualizadoPor=currentUser.nombre||'';
    visit.actividad=Array.isArray(visit.actividad)?visit.actividad:[];
    visit.actividad.push({ts:typeof nowTs==='function'?nowTs():timestamp,user:currentUser.nombre||'Administrador',msg:'Fecha de creación corregida: '+(previousDate||'sin fecha')+' → '+selected});
    try{
      await persistOwnVisit(visit,previous);
      closeCreationDateEditor();
      renderVisits();
      updateVisitCount();
      toast('Fecha de creación actualizada.','success');
    }catch(error){
      Object.keys(visit).forEach(function(key){delete visit[key];});
      Object.assign(visit,previous);
      console.error('No se pudo corregir la fecha de creación:',error);
      toast('No se pudo guardar la fecha. Inténtalo nuevamente.','error');
    }finally{
      if(saveButton)saveButton.disabled=false;
    }
  }

  function saveEditor(event){
    event.preventDefault();
    return CarteraSaveGuard.run('visita-editor',{modal:'modal-av-editor',button:'av-editor-save'},saveEditorOnce).catch(function(error){
      console.error('No se pudo confirmar el guardado de la visita:',error);
      toast('No se pudo confirmar el guardado. Conserva la ficha abierta y vuelve a Guardar.','error');
      return false;
    });
  }

  async function saveEditorOnce(){
    var existing=editingVisitId?findVisit(editingVisitId):null;
    if(!existing&&!canEditVisit(null)){toast('No tienes permiso para crear visitas.','error');return;}
    if(existing&&!canEditVisit(existing)){toast('No puedes editar esta visita.','error');return;}
    if(existing&&editingObservationContext){await saveObservationEdit(existing);return;}
    if(isTerrainUser(currentUser)){
      if(!existing||!canSeeVisit(existing)){toast('Sólo puedes agregar observaciones a tus visitas asignadas.','error');return;}
      var terrainNote=selectedValue('av-notes');
      if(!terrainNote){toast('Escribe una observación antes de guardar.','error');return;}
      var terrainTimestamp=nowIso();
      var terrainTarget=existing;
      var terrainPrevious=JSON.parse(JSON.stringify(existing));
      var terrainEntry=appendVisitObservation(terrainTarget,'terrain',terrainNote,currentUser.nombre||existing.terreno||'Terreno',terrainTimestamp);
      terrainTarget.actualizadoAt=terrainTimestamp;
      terrainTarget.actualizadoPor=terrainEntry.autor;
      terrainTarget.actividad=terrainTarget.actividad||[];
      terrainTarget.actividad.push({ts:terrainEntry.ts,user:terrainEntry.autor,msg:'Observación de terreno agregada'});
      try{
        await persistOwnVisit(terrainTarget,terrainPrevious);
      }catch(error){
        Object.keys(terrainTarget).forEach(function(key){delete terrainTarget[key];});
        Object.assign(terrainTarget,terrainPrevious);
        console.error('No se pudo guardar la observación en la agenda propia:',error);
        toast('No se pudo guardar la observación. Inténtalo nuevamente.','error');
        return;
      }
      CarteraSaveGuard.complete('visita-editor');
      closeEditor();
      renderVisits();
      updateVisitCount();
      toast('Observación guardada para la ejecutiva remota.','success');
      return;
    }
    var data={
      cliente:selectedValue('av-client'),rut:selectedValue('av-rut'),telefono:selectedValue('av-phone'),email:selectedValue('av-email'),
      proyecto:selectedValue('av-project'),lote:selectedValue('av-lot'),fechaVisita:selectedValue('av-date'),horaVisita:selectedVisitTime(),
      estado:selectedValue('av-status'),subEstado:selectedValue('av-substatus'),remoto:selectedValue('av-remote'),terreno:selectedValue('av-terrain'),
      medio:selectedValue('av-medium')
    };
    var observationDraft=selectedValue('av-notes');
    if(!projectAllowed(data.proyecto,existing)){
      toast('Este proyecto no está asignado a tu perfil del Cotizador.','error');
      return;
    }
    var missing=missingVisitFields(data);
    if(missing.length){toast('Completa: '+missing.join(', ')+'.','error');return;}
    if(!terrainAllowed(data.proyecto,data.terreno,existing)){
      refreshTerrainOptions();
      toast('La persona de terreno no está asignada a este proyecto en el Cotizador. Selecciona una de la lista o deja sin asignar.','error');
      return;
    }
    var timestamp=nowIso();
    if(existing){
      var previous=JSON.parse(JSON.stringify(existing));
      var remoteNote=String(observationDraft||'').trim();
      Object.assign(existing,data,{actualizadoAt:timestamp,actualizadoPor:currentUser.nombre||''});
      existing.actividad=existing.actividad||[];
      existing.actividad.push({ts:typeof nowTs==='function'?nowTs():timestamp,user:currentUser.nombre||'',msg:'Visita actualizada'});
      if(remoteNote){
        var remoteEntry=appendVisitObservation(existing,'remote',remoteNote,currentUser.nombre||existing.remoto||'Ejecutiva remota',timestamp);
        existing.actividad.push({ts:remoteEntry.ts,user:remoteEntry.autor,msg:'Observación remota agregada'});
      }
      if(previous.reservaId)existing.reservaId=previous.reservaId;
      try{
        await persistOwnVisit(existing,previous);
      }catch(error){
        Object.keys(existing).forEach(function(key){delete existing[key];});
        Object.assign(existing,previous);
        console.error('No se pudo guardar la visita en la agenda propia:',error);
        toast('No se pudo guardar la visita. Inténtalo nuevamente.','error');
        return;
      }
    }else{
      // Keep this identity even if the server saved but its confirmation was
      // lost. Retrying upserts this visit rather than creating another one.
      if(!pendingNewVisit)pendingNewVisit={id:'av'+Date.now()+Math.random().toString(36).slice(2,7),creadoAt:timestamp,previousDate:data.fechaVisita};
      var previousAttemptDate=pendingNewVisit.previousDate;
      var created=Object.assign(data,{observacion:'',
        id:pendingNewVisit.id,creadoAt:pendingNewVisit.creadoAt,actualizadoAt:timestamp,
        creadoPor:currentUser.nombre||'',creadoPorUid:(currentFirebaseUser&&currentFirebaseUser.uid)||(currentUser&&currentUser.uid)||'',
        actividad:[{ts:typeof nowTs==='function'?nowTs():timestamp,user:currentUser.nombre||'',msg:'Visita creada'}]
      });
      if(String(observationDraft||'').trim())appendVisitObservation(created,'remote',observationDraft,currentUser.nombre||created.remoto||'Ejecutiva remota',timestamp);
      pendingNewVisit.previousDate=created.fechaVisita;
      try{
        await persistOwnVisit(created,{fechaVisita:previousAttemptDate});
      }catch(error){
        console.error('No se pudo crear la visita en la agenda propia:',error);
        toast('No se pudo confirmar la visita. Mantén esta ficha abierta y pulsa Guardar para reintentar la misma visita.','error');
        return;
      }
    }
    CarteraSaveGuard.complete('visita-editor');
    closeEditor();
    renderVisits();
    updateVisitCount();
    toast(existing?'Visita actualizada.':'Visita agendada.','success');
  }

  async function deleteVisit(id){
    if(typeof canDeleteVisits!=='function'||!canDeleteVisits()){
      toast('Solo un Administrador o Alex Demo puede eliminar visitas.','error');
      return false;
    }
    var visit=findVisit(id);
    if(!visit)return false;
    var linked=linkedReservations(visit).length?'\n\nLas Reservas asociadas se conservarán y sólo se quitará el vínculo con esta visita.':'';
    if(!confirm('¿Eliminar la visita de "'+(visit.cliente||'este cliente')+'"?'+linked+'\n\nSe guardará una copia de recuperación antes de eliminarla.'))return false;
    toast('Guardando respaldo y eliminando visita...','info');
    try{
      await deleteManagedEntity('visita',id);
      await Promise.all([loadCloudState(),ensureVisitasLoaded(true)]);
      renderVisits();
      if(typeof renderAll==='function')renderAll();
      toast('Visita eliminada. Se guardó una copia de recuperación.','success');
      return true;
    }catch(error){
      console.error('No se pudo eliminar la visita:',error);
      return false;
    }
  }

  function dateMatchesVisitRange(value,filters,requireDate){
    var date=String(value||'').slice(0,10);
    if(requireDate&&!/^\d{4}-\d{2}-\d{2}$/.test(date))return false;
    if((filters.dateFrom||filters.dateTo)&&!date)return false;
    if(filters.dateFrom&&date<filters.dateFrom)return false;
    if(filters.dateTo&&date>filters.dateTo)return false;
    return true;
  }

  function visitMatchesOtherFilters(visit,filters){
      if(filters.projects.length&&!filters.projects.some(function(project){return normalize(canonicalProjectName(project))===normalize(canonicalProjectName(visit.proyecto));}))return false;
      if(filters.statuses.length&&!filters.statuses.some(function(status){return normalize(status)===normalize(visit.estado);}))return false;
      if(filters.agents.length&&!filters.agents.some(function(agent){return normalize(agent)===normalize(visit.remoto);}))return false;
      if(filters.terrains&&filters.terrains.length&&!filters.terrains.some(function(terrain){return normalize(terrain)===normalize(visit.terreno||UNASSIGNED_TERRAIN_FILTER);}))return false;
      if(filters.search&&normalize([visit.cliente,visit.rut,visit.telefono,visit.email,visit.proyecto,visit.lote,visit.remoto,visit.terreno,visit.medio].join(' ')).indexOf(filters.search)<0)return false;
      return true;
  }

  function filteredVisits(sourceVisits,filters){
    filters=filters||currentVisitFilters();
    return (Array.isArray(sourceVisits)?sourceVisits:visibleVisits()).filter(function(visit){
      if(!visitMatchesOtherFilters(visit,filters))return false;
      if(!dateMatchesVisitRange(visit.fechaVisita,filters,false))return false;
      return dateMatchesVisitRange(creationDateForInput(visit.creadoAt||visit.fechaCreacion),{dateFrom:filters.createdFrom,dateTo:filters.createdTo},false);
    }).sort(function(a,b){
      var createdA=Date.parse(a.creadoAt||a.fechaCreacion||'')||0;
      var createdB=Date.parse(b.creadoAt||b.fechaCreacion||'')||0;
      return createdB-createdA||String(b.fechaVisita||'').localeCompare(String(a.fechaVisita||''))||String(a.horaVisita||'').localeCompare(String(b.horaVisita||''));
    });
  }

  function currentVisitFilters(){
    var dateFrom=selectedValue('av-filter-desde');
    var dateTo=selectedValue('av-filter-hasta');
    var createdFrom=selectedValue('av-created-desde');
    var createdTo=selectedValue('av-created-hasta');
    var projects=selectedProjectValues();
    var statuses=listMultiFilterValues('av-filter-status');
    var agents=listMultiFilterValues('av-filter-agent');
    var terrains=listMultiFilterValues('av-filter-terrain');
    if(dateFrom&&dateTo&&dateFrom>dateTo){var dateSwap=dateFrom;dateFrom=dateTo;dateTo=dateSwap;}
    if(createdFrom&&createdTo&&createdFrom>createdTo){var createdSwap=createdFrom;createdFrom=createdTo;createdTo=createdSwap;}
    return {
      search:normalize(selectedValue('av-search')),
      searchLabel:selectedValue('av-search'),
      dateFrom:dateFrom,
      dateTo:dateTo,
      createdFrom:createdFrom,
      createdTo:createdTo,
      project:projects[0]||'',
      projects:projects,
      status:statuses[0]||'',
      statuses:statuses,
      agent:agents[0]||'',
      agents:agents,
      terrain:terrains[0]||'',
      terrains:terrains
    };
  }

  function visitFiltersAreActive(filters){
    filters=filters||currentVisitFilters();
    return !!(filters.search||filters.dateFrom||filters.dateTo||filters.createdFrom||filters.createdTo||filters.projects&&filters.projects.length||filters.statuses&&filters.statuses.length||filters.agents&&filters.agents.length||filters.terrains&&filters.terrains.length);
  }

  function exportDateTime(value){
    if(!value)return '';
    var date=new Date(value);
    if(isNaN(date.getTime()))return String(value);
    return date.toLocaleString('es-CL',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'});
  }

  function exportObservationHistory(history){
    return (history||[]).map(function(item){
      return [exportDateTime(item.at||item.ts),item.autor||'',item.texto||''].filter(Boolean).join(' | ');
    }).join('\n');
  }

  function exportActivity(visit){
    return (visit&&visit.actividad||[]).map(function(item){
      return [item.ts||item.at||'',item.user||item.autor||'',item.msg||item.texto||''].filter(Boolean).join(' | ');
    }).join('\n');
  }

  function buildVisitExportRows(visits){
    return (visits||[]).map(function(visit,index){
      var reservations=linkedReservations(visit);
      var remoteNotes=remoteObservationHistory(visit);
      var terrainNotes=terrainObservationHistory(visit);
      return {
        'N°':index+1,
        'ID visita':visit.id||'',
        'Creada':exportDateTime(visit.creadoAt||visit.fechaCreacion),
        'Creada por':visit.creadoPor||'',
        'UID creador':visit.creadoPorUid||'',
        'Última actualización':exportDateTime(visit.actualizadoAt),
        'Actualizada por':visit.actualizadoPor||'',
        'Fecha de visita':visit.fechaVisita||'',
        'Hora de visita':visit.horaVisita||'',
        'Cliente':visit.cliente||'',
        'RUT':typeof formatRutParaExportar==='function'?formatRutParaExportar(visit.rut):visit.rut||'',
        'Teléfono':visit.telefono||'',
        'Correo electrónico':visit.email||'',
        'Medio de contacto':visit.medio||'',
        'Proyecto':visit.proyecto||'',
        'Lote de interés':visit.lote||'',
        'Estado':visit.estado||'',
        'Subestado':visit.subEstado||'',
        'Ejecutiva remota':visit.remoto||'',
        'Vendedora de terreno':visit.terreno||'',
        'Observación más reciente':visit.observacion||'',
        'Observaciones ejecutiva remota':exportObservationHistory(remoteNotes),
        'Cantidad observaciones remota':remoteNotes.length,
        'Observaciones terreno':exportObservationHistory(terrainNotes),
        'Cantidad observaciones terreno':terrainNotes.length,
        'Cantidad reservas':reservations.length,
        'ID reserva':reservations.map(function(record){return record.id;}).join('; '),
        'N° reserva':reservations.map(function(record){return record.numReserva||record.name||'';}).join('; '),
        'Estado reserva':reservations.map(function(record){return typeof getEstado==='function'?getEstado(record):record.estado||'';}).join('; '),
        'ID cotización':reservations.map(function(record){return record.cotizacionId||'';}).join('; '),
        'N° cotización':reservations.map(function(record){return record.cotizacionFolio||'';}).join('; '),
        'Convertida a reserva':exportDateTime(visit.reservadoAt),
        'Fuente':visit.source||'Base propia',
        'ID fuente Monday':visit.mondaySourceId||'',
        'Board Monday':visit.mondayBoardId||'',
        'Item Monday':visit.mondayItemId||'',
        'Edición local':visit.localEdited?'Sí':'No',
        'Historial de actividad':exportActivity(visit)
      };
    });
  }

  async function exportVisitsExcel(format){
    try{
    if(format!=='pdf'&&(typeof XLSX==='undefined'||!XLSX.utils)){toast('No fue posible cargar el generador de Excel.','error');return;}
    var visits=filteredVisits();
    if(!visits.length){toast('No hay visitas para descargar con los filtros actuales.','error');return;}
    var filters=currentVisitFilters();
    var profiles=await CarteraClientesInforme.visitProfiles(visits,linkedReservations),rawRows=buildVisitExportRows(visits);
    var report=CarteraClientesInforme.table(Object.keys(rawRows[0]),rawRows.map(function(row){return Object.values(row);}),profiles);
    var rows=report.rows.map(function(row){return Object.fromEntries(report.headers.map(function(header,col){return [header,row[col]];}));});
    var now=new Date();
    var suffix=now.getFullYear()+String(now.getMonth()+1).padStart(2,'0')+String(now.getDate()).padStart(2,'0')+'_'+String(now.getHours()).padStart(2,'0')+String(now.getMinutes()).padStart(2,'0');
    if(format==='pdf'){
      var headers=Object.keys(rows[0]||{});
      return downloadTablePDF({title:'Agendamiento de visitas',filename:(visitFiltersAreActive(filters)?'Visitas_filtradas_':'Visitas_completas_')+suffix+'.pdf',headers:headers,rows:rows.map(function(row){return headers.map(function(header){return row[header];});})});
    }
    var sheet=XLSX.utils.json_to_sheet(rows,{cellDates:false});
    sheet['!autofilter']={ref:sheet['!ref']};
    sheet['!cols']=[6,22,20,20,22,20,20,15,13,28,15,18,28,20,24,16,22,20,22,22,36,60,14,60,14,24,16,22,24,24,20,18,24,18,18,13,70].map(function(width){return {wch:width};});
    sheet['!cols']=report.headers.map(function(header,index){return sheet['!cols'][index]||{wch:Math.max(20,header.length+2)};});
    var filterRows=[
      {'Filtro':'Generado','Valor':exportDateTime(nowIso())},
      {'Filtro':'Usuario','Valor':currentUser&&currentUser.nombre||''},
      {'Filtro':'Visitas exportadas','Valor':visits.length},
      {'Filtro':'Búsqueda','Valor':filters.searchLabel||'Todos'},
      {'Filtro':'Fecha de visita desde','Valor':filters.dateFrom||'Sin límite'},
      {'Filtro':'Fecha de visita hasta','Valor':filters.dateTo||'Sin límite'},
      {'Filtro':'Fecha de creación desde','Valor':filters.createdFrom||'Sin límite'},
      {'Filtro':'Fecha de creación hasta','Valor':filters.createdTo||'Sin límite'},
      {'Filtro':'Proyecto','Valor':filters.projects.length?filters.projects.join(', '):'Todos'},
      {'Filtro':'Estado','Valor':filters.statuses.length?filters.statuses.join(', '):'Todos'},
      {'Filtro':'Ejecutiva','Valor':filters.agents.length?filters.agents.join(', '):'Todas'},
      {'Filtro':'Terreno','Valor':filters.terrains.length?filters.terrains.join(', '):'Todos'}
    ];
    var filterSheet=XLSX.utils.json_to_sheet(filterRows);
    filterSheet['!cols']=[{wch:24},{wch:42}];
    var workbook=XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook,sheet,'Visitas');
    XLSX.utils.book_append_sheet(workbook,filterSheet,'Filtros aplicados');
    XLSX.writeFile(workbook,(visitFiltersAreActive(filters)?'Visitas_filtradas_':'Visitas_completas_')+suffix+'.xlsx',{compression:true});
    toast('Excel descargado con '+visits.length+' visita'+(visits.length===1?'':'s')+'.','success');
    }catch(error){console.error('No se pudieron exportar las visitas:',error);toast('No se pudieron consultar los datos de clientes. Intenta nuevamente.','error');}
  }

  function updateFilters(sourceVisits){
    var visits=Array.isArray(sourceVisits)?sourceVisits:visibleVisits();
    setProjectFilterOptions(visits.map(function(item){return item.proyecto;}));
    setListMultiFilterOptions('av-filter-status',visits.map(function(item){return item.estado;}));
    setListMultiFilterOptions('av-filter-agent',visits.map(function(item){return item.remoto;}));
    setListMultiFilterOptions('av-filter-terrain',visits.map(function(item){return item.terreno||UNASSIGNED_TERRAIN_FILTER;}));
    var agentFilter=document.getElementById('av-filter-agent');
    if(agentFilter){var agentControl=agentFilter.closest&&agentFilter.closest('.av-list-multi')||agentFilter;agentControl.hidden=isSeller(currentUser);}
    var terrainControl=document.getElementById('av-filter-terrain-control');
    if(terrainControl)terrainControl.hidden=isTerrainUser(currentUser);
  }

  function renderPagination(total,pageCount){
    var pager=document.getElementById('av-pagination');
    if(!pager)return;
    if(total<=VISITS_PAGE_SIZE){pager.innerHTML='';pager.hidden=true;return;}
    pager.hidden=false;
    pager.innerHTML='<button type="button" class="btn btn-ghost btn-sm" data-av-page="'+(visitsPage-1)+'"'+(visitsPage<=1?' disabled':'')+'>Anterior</button>'+ 
      '<span>Página '+visitsPage+' de '+pageCount+' · '+total+' visitas</span>'+ 
      '<button type="button" class="btn btn-ghost btn-sm" data-av-page="'+(visitsPage+1)+'"'+(visitsPage>=pageCount?' disabled':'')+'>Siguiente</button>';
  }

  function visitRangeMetrics(sourceVisits,filters){
    var createdRange={dateFrom:filters.createdFrom,dateTo:filters.createdTo};
    var scoped=(sourceVisits||[]).filter(function(visit){
      return visitMatchesOtherFilters(visit,filters)&&dateMatchesVisitRange(creationDateForInput(visit.creadoAt||visit.fechaCreacion),createdRange,false);
    });
    var created=scoped.filter(function(visit){
      return dateMatchesVisitRange(creationDateForInput(visit.creadoAt||visit.fechaCreacion),filters,true);
    });
    var scheduled=scoped.filter(function(visit){return dateMatchesVisitRange(visit.fechaVisita,filters,true);});
    var today=todayIso();
    var buckets={done:0,notDone:0,converted:0,pending:0,cancelled:0,other:0};
    var future=0;
    scheduled.forEach(function(visit){
      var status=normalize(visit.estado);
      var bucket=isReservedVisit(visit)?'converted':
        status==='visita concretada'?'done':
        status==='visita no concretada'||status==='reagendada'||status==='no calificado'||status==='no interesado'||status==='no logrado'?'notDone':
        status.indexOf('cancel')>=0?'cancelled':
        status==='agenda visita'||status==='visita confirmada'?'pending':'other';
      buckets[bucket]++;
      if(bucket==='pending'&&visit.fechaVisita>=today)future++;
    });
    return {
      created:created.length,scheduled:scheduled.length,future:future,
      done:buckets.done+buckets.converted,notDone:buckets.notDone,converted:buckets.converted,
      pending:buckets.pending,cancelled:buckets.cancelled,other:buckets.other,
      donePercent:scheduled.length?100*(buckets.done+buckets.converted)/scheduled.length:0,
      notDonePercent:scheduled.length?100*buckets.notDone/scheduled.length:0
    };
  }

  function visitPercent(value){
    return new Intl.NumberFormat('es-CL',{minimumFractionDigits:1,maximumFractionDigits:1}).format(value)+'%';
  }

  function renderVisits(resetPage){
    var panel=document.getElementById('panel-'+VIEW_ID);
    if(!panel)return;
    if(resetPage)visitsPage=1;
    var all=visibleVisits();
    updateFilters(all);
    var filters=currentVisitFilters();
    var filtered=filteredVisits(all,filters);
    var metrics=visitRangeMetrics(all,filters);
    var creationFilter=document.getElementById('av-created-filter');
    if(creationFilter)creationFilter.classList.toggle('has-active',!!(filters.createdFrom||filters.createdTo));
    var pageCount=Math.max(1,Math.ceil(filtered.length/VISITS_PAGE_SIZE));
    visitsPage=Math.min(Math.max(1,visitsPage),pageCount);
    var rows=filtered.slice((visitsPage-1)*VISITS_PAGE_SIZE,visitsPage*VISITS_PAGE_SIZE);
    document.getElementById('av-kpis').innerHTML=
      '<div class="kpi-card kc-blue"><div class="kpi-label">Creadas en el rango</div><div class="kpi-value">'+metrics.created+'</div><div class="kpi-sub">por fecha de creación</div></div>'+ 
      '<div class="kpi-card kc-teal"><div class="kpi-label">Fechas de visita</div><div class="kpi-value">'+metrics.scheduled+'</div><div class="kpi-sub">programadas en el rango</div></div>'+ 
      '<div class="kpi-card kc-yellow"><div class="kpi-label">Visitas por realizar</div><div class="kpi-value">'+metrics.future+'</div><div class="kpi-sub">con fecha desde hoy</div></div>'+ 
      '<div class="kpi-card kc-green"><div class="kpi-label">Concretadas</div><div class="kpi-value">'+metrics.done+'</div><div class="kpi-sub">'+visitPercent(metrics.donePercent)+' de visitas con fecha</div></div>'+ 
      '<div class="kpi-card kc-red"><div class="kpi-label">No concretadas</div><div class="kpi-value">'+metrics.notDone+'</div><div class="kpi-sub">'+visitPercent(metrics.notDonePercent)+' de visitas con fecha</div></div>'+ 
      '<div class="kpi-card kc-purple"><div class="kpi-label">Convertidas</div><div class="kpi-value">'+metrics.converted+'</div><div class="kpi-sub">incluidas en concretadas</div></div>';
    var breakdown=[
      [metrics.done,'concretadas'+(metrics.converted?' (incluyen '+metrics.converted+' con reserva)':'')],
      [metrics.notDone,'no concretadas'],[metrics.pending,'agendadas'],[metrics.cancelled,'canceladas'],[metrics.other,'otros estados']
    ].filter(function(item){return item[0]>0;});
    document.getElementById('av-status-breakdown').innerHTML=
      '<strong>Así se completan las '+metrics.scheduled+' visitas con fecha:</strong> '+
      breakdown.map(function(item){return '<span><b>'+item[0]+'</b> '+item[1]+'</span>';}).join('<em>+</em>')+
      '<small>“Convertidas” ('+metrics.converted+') ya está incluido en concretadas y no se suma otra vez. “Por realizar” ('+metrics.future+') ya está incluido en agendadas. “Creadas” usa otra fecha.</small>';
    document.getElementById('av-count').textContent=filtered.length+' visita'+(filtered.length===1?'':'s')+
      ((filters.dateFrom||filters.dateTo)?' por fecha de visita':'')+
      ((filters.createdFrom||filters.createdTo)?' · creación filtrada':'');
    document.getElementById('av-new-button').hidden=!canFullyEditVisit(null);
    document.getElementById('av-tbody').innerHTML=rows.map(function(visit){
      var editable=canEditVisit(visit);
      var historical=isHistoricalVisit(visit);
      var deletable=!historical&&typeof canDeleteVisits==='function'&&canDeleteVisits();
      var reservations=linkedReservations(visit);
      var reserved=reservations.length>0;
      var created=createdAtDisplay(visit.creadoAt||visit.fechaCreacion);
      var source=historical?'<span class="av-source" title="Registro histórico de Visitas">Histórico</span>':'';
      var remoteNote=hasRemoteObservation(visit)?'<button type="button" class="av-remote-note-badge" data-av-action="detail" data-id="'+escapeHtml(visit.id)+'" title="Ver la observación de la ejecutiva remota"><span class="av-note-dot"></span> Nota remota</button>':'';
      var terrainNote=hasTerrainObservation(visit)?'<button type="button" class="av-terrain-note-badge" data-av-action="detail" data-id="'+escapeHtml(visit.id)+'" title="Ver la observación que dejó terreno"><span class="av-note-dot"></span> Nota terreno</button>':'';
      var actions='<div class="av-actions">'+
        (editable?'<button type="button" class="av-icon-button" data-av-action="edit" data-id="'+escapeHtml(visit.id)+'" title="'+(isTerrainUser(currentUser)?'Escribir observación':'Editar visita')+'" aria-label="'+(isTerrainUser(currentUser)?'Escribir observación':'Editar visita')+'">✎</button>':'')+
        (canEditCreationDate(visit)?'<button type="button" class="av-icon-button" data-av-action="creation-date" data-id="'+escapeHtml(visit.id)+'" title="Corregir fecha de creación" aria-label="Corregir fecha de creación">📅</button>':'')+
        (deletable?'<button type="button" class="av-icon-button danger" data-av-action="delete" data-id="'+escapeHtml(visit.id)+'" title="Eliminar visita" aria-label="Eliminar visita">🗑 <span class="av-delete-label">Eliminar</span></button>':'')+
        reservations.map(function(record){
          var number=record.numReserva||record.name||record.id;
          return '<button type="button" class="btn btn-ghost btn-sm av-reservation-button" data-av-action="open-reservation" data-id="'+escapeHtml(record.id)+'" title="'+escapeHtml('Reserva '+number+' · Lote '+(record.name||'—')+(record.cotizacionFolio?' · '+record.cotizacionFolio:''))+'">'+escapeHtml(reserved&&reservations.length===1?'Ver reserva':'Reserva '+number)+'</button>';
        }).join('')+
      '</div>';
      return '<tr>'+ 
        '<td><div class="av-primary">'+escapeHtml(created.date)+'</div><div class="av-secondary">'+escapeHtml(created.time||'Fecha automatica')+' '+source+'</div></td>'+ 
        '<td><div class="av-primary">'+escapeHtml(formatDate(visit.fechaVisita))+'</div><div class="av-secondary">'+escapeHtml(visit.horaVisita||'Sin hora')+'</div></td>'+ 
        '<td><div class="av-primary">'+escapeHtml(visit.cliente||'Sin cliente')+'</div><div class="av-secondary">'+escapeHtml(visit.rut||visit.email||'')+'</div></td>'+ 
        '<td><div class="av-primary av-project">'+escapeHtml(visit.proyecto||'Sin proyecto')+'</div><div class="av-secondary">'+(visit.lote?'Lote '+escapeHtml(visit.lote):'Lote por definir')+'</div></td>'+ 
        '<td><div class="av-primary">'+escapeHtml(visit.telefono||'Sin telefono')+'</div><div class="av-secondary">'+escapeHtml(visit.medio||'Sin medio')+'</div></td>'+ 
        '<td><div>'+escapeHtml(visit.remoto||'—')+'</div>'+remoteNote+'</td><td><div>'+escapeHtml(visit.terreno||'—')+'</div>'+terrainNote+'</td>'+ 
        '<td>'+stateBadge(visit.estado)+(reserved?'<div class="av-reservation-count">'+reservations.length+' reserva'+(reservations.length===1?'':'s')+' vinculada'+(reservations.length===1?'':'s')+'</div>':'')+(visit.subEstado?'<div class="av-secondary">'+escapeHtml(visit.subEstado)+'</div>':'')+'</td><td>'+actions+'</td>'+ 
      '</tr>';
    }).join('')||'<tr><td colspan="9"><div class="av-empty">No hay visitas para estos filtros.</div></td></tr>';
    renderPagination(filtered.length,pageCount);
    updateVisitCount(all.length);
  }

  function updateVisitCount(knownCount){
    var counter=document.getElementById('cnt-'+VIEW_ID);
    if(counter)counter.textContent=typeof knownCount==='number'?knownCount:visibleVisits().length;
  }

  function clearFilters(){
    var search=document.getElementById('av-search');
    if(search)search.value='';
    ['av-filter-desde','av-filter-hasta','av-created-desde','av-created-hasta'].forEach(function(id){
      var el=document.getElementById(id);
      if(!el)return;
      if(el._flatpickr){
        el._flatpickr.clear(false);
        if(el._flatpickr.altInput)el._flatpickr.altInput.value='';
      }
      el.value='';
    });
    setProjectFilterSelection([],false);
    Object.keys(LIST_MULTI_FILTERS).forEach(function(id){setListMultiFilterSelection(id,[],false);});
    setProjectFilterOpen(false);
    setListMultiFilterOpen('',false);
    var creationFilter=document.getElementById('av-created-filter');
    if(creationFilter)creationFilter.open=false;
    renderVisits(true);
  }

  function personMatches(left,right){
    var a=normalize(left),b=normalize(right);
    if(!a||!b)return false;
    if(a===b)return true;
    if(a.length>=5&&(a.indexOf(b)>=0||b.indexOf(a)>=0))return true;
    var ap=a.split(/\s+/),bp=b.split(/\s+/);
    return ap.length>1&&bp.length>1&&ap[0]===bp[0]&&ap[ap.length-1]===bp[bp.length-1];
  }

  function loadQuotes(force){
    var list=window._cvTodasCotizaciones||[];
    if(list.length&&!force)return Promise.resolve(list);
    if(typeof window._fbCargarCotizaciones!=='function')return Promise.reject(new Error('Cotizador no disponible'));
    return new Promise(function(resolve,reject){
      var completed=false;
      var timer=setTimeout(function(){if(!completed){completed=true;reject(new Error('Tiempo de espera agotado'));}},15000);
      try{
        window._fbCargarCotizaciones(function(items){
          if(completed)return;
          completed=true;clearTimeout(timer);
          window._cvTodasCotizaciones=items||[];
          try{_todasCotizaciones=items||[];}catch(error){}
          resolve(items||[]);
        });
      }catch(error){completed=true;clearTimeout(timer);reject(error);}
    });
  }

  function quoteFolio(quote){
    try{return getFolioCompleto(quote)||quote.folioCompleto||quote.id||'';}catch(error){return quote.folioCompleto||quote.id||'';}
  }

  function quoteIsAvailable(quote){
    if(!quote.reservaCreada)return true;
    return !(state.registros||[]).some(function(record){return record.cotizacionId===quote.id||(quote.reservaId&&record.id===quote.reservaId);});
  }

  function visitForReserve(){
    return visitStore().find(function(item){return item.id===reserveVisitId;})||null;
  }

  function matchingQuotes(visit){
    return availableQuotes.filter(function(quote){
      return quoteIsAvailable(quote)&&personMatches(quote.vendedor,visit.remoto);
    });
  }

  function renderQuoteList(){
    var visit=visitForReserve();
    var container=document.getElementById('av-quote-list');
    if(!visit||!container)return;
    var search=normalize(selectedValue('av-quote-search'));
    var quotes=matchingQuotes(visit).filter(function(quote){
      if(!search)return true;
      return normalize([quoteFolio(quote),quote.nombre,quote.rut,quote.proyecto,quote.lote].join(' ')).indexOf(search)>=0;
    });
    if(!quotes.length){
      container.innerHTML='<div class="av-empty">No encontramos cotizaciones disponibles de '+escapeHtml(visit.remoto||'esta ejecutiva')+'. Crea la cotizacion primero y luego pulsa Actualizar.</div>';
      selectedQuoteId='';
      renderSelectedQuote();
      return;
    }
    if(selectedQuoteId&&!quotes.some(function(quote){return quote.id===selectedQuoteId;}))selectedQuoteId='';
    container.innerHTML=quotes.map(function(quote){
      var selected=quote.id===selectedQuoteId;
      return '<label class="av-quote-option'+(selected?' selected':'')+'">'+
        '<input type="radio" name="av-quote" value="'+escapeHtml(quote.id)+'"'+(selected?' checked':'')+'>'+ 
        '<span class="av-quote-main"><strong>'+escapeHtml(quoteFolio(quote)||'Sin folio')+'</strong><span>'+escapeHtml(quote.nombre||'Sin cliente')+'</span></span>'+ 
        '<span class="av-quote-meta"><strong>'+escapeHtml(quote.proyecto||'Sin proyecto')+'</strong><span>Lote '+escapeHtml(quote.lote||'—')+'</span></span>'+ 
      '</label>';
    }).join('');
  }

  function quoteValidation(visit,quote){
    var errors=[],warnings=[];
    if(!quote)errors.push('Selecciona una cotizacion.');
    if(quote&&!personMatches(quote.vendedor,visit.remoto))errors.push('La cotizacion no pertenece a la ejecutiva de esta visita.');
    if(quote&&visit.proyecto&&normalize(quote.proyecto)!==normalize(visit.proyecto))errors.push('El proyecto de la cotizacion no coincide con la visita.');
    if(quote&&visit.lote&&normalize(quote.lote)!==normalize(visit.lote))warnings.push('La cotizacion corresponde a otro lote del mismo proyecto.');
    if(quote&&visit.rut&&quote.rut&&normalize(quote.rut)!==normalize(visit.rut))errors.push('El RUT de la cotizacion no coincide con la visita.');
    if(quote&&visit.cliente&&quote.nombre&&!personMatches(quote.nombre,visit.cliente))warnings.push('Revisa el nombre del cliente: la visita y la cotizacion no coinciden exactamente.');
    if(quote&&linkedReservations(visit).some(function(record){
      return normalize(record.proyecto)===normalize(quote.proyecto)&&
        (typeof sameLote==='function'?sameLote(record.name,quote.lote):normalize(record.name)===normalize(quote.lote));
    }))errors.push('Esta visita ya tiene una Reserva vinculada para el mismo lote. Elige una cotizacion de otro lote.');
    return {errors:errors,warnings:warnings};
  }

  function selectedQuote(){
    return availableQuotes.find(function(quote){return quote.id===selectedQuoteId;})||null;
  }

  function renderSelectedQuote(){
    var visit=visitForReserve(),quote=selectedQuote();
    var detail=document.getElementById('av-quote-detail');
    var validation=document.getElementById('av-reserve-validation');
    if(!visit||!detail||!validation)return;
    if(!quote){detail.innerHTML='';validation.hidden=true;updateReserveButton();return;}
    var check=quoteValidation(visit,quote);
    detail.innerHTML='<div class="av-selected-quote"><div><span>Folio</span><strong>'+escapeHtml(quoteFolio(quote)||'—')+'</strong></div><div><span>Cliente</span><strong>'+escapeHtml(quote.nombre||'—')+'</strong></div><div><span>Proyecto y lote</span><strong>'+escapeHtml(quote.proyecto||'—')+' · '+escapeHtml(quote.lote||'—')+'</strong></div><div><span>Precio neto</span><strong>'+escapeHtml(quote.precioNeto||'—')+'</strong></div></div>';
    var messages=check.errors.concat(check.warnings);
    validation.hidden=!messages.length;
    validation.className='av-validation '+(check.errors.length?'error':'warning');
    validation.innerHTML=messages.map(function(message){return '<div>'+escapeHtml(message)+'</div>';}).join('');
    updateReserveButton();
  }

  function renderReview(visit){
    document.getElementById('av-review').innerHTML=
      '<div><span>Cliente</span><strong>'+escapeHtml(visit.cliente||'—')+'</strong><small>'+escapeHtml(visit.telefono||'Sin telefono')+'</small></div>'+ 
      '<div><span>Visita</span><strong>'+escapeHtml(formatDate(visit.fechaVisita))+' · '+escapeHtml(visit.horaVisita||'Sin hora')+'</strong><small>'+escapeHtml(visit.medio||'Sin medio')+'</small></div>'+ 
      '<div><span>Proyecto</span><strong>'+escapeHtml(visit.proyecto||'—')+(visit.lote?' · Lote '+escapeHtml(visit.lote):'')+'</strong><small>'+escapeHtml(visit.terreno||'Sin terreno')+'</small></div>'+ 
      '<div><span>Ejecutiva</span><strong>'+escapeHtml(visit.remoto||'—')+'</strong><small>'+escapeHtml(visit.estado||'Sin estado')+'</small></div>';
  }

  function openReserve(id){
    if(!CarteraSaveGuard.canClose('modal-av-reserve'))return;
    var visit=visitStore().find(function(item){return item.id===id;});
    if(!visit)return;
    if(!canFullyEditVisit(visit)){toast('No puedes reservar esta visita.','error');return;}
    reserveVisitId=id;selectedQuoteId='';pendingDocuments=[];
    document.getElementById('av-quote-search').value='';
    document.getElementById('av-reserve-files').value='';
    document.getElementById('av-reserve-age').value='';
    document.getElementById('av-reserve-children').value='';
    renderReview(visit);renderFiles();
    document.getElementById('av-quote-list').innerHTML='<div class="av-empty">Cargando cotizaciones...</div>';
    document.getElementById('av-quote-detail').innerHTML='';
    document.getElementById('av-reserve-validation').hidden=true;
    openModal('modal-av-reserve');
    refreshQuotes(false);
  }

  function closeReserve(){
    if(!CarteraSaveGuard.canClose('modal-av-reserve'))return;
    reserveVisitId='';selectedQuoteId='';pendingDocuments=[];
    closeModal('modal-av-reserve');
  }

  function refreshQuotes(force){
    var button=document.getElementById('av-refresh-quotes');
    if(button)button.disabled=true;
    loadQuotes(force).then(function(quotes){
      availableQuotes=quotes||[];
      renderQuoteList();renderSelectedQuote();
    }).catch(function(error){
      console.error('No se pudieron cargar las cotizaciones para la visita:',error);
      document.getElementById('av-quote-list').innerHTML='<div class="av-empty error">No fue posible cargar las cotizaciones. Revisa la conexion y vuelve a intentar.</div>';
      updateReserveButton();
    }).finally(function(){if(button)button.disabled=false;});
  }

  function addDocuments(input){
    var files=Array.prototype.slice.call(input.files||[]);
    var total=pendingDocuments.reduce(function(sum,doc){return sum+(doc.size||0);},0);
    files.forEach(function(file){
      if(file.size>5*1024*1024){toast('"'+file.name+'" supera los 5 MB.','error');return;}
      if(total+file.size>8*1024*1024){toast('Los adjuntos no pueden superar 8 MB en total.','error');return;}
      total+=file.size;
      var reader=new FileReader();
      reader.onload=function(event){
        pendingDocuments.push({id:'doc'+Date.now()+Math.random().toString(36).slice(2,7),name:file.name,type:file.type||'',size:file.size,dataUrl:event.target.result,addedAt:todayIso(),addedBy:currentUser.nombre||''});
        renderFiles();
      };
      reader.onerror=function(){toast('No se pudo leer "'+file.name+'".','error');};
      reader.readAsDataURL(file);
    });
    input.value='';
  }

  function removeDocument(id){
    pendingDocuments=pendingDocuments.filter(function(doc){return doc.id!==id;});
    renderFiles();
  }

  function renderFiles(){
    var container=document.getElementById('av-file-list');
    if(!container)return;
    container.innerHTML=pendingDocuments.map(function(doc){
      return '<div class="av-file"><span class="av-file-icon" aria-hidden="true">↥</span><span><strong>'+escapeHtml(doc.name)+'</strong><small>'+escapeHtml(typeof fmtFileSize==='function'?fmtFileSize(doc.size):Math.round(doc.size/1024)+' KB')+'</small></span><button type="button" class="av-icon-button danger" data-av-file-remove="'+escapeHtml(doc.id)+'" title="Quitar archivo" aria-label="Quitar archivo">✕</button></div>';
    }).join('')||'<div class="av-empty compact">Sin archivos adjuntos.</div>';
    updateReserveButton();
  }

  function updateReserveButton(){
    var button=document.getElementById('av-reserve-confirm');
    var visit=visitForReserve(),quote=selectedQuote();
    var check=visit?quoteValidation(visit,quote):{errors:['Sin visita']};
    if(button)button.disabled=!visit||!quote||!!check.errors.length||!pendingDocuments.length;
  }

  function confirmReserve(){
    return CarteraSaveGuard.run('visita-reserva',{modal:'modal-av-reserve',button:'av-reserve-confirm',label:'Creando Reserva...'},confirmReserveOnce);
  }

  async function confirmReserveOnce(){
    var visit=visitForReserve(),quote=selectedQuote();
    if(!visit||!quote)return;
    if(!canFullyEditVisit(visit)){toast('No puedes reservar esta visita.','error');return;}
    var check=quoteValidation(visit,quote);
    if(check.errors.length){toast(check.errors[0],'error');return;}
    if(!pendingDocuments.length){toast('Adjunta al menos un comprobante de pago.','error');return;}
    var datosManuales=leerDatosManualesReserva('av-reserve-age','av-reserve-children');
    if(!datosManuales)return;
    var button=document.getElementById('av-reserve-confirm');
    button.disabled=true;button.textContent='Creando Reserva...';
    try{
      var created=await crearReservaDesdeCotizacion(quote,pendingDocuments.slice(),visit.id,datosManuales);
      if(!created){updateReserveButton();return;}
      CarteraSaveGuard.complete('visita-reserva');
      closeReserve();renderVisits();
    }catch(error){
      console.error('No se pudo crear la Reserva desde la visita:',error);
      toast('No se pudo crear la Reserva. No se modifico la visita.','error');
      updateReserveButton();
    }finally{
      button.textContent='Crear Reserva';
    }
  }

  function openReservation(id){
    var record=(state.registros||[]).find(function(item){return item.id===id;});
    if(!record){toast('La Reserva vinculada ya no existe.','error');return;}
    var button=document.getElementById('tbtn-cartera');
    if(button)setTab('cartera',button);
    setTimeout(function(){if(typeof openEdit==='function')openEdit(id);},80);
  }

  function bindEvents(){
    document.getElementById('av-new-button').addEventListener('click',function(){openEditor('');});
    document.getElementById('av-view-list').addEventListener('click',function(){setScheduleView('list');});
    document.getElementById('av-view-calendar').addEventListener('click',function(){setScheduleView('calendar');});
    document.getElementById('av-export-excel').addEventListener('click',function(){exportVisitsExcel();});
    document.getElementById('av-export-pdf').addEventListener('click',function(){exportVisitsExcel('pdf');});
    document.getElementById('av-editor-form').addEventListener('submit',saveEditor);
    document.getElementById('av-editor-close').addEventListener('click',closeEditor);
    document.getElementById('av-editor-cancel').addEventListener('click',closeEditor);
    document.getElementById('av-created-form').addEventListener('submit',saveCreationDateEditor);
    document.getElementById('av-created-close').addEventListener('click',closeCreationDateEditor);
    document.getElementById('av-created-cancel').addEventListener('click',closeCreationDateEditor);
    document.getElementById('av-note-edit-cancel').addEventListener('click',cancelObservationEdit);
    document.getElementById('av-notes-history').addEventListener('click',function(event){
      var deleteButton=event.target.closest('[data-av-note-delete]');
      if(deleteButton){deleteVisitObservation(deleteButton.getAttribute('data-kind'),parseInt(deleteButton.getAttribute('data-index'),10));return;}
      var button=event.target.closest('[data-av-note-edit]');
      if(!button)return;
      beginObservationEdit(button.getAttribute('data-kind'),parseInt(button.getAttribute('data-index'),10));
    });
    document.getElementById('av-project').addEventListener('change',function(){refreshLotOptions('');refreshTerrainOptions();});
    ['av-search','av-filter-desde','av-filter-hasta','av-created-desde','av-created-hasta'].forEach(function(id){
      var element=document.getElementById(id);element.addEventListener(id==='av-search'?'input':'change',function(){
        if(id==='av-search')scheduleRuntimeSearch('visits',function(){renderVisits(true);});
        else renderVisits(true);
      });
    });
    document.getElementById('av-created-clear').addEventListener('click',function(){
      ['av-created-desde','av-created-hasta'].forEach(function(id){
        var element=document.getElementById(id);
        if(element._flatpickr){
          element._flatpickr.clear(false);
          if(element._flatpickr.altInput)element._flatpickr.altInput.value='';
        }
        element.value='';
      });
      document.getElementById('av-created-filter').open=false;
      renderVisits(true);
    });
    document.getElementById('av-filter-project-button').addEventListener('click',function(){
      var menu=document.getElementById('av-filter-project-menu');
      setProjectFilterOpen(!!(menu&&menu.hidden));
    });
    document.getElementById('av-filter-project-options').addEventListener('change',function(event){
      var input=event.target&&event.target.matches&&event.target.matches('[data-av-project-option]')?event.target:null;
      if(!input)return;
      var selected=selectedProjectFilters.slice();
      var key=normalize(input.value);
      selected=selected.filter(function(value){return normalize(value)!==key;});
      if(input.checked)selected.push(input.value);
      setProjectFilterSelection(selected);
    });
    document.getElementById('av-filter-project-clear').addEventListener('click',function(){setProjectFilterSelection([]);});
    document.addEventListener('click',function(event){
      var wrapper=document.getElementById('av-project-filter');
      if(wrapper&&typeof wrapper.contains==='function'&&!wrapper.contains(event.target))setProjectFilterOpen(false);
    });
    document.addEventListener('keydown',function(event){if(event.key==='Escape')setProjectFilterOpen(false);});
    Object.keys(LIST_MULTI_FILTERS).forEach(function(id){
      var button=document.getElementById(id+'-button'),menu=document.getElementById(id+'-menu'),options=document.getElementById(id+'-options'),clear=document.getElementById(id+'-clear');
      if(button)button.addEventListener('click',function(){setListMultiFilterOpen(id,!!(menu&&menu.hidden));});
      if(options)options.addEventListener('change',function(event){
        var input=event.target&&event.target.matches&&event.target.matches('[data-av-list-option]')?event.target:null;
        if(!input)return;
        var selected=listMultiFilterValues(id),key=normalize(input.value);
        selected=selected.filter(function(value){return normalize(value)!==key;});
        if(input.checked)selected.push(input.value);
        setListMultiFilterSelection(id,selected);
      });
      if(clear)clear.addEventListener('click',function(event){event.stopPropagation();setListMultiFilterSelection(id,[]);});
    });
    document.addEventListener('click',function(event){if(!(event.target&&event.target.closest&&event.target.closest('.av-list-multi')))setListMultiFilterOpen('',false);});
    document.addEventListener('keydown',function(event){if(event.key==='Escape')setListMultiFilterOpen('',false);});
    Object.keys(CALENDAR_MULTI_FILTERS).forEach(function(id){
      var button=document.getElementById(id+'-button');
      var menu=document.getElementById(id+'-menu');
      var options=document.getElementById(id+'-options');
      var clear=document.getElementById(id+'-clear');
      if(button)button.addEventListener('click',function(){setCalendarFilterOpen(id,!!(menu&&menu.hidden));});
      if(options)options.addEventListener('change',function(event){
        var input=event.target&&event.target.matches&&event.target.matches('[data-av-calendar-option]')?event.target:null;
        if(!input)return;
        var selected=calendarFilterValues(id),key=normalize(input.value);
        selected=selected.filter(function(value){return normalize(value)!==key;});
        if(input.checked)selected.push(input.value);
        setCalendarFilterSelection(id,selected);
      });
      if(clear)clear.addEventListener('click',function(event){event.stopPropagation();setCalendarFilterSelection(id,[]);});
    });
    document.addEventListener('click',function(event){
      if(!(event.target&&event.target.closest&&event.target.closest('.av-calendar-multi')))setCalendarFilterOpen('',false);
    });
    document.addEventListener('keydown',function(event){if(event.key==='Escape')setCalendarFilterOpen('',false);});
    document.getElementById('av-clear-filters').addEventListener('click',clearFilters);
    document.getElementById('av-tbody').addEventListener('click',function(event){
      var button=event.target.closest('[data-av-action]');if(!button)return;
      var action=button.getAttribute('data-av-action'),id=button.getAttribute('data-id');
      if(action==='edit')openEditor(id);
      if(action==='creation-date')openCreationDateEditor(id);
      if(action==='detail'&&typeof openVisitaCalendarDetail==='function')openVisitaCalendarDetail(id);
      if(action==='delete')deleteVisit(id);
      if(action==='reserve')openReserve(id);
      if(action==='open-reservation')openReservation(id);
    });
    document.getElementById('av-pagination').addEventListener('click',function(event){
      var button=event.target.closest('[data-av-page]');
      if(!button||button.disabled)return;
      visitsPage=parseInt(button.getAttribute('data-av-page'),10)||1;
      renderVisits();
      var scroll=document.querySelector('#panel-'+VIEW_ID+' .table-scroll');
      if(scroll)scroll.scrollTop=0;
    });
    document.getElementById('av-reserve-close').addEventListener('click',closeReserve);
    document.getElementById('av-reserve-cancel').addEventListener('click',closeReserve);
    document.getElementById('av-refresh-quotes').addEventListener('click',function(){refreshQuotes(true);});
    document.getElementById('av-quote-search').addEventListener('input',function(){scheduleRuntimeSearch('quotes',renderQuoteList);});
    document.getElementById('av-quote-list').addEventListener('change',function(event){
      if(event.target.name!=='av-quote')return;
      selectedQuoteId=event.target.value;renderQuoteList();renderSelectedQuote();
    });
    document.getElementById('av-reserve-files').addEventListener('change',function(){addDocuments(this);});
    document.getElementById('av-file-list').addEventListener('click',function(event){
      var button=event.target.closest('[data-av-file-remove]');if(button)removeDocument(button.getAttribute('data-av-file-remove'));
    });
    document.getElementById('av-reserve-confirm').addEventListener('click',confirmReserve);
  }

  function registerView(){
    if(Array.isArray(VISTAS_APP)){
      for(var legacyIndex=VISTAS_APP.length-1;legacyIndex>=0;legacyIndex--){
        if(VISTAS_APP[legacyIndex].id==='visitas'||VISTAS_APP[legacyIndex].id==='cal-visitas')VISTAS_APP.splice(legacyIndex,1);
      }
      var signaturesView=VISTAS_APP.find(function(view){return view.id==='calendario';});
      if(signaturesView)signaturesView.label='Calendario de firmas';
    }
    if(Array.isArray(VISTAS_APP)&&!VISTAS_APP.some(function(view){return view.id===VIEW_ID;})){
      var view={id:VIEW_ID,area:'VENTAS',label:'Agendamiento de visita',btn:'tbtn-'+VIEW_ID,verRoles:['Remoto','Terreno','Vendedor','Ej. Adm. Ventas','Supervisor','Administrador'],editRoles:['Remoto','Terreno','Vendedor','Ej. Adm. Ventas','Supervisor','Administrador']};
      var cotizadorIndex=VISTAS_APP.findIndex(function(item){return item.id==='ventas';});
      VISTAS_APP.splice(cotizadorIndex<0?0:cotizadorIndex,0,view);
    }
    if(Array.isArray(SELLER_ALLOWED_INTEGRATED_VIEWS)&&SELLER_ALLOWED_INTEGRATED_VIEWS.indexOf(VIEW_ID)<0)SELLER_ALLOWED_INTEGRATED_VIEWS.push(VIEW_ID);
    if(typeof syncVistaPermisos==='function')syncVistaPermisos();
  }

  function patchLifecycle(){
    if(typeof aplicarConfigCentral==='function'){
      var originalConfig=aplicarConfigCentral;
      aplicarConfigCentral=function(config){
        var result=originalConfig.apply(this,arguments);
        var editor=document.getElementById('modal-av-editor');
        if(editor&&editor.classList.contains('open'))refreshTerrainOptions();
        return result;
      };
    }
    var originalNormalize=normalizeStateShape;
    normalizeStateShape=function(value){var normalized=originalNormalize(value);visitStore(normalized);invalidateVisitCaches();return normalized;};
    visitStore(state);
    var originalSetTab=setTab;
    setTab=function(name,button){
      originalSetTab(name,button);
      if(name===VIEW_ID){
        if(typeof visitasLoaded!=='undefined'&&visitasLoaded)renderActiveScheduleView();
        else{showVisitLoadingState();refreshOwnVisits(false);}
      }
    };
    var originalRenderAll=renderAll;
    renderAll=function(){originalRenderAll();var panel=document.getElementById('panel-'+VIEW_ID);if(panel&&panel.classList.contains('active'))renderActiveScheduleView();};
    var originalUpdateCounts=updateTabCounts;
    updateTabCounts=function(){originalUpdateCounts();updateVisitCount();};
  }

  function initialize(){
    if(typeof state==='undefined'||typeof VISTAS_APP==='undefined')return;
    injectNavigation();injectPanel();enhanceCalendarFilters();injectModals();registerView();patchLifecycle();bindEvents();setScheduleView('list');updateVisitCount();
    if(currentUser&&typeof applyTabVisibility==='function')applyTabVisibility();
  }

  window.PruebaVisitScheduling={
    normalize:normalize,personMatches:personMatches,quoteValidation:quoteValidation,missingVisitFields:missingVisitFields,createdAtDisplay:createdAtDisplay,creationDateForInput:creationDateForInput,creationTimestampWithDate:creationTimestampWithDate,canEditCreationDate:canEditCreationDate,openCreationDateEditor:openCreationDateEditor,saveCreationDateEditor:saveCreationDateEditor,stripQuoteReservationAction:stripQuoteReservationAction,canonicalProjectName:canonicalProjectName,projectNames:projectNames,projectAccess:projectAccess,projectAllowed:projectAllowed,defaultRemoteAgent:defaultRemoteAgent,isMondayVisit:isMondayVisit,isHistoricalVisit:isHistoricalVisit,isReservedVisit:isReservedVisit,isRemoteUser:isRemoteUser,isTerrainUser:isTerrainUser,canSeeVisit:canSeeVisit,canSeeCalendarVisit:canSeeCalendarVisit,canEditVisit:canEditVisit,canFullyEditVisit:canFullyEditVisit,canEditVisitObservation:canEditVisitObservation,hasTerrainObservation:hasTerrainObservation,terrainObservationHistory:terrainObservationHistory,hasRemoteObservation:hasRemoteObservation,remoteObservationHistory:remoteObservationHistory,appendVisitObservation:appendVisitObservation,removeVisitObservationFromDraft:removeVisitObservationFromDraft,deleteVisitObservation:deleteVisitObservation,deleteVisit:deleteVisit,setEditorAccessMode:setEditorAccessMode,mergeMondayVisit:mergeMondayVisit,allVisits:allVisits,findVisit:findVisit,linkedReservations:linkedReservations,openReservation:openReservation,visibleVisits:visibleVisits,calendarVisibleVisits:calendarVisibleVisits,invalidateVisitCaches:invalidateVisitCaches,selectedProjectValues:selectedProjectValues,setProjectFilterSelection:setProjectFilterSelection,setProjectFilterOptions:setProjectFilterOptions,listMultiFilterValues:listMultiFilterValues,setListMultiFilterSelection:setListMultiFilterSelection,setListMultiFilterOptions:setListMultiFilterOptions,calendarFilterValues:calendarFilterValues,setCalendarFilterSelection:setCalendarFilterSelection,setCalendarFilterOptions:setCalendarFilterOptions,enhanceCalendarFilters:enhanceCalendarFilters,filteredVisits:filteredVisits,currentVisitFilters:currentVisitFilters,visitRangeMetrics:visitRangeMetrics,buildVisitExportRows:buildVisitExportRows,exportVisitsExcel:exportVisitsExcel,linkReservation:linkReservation,refreshOwnVisits:refreshOwnVisits,refreshMondayVisits:refreshOwnVisits,persistOwnVisit:persistOwnVisit,showLoading:showVisitLoadingState,render:renderVisits,renderActive:renderActiveScheduleView,setView:setScheduleView,openEditor:openEditor,openReserve:openReserve
  };
  window.PruebaVisitScheduling.hasJocelynCalendarAccess=hasJocelynCalendarAccess;
  window.PruebaVisitScheduling.projectTerrainAgents=projectTerrainAgents;
  window.PruebaVisitScheduling.terrainAllowed=terrainAllowed;
  window.PruebaVisitScheduling.refreshTerrainOptions=refreshTerrainOptions;
  initialize();
})();
