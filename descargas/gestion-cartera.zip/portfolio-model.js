(function(root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.CarteraPortfolioModel = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function() {
  'use strict';
  var HISTORY = ['actividad', 'obsHistorial', 'reuniones'];
  function fail(message) { var error = new Error(message); error.code = 'portfolio-integrity'; throw error; }
  function plain(value) { if (!value || typeof value !== 'object') return false; var proto = Object.getPrototypeOf(value); return proto === null || Object.getPrototypeOf(proto) === null; }
  function clone(value) {
    if (Array.isArray(value)) return value.map(clone);
    if (plain(value)) {
      return Object.fromEntries(Object.keys(value).map(function(key) { return [key, clone(value[key])]; }));
    }
    return value;
  }
  function stable(value) {
    if (Array.isArray(value)) return '[' + value.map(stable).join(',') + ']';
    if (plain(value)) return '{' + Object.keys(value).sort().map(function(key) { return JSON.stringify(key) + ':' + stable(value[key]); }).join(',') + '}';
    return JSON.stringify(value);
  }
  function key(id) {
    if (typeof id !== 'string' || !id || id.length > 350) fail('Identificador de ficha inválido.');
    var encoded = encodeURIComponent(id).replace(/\./g, '%2E');
    if (encoded.length > 1400) fail('Identificador de ficha demasiado largo.');
    return encoded;
  }
  function historyKey(id, field, index) { return key(id) + '~' + field + '~' + String(index).padStart(8, '0'); }
  // Small event-local projection: notifications must compare the exact before/
  // after event, never fetch newer histories and accidentally send duplicates.
  function notificationContext(record) {
    var lastObservation = '';
    var history = Array.isArray(record.obsHistorial) ? record.obsHistorial : [];
    for (var i = history.length - 1; i >= 0; i--) {
      if (String(history[i]?.texto == null ? '' : history[i].texto).trim()) { lastObservation = history[i].texto; break; }
    }
    var fields = ['id', 'fecha', 'fechaReunion', 'hora', 'horaReunion', 'abogada', 'estado', 'estadoReunion'];
    return {lastObservation: clone(lastObservation), meetings: (Array.isArray(record.reuniones) ? record.reuniones : []).filter(Boolean).map(function(meeting) {
      return Object.fromEntries(fields.filter(function(field) { return Object.hasOwn(meeting, field); }).map(function(field) { return [field, clone(meeting[field])]; }));
    })};
  }
  function recordForNotifications(envelope) {
    if (!envelope) return null;
    if (envelope.schemaVersion !== 2 || !envelope.notificationContext) fail('Falta el contexto de notificaciones.');
    return Object.assign(clone(envelope.data), {reuniones: clone(envelope.notificationContext.meetings), obsHistorial: [{texto: clone(envelope.notificationContext.lastObservation)}]});
  }
  function split(state) {
    if (!state || !Array.isArray(state.registros)) fail('La cartera no contiene un listado válido.');
    var control = clone(state), records = new Map(), histories = new Map();
    control.registros = [];
    state.registros.forEach(function(record, position) {
      var id = key(record.id);
      if (records.has(id)) fail('Identificador de ficha duplicado.');
      var data = clone(record), historyCounts = {};
      HISTORY.forEach(function(field) {
        if (!Array.isArray(data[field])) return;
        historyCounts[field] = data[field].length;
        data[field].forEach(function(value, index) {
          histories.set(historyKey(record.id, field, index), {recordId: record.id, field: field, index: index, value: clone(value)});
        });
        delete data[field];
      });
      records.set(id, {schemaVersion: 2, id: record.id, position: position, data: data, historyCounts: historyCounts, notificationContext: notificationContext(record)});
    });
    return {control: control, records: records, histories: histories};
  }
  function hydrate(control, records, histories) {
    if (!control || !Array.isArray(control.registros) || control.registros.length) fail('Control de cartera inválido.');
    var state = clone(control), grouped = new Map(), seen = new Set(), positions = new Set();
    histories.forEach(function(entry, documentId) {
      if (!entry || !HISTORY.includes(entry.field) || !Number.isInteger(entry.index) || entry.index < 0) fail('Entrada de historial inválida.');
      if (documentId !== historyKey(entry.recordId, entry.field, entry.index)) fail('Identificador de historial inconsistente.');
      var mapKey = key(entry.recordId) + '~' + entry.field;
      if (!grouped.has(mapKey)) grouped.set(mapKey, []);
      grouped.get(mapKey).push(entry);
    });
    var list = [];
    records.forEach(function(record, documentId) {
      if (!record || record.schemaVersion !== 2 || record.id !== record.data?.id || documentId !== key(record.id)) fail('Ficha inconsistente.');
      if (seen.has(record.id)) fail('Ficha duplicada.'); seen.add(record.id);
      if (!Number.isInteger(record.position) || record.position < 0 || positions.has(record.position)) fail('Orden de ficha inválido.');
      positions.add(record.position);
      var data = clone(record.data);
      Object.keys(record.historyCounts || {}).forEach(function(field) {
        if (!HISTORY.includes(field)) fail('Tipo de historial desconocido.');
        if (Object.hasOwn(data, field)) fail('Historial duplicado en la ficha.');
        var count = record.historyCounts[field], values = grouped.get(documentId + '~' + field) || [];
        if (!Number.isInteger(count) || count < 0 || values.length !== count) fail('Historial incompleto. Actualiza antes de guardar.');
        values.sort(function(a, b) { return a.index - b.index; });
        data[field] = values.map(function(item, index) { if (item.index !== index) fail('Historial incompleto o duplicado.'); return clone(item.value); });
      });
      list.push({position: record.position, data: data});
    });
    histories.forEach(function(entry) {
      var record = records.get(key(entry.recordId));
      if (!record || !Object.hasOwn(record.historyCounts || {}, entry.field)) fail('Historial sin ficha asociada.');
    });
    list.sort(function(a, b) { return a.position - b.position || String(a.data.id).localeCompare(String(b.data.id)); });
    state.registros = list.map(function(item) { return item.data; });
    return state;
  }
  function diff(before, after) {
    var left = split(before), right = split(after), writes = [];
    [['cartera_registros', left.records, right.records], ['cartera_historial', left.histories, right.histories]].forEach(function(group) {
      group[2].forEach(function(value, id) {
        if (!group[1].has(id) || stable(group[1].get(id)) !== stable(value)) writes.push({operation: 'set', collection: group[0], id: id, data: value});
      });
      group[1].forEach(function(value, id) { if (!group[2].has(id)) writes.push({operation: 'delete', collection: group[0], id: id}); });
    });
    return {control: right.control, writes: writes, recordCount: right.records.size};
  }
  function assertWritable(control) {
    if (control.portfolioMaintenance === true) { var error = new Error('El sistema está en mantenimiento. Conserva la ficha abierta y espera la confirmación.'); error.code = 'portfolio-maintenance'; throw error; }
    if (control.portfolioSchema !== 2) fail('Esta versión de almacenamiento aún no está activada.');
  }
  return {HISTORY: HISTORY, clone: clone, stable: stable, key: key, historyKey: historyKey, split: split, hydrate: hydrate, diff: diff, assertWritable: assertWritable, recordForNotifications: recordForNotifications};
});
