(function(root){
  'use strict';
  // La vista y el guardado comparten la consulta de la UF para la fecha exacta.
  var values=new Map(),pending=new Map(),failures=new Map(),FRESH_MS=6*60*60*1000;
  function escape(value){return String(value==null?'':value).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function date(value){
    var iso=typeof root.normalizeDateValue==='function'?root.normalizeDateValue(value):String(value||'');
    return /^\d{4}-\d{2}-\d{2}$/.test(iso)&&iso.slice(0,4)!=='0000'&&!isNaN(Date.parse(iso))&&new Date(iso).toISOString().slice(0,10)===iso?iso:'';
  }
  function valid(entry,iso){return entry&&entry.fecha===iso&&Number.isFinite(entry.valor)&&entry.valor>0;}
  function peek(iso){
    var saved=values.get(iso);
    if(saved&&Date.now()-saved.at<FRESH_MS)return saved.entry;
    var entry=root.CarteraUF&&root.CarteraUF.peek(iso);
    return valid(entry,iso)?entry:null;
  }
  function format(value){return typeof root.fmtUfValue==='function'?root.fmtUfValue(value):'$ '+Number(value).toLocaleString('es-CL',{minimumFractionDigits:2,maximumFractionDigits:2});}
  function label(iso){return iso.slice(8,10)+'/'+iso.slice(5,7)+'/'+iso.slice(0,4);}
  function valueTitle(entry){return 'UF de la fecha de depósito: '+label(entry.fecha)+' · '+(entry.proveedor||'Consulta UF')+(entry.offline?' · Valor guardado para esa fecha':'');}
  function errorHtml(iso){return '<span class="text-muted">Sin dato</span> <button type="button" class="ico-btn" data-cc-uf-retry="'+iso+'" title="Reintentar UF del '+label(iso)+'" aria-label="Reintentar UF del '+label(iso)+'" style="padding:0 4px;font-size:11px;line-height:18px">↻</button>';}
  function cell(moneda,fechaDeposito,original){
    if(moneda!=='UF')return '—';
    var iso=date(fechaDeposito);
    if(!iso)return original?escape(format(original)):'—';
    var entry=peek(iso),failed=failures.get(iso),recent=failed&&Date.now()-failed<30000;
    return '<span data-cc-deposit-uf="'+iso+'" title="'+escape(entry?valueTitle(entry):'UF de la fecha de depósito: '+label(iso))+'">'+
      (entry?escape(format(entry.valor)):recent?errorHtml(iso):'<span class="text-muted">Consultando…</span>')+'</span>';
  }
  function request(iso,force){
    if(pending.has(iso))return pending.get(iso);
    var saved=values.get(iso);
    if(!force&&saved&&Date.now()-saved.at<FRESH_MS)return Promise.resolve(saved.entry);
    var promise=Promise.resolve().then(function(){if(!root.CarteraUF)throw new Error('uf/unavailable');return root.CarteraUF.get(iso,!!force);}).then(function(entry){
      if(!valid(entry,iso))throw new Error('uf/wrong-date');
      failures.delete(iso);values.set(iso,{entry:entry,at:Date.now()});
      if(values.size>256)values.delete(values.keys().next().value);
      return entry;
    }).finally(function(){pending.delete(iso);});
    pending.set(iso,promise);return promise;
  }
  function beforeRender(tbody){
    var pickers=[];
    tbody.querySelectorAll('.cc-deposit-date').forEach(function(input){if(input._flatpickr)pickers.push(input._flatpickr);});
    // Flatpickr termina sus eventos antes de destruir las instancias de filas
    // reemplazadas. Así no quedan calendarios ni eventos de campos antiguos.
    Promise.resolve().then(function(){pickers.forEach(function(picker){if(picker.input&&!picker.input.isConnected)picker.destroy();});});
  }
  function hydrate(forceDate){
    var tbody=document.getElementById('tbody-cc');if(!tbody)return Promise.resolve();
    var groups=new Map();
    tbody.querySelectorAll('[data-cc-deposit-uf]').forEach(function(node){var iso=date(node.dataset.ccDepositUf);if(!iso)return;if(!groups.has(iso))groups.set(iso,[]);groups.get(iso).push(node);});
    var tasks=[];
    groups.forEach(function(nodes,iso){
      var force=forceDate===iso,failed=failures.get(iso);
      if(failed&&Date.now()-failed<30000&&!force){nodes.forEach(function(node){if(!peek(iso))node.innerHTML=errorHtml(iso);});return;}
      if(force){failures.delete(iso);nodes.forEach(function(node){if(!peek(iso))node.innerHTML='<span class="text-muted">Consultando…</span>';});}
      tasks.push(request(iso,force).then(function(entry){nodes.forEach(function(node){if(node.isConnected&&node.dataset.ccDepositUf===iso){node.textContent=format(entry.valor);node.title=valueTitle(entry);}});}).catch(function(){
        failures.set(iso,Date.now());nodes.forEach(function(node){if(node.isConnected&&node.dataset.ccDepositUf===iso){var entry=peek(iso);if(entry){node.textContent=format(entry.valor);node.title=valueTitle(entry);}else{node.innerHTML=errorHtml(iso);node.title='No se pudo consultar la UF del '+label(iso)+'. Reintenta la consulta.';}}});
      }));
    });
    return Promise.all(tasks);
  }
  document.addEventListener('click',function(event){var button=event.target.closest&&event.target.closest('[data-cc-uf-retry]');if(!button||!button.closest('#tbody-cc'))return;event.preventDefault();event.stopPropagation();hydrate(button.dataset.ccUfRetry);});
  root.CarteraCCDepositoUF={cell:cell,hydrate:hydrate,beforeRender:beforeRender,resolve:function(value){
    var iso=date(value);
    return iso?request(iso,false):Promise.reject(new Error('uf/invalid-date'));
  }};
})(window);
