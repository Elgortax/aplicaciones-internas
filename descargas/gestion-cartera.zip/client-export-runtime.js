(function(root){
  'use strict';
  var fields=[['nombre','Cliente',['cliente','nombre','nombrecliente']],['rut','RUT Cliente',['rut','rutcliente']],
    ['telefono','Teléfono',['telefono','telefonocliente']],['correo','Correo',['correo','email','correoelectronico']],
    ['comuna','Comuna',['comuna']],['nacionalidad','Nacionalidad',['nacionalidad']],['direccion','Dirección',['direccion']],
    ['region','Región',['region']],['estadoCivil','Estado civil',['estadocivil']],['profesion','Profesión',['profesion','ocupacion']],
    ['grupoProfesion','Grupo profesión',['grupoprofesion']],['sexo','Sexo',['sexo']],['edad','Edad',['edad']],
    ['hijos','Cantidad de hijos',['cantidaddehijos','hijos']],['fechaNacimiento','Fecha nacimiento',['fechanacimiento','fechadenacimiento']]];
  function clean(v){if(v===null||v===undefined)return '';var s=String(v).trim();return /^(?:[-—–]|n\/?a|sin (?:informar|indicar|informaci[oó]n)|no informado|null|undefined)$/i.test(s)?'':s;}
  function key(v){return clean(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');}
  function rut(v){return clean(v).toUpperCase().replace(/[^0-9K]/g,'');}
  function first(){for(var i=0;i<arguments.length;i++)if(clean(arguments[i])!=='')return typeof arguments[i]==='number'?arguments[i]:clean(arguments[i]);return '';}
  function profile(record,quote,contact){
    var r=record||{},q=quote||{},s=contact||{},has=function(k){return Object.prototype.hasOwnProperty.call(s,k);};
    var actualRut=has('rut')?s.rut:r.rut;
    if(rut(actualRut)&&rut(q.rut)&&rut(actualRut)!==rut(q.rut))q={};
    if(has('rut')&&rut(s.rut)&&rut(r.rut)&&rut(s.rut)!==rut(r.rut)){
      r={cliente:r.cliente};if(!rut(q.rut))q={};
    }
    return {nombre:first(r.cliente,r.nombre,q.nombre,q.cliente),rut:typeof root.formatRutParaExportar==='function'?root.formatRutParaExportar(has('rut')?s.rut:first(r.rut,q.rut)):first(actualRut,q.rut),
      telefono:has('telefono')?clean(s.telefono):first(r.telefono,q.telefono),correo:has('correo')?clean(s.correo):first(r.correo,r.email,q.correo,q.email),
      comuna:first(r.comuna,q.comuna),nacionalidad:first(r.nacionalidad,q.nacionalidad),direccion:first(r.direccion,q.direccion),region:first(r.region,q.region),
      estadoCivil:first(r.estadoCivil,q.estadoCivil),profesion:first(r.profesion,r.ocupacion,q.profesion,q.ocupacion),grupoProfesion:first(r.grupoProfesion,q.grupoProfesion),
      sexo:first(r.sexo,q.sexo),edad:first(r.edad,q.edad),hijos:first(r.hijos,q.hijos),fechaNacimiento:first(r.fechaNacimiento,r.fechaNac,q.fechaNacimiento,q.fechaNac)};
  }
  function missing(headers){var keys=headers.map(key);return fields.filter(function(f){return !f[2].some(function(alias){return keys.indexOf(alias)>=0;});});}
  function table(headers,rows,profiles){
    var extra=missing(headers),columns=headers.map(function(h){return fields.find(function(f){return f[2].indexOf(key(h))>=0;});});
    return {headers:headers.concat(extra.map(function(f){return f[1];})),rows:rows.map(function(row,index){
      var p=profiles&&profiles[index],out=row.slice();
      if(p)columns.forEach(function(f,col){if(f)out[col]=p[f[0]]===undefined?'':p[f[0]];});
      return out.concat(extra.map(function(f){return p&&p[f[0]]!==undefined?p[f[0]]:'';}));
    })};
  }
  function parse(line){var row=[],v='',quoted=false;for(var i=0;i<line.length;i++){var ch=line[i];if(ch==='"'){if(quoted&&line[i+1]==='"'){v+='"';i++;}else quoted=!quoted;}else if(ch===';'&&!quoted){row.push(v);v='';}else v+=ch;}row.push(v);return row;}
  function delimited(lines,profiles){var rows=lines.map(parse),report=table(rows[0],rows.slice(1),profiles);return [report.headers].concat(report.rows).map(function(row){return row.map(function(v){return '"'+String(v==null?'':v).replace(/"/g,'""')+'"';}).join(';');});}
  function forRows(rows,contacts){return rows.map(function(row){return root.contactoDeFilaInforme(row,contacts);});}
  function record(id){return typeof state!=='undefined'&&(state.registros||[]).find(function(r){return String(r.id)===String(id);});}
  function visible(r){return r&&!(typeof shouldScopeRecordsToUser==='function'&&shouldScopeRecordsToUser()&&!userOwnsRecord(r));}
  async function quoteProfiles(quotes){
    var linked=quotes.map(function(q){var r=q.reservaId&&record(q.reservaId);return visible(r)&&(!rut(q.rut)||!rut(r.rut)||rut(q.rut)===rut(r.rut))?r:null;});
    var contacts=await root.cargarContactosInforme(linked.filter(Boolean));
    return quotes.map(function(q,i){var p=profile({},q,{}),from=linked[i]&&root.contactoDeFilaInforme(linked[i],contacts);if(from&&(!rut(q.rut)||!rut(from.rut)||rut(q.rut)===rut(from.rut)))fields.forEach(function(f){if(clean(from[f[0]])!==''||(from._contactFields||[]).indexOf(f[0])>=0)p[f[0]]=from[f[0]];});return p;});
  }
  async function visitProfiles(visits,reservations){
    var linked=visits.map(function(v){var candidates=(reservations(v)||[]).filter(function(r){return visible(r)&&(!rut(v.rut)||!rut(r.rut)||rut(v.rut)===rut(r.rut));});return candidates.length===1?candidates[0]:null;});
    var contacts=await root.cargarContactosInforme(linked.filter(Boolean));
    return visits.map(function(v,i){var p=profile(v,{},{}),from=linked[i]&&root.contactoDeFilaInforme(linked[i],contacts);if(from&&(!rut(v.rut)||!rut(from.rut)||rut(v.rut)===rut(from.rut)))fields.forEach(function(f){if(clean(from[f[0]])!==''||(from._contactFields||[]).indexOf(f[0])>=0)p[f[0]]=from[f[0]];});return p;});
  }
  function clientTable(rows,contacts){return table(['Proyecto','Lote'],rows.map(function(row){var r=root.registroDeFilaInforme(row)||row;return [r.proyecto||'',r.name||r.lote||''];}),forRows(rows,contacts));}
  root.CarteraClientesInforme={fields:fields,profile:profile,table:table,delimited:delimited,forRows:forRows,quoteProfiles:quoteProfiles,visitProfiles:visitProfiles,clientTable:clientTable};
  function installExportErrors(){
    ['exportInformeReservasExcel','exportCalendarioFirmasExcel','exportCalendarioEscriturasExcel','exportMonitorEscriturasPDF','exportarExcel'].forEach(function(name){
      var original=root[name];if(typeof original!=='function')return;
      root[name]=async function(){try{return await original.apply(this,arguments);}catch(error){console.error('No se pudieron reunir los datos del cliente para '+name,error);if(typeof root.toast==='function')root.toast('No se pudieron consultar los datos de clientes. Intenta descargar nuevamente.','error');}};
    });
  }
  if(typeof document!=='undefined')document.addEventListener('DOMContentLoaded',installExportErrors,{once:true});
  if(typeof module==='object'&&module.exports)module.exports=root.CarteraClientesInforme;
})(typeof window!=='undefined'?window:globalThis);
