(function(){
  'use strict';

  var active=null;
  var requestToken=0;
  var own=Object.prototype.hasOwnProperty;

  function byId(id){return document.getElementById(id);}
  function clean(value){return String(value==null?'':value).trim();}
  function safe(value){return typeof esc==='function'?esc(clean(value)):clean(value).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function recordById(id){return (state.registros||[]).find(function(row){return String(row.id)===String(id);});}
  function fichaOf(record,type){return record&&record.fichasDevolucion&&record.fichasDevolucion[type]||null;}
  function hasFicha(record,type){return !!fichaOf(record,type);}
  function isComplete(record,type){
    var ficha=fichaOf(record,type);
    return !!ficha&&['rut','banco','tipoCuenta','cuenta','correo'].every(function(field){return !!clean(ficha[field]);});
  }
  function canEdit(type,approval){
    if(approval)return canDo('Aprobar Resciliación');
    return canDoEnVista('Editar Conciliación Contable',type==='desist'?'dev-desistimientos':'dev-resciliaciones');
  }
  function approvalPending(record,type){
    return type==='desist'
      ? record.estado==='Desistido'&&record.desistEstado==='pendiente'
      : record.estado==='Resciliación'&&record.rescilEstado==='pendiente';
  }
  function approved(record,type){
    return type==='desist'
      ? record.estado==='Desistido'&&(record.desistEstado||'aprobada')==='aprobada'
      : record.estado==='Resciliación'&&record.rescilEstado==='aprobada';
  }
  function canView(record,type,approval){
    if(!record||shouldScopeRecordsToUser()&&!userOwnsRecord(record))return false;
    if(approval)return approvalPending(record,type)&&canEdit(type,true);
    return approved(record,type)&&puedeVerVista(type==='desist'?'dev-desistimientos':'dev-resciliaciones');
  }
  function accountTypeFromText(value){
    var source=clean(value);
    if(/\b(?:corriente|ctte|cte)\b/i.test(source))return 'Cuenta corriente';
    if(/\b(?:vista|chequera\s+electr[oó]nica)\b/i.test(source))return 'Cuenta vista';
    if(/\b(?:cuenta\s+rut|cta\s+rut)\b/i.test(source))return 'Cuenta RUT';
    if(/\b(?:ahorro|ahorros)\b/i.test(source))return 'Cuenta de ahorro';
    return '';
  }
  function legacyBank(record){
    var previous=record.fichaDesistimiento||{};
    var lines=clean(record.datosBancarios).split(/\r?\n/).map(clean);
    var accountLine=lines.find(function(line){return /^(?:cta\.?\s*(?:cte|ctte|vista|corriente)?|cuenta(?:\s+(?:corriente|vista|rut))?|c\/c)\b/i.test(line);})||'';
    var bankLine=lines.find(function(line){return /^(?:bco\.?|banco)\b/i.test(line);})||'';
    var typeLine=lines.find(function(line){return /^(?:tipo\s+(?:de\s+)?cuenta|cuenta\s+(?:corriente|vista|rut|de\s+ahorro)|cta\s+(?:cte|ctte|vista|rut))\b/i.test(line);})||'';
    return {
      cuenta:own.call(previous,'cuenta')?clean(previous.cuenta):clean(record.cuentaBancaria||record.numCuenta||record.cuenta||accountLine.replace(/^(?:cta\.?\s*(?:cte|ctte|vista|corriente)?|cuenta(?:\s+(?:corriente|vista|rut))?|c\/c)\s*[:#-]?\s*/i,'')),
      banco:own.call(previous,'banco')?clean(previous.banco):clean(record.bancoCliente||bankLine.replace(/^(?:bco\.?|banco)\s*[:#-]?\s*/i,'')),
      tipoCuenta:own.call(previous,'tipoCuenta')?clean(previous.tipoCuenta):clean(record.tipoCuenta||record.tipoCuentaBancaria||accountTypeFromText(typeLine)||accountTypeFromText(accountLine))
    };
  }
  function observation(record,type){
    if(type==='desist')return clean(getDevolucionDesistObj(record).obj.obs);
    var cc=getCCByRegistroId(record.id);
    return clean(cc&&cc.devolucion&&cc.devolucion.obs);
  }
  function parseLegacyObservation(text){
    var source=clean(text);
    var email=(source.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i)||[])[0]||'';
    var rut=(source.match(/\b\d{1,2}[.]?\d{3}[.]?\d{3}-[0-9Kk]\b/)||[])[0]||'';
    var account=(source.match(/\b(?:CTA\s*(?:CTE|CORRIENTE|VISTA|RUT)?|CUENTA\s*(?:CORRIENTE|VISTA|RUT)?)\s*[:#-]?\s*([0-9][0-9.\-]{3,})/i)||[])[1]||'';
    var typeMatch=(source.match(/\b(?:TIPO\s+(?:DE\s+)?CUENTA\s*[:#-]?\s*|CTA\s+|CUENTA\s+)(?:DE\s+)?(CORRIENTE|CTTE|CTE|VISTA|RUT|AHORROS?)\b/i)||[])[1]||'';
    var segments=source.split(/\s+[-–]\s+/);
    var accountIndex=segments.findIndex(function(segment){return /\b(?:CTA|CUENTA)\b/i.test(segment);});
    var bank=accountIndex>=0&&segments[accountIndex+1]&&!/@/.test(segments[accountIndex+1])?clean(segments[accountIndex+1]):'';
    return {rut:rut,cuenta:account,tipoCuenta:accountTypeFromText('Cuenta '+typeMatch),banco:bank,correo:email};
  }
  function dataFor(record,type,contact){
    var existing=fichaOf(record,type)||{};
    var legacy=legacyBank(record);
    var observed=observation(record,type);
    var fromObs=parseLegacyObservation(observed);
    function pick(field,values){
      if(own.call(existing,field))return clean(existing[field]);
      return values.map(clean).find(Boolean)||'';
    }
    return {
      rut:pick('rut',[contact&&own.call(contact,'rut')?contact.rut:record.rut,fromObs.rut]),
      cuenta:pick('cuenta',[legacy.cuenta,fromObs.cuenta]),
      banco:pick('banco',[legacy.banco,fromObs.banco]),
      tipoCuenta:pick('tipoCuenta',[legacy.tipoCuenta,fromObs.tipoCuenta]),
      correo:pick('correo',[contact&&own.call(contact,'correo')?contact.correo:(record.correo||record.email),fromObs.correo]),
      observacion:own.call(existing,'observacion')?clean(existing.observacion):observed
    };
  }
  function amount(type,record,approval){
    if(type==='desist'){
      var validated=getValidacionByRegistroId(record.id);
      if((approval||record.exigirValidacionDevolucion)&&(!validated||validated.estado!=='Validado'))return 0;
      var info=getDevolucionDesistObj(record);
      var paid=info.fuente==='plan'?getTotalAbonadoConciliacion(info.cc):info.fuente==='validacion'?(parseFloat(info.val.monto)||0):(parseFloat(record.montoReservaCotizacion)||0);
      paid=getDevDesistMontoEfectivo(info.obj,'montoPagadoManual',paid);
      return getDevDesistMontoEfectivo(info.obj,'montoDevolverManual',paid);
    }
    var plan=getConciliacionByRegistroId(record.id);
    if(!plan)return 0;
    var cc=getCCByRegistroId(record.id)||{lineas:{},devolucion:{}};
    var dev=cc.devolucion||{};
    var paidResc=getDevRescMontoPagado(dev,getDevRescTotalPagado(cc,plan));
    var pct=Math.max(0,Math.min(100,parseFloat(dev.pctMulta)||0));
    var penalty=dev.modoMulta==='monto'?Math.min(Math.max(0,parseFloat(dev.montoMultaManual)||0),paidResc):Math.round(paidResc*pct/100);
    return getDevRescMontoDevolver(dev,paidResc,penalty);
  }
  function syncDates(){
    ['fil-fecha-desist-desde','fil-fecha-desist-hasta','fil-fecha-rescil-desde','fil-fecha-rescil-hasta'].forEach(function(id){
      var input=byId(id);
      if(input&&input.closest('.desist-date-field'))input.closest('.desist-date-field').dataset.empty=input.value?'0':'1';
    });
  }
  function ensureModal(){
    var modal=byId('ficha-devolucion-modal');
    if(modal)return modal;
    modal=document.createElement('div');
    modal.id='ficha-devolucion-modal';
    modal.className='modal-overlay';
    modal.style.zIndex='20140';
    modal.innerHTML='<div class="modal ficha-devolucion-dialog" role="dialog" aria-modal="true" aria-labelledby="ficha-devolucion-title">'+
      '<div class="modal-head"><h3 id="ficha-devolucion-title">Ficha de devolución</h3><button class="modal-close" type="button" data-ficha-close aria-label="Cerrar">✕</button></div>'+
      '<div class="modal-body">'+
        '<div class="ficha-devolucion-summary"><div><span>PROYECTO</span><strong id="ficha-devolucion-proyecto">—</strong></div><div><span>LOTE</span><strong id="ficha-devolucion-lote">—</strong></div><div><span>MONTO A DEVOLVER</span><strong id="ficha-devolucion-monto">$0</strong></div><div><span>NOMBRE</span><strong id="ficha-devolucion-nombre">—</strong></div></div>'+
        '<div id="ficha-devolucion-validacion" class="ficha-devolucion-warning" hidden>⚠ Validar reserva: mientras no figure como Validado, el monto a devolver es $0.</div>'+
        '<div class="ficha-devolucion-fields">'+
          '<label>RUT <input id="ficha-devolucion-rut" type="text" autocomplete="off" placeholder="RUT del cliente"></label>'+
          '<label>CORREO <input id="ficha-devolucion-correo" type="email" autocomplete="email" placeholder="contacto-demo-66a210ce@example.invalid"></label>'+
          '<label>BANCO <input id="ficha-devolucion-banco" type="text" autocomplete="off" placeholder="Banco de destino"></label>'+
          '<label>TIPO DE CUENTA <input id="ficha-devolucion-tipoCuenta" type="text" list="ficha-devolucion-tipos-cuenta" autocomplete="off" placeholder="Ej: Cuenta corriente"></label>'+
          '<label class="ficha-devolucion-account-number">NÚMERO DE CUENTA <input id="ficha-devolucion-cuenta" type="text" inputmode="numeric" autocomplete="off" placeholder="N° de cuenta para devolución"></label>'+
          '<datalist id="ficha-devolucion-tipos-cuenta"><option value="Cuenta corriente"><option value="Cuenta vista"><option value="Cuenta RUT"><option value="Cuenta de ahorro"></datalist>'+
        '</div><label class="ficha-devolucion-observacion">OBSERVACIONES <textarea id="ficha-devolucion-obs" rows="3" placeholder="Antecedentes o instrucciones de la devolución"></textarea></label>'+
        '<p class="ficha-devolucion-hint" id="ficha-devolucion-hint"></p>'+
      '</div><div class="modal-footer"><button class="btn btn-ghost" type="button" data-ficha-close>Cancelar</button><button class="btn btn-primary" type="button" id="ficha-devolucion-save">Guardar ficha</button></div></div>';
    modal.addEventListener('click',function(event){if(event.target===modal||event.target.closest('[data-ficha-close]'))close();});
    document.body.appendChild(modal);
    byId('ficha-devolucion-save').addEventListener('click',save);
    return modal;
  }
  function close(){
    if(active&&active.saving)return;
    var modal=byId('ficha-devolucion-modal');
    if(modal)modal.classList.remove('open');
    active=null;
    requestToken++;
  }
  function open(type,id,approval){
    var record=recordById(id);
    if(!canView(record,type,approval)){
      toast('No tienes permiso o este registro ya cambió de estado.','error');return;
    }
    if(approval&&type==='rescil'&&!getConciliacionByRegistroId(record.id)){
      toast('Antes de aprobar la Resciliación debe agregar su Plan de Pago.','error');return;
    }
    var modal=ensureModal();
    var token=++requestToken;
    active={type:type,id:String(id),approval:!!approval,saving:false,contact:{}};
    var typeName=type==='desist'?'Desistimiento':'Resciliación';
    byId('ficha-devolucion-title').textContent=(approval?'Aprobar ':'Ficha de devolución · ')+typeName;
    byId('ficha-devolucion-proyecto').textContent=record.proyecto||'—';
    byId('ficha-devolucion-lote').textContent=record.name||'—';
    byId('ficha-devolucion-monto').textContent=fmtClp(amount(type,record,approval));
    byId('ficha-devolucion-nombre').textContent=record.cliente||'—';
    var validation=getValidacionByRegistroId(id);
    byId('ficha-devolucion-validacion').hidden=!(type==='desist'&&(approval||record.exigirValidacionDevolucion)&&(!validation||validation.estado!=='Validado'));
    byId('ficha-devolucion-hint').textContent=approval
      ?'Puedes aprobar aunque falten datos. Quedará un aviso en '+(type==='desist'?'Desistimientos':'Resciliaciones')+' para completar la ficha de devolución.'
      :'Puedes actualizar los datos de devolución y agregar observaciones.';
    var edit=canEdit(type,approval);
    ['rut','cuenta','banco','tipoCuenta','correo','obs'].forEach(function(field){byId('ficha-devolucion-'+field).disabled=!edit;});
    byId('ficha-devolucion-save').hidden=!edit;
    byId('ficha-devolucion-save').textContent=approval?'Guardar y aprobar':'Guardar ficha';
    byId('ficha-devolucion-save').disabled=true;
    var fallback=dataFor(record,type,{});
    ['rut','cuenta','banco','tipoCuenta','correo'].forEach(function(field){byId('ficha-devolucion-'+field).value=fallback[field];});
    byId('ficha-devolucion-obs').value=fallback.observacion;
    modal.classList.add('open');
    var api=window.RecordContactRuntime;
    (api?api.getForRecord(id):Promise.resolve({})).then(function(contact){
      if(token!==requestToken||!active)return;
      active.contact=contact||{};
      var data=dataFor(record,type,active.contact);
      ['rut','cuenta','banco','tipoCuenta','correo'].forEach(function(field){
        var input=byId('ficha-devolucion-'+field);
        if(document.activeElement!==input)input.value=data[field];
      });
      if(edit)byId('ficha-devolucion-save').disabled=false;
    }).catch(function(){
      if(token!==requestToken||!active)return;
      byId('ficha-devolucion-hint').textContent='No se pudo cargar el contacto. Revisa la conexión antes de guardar.';
      if(edit)byId('ficha-devolucion-save').disabled=false;
    });
  }
  function openForApproval(type,id){open(type,id,true);}
  function openFromDevolucion(type,id){open(type,id,false);}
  function readFields(){
    return {rut:clean(byId('ficha-devolucion-rut').value),cuenta:clean(byId('ficha-devolucion-cuenta').value),banco:clean(byId('ficha-devolucion-banco').value),tipoCuenta:clean(byId('ficha-devolucion-tipoCuenta').value),correo:clean(byId('ficha-devolucion-correo').value),observacion:clean(byId('ficha-devolucion-obs').value)};
  }
  function save(){
    if(!active||active.saving)return;
    var ctx=active;
    var record=recordById(ctx.id);
    if(!canView(record,ctx.type,ctx.approval)||!canEdit(ctx.type,ctx.approval)){
      toast('Este registro cambió o no tienes permiso para guardar.','error');return;
    }
    var fields=readFields();
    var emailInput=byId('ficha-devolucion-correo');
    if(fields.correo&&!emailInput.checkValidity()){toast('Revisa el formato del correo.','error');emailInput.focus();return;}
    if(ctx.approval){
      var typeName=ctx.type==='desist'?'Desistimiento':'Resciliación';
      var pendiente=['rut','banco','tipoCuenta','cuenta','correo'].some(function(field){return !fields[field];});
      if(!confirm('¿Aprobar el '+typeName+' de "'+record.cliente+'"? El lote quedará disponible para nueva reserva.'+(pendiente?'\n\nLa ficha de devolución quedará pendiente de completar.':'')))return;
    }
    ctx.saving=true;
    var button=byId('ficha-devolucion-save');
    button.disabled=true;button.textContent='Guardando…';
    var api=window.RecordContactRuntime;
    var current=ctx.contact||{};
    var patch={};
    ['rut','correo'].forEach(function(field){
      var prior=own.call(current,field)?clean(current[field]):clean(field==='rut'?record.rut:(record.correo||record.email));
      if(prior!==fields[field])patch[field]=fields[field];
    });
    var write=Object.keys(patch).length?(api?api.saveForRecord(ctx.id,patch):Promise.reject(new Error('contact-storage-unavailable'))):Promise.resolve();
    write.then(function(){
      if(!canView(record,ctx.type,ctx.approval))throw new Error('record-state-changed');
      var now=nowTs();
      var existing=fichaOf(record,ctx.type)||{};
      record.fichasDevolucion=record.fichasDevolucion||{};
      record.fichasDevolucion[ctx.type]={rut:fields.rut,banco:fields.banco,tipoCuenta:fields.tipoCuenta,cuenta:fields.cuenta,correo:fields.correo,observacion:fields.observacion,createdAt:existing.createdAt||now,createdBy:existing.createdBy||(currentUser&&currentUser.nombre)||'',updatedAt:now,updatedBy:(currentUser&&currentUser.nombre)||''};
      if(ctx.type==='desist')getDevolucionDesistObj(record).obj.obs=fields.observacion;
      else {
        var plan=getConciliacionByRegistroId(record.id);
        if(plan)normalizarDevolucion(getCCByRegistroId(record.id)||crearCCDesdePlan(plan)).obs=fields.observacion;
      }
      (record.actividad=record.actividad||[]).push({ts:now,user:(currentUser&&currentUser.nombre)||'Usuario',msg:'Ficha de devolución de '+(ctx.type==='desist'?'Desistimiento':'Resciliación')+' guardada'});
      if(ctx.approval){
        if(ctx.type==='desist')aprobarDesistimientoConfirmado(record.id);
        else aprobarResciliacionConfirmada(record.id);
      }else{
        saveState();
        if(ctx.type==='desist'){renderDevDesistimientos();renderDesist();}else {renderDevResciliaciones();renderResciliaciones();}
        toast('Ficha de devolución guardada.','success');
      }
      ctx.saving=false;
      close();
    }).catch(function(error){
      console.error('No se pudo guardar la ficha de devolución:',error);
      ctx.saving=false;
      button.disabled=false;
      button.textContent=ctx.approval?'Guardar y aprobar':'Guardar ficha';
      toast('No se pudo guardar el contacto. Intenta nuevamente.','error');
    });
  }
  function button(type,id){
    var record=recordById(id);
    var pending=!isComplete(record,type);
    var label=pending?(canEdit(type,false)?'⚠ Completar ficha':'Ver ficha pendiente'):hasFicha(record,type)?'Ver ficha de devolución':'Crear ficha';
    return '<button class="ico-btn ficha-devolucion-btn'+(pending?' ficha-devolucion-pendiente-btn':'')+'" type="button" onclick="FichaDevolucionRuntime.openFromDevolucion(\''+safe(type)+'\',\''+safe(id)+'\')">'+label+'</button>';
  }
  function status(record,type){
    var pending=!isComplete(record,type);
    return '<div class="rescil-ficha-status"><span class="badge '+(pending?'rescil-ficha-pendiente':'rescil-ficha-completa')+'">'+(pending?'⚠ Ficha pendiente de completar':'✓ Ficha completa')+'</span>'+
      (canView(record,type,false)?button(type,record.id):'')+'</div>';
  }
  function rescilStatus(record){return status(record,'rescil');}
  function desistStatus(record){return status(record,'desist');}
  function init(){
    ['fil-fecha-desist-desde','fil-fecha-desist-hasta','fil-fecha-rescil-desde','fil-fecha-rescil-hasta'].forEach(function(id){
      var input=byId(id);
      if(input){input.addEventListener('input',syncDates);input.addEventListener('change',syncDates);}
    });
    syncDates();
  }
  window.FichaDevolucionRuntime={openForApproval:openForApproval,openFromDevolucion:openFromDevolucion,button:button,hasFicha:hasFicha,isComplete:isComplete,rescilStatus:rescilStatus,desistStatus:desistStatus,amount:amount,syncDates:syncDates,parseLegacyObservation:parseLegacyObservation};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
