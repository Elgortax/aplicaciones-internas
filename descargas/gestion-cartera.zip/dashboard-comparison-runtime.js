(function(root){
  'use strict';
  var model=root.DashboardComparisonModel,baseMonths=[],initialized=false,owner=null;
  var monthNames=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
  function el(id){return document.getElementById('dash-compare-'+id);}
  function escape(value){return String(value===undefined?'':value).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function todayChile(){
    var parts=new Intl.DateTimeFormat('en-CA',{timeZone:'America/Santiago',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date()),date={};
    parts.forEach(function(p){date[p.type]=p.value;});return date.year+'-'+date.month+'-'+date.day;
  }
  function label(month){return monthNames[Number(month.slice(5))-1]+' '+month.slice(0,4);}
  function setMonth(input,value){if(input._flatpickr)input._flatpickr.setDate(value,false,'Y-m');else input.value=value;}
  function defaults(){
    var today=todayChile(),month=today.slice(0,7);
    setMonth(el('month'),month);el('day').value=String(Number(today.slice(8)));
    baseMonths=model.previousMonths(month,3);setMonth(el('add-month'),'');initialized=true;
  }
  function allowed(){return typeof currentUser!=='undefined'&&currentUser&&typeof puedeVerVista==='function'&&puedeVerVista('graficos');}
  function showMessage(message){el('message').textContent=message;}
  function number(value,average){return new Intl.NumberFormat('es-CL',{maximumFractionDigits:average?2:0}).format(value);}
  function money(value){return '$'+new Intl.NumberFormat('es-CL',{maximumFractionDigits:0}).format(value);}
  function cells(metric,average,provisional){
    if(!metric)return '<td class="dash-compare-count">—<small>'+(average?'Incluye corte futuro':'Corte futuro')+'</small></td><td class="dash-compare-money">—</td>';
    var note=metric.missing?'<small class="dash-compare-missing">'+(average?'Promedio parcial':metric.missing+' sin monto')+'</small>':'';
    var value=!average&&metric.count>0&&metric.count===metric.missing?'Sin monto':money(metric.amount);
    return '<td class="dash-compare-count">'+number(metric.count,average)+(provisional?'<small>Provisional</small>':'')+'</td><td class="dash-compare-money">'+value+note+'</td>';
  }
  function render(){
    if(!model||!el('body'))return;
    if(!allowed()){
      el('body').innerHTML='';el('months').innerHTML='';el('scope').textContent='';showMessage('');initialized=false;owner=null;return;
    }
    if(owner!==currentUser){owner=currentUser;initialized=false;}
    if(!el('day').options.length){for(var d=1;d<=31;d++){var o=document.createElement('option');o.value=String(d);o.textContent=String(d);el('day').appendChild(o);}}
    if(!initialized)defaults();
    var today=todayChile(),target=el('month').value;
    el('month').max=today.slice(0,7);el('add-month').max=today.slice(0,7);
    var projectInput=document.getElementById('dash-proyecto'),project=projectInput?projectInput.value:'';
    var own=typeof dashboardOwnFilterEnabled==='function'&&dashboardOwnFilterEnabled();
    el('scope').textContent=(project||'Todos los proyectos')+' · '+(own?'Mis datos':'Toda la cartera')+' · Montos completos en CLP';
    el('body').innerHTML='';showMessage('');
    if(typeof stateLoadedFromCloud!=='undefined'&&!stateLoadedFromCloud){showMessage('Esperando que terminen de cargar las fichas…');return;}
    try{
      var records=typeof state==='object'&&state&&Array.isArray(state.registros)?state.registros:[];
      var report=model.build(records,{month:target,months:baseMonths,day:el('day').value,today:today,normalizeDate:normalizeDateValue,getState:getEstado,scope:function(r){return (!project||r.proyecto===project)&&(!own||dashboardRecordBelongsToCurrentUser(r));}});
      baseMonths=report.rows.filter(function(row){return !row.target;}).map(function(row){return row.month;});
      el('months').innerHTML=baseMonths.map(function(month){return '<button type="button" class="dash-compare-chip" data-remove-month="'+month+'" aria-label="Quitar '+escape(label(month))+' del promedio">'+escape(label(month))+' <span aria-hidden="true">×</span></button>';}).join('')||'<span class="dash-compare-empty">Sin meses para el promedio. Agrega los que quieras comparar.</span>';
      el('cutoff-label').textContent='Hasta el día '+report.day+' inclusive';
      var average='<tr class="dash-compare-average"><th scope="row">Promedio de '+report.average.months+' '+(report.average.months===1?'mes':'meses')+'<small>Solo los meses seleccionados arriba</small></th>';
      average+=report.average.months?cells(report.average.accumulated,true,false)+cells(report.average.closing,true,false):'<td>—</td><td>—</td><td>—</td><td>—</td>';
      average+='</tr>';
      var missing=false,future=false,partialBase=false;
      var rows=report.rows.map(function(row){
        if(row.accumulated&&row.accumulated.missing||row.closing.missing)missing=true;
        if(row.futureCutoff)future=true;
        if(row.provisional&&!row.target)partialBase=true;
        var date=row.cutoff.split('-').reverse().join('-');
        var source=row.source==='future'?'Corte futuro · aún no disponible':'Por fecha de firma registrada';
        return '<tr class="'+(row.target?'dash-compare-target':'')+'"><th scope="row">'+escape(date)+(row.target?' <span class="dash-compare-tag">Mes a comparar</span>':'')+'<small>'+escape(label(row.month))+'</small><small>'+escape(source)+'</small></th>'+cells(row.accumulated,false,false)+cells(row.closing,false,row.provisional)+'</tr>';
      }).join('');
      el('body').innerHTML=average+rows;
      var warnings=[];
      if(report.invalidDates)warnings.push(report.invalidDates+' fichas sin fecha válida no se pueden ubicar en un mes.');
      if(missing)warnings.push('Hay operaciones sin precio de venta válido; esos montos son parciales.');
      if(future)warnings.push('Un corte futuro aún no está disponible.');
      if(!report.average.accumulated&&report.average.months)warnings.push('El promedio del acumulado no se calcula mientras incluya un corte futuro.');
      if(partialBase)warnings.push('El promedio incluye un mes en curso: su cierre es provisional.');
      showMessage(warnings.join(' '));
    }catch(error){showMessage(error.message||'Revisa los meses y el día seleccionados.');}
  }
  function addMonth(){
    if(!allowed())return;
    var month=el('add-month').value;
    if(!model.validMonth(month)||month>todayChile().slice(0,7)){showMessage('Selecciona un mes válido, hasta el mes actual.');return;}
    if(month===el('month').value){showMessage('Ese es el mes a comparar; no se incluye en su propio promedio.');return;}
    if(baseMonths.indexOf(month)>=0){showMessage('Ese mes ya está incluido en el promedio.');return;}
    if(baseMonths.length>=23){showMessage('Puedes comparar hasta 23 meses más el mes objetivo.');return;}
    baseMonths.push(month);setMonth(el('add-month'),'');render();
  }
  function bind(){
    if(!el('body')||el('body').dataset.comparisonBound)return;
    el('body').dataset.comparisonBound='1';
    el('month').addEventListener('change',render);el('day').addEventListener('change',render);
    el('add').addEventListener('click',addMonth);
    el('reset').addEventListener('click',function(){if(allowed()){defaults();render();}});
    el('months').addEventListener('click',function(event){
      var button=event.target.closest('[data-remove-month]');if(!button||!allowed())return;
      baseMonths=baseMonths.filter(function(month){return month!==button.dataset.removeMonth;});render();
    });
  }
  root.renderDashboardComparison=function(){bind();render();};
  bind();
})(window);
