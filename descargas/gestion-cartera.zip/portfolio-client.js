(function(root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./portfolio-model'));
  else root.CarteraPortfolioClient = factory(root.CarteraPortfolioModel);
})(typeof globalThis !== 'undefined' ? globalThis : this, function(model) {
  'use strict';
  function error(code, message) { var result = new Error(message); result.code = code; return result; }
  function create(db) {
    var stateRef = db.doc('cartera/state'), cache = null;
    function token(snapshot) { return model.stable(snapshot.exists ? snapshot.data() : null); }
    function isState(ref) { return ref && ref.path === stateRef.path; }
    function wrap(snapshot, data) {
      return {id: snapshot.id, ref: snapshot.ref, exists: snapshot.exists, metadata: snapshot.metadata, data: function() { return data; }};
    }
    function guard(control) {
      if (control.portfolioMaintenance === true) throw error('portfolio-maintenance', 'El sistema está en mantenimiento. Conserva tus cambios y espera la confirmación.');
      if (control.portfolioSchema != null && control.portfolioSchema !== 1 && control.portfolioSchema !== 2) throw error('portfolio-integrity', 'Actualiza la aplicación antes de continuar.');
    }
    async function read() {
      for (var attempt = 0; attempt < 4; attempt++) {
        var before = await stateRef.get({source: 'server'}), control = before.exists ? before.data() : {};
        guard(control);
        if (control.portfolioSchema !== 2) { cache = null; return before; }
        var signature = token(before);
        if (cache && cache.token === signature) return wrap(before, model.clone(cache.data));
        var results = await Promise.all([
          db.collection('cartera_registros').get({source: 'server'}),
          db.collection('cartera_historial').get({source: 'server'})
        ]);
        var after = await stateRef.get({source: 'server'});
        if (token(after) !== signature) continue;
        var records = new Map(results[0].docs.map(function(doc) { return [doc.id, doc.data()]; }));
        var histories = new Map(results[1].docs.map(function(doc) { return [doc.id, doc.data()]; }));
        var state = model.hydrate(control.state, records, histories);
        if (state.registros.length !== control.portfolioRecordCount) throw error('portfolio-integrity', 'La carga de fichas está incompleta. No se guardarán cambios.');
        var hydrated = Object.assign({}, control, {state: state});
        cache = {token: signature, data: model.clone(hydrated)};
        return wrap(after, hydrated);
      }
      throw error('portfolio-conflict', 'Otros cambios siguen llegando. Intenta guardar nuevamente; tus cambios se conservan.');
    }
    async function runTransaction(callback) {
      for (var attempt = 0; attempt < 4; attempt++) {
        var prepared = await read(), preparedData = prepared.exists ? prepared.data() : {};
        var expected = preparedData.portfolioSchema === 2 && cache ? cache.token : null;
        try {
          var result = await db.runTransaction(async function(transaction) {
            var actual = await transaction.get(stateRef), control = actual.exists ? actual.data() : {};
            guard(control);
            var modern = control.portfolioSchema === 2;
            if ((modern && token(actual) !== expected) || (!modern && expected !== null)) throw error('portfolio-conflict', 'La cartera cambió durante el guardado.');
            var full = modern ? preparedData : control;
            var stateWritten = false;
            function write(method, ref, payload, options) {
              if (!isState(ref) || !modern) { transaction[method](ref, payload, ...(options ? [options] : [])); return wrapper; }
              if (stateWritten) throw error('portfolio-integrity', 'La misma operación intentó guardar la cartera dos veces.');
              if (!payload.state || !Array.isArray(payload.state.registros)) throw error('portfolio-integrity', 'Falta la cartera completa antes de guardar.');
              var archived = new Set((control.state.archivedRegistroIds || []).map(String));
              if (payload.state.registros.some(function(record) { return archived.has(String(record.id)); })) throw error('portfolio-deleted-record', 'Una ficha fue eliminada por un administrador. Actualiza los datos antes de guardar.');
              var change = model.diff(full.state, payload.state);
              if (change.recordCount < control.portfolioRecordCount || change.writes.some(function(item) { return item.collection === 'cartera_registros' && item.operation === 'delete'; })) throw error('portfolio-delete-forbidden', 'La eliminación de fichas debe realizarse desde Administración.');
              change.writes.forEach(function(item) {
                var target = db.collection(item.collection).doc(item.id);
                if (item.operation === 'delete') transaction.delete(target);
                else transaction.set(target, item.data);
              });
              var next = Object.assign({}, payload, {state: change.control, portfolioSchema: 2, portfolioRecordCount: change.recordCount});
              transaction[method](ref, next, ...(options ? [options] : []));
              stateWritten = true;
              return wrapper;
            }
            var wrapper = {
              get: function(ref) { return isState(ref) ? Promise.resolve(modern ? wrap(actual, model.clone(full)) : actual) : transaction.get(ref); },
              set: function(ref, payload, options) { return write('set', ref, payload, options); },
              update: function(ref, payload) { return write('update', ref, payload); },
              delete: function(ref) { if (isState(ref)) throw error('portfolio-delete-forbidden', 'No se puede eliminar el control de cartera.'); transaction.delete(ref); return wrapper; }
            };
            return callback(wrapper);
          });
          cache = null;
          return result;
        } catch (failure) {
          cache = null;
          if (failure.code !== 'portfolio-conflict' || attempt === 3) throw failure;
        }
      }
    }
    return {read: read, runTransaction: runTransaction, invalidate: function() { cache = null; }};
  }
  return {create: create};
});
