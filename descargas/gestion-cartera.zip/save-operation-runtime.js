(function(root){
  'use strict';
  // One promise per operation. Never release the lock just because a timer
  // elapsed: Firestore may still be committing the original request.
  var operations=Object.create(null);
  function canClose(modal){
    return !Object.keys(operations).some(function(key){var op=operations[key];return op.modal===modal&&!op.complete;});
  }
  function complete(key){if(operations[key])operations[key].complete=true;}
  function busy(key){return !!operations[key];}
  function run(key,options,work){
    if(operations[key])return operations[key].promise;
    options=options||{};
    var op={modal:options.modal||'',complete:false};
    operations[key]=op;
    var modal=op.modal&&document.getElementById(op.modal);
    var button=options.button&&document.getElementById(options.button);
    var controls=modal?Array.prototype.map.call(modal.querySelectorAll('button,input,select,textarea'),function(el){return {el:el,disabled:el.disabled};}):[];
    var oldText=button&&button.textContent;
    controls.forEach(function(item){item.el.disabled=true;});
    if(button){button.disabled=true;button.textContent=options.label||'Guardando...';}
    var status=null;
    if(modal){
      modal.setAttribute('aria-busy','true');
      status=modal.querySelector('[data-save-operation-status]');
      if(!status){
        status=document.createElement('div');status.setAttribute('data-save-operation-status','');status.setAttribute('role','status');
        status.style.cssText='padding:10px 16px;font-size:12px;color:var(--text2);line-height:1.5';
        var footer=button&&button.parentElement;
        if(footer&&footer.parentElement)footer.parentElement.insertBefore(status,footer);else modal.appendChild(status);
      }
      status.hidden=false;
      status.textContent='Guardando. Espera la confirmación; no necesitas volver a pulsar.';
    }
    var timer=setTimeout(function(){if(status)status.textContent='La conexión está demorando. El guardado sigue en curso; no cierres ni recargues esta ficha.';},8000);
    op.promise=Promise.resolve().then(work).finally(function(){
      clearTimeout(timer);
      controls.forEach(function(item){item.el.disabled=item.disabled;});
      if(button)button.textContent=oldText;
      if(modal)modal.removeAttribute('aria-busy');
      if(status){status.textContent='';status.hidden=true;}
      delete operations[key];
    });
    return op.promise;
  }
  root.CarteraSaveGuard={run:run,busy:busy,canClose:canClose,complete:complete};
})(window);
