// Cambia solo el catalogo del proyecto; no reescribe cotizaciones ni reservas historicas.
let projectImportPid = '';
let projectImportPending = null;
let projectImportSaving = false;
let projectImportReadId = 0;

function projectSheetKey(v) { return String(v ?? '').trim().toLocaleLowerCase('es-CL'); }
function projectSheetNumber(raw, label, row) {
  if (raw === '' || raw == null) throw new Error(`Fila ${row}: falta ${label}.`);
  let value = raw;
  if (typeof value !== 'number') {
    value = String(value).trim().replace(/\s/g, '');
    if (value.includes(',')) value = value.replace(/\./g, '').replace(',', '.');
    else if (/^\d{1,3}(\.\d{3})+$/.test(value)) value = value.replace(/\./g, '');
    value = Number(value);
  }
  if (!Number.isFinite(value) || value < 0) throw new Error(`Fila ${row}: ${label} debe ser un número válido mayor o igual a cero.`);
  return value;
}

function descargarExcelProyecto(pid) {
  const p = DB[pid];
  if (!p || !window.XLSX) { showToast('No se pudo preparar el Excel.'); return; }
  const rows = [
    ['ACTUALIZACIÓN DE UN PROYECTO · COTIZADOR'], ['Proyecto', p.nombre],
    ['Lote actual identifica el existente; déjalo vacío para agregar uno nuevo.'],
    ['Al cargar eliges actualizar los incluidos o reemplazar todo el catálogo.'],
    ['Lote actual','Lote nuevo','Mts total','Servidumbre','Mts útiles','Moneda','Precio de lista']
  ];
  Object.entries(p.lotes || {}).forEach(([name,lot]) => {
    if (lot && typeof lot === 'object') rows.push([name,name,Number(lot.mts||0),Number(lot.servidumbre||0),Number(lot.utiles||0),lot.moneda||'UF',Number(lot.precio||0)]);
  });
  const sheet = XLSX.utils.aoa_to_sheet(rows);
  sheet['!cols'] = [{wch:22},{wch:24},{wch:17},{wch:18},{wch:17},{wch:14},{wch:20}];
  sheet['!merges'] = [{s:{r:0,c:0},e:{r:0,c:6}},{s:{r:2,c:0},e:{r:2,c:6}},{s:{r:3,c:0},e:{r:3,c:6}}];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb,sheet,'Lotes');
  XLSX.writeFile(wb,`Actualizar_${String(p.nombre||'Proyecto').replace(/[\\/:*?"<>|]/g,'_').slice(0,70)}.xlsx`);
}

function descargarPDFProyecto(pid) {
  const project=DB[pid];
  if(!project){showToast('No se encontró el proyecto.');return;}
  const headers=['Lote','Mts total','Servidumbre','Mts útiles','Moneda','Precio de lista'];
  const rows=Object.entries(project.lotes||{}).filter(([,lot])=>lot&&typeof lot==='object').map(([name,lot])=>[
    name,Number(lot.mts||0),Number(lot.servidumbre||0),Number(lot.utiles||0),lot.moneda||'UF',Number(lot.precio||0)
  ]);
  downloadTablePDF({title:'Lotes · '+project.nombre,filename:'Lotes_'+String(project.nombre||'Proyecto').replace(/[^\w-]+/g,'_').slice(0,60)+'.pdf',headers,rows});
}

function cerrarVistaPreviaProyecto() {
  projectImportReadId++;
  projectImportPending = null;
  const preview = document.getElementById('projectImportPreview');
  if (preview) { preview.style.display = 'none'; preview.innerHTML = ''; delete preview.dataset.status; }
}

function mostrarEstadoExcelProyecto(message,status) {
  const preview=document.getElementById('projectImportPreview');
  if(!preview)return;
  const titles={loading:'Procesando Excel',error:'No se pudo cargar el Excel',success:'Proyecto actualizado',warning:'Proyecto guardado'};
  preview.dataset.status=status;
  preview.innerHTML=`<strong>${titles[status]}</strong><p role="${status==='error'?'alert':'status'}">${escHTML(message)}</p>
    <div class="project-import-actions">
      ${status==='error'?'<button type="button" class="project-sheet-btn" onclick="elegirExcelProyecto(projectImportPid)">Elegir otro Excel</button>':''}
      <button type="button" class="project-sheet-btn" onclick="cerrarVistaPreviaProyecto()">${status==='loading'?'Cancelar':'Cerrar'}</button>
    </div>`;
  preview.style.display='block';
  preview.scrollIntoView({block:'nearest'});
}

function describirCambiosExcelProyecto(pending) {
  const fields=[['mts','Superficie total','area'],['servidumbre','Servidumbre','area'],['utiles','Superficie útil','area'],['moneda','Moneda','text'],['precio','Precio de lista','price']];
  function present(value,type,currency) {
    if(value===null||value===undefined||value==='')return 'Sin dato';
    if(type==='text')return String(value);
    const number=Number(value);
    if(!Number.isFinite(number))return String(value);
    const text=number.toLocaleString('es-CL',{maximumFractionDigits:20});
    if(type==='area')return text+' m²';
    return currency==='UF'?text+' UF':'$'+text+' '+(currency||'CLP');
  }
  const included=new Set(pending.entries.filter(item=>item.oldName).map(item=>projectSheetKey(item.oldName)));
  const lots=pending.entries.map(item=>{
    const current=item.oldName?pending.expected.lotes[item.oldName]:null;
    const changes=[];
    if(current&&item.oldName!==item.newName)changes.push({field:'nombre',label:'Nombre del lote',before:item.oldName,after:item.newName});
    fields.forEach(([field,label,type])=>{
      const before=current&&current[field],after=item.lot[field];
      const missing=before===null||before===undefined||before==='';
      const equal=type==='text'?String(before)===String(after):!missing&&Number(before)===Number(after);
      if(!current||!equal||(field==='precio'&&current.moneda!==item.lot.moneda)){
        changes.push({field,label,before:current?present(before,type,current.moneda):'No existe',after:present(after,type,item.lot.moneda)});
      }
    });
    return {oldName:item.oldName,newName:item.newName,kind:!current?'new':changes.length?'changed':'unchanged',renamed:!!current&&item.oldName!==item.newName,changes};
  });
  const omitted=Object.keys(pending.expected.lotes||{}).filter(name=>{
    const lot=pending.expected.lotes[name];
    return lot&&typeof lot==='object'&&!included.has(projectSheetKey(name));
  });
  return {lots,omitted,changed:lots.filter(lot=>lot.kind==='changed').length,unchanged:lots.filter(lot=>lot.kind==='unchanged').length,
    added:lots.filter(lot=>lot.kind==='new').length,renamed:lots.filter(lot=>lot.renamed).length};
}

function detalleCambiosExcelProyecto(detail) {
  const labels={new:'Nuevo lote',changed:'Con cambios',unchanged:'Sin cambios'};
  const rows=detail.lots.map(lot=>{
    const name=lot.oldName||lot.newName;
    const heading=`<th scope="row" rowspan="${Math.max(1,lot.changes.length)}"><span class="project-import-lot-name">${escHTML(name)}</span><span class="project-import-lot-status">${labels[lot.kind]}</span></th>`;
    if(!lot.changes.length)return `<tr class="project-import-lot-start">${heading}<td colspan="3" class="project-import-unchanged">Se conservan el nombre, las superficies, la moneda y el precio.</td></tr>`;
    return lot.changes.map((change,index)=>`<tr${index===0?' class="project-import-lot-start"':''}>${index===0?heading:''}<td>${escHTML(change.label)}</td><td class="project-import-before">${escHTML(change.before)}</td><td class="project-import-after">${escHTML(change.after)}</td></tr>`).join('');
  }).join('');
  return `<div class="project-import-detail" role="region" aria-label="Detalle de cambios por lote" tabindex="0"><table>
    <caption>Detalle de cambios por lote</caption><thead><tr><th scope="col">Lote</th><th scope="col">Campo</th><th scope="col">Valor actual</th><th scope="col">Valor del Excel</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}

function renderVistaPreviaProyecto(pending,errorMessage) {
  const preview=document.getElementById('projectImportPreview');
  const detail=describirCambiosExcelProyecto(pending);
  preview.dataset.status=errorMessage?'error':'ready';
  preview.innerHTML=`<strong>Vista previa · ${escHTML(pending.expected.nombre)}</strong>
    <p>${detail.changed} lote(s) con cambios, ${detail.unchanged} sin cambios, ${detail.added} nuevo(s) y ${detail.omitted.length} lote(s) actuales no incluidos.</p>
    <p class="project-import-note">Todavía no se ha guardado. Revisa los valores antes de confirmar. Los precios y superficies corresponden al catálogo del Cotizador.</p>
    ${detail.renamed?'<p class="project-import-rename" role="status">El Excel cambia el nombre de '+detail.renamed+' lote(s). Los nombres vinculan la disponibilidad con las reservas. Para cambiar solo precios o superficies, conserva el mismo nombre en ambas columnas.</p>':''}
    ${detalleCambiosExcelProyecto(detail)}
    ${detail.omitted.length?'<div class="project-import-omitted"><strong>Lotes no incluidos en el Excel</strong><p>'+detail.omitted.map(escHTML).join(', ')+'</p><p>“Actualizar solo incluidos” los conserva. “Reemplazar todo el catálogo” los retira del catálogo para futuras cotizaciones.</p></div>':''}
    ${errorMessage?'<p role="alert">'+escHTML(errorMessage)+'</p>':''}
    <div class="project-import-actions">
      <button type="button" class="project-sheet-btn" onclick="aplicarExcelProyecto('partial')">Actualizar solo incluidos</button>
      <button type="button" class="project-sheet-btn" onclick="aplicarExcelProyecto('replace')">Reemplazar todo el catálogo</button>
      <button type="button" class="project-sheet-btn" onclick="cerrarVistaPreviaProyecto()">Cancelar</button>
    </div>`;
  preview.style.display='block';
  preview.scrollIntoView({block:'nearest'});
}
function elegirExcelProyecto(pid) {
  if(projectImportSaving)return;
  if (!DB[pid]) return;
  projectImportPid = pid;
  cerrarVistaPreviaProyecto();
  const input = document.getElementById('projectExcelInput');
  input.value = '';
  input.click();
}

function validarExcelProyecto(rows,pid) {
  const project = DB[pid];
  if (!project) throw new Error('El proyecto ya no está disponible.');
  const sheetProject = String(rows[1]?.[1] || '').trim();
  if (projectSheetKey(sheetProject) !== projectSheetKey(project.nombre))
    throw new Error(`El Excel indica “${sheetProject || '(sin proyecto)'}”, pero seleccionaste “${project.nombre}”. Revisa la celda B2.`);
  const headers = ['Lote actual','Lote nuevo','Mts total','Servidumbre','Mts útiles','Moneda','Precio de lista'];
  if (headers.some((h,i) => projectSheetKey(rows[4]?.[i]) !== projectSheetKey(h)))
    throw new Error('Las columnas no corresponden a la plantilla. Conserva la fila de encabezados.');
  const existing = project.lotes || {};
  const existingByKey = new Map(Object.keys(existing).filter(k => existing[k] && typeof existing[k] === 'object').map(k => [projectSheetKey(k),k]));
  const entries = [], seenOld = new Set(), seenNew = new Set();
  for (let i=5;i<rows.length;i++) {
    const cells = rows[i] || [];
    if (!cells.some(v => String(v ?? '').trim() !== '')) continue;
    const line = i+1;
    let oldName = String(cells[0] ?? '').trim();
    const newName = String(cells[1] ?? '').trim();
    if (!newName) throw new Error(`Fila ${line}: falta Lote nuevo.`);
    if (newName.length > 120) throw new Error(`Fila ${line}: el nombre del lote es demasiado largo.`);
    if (['__proto__','prototype','constructor'].includes(projectSheetKey(newName)))
      throw new Error(`Fila ${line}: ese nombre de lote no está permitido.`);
    if (!oldName && existingByKey.has(projectSheetKey(newName))) oldName = existingByKey.get(projectSheetKey(newName));
    if (oldName) {
      const canonical = existingByKey.get(projectSheetKey(oldName));
      if(!canonical&&projectSheetKey(oldName)===projectSheetKey(newName)){
        // Al copiar una fila para agregar un lote, ambas columnas pueden
        // contener el mismo nombre nuevo. No representa un cambio de nombre.
        oldName='';
      }else{
        if (!canonical) throw new Error(`Fila ${line}: “${oldName}” no existe como lote actual.`);
        oldName = canonical;
        if (seenOld.has(projectSheetKey(oldName))) throw new Error(`Fila ${line}: el lote actual “${oldName}” se repite.`);
        seenOld.add(projectSheetKey(oldName));
      }
    }
    if (seenNew.has(projectSheetKey(newName))) throw new Error(`Fila ${line}: el lote nuevo “${newName}” se repite.`);
    seenNew.add(projectSheetKey(newName));
    const mts = projectSheetNumber(cells[2],'Mts total',line);
    const servidumbre = projectSheetNumber(cells[3],'Servidumbre',line);
    const utiles = projectSheetNumber(cells[4],'Mts útiles',line);
    const moneda = String(cells[5] ?? '').trim().toUpperCase();
    if (moneda !== 'CLP' && moneda !== 'UF') throw new Error(`Fila ${line}: Moneda debe ser CLP o UF.`);
    const precio = projectSheetNumber(cells[6],'Precio de lista',line);
    if (servidumbre > mts || utiles > mts) throw new Error(`Fila ${line}: Servidumbre y Mts útiles no pueden superar Mts total.`);
    entries.push({oldName,newName,lot:{mts,servidumbre,utiles,moneda,precio}});
    if (entries.length > 1000) throw new Error('El Excel supera el máximo de 1000 lotes.');
  }
  if (!entries.length) throw new Error('El Excel no contiene lotes; no se hará ningún cambio.');
  return {pid,expected:JSON.parse(JSON.stringify(project)),entries,omitted:existingByKey.size-seenOld.size};
}

function leerExcelProyecto(input) {
  if(projectImportSaving)return;
  const file = input.files?.[0];
  if (!file) return;
  cerrarVistaPreviaProyecto();
  if (!/\.xlsx?$/i.test(file.name)) { mostrarEstadoExcelProyecto('Selecciona un archivo Excel .xlsx o .xls.','error'); return; }
  if (file.size > 2*1024*1024) { mostrarEstadoExcelProyecto('El Excel supera el máximo de 2 MB.','error'); return; }
  const pid = projectImportPid;
  const readId=++projectImportReadId;
  mostrarEstadoExcelProyecto('Leyendo '+file.name+'…','loading');
  const reader = new FileReader();
  reader.onerror = () => {
    if(readId===projectImportReadId)mostrarEstadoExcelProyecto('No se pudo leer el archivo Excel. Comprueba que esté descargado en este equipo e inténtalo nuevamente.','error');
  };
  reader.onload = event => {
    if(readId!==projectImportReadId)return;
    try {
      if(!window.XLSX)throw new Error('La herramienta de Excel todavía no está disponible. Actualiza la página e inténtalo nuevamente.');
      const wb = XLSX.read(new Uint8Array(event.target.result),{type:'array'});
      const sheet = wb.Sheets.Lotes || wb.Sheets[wb.SheetNames[0]];
      if (!sheet) throw new Error('El Excel no contiene una hoja de lotes.');
      const pending = validarExcelProyecto(XLSX.utils.sheet_to_json(sheet,{header:1,raw:true,defval:''}),pid);
      projectImportPending = pending;
      renderVistaPreviaProyecto(pending);
    } catch(error) { projectImportPending=null; mostrarEstadoExcelProyecto(error.message,'error'); }
  };
  try{reader.readAsArrayBuffer(file);}
  catch(error){mostrarEstadoExcelProyecto('No se pudo abrir el archivo Excel. Selecciónalo nuevamente.','error');}
}

function prepararCambioExcelProyecto(pending,mode) {
  const lotes = mode === 'replace' ? {} : {...pending.expected.lotes};
  pending.entries.forEach(item => { if (item.oldName) delete lotes[item.oldName]; });
  const occupied = new Set(Object.keys(lotes).map(projectSheetKey));
  pending.entries.forEach(item => {
    const key = projectSheetKey(item.newName);
    if (occupied.has(key)) throw new Error(`“${item.newName}” ya existe en un lote no incluido. Inclúyelo también o reemplaza todo.`);
    occupied.add(key);
    lotes[item.newName] = item.lot;
  });
  return {...pending.expected,lotes};
}

async function aplicarExcelProyecto(mode) {
  if (projectImportSaving || !projectImportPending || !['partial','replace'].includes(mode)) return;
  const pending = projectImportPending;
  if (JSON.stringify(DB[pending.pid]) !== JSON.stringify(pending.expected)) {
    projectImportPending=null;
    mostrarEstadoExcelProyecto('El proyecto cambió. Descarga el Excel actualizado y vuelve a intentar.','error');return;
  }
  let next;
  try { next = prepararCambioExcelProyecto(pending,mode); }
  catch(error) { renderVistaPreviaProyecto(pending,error.message); return; }
  if (mode === 'replace' && pending.omitted > 0 &&
      !confirm(`Se retirarán ${pending.omitted} lote(s) no incluidos del catálogo para futuras cotizaciones. ¿Continuar?`)) return;
  if (!window._fbActualizarProyectoCotizador) { renderVistaPreviaProyecto(pending,'No está disponible la conexión para guardar. Actualiza la página e inténtalo nuevamente.'); return; }
  projectImportSaving = true;
  const preview = document.getElementById('projectImportPreview');
  preview.querySelectorAll('button').forEach(button => { button.disabled=true; });
  preview.querySelector('strong').textContent='Guardando '+pending.expected.nombre+'…';
  let config;
  try {
    config = await window._fbActualizarProyectoCotizador(pending.pid,pending.expected,next);
  } catch(error) {
    console.error('Error actualizando proyecto desde Excel:',error);
    renderVistaPreviaProyecto(pending,error?.message === 'PROJECT_CHANGED'
      ? 'Otra persona cambió este proyecto. Descarga el Excel actualizado y vuelve a intentar.'
      : 'No se pudo guardar el proyecto. Puedes reintentar con los botones de abajo.');
    projectImportSaving=false;
    return;
  }
  try {
    aplicarConfigCentral(config);
    pending.entries.forEach(item => syncLoteToGestionCartera(next.nombre,item.newName));
    if (typeof saveState === 'function') saveState();
    refreshCotizadorProySelect();
    mostrarEstadoExcelProyecto(`${pending.entries.length} lote(s) procesados en ${next.nombre}.`,'success');
  } catch(error) {
    console.error('El proyecto se guardó pero falló la actualización de la pantalla:',error);
    mostrarEstadoExcelProyecto('El proyecto se guardó. Recarga la página para ver los cambios.','warning');
  } finally {
    projectImportPending=null;
    projectImportSaving=false;
  }
}
