(function initCotizadorGestionSso() {
  'use strict';

  var originalMostrarLogin = typeof mostrarLogin === 'function' ? mostrarLogin : null;
  var originalEnterAppWithProfile = typeof enterAppWithProfile === 'function' ? enterAppWithProfile : null;
  var originalSetTab = typeof setTab === 'function' ? setTab : null;
  var originalRefreshProyectos = typeof refreshProyectosPorEjecutivo === 'function' ? refreshProyectosPorEjecutivo : null;
  var originalAplicarConfigCentral = typeof aplicarConfigCentral === 'function' ? aplicarConfigCentral : null;
  var originalSellerCanView = typeof sellerCanViewIntegratedTab === 'function' ? sellerCanViewIntegratedTab : null;
  var originalGuardarCotizacion = typeof guardarCotizacion === 'function' ? guardarCotizacion : null;
  var originalGuardarYCompartir = typeof guardarYCompartir === 'function' ? guardarYCompartir : null;
  var originalDoLogout = typeof doLogout === 'function' ? doLogout : null;
  var originalCloseAdmin = typeof closeAdmin === 'function' ? closeAdmin : null;

  function normalize(value) {
    return String(value || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, ' ')
      .trim();
  }

  function compact(value) {
    return normalize(value).replace(/\s+/g, '');
  }

  function userKey(user) {
    user = user || {};
    return String(user.uid || user.id || user.email || user.user || user.nombre || 'usuario');
  }

  function isGestionAdmin(user) {
    if (!user) return false;
    if (typeof getRoleKey === 'function' && getRoleKey(user) === 'Administrador') return true;
    return normalize(user.rol) === 'administrador';
  }

  function userAliases(user) {
    user = user || {};
    var email = String(user.email || '').split('@')[0];
    var values = [user.uid, user.id, user.email, email, user.user, user.nombre];
    var aliases = [];
    values.forEach(function(value) {
      var alias = compact(value);
      if (alias && aliases.indexOf(alias) < 0) aliases.push(alias);
    });
    return aliases;
  }

  function sellerAliases(seller) {
    seller = seller || {};
    return [seller.gestionUid, seller.gestionUserId, seller.email, seller.user, seller.id, seller.nombre]
      .map(compact)
      .filter(Boolean);
  }

  function findCotizadorSeller(user) {
    var sellers = typeof VENDEDORES_DB !== 'undefined' && Array.isArray(VENDEDORES_DB)
      ? VENDEDORES_DB
      : [];
    var aliases = userAliases(user);
    var normalizedName = compact(user && user.nombre);

    return sellers.find(function(seller) {
      var candidateAliases = sellerAliases(seller);
      if (candidateAliases.some(function(candidate) { return aliases.indexOf(candidate) >= 0; })) return true;

      var candidateName = compact(seller.nombre);
      return !!candidateName && !!normalizedName && (
        candidateName === normalizedName ||
        (candidateName.length >= 5 && normalizedName.indexOf(candidateName) >= 0) ||
        (normalizedName.length >= 5 && candidateName.indexOf(normalizedName) >= 0)
      );
    }) || null;
  }

  function makeCotizadorSession(user) {
    var matched = findCotizadorSeller(user);
    var stableKey = compact(userKey(user)).slice(0, 48) || 'usuario';
    var session = matched ? Object.assign({}, matched) : {
      id: 'GC_' + stableKey,
      nombre: String(user.nombre || user.user || user.email || 'Usuario de Gestion'),
      cargo: String(user.rol || 'Vendedor')
    };

    session.nombre = String(session.nombre || user.nombre || 'Usuario de Gestion');
    session.cargo = String(session.cargo || user.rol || 'Vendedor');
    session.gestionUid = String(user.uid || '');
    session.gestionUserId = String(user.id || '');
    session.email = String(user.email || session.email || '');
    session._gestionSso = true;
    session._gestionSsoKey = userKey(user);
    session._sinAsignacionCotizador = !matched;
    return session;
  }

  function hideCotizadorLogin() {
    ['loginOverlay', 'pinOverlay'].forEach(function(id) {
      var overlay = document.getElementById(id);
      if (!overlay) return;
      overlay.classList.remove('open');
      overlay.style.cssText = 'display:none!important';
    });
    if (typeof finalizarArranqueVisual === 'function') finalizarArranqueVisual();
  }

  function syncSessionHeader(session) {
    var info = document.getElementById('sessionInfo');
    var name = document.getElementById('sessionName');
    var logout = info && info.querySelector('.btn-logout');
    if (info) info.classList.add('active');
    if (name) name.textContent = session.nombre + ' - sesion de Gestion';
    if (logout) logout.style.display = 'none';
  }

  function assignedProjectIds(user, session) {
    var projects = typeof DB !== 'undefined' && DB ? DB : {};
    var ids = Object.keys(projects);
    if (isGestionAdmin(user)) return ids;
    var assignments = typeof ASIG_DB !== 'undefined' && ASIG_DB ? ASIG_DB : {};
    var allowed = ids.filter(function(projectId) {
      if (!session || session._sinAsignacionCotizador) return false;
      var assigned = Array.isArray(assignments[projectId]) ? assignments[projectId] : [];
      return assigned.indexOf(session.id) >= 0;
    });
    var editing = typeof _cotizacionEditandoAdmin !== 'undefined' ? _cotizacionEditandoAdmin : null;
    if (editing && typeof puedeEditarCotizacionVentas === 'function' && puedeEditarCotizacionVentas(editing)) {
      var originalId = buscarProyectoPorNombre(editing.proyecto);
      if (originalId && allowed.indexOf(originalId) < 0) allowed.push(originalId);
    }
    return allowed;
  }

  function populateVisibleProjects() {
    var select = document.getElementById('proyecto');
    if (!select || typeof DB === 'undefined') return;
    var current = select.value;
    var user = typeof currentUser !== 'undefined' ? currentUser : null;
    var session = typeof _sesionActiva !== 'undefined' ? _sesionActiva : null;
    var projectIds = assignedProjectIds(user, session);
    var emptyLabel = projectIds.length ? 'Seleccionar' : 'Sin proyectos asignados';
    select.innerHTML = '<option value="">' + emptyLabel + '</option>';
    projectIds.forEach(function(projectId) {
      var option = document.createElement('option');
      option.value = projectId;
      option.textContent = DB[projectId] && DB[projectId].nombre ? DB[projectId].nombre : projectId;
      select.appendChild(option);
    });
    var currentStillExists = Array.prototype.some.call(select.options || [], function(option) {
      return option.value === current;
    });
    select.value = current && currentStillExists ? current : '';
    if (typeof actualizarVendedorProyecto === 'function') actualizarVendedorProyecto();
  }

  function selectedProjectIsAllowed() {
    var user = typeof currentUser !== 'undefined' ? currentUser : null;
    if (!user) return true;
    var select = document.getElementById('proyecto');
    var projectId = select ? String(select.value || '') : '';
    var session = typeof _sesionActiva !== 'undefined' ? _sesionActiva : null;
    return !!projectId && assignedProjectIds(user, session).indexOf(projectId) >= 0;
  }

  function guardAssignedProject() {
    if (selectedProjectIsAllowed()) return true;
    if (typeof showToast === 'function') showToast('Este proyecto no esta asignado a tu perfil del Cotizador');
    return false;
  }

  function applyGestionSession(force) {
    if (typeof currentUser === 'undefined' || !currentUser) return false;

    var key = userKey(currentUser);
    if (!force && typeof _sesionActiva !== 'undefined' && _sesionActiva && _sesionActiva._gestionSsoKey === key) {
      if (typeof _adminAutorizado !== 'undefined') _adminAutorizado = isGestionAdmin(currentUser);
      hideCotizadorLogin();
      syncSessionHeader(_sesionActiva);
      if (typeof syncCotizadorAdminShortcut === 'function') syncCotizadorAdminShortcut();
      return true;
    }

    _sesionActiva = makeCotizadorSession(currentUser);
    var isAdmin = isGestionAdmin(currentUser);
    if (typeof _adminAutorizado !== 'undefined') _adminAutorizado = isAdmin;

    hideCotizadorLogin();
    syncSessionHeader(_sesionActiva);
    if (typeof actualizarAccesoAdminHeader === 'function') actualizarAccesoAdminHeader();
    if (typeof syncCotizadorAdminShortcut === 'function') syncCotizadorAdminShortcut();
    if (typeof refreshProyectosPorEjecutivo === 'function') refreshProyectosPorEjecutivo();
    if (typeof cargarRegistro === 'function') cargarRegistro();
    if (typeof adjustContentPadding === 'function') adjustContentPadding();
    document.body.classList.add('cotizador-gestion-sso');
    return true;
  }

  window.cotizadorGestionSso = {
    apply: applyGestionSession,
    findSeller: findCotizadorSeller,
    makeSession: makeCotizadorSession,
    normalize: normalize,
    status: function() {
      return {
        active: typeof _sesionActiva !== 'undefined' && !!_sesionActiva,
        session: typeof _sesionActiva !== 'undefined' && _sesionActiva ? Object.assign({}, _sesionActiva) : null,
        adminAuthorized: typeof _adminAutorizado !== 'undefined' && !!_adminAutorizado,
        visibleProjectIds: assignedProjectIds(
          typeof currentUser !== 'undefined' ? currentUser : null,
          typeof _sesionActiva !== 'undefined' ? _sesionActiva : null
        )
      };
    }
  };

  if (originalSellerCanView) {
    sellerCanViewIntegratedTab = function(name, user) {
      if ((name === 'ventas' || name === 'cotizaciones-ventas') && user && typeof vistaPermiso === 'function') {
        return !!vistaPermiso(name, 'ver', user);
      }
      return originalSellerCanView(name, user);
    };
  }

  if (originalRefreshProyectos) {
    refreshProyectosPorEjecutivo = function() {
      if (typeof currentUser === 'undefined' || !currentUser) return originalRefreshProyectos.apply(this, arguments);
      populateVisibleProjects();
    };
  }

  if (originalGuardarCotizacion) {
    guardarCotizacion = function() {
      if (!guardAssignedProject()) return Promise.resolve(false);
      return originalGuardarCotizacion.apply(this, arguments);
    };
  }

  if (originalGuardarYCompartir) {
    guardarYCompartir = function() {
      if (!guardAssignedProject()) return Promise.resolve(false);
      return originalGuardarYCompartir.apply(this, arguments);
    };
  }

  if (originalMostrarLogin) {
    mostrarLogin = function() {
      if (applyGestionSession(false)) return;
      return originalMostrarLogin.apply(this, arguments);
    };
  }

  if (originalEnterAppWithProfile) {
    enterAppWithProfile = function(firebaseUser, profile) {
      var result = originalEnterAppWithProfile.apply(this, arguments);
      setTimeout(function() { applyGestionSession(true); }, 0);
      return result;
    };
  }

  if (originalSetTab) {
    setTab = function(name, button) {
      if (name === 'ventas' || name === 'cotizaciones-ventas') applyGestionSession(false);
      return originalSetTab.apply(this, arguments);
    };
  }

  if (originalAplicarConfigCentral) {
    aplicarConfigCentral = function(config) {
      var result = originalAplicarConfigCentral.apply(this, arguments);
      setTimeout(function() { applyGestionSession(true); }, 0);
      return result;
    };
  }

  if (originalCloseAdmin) {
    closeAdmin = function() {
      var result = originalCloseAdmin.apply(this, arguments);
      if (typeof currentUser !== 'undefined' && isGestionAdmin(currentUser)) applyGestionSession(false);
      return result;
    };
  }

  if (originalDoLogout) {
    doLogout = function() {
      if (typeof _sesionActiva !== 'undefined') _sesionActiva = null;
      if (typeof _adminAutorizado !== 'undefined') _adminAutorizado = false;
      document.body.classList.remove('cotizador-gestion-sso');
      hideCotizadorLogin();
      return originalDoLogout.apply(this, arguments);
    };
  }

  if (typeof cerrarSesion === 'function') {
    cerrarSesion = function() {
      if (typeof doLogout === 'function') doLogout();
    };
  }

  document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() { applyGestionSession(false); }, 0);
  });
})();
