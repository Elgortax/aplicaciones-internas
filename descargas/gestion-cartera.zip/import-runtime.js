(function(){
  'use strict';

  var seq=0;
  var activeJob=null;
  var readyJobs={desist:null,rescil:null,conciliacion:null};
  var baseConfirmConciliacion=window.confirmConciliacionImport;
  var baseRenderSpecialImportPreview=window.renderSpecialImportPreview;

  var configs={
    desist:{
      inputId:'desist-import-file',previewId:'desist-import-preview',actionsId:'desist-import-actions',countId:'desist-import-count',
      dropzoneId:'dropzone-desist',label:'Histórico de Desistimientos',shortLabel:'Desistimientos'
    },
    rescil:{
      inputId:'rescil-import-file',previewId:'rescil-import-preview',actionsId:'rescil-import-actions',countId:'rescil-import-count',
      dropzoneId:'dropzone-rescil-imp',label:'Solicitudes de Resciliación',shortLabel:'Aprobación de resciliaciones'
    },
    conciliacion:{
      inputId:'concimp-import-file',previewId:'concimp-preview',actionsId:'concimp-actions',countId:'concimp-count',
      dropzoneId:'dropzone-concimp',label:'Plan de Pago / Conciliaciones',shortLabel:'Conciliaciones'
    }
  };

  function safeEsc(value){
    if(typeof esc==='function')return esc(value);
    return String(value||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function formatMoney(value){
    if(typeof fmtClp==='function')return fmtClp(value);
    return '$ '+new Intl.NumberFormat('es-CL',{maximumFractionDigits:2}).format(parseFloat(value)||0);
  }

  function cloneJson(value){
    return JSON.parse(JSON.stringify(value));
  }

  function importHeaderKey(value){
    return String(value===undefined||value===null?'':value)
      .replace(/\uFEFF/g,'')
      .replace(/dep\uFFFDsito/gi,'deposito')
      .replace(/cotizaci\uFFFDn/gi,'cotizacion')
      .replace(/inter\uFFFDs/gi,'interes')
      .replace(/observaci\uFFFDn/gi,'observacion')
      .replace(/^n\uFFFD(?=\s|$)/i,'n ')
      .replace(/\uFFFD/g,'')
      .replace(/[º°]/g,' ')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g,'')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g,' ')
      .trim();
  }

  function canonicalPaymentMethod(value){
    var original=String(value===undefined||value===null?'':value).trim();
    var normalized=typeof normalizeLookupText==='function'?normalizeLookupText(original):importHeaderKey(original);
    var aliases={
      'transferencia':'Transferencia Electrónica',
      'transferencia electronica':'Transferencia Electrónica',
      'transferencia bancaria':'Transferencia Electrónica',
      'tef':'Transferencia Electrónica',
      'deposito':'Depósito',
      'deposito bancario':'Depósito',
      'efectivo':'Efectivo',
      'cheque':'Cheque',
      'tarjeta debito':'Tarjeta Débito',
      'debito':'Tarjeta Débito',
      'tarjeta credito':'Tarjeta Crédito',
      'credito':'Tarjeta Crédito',
      'vale vista':'Vale Vista',
      'valevista':'Vale Vista',
      'otro':'Otro'
    };
    var result=aliases[normalized]||original;
    if(result&&typeof CC_MEDIO_PAGO_OPTS!=='undefined'&&Array.isArray(CC_MEDIO_PAGO_OPTS)&&CC_MEDIO_PAGO_OPTS.indexOf(result)<0){
      CC_MEDIO_PAGO_OPTS.push(result);
    }
    return result;
  }

  function identifierText(value){
    if(value===undefined||value===null)return '';
    if(typeof value==='number'&&Number.isFinite(value))return Number.isSafeInteger(value)?value.toFixed(0):String(value);
    var text=String(value).trim();
    if(/^[+-]?\d+(?:[.,]\d+)?e[+-]?\d+$/i.test(text)){
      var numeric=Number(text.replace(',','.'));
      if(Number.isFinite(numeric)&&Number.isSafeInteger(numeric))return numeric.toFixed(0);
    }
    return text;
  }

  function splitBankDocument(bank,documentNumber,combined){
    var result={banco:String(bank||'').trim(),documento:identifierText(documentNumber)};
    var source=String(combined||'').trim();
    if(!source&&!result.banco&&/[—–|]|\s\/\s/.test(result.documento))source=result.documento;
    if(source){
      var parts=source.split(/\s*(?:—|–|\|)\s*|\s+\/\s+/).filter(Boolean);
      if(parts.length>1){
        if(!result.banco)result.banco=parts.shift().trim();
        if(!result.documento)result.documento=identifierText(parts.join(' - '));
      }else if(!result.banco&&!result.documento){
        result.banco=source;
      }
    }
    return result;
  }

  function buildImportedAccountingDetail(row,col,colRaw,parseDate,fila,issues){
    var detail=buildDetalleFromRow(row,col,colRaw,parseDate,fila,issues)||{};
    detail.medioPago=canonicalPaymentMethod(detail.medioPago||col(row,[
      'Forma de Pago','Forma Pago','Tipo de Pago','Método de Pago','Metodo de Pago'
    ]));
    var combined=col(row,[
      'Banco / N° Documento','Banco / Nº Documento','Banco / Nro Documento',
      'Banco y N° Documento','Banco y Nro Documento','Banco - N° Documento'
    ]);
    var paymentRef=splitBankDocument(
      detail.banco||col(row,['Nombre Banco','Banco Pago','Banco de Pago']),
      detail.nroDocumento||colRaw(row,[
        'Número Documento','Numero Documento','N° Doc','Nro Doc','Documento',
        'N° Operación','Nro Operación','Nro Operacion','Número Operación','Numero Operacion',
        'N° Transferencia','Nro Transferencia','Código Transacción','Codigo Transaccion','Comprobante'
      ]),
      combined
    );
    detail.banco=paymentRef.banco;
    detail.nroDocumento=paymentRef.documento;
    if(!detail.fechaDeposito)detail.fechaDeposito=parseDate(colRaw(row,[
      'Fecha de Depósito','Fecha de Deposito','Fecha Pago','Fecha de Pago','F. Pago','Fecha Abono'
    ]));
    if(!detail.nroCuentaCliente)detail.nroCuentaCliente=identifierText(colRaw(row,[
      'Número Cuenta Cliente','Numero Cuenta Cliente','Cuenta Cliente','Cuenta de Origen','Cuenta Origen','N° Cuenta'
    ]));
    else detail.nroCuentaCliente=identifierText(detail.nroCuentaCliente);
    if(!detail.rutPago)detail.rutPago=col(row,['RUT Pagador','Rut Pagador','RUT Titular','Rut Titular','RUT de Pago']);
    if(!detail.titularPago)detail.titularPago=col(row,['Titular del Pago','Nombre Titular','Nombre Pagador','Pagador']);
    return detail;
  }

  function moneyMinor(value){
    var number=typeof value==='number'?value:parseFloat(value);
    return Number.isFinite(number)?Math.round(number*100):NaN;
  }

  function moneyFromMinor(value){
    return value/100;
  }

  function parseMoneyImport(value,preservePrecision){
    if(typeof value==='number'){
      if(!Number.isFinite(value))return {valid:false,value:0,minor:0};
      var numericMinor=moneyMinor(value);
      return {valid:true,value:preservePrecision?value:moneyFromMinor(numericMinor),minor:numericMinor};
    }
    if(value===undefined||value===null||String(value).trim()==='')return {valid:false,value:0,minor:0};
    var source=String(value).trim();
    var negative=/^\s*-/.test(source)||/^\s*\(.*\)\s*$/.test(source);
    var clean=source.replace(/[^\d.,]/g,'');
    if(!/\d/.test(clean))return {valid:false,value:0,minor:0};
    var comma=clean.lastIndexOf(',');
    var dot=clean.lastIndexOf('.');
    var decimal='';
    if(comma>=0&&dot>=0){
      decimal=comma>dot?',':'.';
    }else{
      var separator=comma>=0?',':(dot>=0?'.':'');
      if(separator){
        var parts=clean.split(separator);
        var tail=parts[parts.length-1];
        var allThousands=parts.length>1&&parts.slice(1).every(function(part){return part.length===3;});
        if(!allThousands||tail.length<=2)decimal=separator;
      }
    }
    var normalized;
    if(decimal){
      var decimalIndex=clean.lastIndexOf(decimal);
      normalized=clean.slice(0,decimalIndex).replace(/[.,]/g,'')+'.'+clean.slice(decimalIndex+1).replace(/[.,]/g,'');
    }else normalized=clean.replace(/[.,]/g,'');
    var parsed=Number(normalized);
    if(!Number.isFinite(parsed))return {valid:false,value:0,minor:0};
    if(negative)parsed=-parsed;
    var minor=moneyMinor(parsed);
    return {valid:true,value:preservePrecision?parsed:moneyFromMinor(minor),minor:minor};
  }

  var conceptLabels={reserva:'Reserva',contraPromesa:'Contra Promesa',contraEscritura:'Contra Escritura',pieDiferido:'Pie diferido',diferidas:'Cuota diferida',cuotas:'Cuota'};

  function planLineRefs(plan){
    var refs=[];
    ['reserva','contraPromesa','pieDiferido','diferidas','cuotas','contraEscritura'].forEach(function(tipo){
      if(tipo==='pieDiferido'||tipo==='diferidas'||tipo==='cuotas'){
        (plan[tipo]&&plan[tipo].rows||[]).forEach(function(data,idx){refs.push({tipo:tipo,idx:idx,data:data});});
      }else if(plan[tipo])refs.push({tipo:tipo,idx:null,data:plan[tipo]});
    });
    return refs;
  }

  // Los totales son una vista de las partidas originales, nunca nuevas deudas.
  // Cada partida conserva su monto abonado, vencimiento y documento propios.
  function groupConceptRows(rows){
    var groups=[],index=new Map();
    (rows||[]).forEach(function(row,position){
      var meta=row.importConcept;
      var key=meta&&meta.numeroCuota?JSON.stringify([row.registroId,meta.tipo,meta.numeroCuota,meta.moneda]):'line:'+position;
      var group=index.get(key);
      if(!group){
        group={key:key,label:meta?(conceptLabels[meta.tipo]+' '+meta.numeroCuota).trim():row.label,
          moneda:meta?meta.moneda:row.moneda,rows:[],montoMinor:0,monto:0,montoVenta:0,hasMontoVenta:true};
        index.set(key,group);groups.push(group);
      }
      group.rows.push(row);
      group.montoMinor+=moneyMinor(row.monto||0);
      group.monto=moneyFromMinor(group.montoMinor);
      if(!meta||meta.montoVenta===null||meta.montoVenta===undefined)group.hasMontoVenta=false;
      else group.montoVenta+=meta.montoVenta;
    });
    groups.forEach(function(group){
      group.montoVenta=group.hasMontoVenta?Number(group.montoVenta.toFixed(8)):null;
    });
    return groups;
  }

  function importedPaymentFromLine(line){
    var detail=line&&line.detalle||{};
    var amount=detail.montoAbonado;
    if(amount===undefined&&(detail.estado==='Pagado'||detail.estado==='Pagado (En confirmación)'))amount=line.monto;
    amount=parseFloat(amount)||0;
    if(amount<=0)return null;
    return {
      monto:amount,
      fecha:detail.fechaDeposito||'',
      medioPago:detail.medioPago||'',
      banco:detail.banco||'',
      nroDocumento:detail.nroDocumento||'',
      nroCuentaCliente:detail.nroCuentaCliente||'',
      rutPago:detail.rutPago||'',
      titularPago:detail.titularPago||''
    };
  }

  function mergeImportedConceptLines(lines){
    var ordered=lines.slice().sort(function(a,b){
      return ((a.importConcept&&a.importConcept.sourceRow)||0)-((b.importConcept&&b.importConcept.sourceRow)||0);
    });
    var first=cloneJson(ordered[0]);
    var amountMinor=0,montoVenta=0,montoUf=0,hasMontoVenta=true;
    var payments=[];
    ordered.forEach(function(line){
      amountMinor+=moneyMinor(line.monto||0);
      montoUf+=parseFloat(line.montoUf)||0;
      if(!line.importConcept||line.importConcept.montoVenta===undefined||line.importConcept.montoVenta===null)hasMontoVenta=false;
      else montoVenta+=parseFloat(line.importConcept.montoVenta)||0;
      var payment=importedPaymentFromLine(line);
      if(payment)payments.push(payment);
    });
    first.monto=moneyFromMinor(amountMinor);
    first.montoUf=Number(montoUf.toFixed(8));
    first.importConcept=first.importConcept||{};
    first.importConcept.montoVenta=hasMontoVenta?Number(montoVenta.toFixed(8)):null;
    first.importConcept.sourceRows=ordered.map(function(line){return line.importConcept&&line.importConcept.sourceRow;}).filter(Boolean);
    first.importConcept.sourceCount=ordered.length;
    first.detalle=cloneJson(first.detalle||{});
    first.detalle.abonos=payments;
    first.detalle.montoAbonado=moneyFromMinor(payments.reduce(function(total,payment){return total+moneyMinor(payment.monto);},0));
    return first;
  }

  // Una combinacion comercial/concepto/cuota representa una sola obligacion.
  // Los movimientos viven en detalle.abonos y la fila visible conserva los
  // datos bancarios de la primera partida del archivo.
  function consolidateImportedConcepts(plan){
    var lines=planLineRefs(plan).map(function(ref){return ref.data;}).filter(function(line){return line&&line.importConcept;});
    lines.sort(function(a,b){return ((a.importConcept&&a.importConcept.sourceRow)||0)-((b.importConcept&&b.importConcept.sourceRow)||0);});
    var grouped=[],byKey=new Map();
    lines.forEach(function(line,position){
      var meta=line.importConcept||{};
      var key=meta.numeroCuota?JSON.stringify([meta.tipo,meta.numeroCuota,meta.moneda]):'line:'+position;
      var group=byKey.get(key);
      if(!group){group=[];byKey.set(key,group);grouped.push(group);}
      group.push(line);
    });
    var merged=grouped.map(mergeImportedConceptLines);
    plan.reserva={monto:0,fecha:'',detalle:null,valorUf:0,montoUf:0};
    plan.contraPromesa={monto:0,fecha:'',detalle:null,valorUf:0,montoUf:0};
    plan.contraEscritura={monto:0,fecha:'',detalle:null,valorUf:0,montoUf:0};
    plan.pieDiferido={cantidad:0,rows:[]};
    plan.diferidas={cantidad:0,rows:[]};
    plan.cuotas={cantidad:0,rows:[]};
    var fixedCounts={reserva:0,contraPromesa:0,contraEscritura:0};
    merged.forEach(function(line){
      var type=line.importConcept.tipo;
      if(type==='reserva'||type==='contraPromesa'||type==='contraEscritura'){
        if(!fixedCounts[type])plan[type]=line;
        else{
          line.tipoOriginal=type;
          line.labelOriginal=(conceptLabels[type]+' '+(line.importConcept.numeroCuota||fixedCounts[type]+1)).trim();
          line.manual=true;
          plan.diferidas.rows.push(line);
        }
        fixedCounts[type]++;
      }else if(type==='pieDiferido')plan.pieDiferido.rows.push(line);
      else if(type==='diferidas')plan.diferidas.rows.push(line);
      else plan.cuotas.rows.push(line);
    });
    plan.pieDiferido.cantidad=plan.pieDiferido.rows.length;
    plan.diferidas.cantidad=plan.diferidas.rows.length;
    plan.cuotas.cantidad=plan.cuotas.rows.length;
    return plan;
  }

  function planConceptRows(plan){
    return planLineRefs(plan).filter(function(ref){return !!ref.data.importConcept;}).map(function(ref){
      return {registroId:plan.registroId,tipo:ref.tipo,idx:ref.idx,monto:ref.data.monto,importConcept:ref.data.importConcept};
    });
  }

  function storedConceptInfo(ref,position){
    var data=ref&&ref.data||{};
    var meta=data.importConcept||{};
    var type=meta.tipo||data.tipoOriginal||'';
    var numero=meta.numeroCuota!==undefined&&meta.numeroCuota!==null?String(meta.numeroCuota).trim():'';
    if(!numero){
      var label=String(data.labelOriginal||data.conceptoImportado||'').trim();
      var numberMatch=label.match(/(\d+)\s*$/);
      if(numberMatch)numero=numberMatch[1];
    }
    if(!numero&&(ref.tipo==='reserva'||ref.tipo==='contraPromesa'||ref.tipo==='contraEscritura')&&(!data.tipoOriginal||data.tipoOriginal===ref.tipo))numero='1';
    if(!type||!numero)return {key:'line:'+position,type:type||ref.tipo,numero:'',moneda:String(meta.moneda||data.moneda||'CLP').toUpperCase()};
    var normalizedNumber=/^\d+$/.test(numero)?String(Number(numero)):numero.toLowerCase();
    var moneda=String(meta.moneda||data.moneda||'CLP').toUpperCase();
    return {key:JSON.stringify([type,normalizedNumber,moneda]),type:type,numero:normalizedNumber,moneda:moneda};
  }

  function accountingLineForRef(cc,ref){
    if(!cc||!cc.lineas||!ref)return {};
    if(ref.tipo==='pieDiferido'||ref.tipo==='diferidas'||ref.tipo==='cuotas')return (cc.lineas[ref.tipo]&&cc.lineas[ref.tipo][ref.idx])||{};
    return cc.lineas[ref.tipo]||{};
  }

  function paymentFromAccountingLine(line){
    line=line||{};
    var amount=parseFloat(line.montoAbonado)||0;
    if(amount<=0)return null;
    return cloneAbonoForEditor({
      monto:amount,
      fecha:line.fechaDeposito||'',
      medioPago:line.medioPago||'',
      banco:line.banco||'',
      nroDocumento:line.nroDocumento||'',
      nroCuentaCliente:line.nroCuentaCliente||'',
      rutPago:line.rutPago||'',
      titularPago:line.titularPago||''
    });
  }

  function mergeStoredAccountingLines(lines,planLine){
    lines=(lines||[]).filter(Boolean);
    var first=cloneJson(lines[0]||{});
    var payments=[];
    lines.forEach(function(line){
      if(Array.isArray(line.abonos)&&line.abonos.length){
        line.abonos.forEach(function(payment){
          var normalized=cloneAbonoForEditor(payment);
          if(normalized.monto>0)payments.push(normalized);
        });
      }else{
        var payment=paymentFromAccountingLine(line);
        if(payment)payments.push(payment);
      }
    });
    first.abonos=payments;
    first.montoAbonado=moneyFromMinor(payments.reduce(function(total,payment){return total+moneyMinor(payment.monto);},0));
    if(payments.length){
      var primary=payments[0];
      first.medioPago=primary.medioPago;
      first.banco=primary.banco;
      first.nroDocumento=primary.nroDocumento;
      first.fechaDeposito=primary.fecha;
      first.nroCuentaCliente=primary.nroCuentaCliente;
      first.rutPago=primary.rutPago;
      first.titularPago=primary.titularPago;
      var obligationMinor=moneyMinor(planLine&&planLine.monto||0);
      if(obligationMinor>0&&moneyMinor(first.montoAbonado)>=obligationMinor)first.estado='Pagado';
    }
    return typeof normalizarLineaPago==='function'?normalizarLineaPago(first):first;
  }

  function rebuildStoredPlanAndAccounting(plan,cc){
    if(!plan)return false;
    var refs=planLineRefs(plan);
    var grouped=[],byKey=new Map(),hasRepeated=false;
    refs.forEach(function(ref,position){
      var info=storedConceptInfo(ref,position);
      var group=byKey.get(info.key);
      if(!group){
        group={key:info.key,info:info,refs:[],accounting:[]};
        byKey.set(info.key,group);grouped.push(group);
      }else if(info.key.indexOf('line:')!==0){
        hasRepeated=true;
      }
      group.refs.push(ref);
      group.accounting.push(accountingLineForRef(cc,ref));
    });
    if(!hasRepeated)return false;

    var beforePlanMinor=planAmountMinor(plan);
    var beforePaidMinor=grouped.reduce(function(total,group){
      return total+group.accounting.reduce(function(lineTotal,line){
        var payments=Array.isArray(line.abonos)&&line.abonos.length?line.abonos:null;
        if(payments)return lineTotal+payments.reduce(function(paymentTotal,payment){return paymentTotal+moneyMinor(payment.monto||0);},0);
        return lineTotal+moneyMinor(line.montoAbonado||0);
      },0);
    },0);

    var entries=grouped.map(function(group){
      var sourceLines=group.refs.map(function(ref,index){
        var line=cloneJson(ref.data);
        if(group.info.numero&&!line.importConcept){
          line.importConcept={
            tipo:group.info.type,
            numeroCuota:group.info.numero,
            moneda:group.info.moneda,
            montoVenta:parseFloat(line.monto)||0,
            sourceRow:index+1
          };
        }
        return line;
      });
      var merged=sourceLines.length>1?mergeImportedConceptLines(sourceLines):cloneJson(sourceLines[0]);
      return {
        key:group.key,
        line:merged,
        semanticType:group.info.type||(merged.importConcept&&merged.importConcept.tipo)||merged.tipoOriginal||group.refs[0].tipo,
        accounting:mergeStoredAccountingLines(group.accounting,merged)
      };
    });

    var next={
      reserva:{monto:0,fecha:'',detalle:null,valorUf:0,montoUf:0},
      contraPromesa:{monto:0,fecha:'',detalle:null,valorUf:0,montoUf:0},
      contraEscritura:{monto:0,fecha:'',detalle:null,valorUf:0,montoUf:0},
      pieDiferido:{cantidad:0,rows:[]},
      diferidas:{cantidad:0,rows:[]},
      cuotas:{cantidad:0,rows:[]}
    };
    var nextAccounting={reserva:{},contraPromesa:{},contraEscritura:{},pieDiferido:[],diferidas:[],cuotas:[]};
    if(cc&&cc.lineas&&cc.lineas.prontopago)nextAccounting.prontopago=cloneJson(cc.lineas.prontopago);
    next.prontopago=plan.prontopago;
    var fixedCounts={reserva:0,contraPromesa:0,contraEscritura:0};
    entries.forEach(function(entry){
      var type=entry.semanticType;
      if(type==='reserva'||type==='contraPromesa'||type==='contraEscritura'){
        if(!fixedCounts[type]){
          next[type]=entry.line;
          nextAccounting[type]=entry.accounting;
        }else{
          entry.line.tipoOriginal=type;
          entry.line.labelOriginal=(conceptLabels[type]+' '+((entry.line.importConcept&&entry.line.importConcept.numeroCuota)||fixedCounts[type]+1)).trim();
          entry.line.manual=true;
          next.diferidas.rows.push(entry.line);
          nextAccounting.diferidas.push(entry.accounting);
        }
        fixedCounts[type]++;
      }else if(type==='pieDiferido'){
        next.pieDiferido.rows.push(entry.line);
        nextAccounting.pieDiferido.push(entry.accounting);
      }else if(type==='cuotas'){
        next.cuotas.rows.push(entry.line);
        nextAccounting.cuotas.push(entry.accounting);
      }else{
        next.diferidas.rows.push(entry.line);
        nextAccounting.diferidas.push(entry.accounting);
      }
    });
    next.pieDiferido.cantidad=next.pieDiferido.rows.length;
    next.diferidas.cantidad=next.diferidas.rows.length;
    next.cuotas.cantidad=next.cuotas.rows.length;

    var afterPlanMinor=planAmountMinor(next);
    var afterPaidMinor=['reserva','contraPromesa','contraEscritura'].reduce(function(total,type){
      return total+moneyMinor(nextAccounting[type].montoAbonado||0);
    },0)+nextAccounting.pieDiferido.concat(nextAccounting.diferidas,nextAccounting.cuotas).reduce(function(total,line){
      return total+moneyMinor(line.montoAbonado||0);
    },0);
    if(beforePlanMinor!==afterPlanMinor||beforePaidMinor!==afterPaidMinor){
      console.error('No se consolidaron conceptos historicos porque los totales no coinciden.',{registroId:plan.registroId,beforePlanMinor:beforePlanMinor,afterPlanMinor:afterPlanMinor,beforePaidMinor:beforePaidMinor,afterPaidMinor:afterPaidMinor});
      return false;
    }

    plan.reserva=next.reserva;
    plan.contraPromesa=next.contraPromesa;
    plan.contraEscritura=next.contraEscritura;
    plan.diferidas=next.diferidas;
    plan.cuotas=next.cuotas;
    plan.conceptConsolidationVersion='2026-09-07.3';
    if(cc){
      cc.lineas=nextAccounting;
      cc.conceptConsolidationVersion='2026-09-07.3';
      cc.actividad=cc.actividad||[];
      cc.actividad.push({ts:typeof nowTs==='function'?nowTs():new Date().toISOString(),user:'Sistema',msg:'Conceptos repetidos consolidados; se conservaron sus abonos individuales'});
    }
    return true;
  }

  function migrateStoredImportedConcepts(){
    if(typeof state==='undefined'||!state)return 0;
    var changed=0;
    (state.conciliaciones||[]).forEach(function(plan){
      var cc=(state.conciliacionesContables||[]).find(function(item){return String(item.registroId||'')===String(plan.registroId||'');});
      if(rebuildStoredPlanAndAccounting(plan,cc))changed++;
    });
    if(changed&&typeof saveState==='function')saveState();
    return changed;
  }

  function formatMontoVenta(group){
    if(group.montoVenta===null)return '—';
    return group.moneda==='UF'?new Intl.NumberFormat('es-CL',{maximumFractionDigits:8}).format(group.montoVenta)+' UF':formatMoney(group.montoVenta);
  }

  function conceptPlanTotals(plan){
    var totals={reserva:0,contraPromesa:0,contraEscritura:0,pieDiferido:0,diferidas:0,cuotas:0,prontopago:moneyMinor(plan.prontopago&&plan.prontopago.monto||0)};
    planLineRefs(plan).forEach(function(ref){
      var tipo=ref.data.importConcept&&ref.data.importConcept.tipo||ref.data.tipoOriginal||ref.tipo;
      totals[tipo]+=moneyMinor(ref.data.monto||0);
    });
    Object.keys(totals).forEach(function(tipo){totals[tipo]=moneyFromMinor(totals[tipo]);});
    return totals;
  }

  if(typeof window.concTotales==='function'){
    var baseConcTotales=window.concTotales;
    window.concTotales=function(plan){
      var total=baseConcTotales(plan),concepts=conceptPlanTotals(plan);
      total.sumReserva=concepts.reserva;total.sumPromesa=concepts.contraPromesa;total.sumEscritura=concepts.contraEscritura;
       total.sumPieDiferido=concepts.pieDiferido;total.sumDif=concepts.diferidas;total.sumCuo=concepts.cuotas;
       ['pieDiferido','diferidas','cuotas'].forEach(function(tipo){
        var refs=planLineRefs(plan).filter(function(ref){return (ref.data.importConcept&&ref.data.importConcept.tipo||ref.data.tipoOriginal||ref.tipo)===tipo;});
         total[tipo==='pieDiferido'?'countPieDiferido':tipo==='diferidas'?'countDif':'countCuo']=groupConceptRows(refs.map(function(ref){return {registroId:plan.registroId,monto:ref.data.monto,importConcept:ref.data.importConcept};})).length;
      });
      return total;
    };
  }

  if(typeof window.renderConciliacionImportPreview==='function'){
    var baseRenderPreview=window.renderConciliacionImportPreview;
    window.renderConciliacionImportPreview=function(plans,issues){
      var summaries=plans.map(function(plan){
        var totals=conceptPlanTotals(plan),summary=Object.assign({},plan);
        ['reserva','contraPromesa','contraEscritura'].forEach(function(tipo){summary[tipo]=Object.assign({},plan[tipo],{monto:totals[tipo]});});
         ['pieDiferido','diferidas','cuotas'].forEach(function(tipo){
          summary[tipo]=Object.assign({},plan[tipo],{cantidad:groupConceptRows(planConceptRows(plan)).filter(function(g){return g.rows[0].importConcept.tipo===tipo;}).length});
        });
        return summary;
      });
      return baseRenderPreview(summaries,issues);
    };
  }

  window.ccImportedConceptRowsHtml=function(rows,dis){
    return orderAnnotatedPaymentRows(rows||[]).map(function(row){return ccLineaDetalleRowHtml(row,dis);}).join('');
  };

  if(typeof window.aplicarDetalleLinea==='function'){
    var baseAplicarDetalleLinea=window.aplicarDetalleLinea;
    window.aplicarDetalleLinea=function(lineaCC,detalle,montoLinea){
      baseAplicarDetalleLinea.apply(this,arguments);
      if(lineaCC&&detalle&&Array.isArray(detalle.abonos))lineaCC.abonos=cloneJson(detalle.abonos);
    };
  }

  function planAmountMinor(plan){
    if(!plan)return NaN;
    var amounts=[plan.reserva&&plan.reserva.monto,plan.contraPromesa&&plan.contraPromesa.monto,plan.contraEscritura&&plan.contraEscritura.monto];
    (plan.diferidas&&plan.diferidas.rows||[]).forEach(function(row){amounts.push(row&&row.monto);});
    (plan.pieDiferido&&plan.pieDiferido.rows||[]).forEach(function(row){amounts.push(row&&row.monto);});
    (plan.cuotas&&plan.cuotas.rows||[]).forEach(function(row){amounts.push(row&&row.monto);});
    var total=0;
    for(var i=0;i<amounts.length;i++){
      var minor=moneyMinor(amounts[i]||0);
      if(!Number.isFinite(minor)||minor<0)return NaN;
      total+=minor;
    }
    var pronto=moneyMinor(plan.prontopago&&plan.prontopago.monto||0);
    return Number.isFinite(pronto)&&pronto<=0?total+pronto:NaN;
  }

  function sameBusinessIdentity(left,right){
    if(!left||!right)return false;
    return normalizeLookupText(left.proyecto)===normalizeLookupText(right.proyecto)&&
      normalizeLoteValue(left.name)===normalizeLoteValue(right.name)&&
      normalizeLookupText(left.cliente)===normalizeLookupText(right.cliente);
  }

  function storedConciliacionIssues(recordIds,requireAccounting){
    var wanted=null;
    if(Array.isArray(recordIds)){
      wanted={};
      recordIds.forEach(function(id){wanted[String(id)]=true;});
    }
    var recordsById={};
    (state.registros||[]).forEach(function(record){
      var id=String(record&&record.id||'');
      if(!id)return;
      if(!recordsById[id])recordsById[id]=[];
      recordsById[id].push(record);
    });
    var plansByRecord={};
    (state.conciliaciones||[]).forEach(function(plan){
      var id=String(plan&&plan.registroId||'');
      if(!id||(wanted&&!wanted[id]))return;
      if(!plansByRecord[id])plansByRecord[id]=[];
      plansByRecord[id].push(plan);
    });
    var accountingByRecord={};
    (state.conciliacionesContables||[]).forEach(function(accounting){
      var id=String(accounting&&accounting.registroId||'');
      if(!id||(wanted&&!wanted[id]))return;
      if(!accountingByRecord[id])accountingByRecord[id]=[];
      accountingByRecord[id].push(accounting);
    });
    var issues=[];
    Object.keys(plansByRecord).forEach(function(recordId){
      var plans=plansByRecord[recordId];
      var records=recordsById[recordId]||[];
      if(plans.length!==1){issues.push('El registro '+recordId+' tiene '+plans.length+' Planes de Pago vinculados.');return;}
      var plan=plans[0];
      if(records.length!==1){issues.push('El Plan de Pago '+(plan.id||recordId)+' no apunta a un registro único.');return;}
      if(!sameBusinessIdentity(plan,records[0]))issues.push('El Plan de Pago de '+(plan.cliente||recordId)+' está enlazado a otro proyecto, lote o cliente.');
      if(!Number.isFinite(planAmountMinor(plan)))issues.push('El Plan de Pago de '+(plan.cliente||recordId)+' contiene un monto inválido o negativo.');
      if(requireAccounting===false)return;
      var accounting=accountingByRecord[recordId]||[];
      if(accounting.length!==1){issues.push('El registro de '+(plan.cliente||recordId)+' tiene '+accounting.length+' conciliaciones contables vinculadas.');return;}
      var cc=accounting[0];
      if(String(cc.planPagoId||'')!==String(plan.id||''))issues.push('La conciliación contable de '+(plan.cliente||recordId)+' apunta a otro Plan de Pago.');
      if(!sameBusinessIdentity(cc,plan))issues.push('La conciliación contable de '+(plan.cliente||recordId)+' tiene otra identidad comercial.');
      var planDiferidas=plan.diferidas&&plan.diferidas.rows||[];
      var planPie=plan.pieDiferido&&plan.pieDiferido.rows||[];
      var planCuotas=plan.cuotas&&plan.cuotas.rows||[];
      var ccDiferidas=cc.lineas&&cc.lineas.diferidas||[];
      var ccPie=cc.lineas&&cc.lineas.pieDiferido||[];
      var ccCuotas=cc.lineas&&cc.lineas.cuotas||[];
      if(planDiferidas.length!==ccDiferidas.length||planPie.length!==ccPie.length||planCuotas.length!==ccCuotas.length){
        issues.push('Las líneas contables de '+(plan.cliente||recordId)+' no coinciden con su Plan de Pago.');
      }
    });
    if(requireAccounting!==false){
      Object.keys(accountingByRecord).forEach(function(recordId){
        if(!plansByRecord[recordId])issues.push('Existe una conciliación contable sin Plan de Pago para el registro '+recordId+'.');
      });
    }
    return issues;
  }

  function moneyExportDiagnostics(recordIds){
    var criticalIssues=storedConciliacionIssues(recordIds,true);
    var wanted=null;
    if(Array.isArray(recordIds)){
      wanted={};
      recordIds.forEach(function(id){wanted[String(id)]=true;});
    }
    var records={},plans={},accounting={};
    function collect(items,key,target){
      (items||[]).forEach(function(item){
        var id=String(item&&item[key]||'');
        if(!id||(wanted&&!wanted[id]))return;
        (target[id]||(target[id]=[])).push(item);
      });
    }
    collect(state.registros,'id',records);
    collect(state.conciliaciones,'registroId',plans);
    collect(state.conciliacionesContables,'registroId',accounting);
    var warnings=[];
    Object.keys(plans).forEach(function(registroId){
      var recordList=records[registroId]||[];
      var planList=plans[registroId]||[];
      var ccList=accounting[registroId]||[];
      if(recordList.length!==1||planList.length!==1||ccList.length!==1)return;
      var record=recordList[0],plan=planList[0],cc=ccList[0];
      var fields=[
        {key:'proyecto',label:'Proyecto',normalize:normalizeLookupText},
        {key:'name',label:'Lote',normalize:normalizeLoteValue},
        {key:'cliente',label:'Cliente',normalize:normalizeLookupText}
      ];
      var differences=[];
      var mismatchedFields=[];
      var hasEmptyMismatch=false;
      fields.forEach(function(field){
        var values=[record[field.key],plan[field.key],cc[field.key]].map(function(value){return String(value===undefined||value===null?'':value).trim();});
        var normalized=values.map(field.normalize);
        if(normalized[0]===normalized[1]&&normalized[1]===normalized[2])return;
        mismatchedFields.push(field.key);
        if(values.some(function(value){return !value;}))hasEmptyMismatch=true;
        differences.push(field.label+': Ficha «'+(values[0]||'sin dato')+'»; Plan de Pago «'+(values[1]||'sin dato')+'»; Conciliación «'+(values[2]||'sin dato')+'».');
      });
      if(!differences.length)return;
      // Un lote distinto, o proyecto y cliente distintos a la vez, pueden señalar una operación equivocada.
      // Solo una diferencia descriptiva aislada de proyecto o de nombre pasa al Excel con advertencia.
      var warningAllowed=!hasEmptyMismatch&&mismatchedFields.length===1&&mismatchedFields[0]!=='name';
      if(warningAllowed){
        if(!sameBusinessIdentity(record,plan)){
          var planIssue='El Plan de Pago de '+(plan.cliente||registroId)+' está enlazado a otro proyecto, lote o cliente.';
          var planIssueIndex=criticalIssues.indexOf(planIssue);
          if(planIssueIndex!==-1)criticalIssues.splice(planIssueIndex,1);
        }
        if(!sameBusinessIdentity(cc,plan)){
          var ccIssue='La conciliación contable de '+(plan.cliente||registroId)+' tiene otra identidad comercial.';
          var ccIssueIndex=criticalIssues.indexOf(ccIssue);
          if(ccIssueIndex!==-1)criticalIssues.splice(ccIssueIndex,1);
        }
      }
      warnings.push({
        registroId:registroId,
        proyectoFicha:String(record.proyecto||''),proyectoPlan:String(plan.proyecto||''),proyectoConciliacion:String(cc.proyecto||''),
        loteFicha:String(record.name||''),lotePlan:String(plan.name||''),loteConciliacion:String(cc.name||''),
        clienteFicha:String(record.cliente||''),clientePlan:String(plan.cliente||''),clienteConciliacion:String(cc.cliente||''),
        rutFicha:String(record.rut||''),
        message:differences.join(' ')
      });
    });
    return {criticalIssues:criticalIssues,warnings:warnings};
  }

  function moneyExportWarnings(recordIds){
    var diagnostics=moneyExportDiagnostics(recordIds);
    var warningsById={};
    diagnostics.warnings.forEach(function(warning){warningsById[String(warning.registroId)]=warning;});
    var ids=Array.isArray(recordIds)?recordIds:(state.conciliaciones||[]).map(function(plan){return plan.registroId;});
    var seen={};
    ids.forEach(function(value){
      var id=String(value||'');
      if(!id||seen[id])return;
      seen[id]=true;
      var issues=storedConciliacionIssues([id],true);
      if(!issues.length)return;
      var record=(state.registros||[]).find(function(item){return String(item.id||'')===id;})||{};
      var plan=(state.conciliaciones||[]).find(function(item){return String(item.registroId||'')===id;})||{};
      var cc=(state.conciliacionesContables||[]).find(function(item){return String(item.registroId||'')===id;})||{};
      var warning=warningsById[id];
      if(!warning){
        warning={
          registroId:id,rutFicha:String(record.rut||''),
          proyectoFicha:String(record.proyecto||''),proyectoPlan:String(plan.proyecto||''),proyectoConciliacion:String(cc.proyecto||''),
          loteFicha:String(record.name||''),lotePlan:String(plan.name||''),loteConciliacion:String(cc.name||''),
          clienteFicha:String(record.cliente||''),clientePlan:String(plan.cliente||''),clienteConciliacion:String(cc.cliente||''),
          message:''
        };
        warningsById[id]=warning;
      }
      var identityPlanIssue='El Plan de Pago de '+(plan.cliente||id)+' está enlazado a otro proyecto, lote o cliente.';
      var identityCcIssue='La conciliación contable de '+(plan.cliente||id)+' tiene otra identidad comercial.';
      var otherIssues=issues.filter(function(issue){
        return !warning.message||issue!==identityPlanIssue&&issue!==identityCcIssue;
      });
      if(otherIssues.length)warning.message+=(warning.message?' Otras incidencias: ':'')+otherIssues.join(' ');
    });
    return Object.keys(warningsById).map(function(id){return warningsById[id];});
  }

  var pendingMoneyExportDecision=null;
  function moneyExportWarningTitle(warning){
    var cliente=warning.clienteFicha||warning.clientePlan||warning.clienteConciliacion||'Cliente sin nombre';
    var proyecto=warning.proyectoFicha||warning.proyectoPlan||warning.proyectoConciliacion||'Proyecto sin dato';
    var lote=warning.loteFicha||warning.lotePlan||warning.loteConciliacion||'—';
    return cliente+' · '+proyecto+' · Lote '+lote;
  }
  window.cerrarConfirmacionDescargaConciliaciones=function(accepted){
    var resolve=pendingMoneyExportDecision;
    if(!resolve)return;
    pendingMoneyExportDecision=null;
    var modal=document.getElementById('modal-money-export-warnings');
    if(modal)modal.classList.remove('open');
    resolve(!!accepted);
  };
  function confirmarDescargaConciliaciones(warnings,format){
    if(!warnings||!warnings.length)return Promise.resolve(true);
    if(pendingMoneyExportDecision)return Promise.resolve(false);
    var modal=document&&typeof document.getElementById==='function'?document.getElementById('modal-money-export-warnings'):null;
    var intro=document&&typeof document.getElementById==='function'?document.getElementById('money-export-warning-intro'):null;
    var list=document&&typeof document.getElementById==='function'?document.getElementById('money-export-warning-list'):null;
    if(!modal||!intro||!list){
      var details=warnings.map(function(warning){return moneyExportWarningTitle(warning)+' — '+warning.message;}).join('\n\n');
      return Promise.resolve(typeof window.confirm==='function'&&window.confirm('Se detectaron '+warnings.length+' incidencia(s) antes de descargar '+format+':\n\n'+details+'\n\n¿Descargar de todas formas?'));
    }
    intro.textContent='Se detectaron '+warnings.length+' incidencia'+(warnings.length===1?'':'s')+' en las conciliaciones. Revisa el detalle y decide si quieres descargar el '+format+' de todas formas.';
    list.innerHTML=warnings.map(function(warning){
      return '<div class="money-export-warning-item"><strong>'+safeEsc(moneyExportWarningTitle(warning))+'</strong><p>'+safeEsc(warning.message||'Revisar la información de esta conciliación.')+'</p></div>';
    }).join('');
    return new Promise(function(resolve){
      pendingMoneyExportDecision=resolve;
      modal.classList.add('open');
      var accept=document.getElementById('money-export-warning-accept');
      if(accept&&typeof accept.focus==='function')accept.focus();
    });
  }
  function exportarTrasConfirmarIncidencias(warnings,format,exportFn){
    if(!warnings||!warnings.length)return exportFn();
    return confirmarDescargaConciliaciones(warnings,format).then(function(accepted){
      if(accepted)return exportFn();
    });
  }

  function normalizeTarget(target){
    return target==='desist'||target==='rescil'||target==='conciliacion'?target:'';
  }

  function getButtons(target){
    var cfg=configs[target];
    var actions=cfg&&document.getElementById(cfg.actionsId);
    return {
      actions:actions,
      confirm:actions&&actions.querySelector('button:first-of-type'),
      cancel:actions&&actions.querySelector('button:last-of-type')
    };
  }

  function setActions(target,mode){
    var buttons=getButtons(target);
    if(!buttons.actions)return;
    if(mode==='hidden'){
      buttons.actions.style.display='none';
      return;
    }
    buttons.actions.style.display='flex';
    if(buttons.confirm){
      buttons.confirm.disabled=mode!=='ready';
      buttons.confirm.setAttribute('aria-disabled',mode==='ready'?'false':'true');
    }
    if(buttons.cancel){
      buttons.cancel.disabled=false;
      buttons.cancel.style.display='inline-flex';
    }
  }

  function renderProgress(job,message,percent){
    if(!job||job.cancelled||activeJob!==job)return;
    var cfg=configs[job.target];
    var preview=document.getElementById(cfg.previewId);
    var count=document.getElementById(cfg.countId);
    var pct=Math.max(0,Math.min(100,Math.round(percent||0)));
    if(count)count.textContent='0';
    if(preview){
      preview.innerHTML='<div class="prueba-import-progress" role="status" aria-live="polite">'+
        '<div class="prueba-import-progress-head"><strong>Destino: '+safeEsc(cfg.shortLabel)+'</strong><span>'+pct+'%</span></div>'+
        '<div class="prueba-import-progress-file">'+safeEsc(job.fileName||'Archivo seleccionado')+'</div>'+
        '<div class="prueba-import-progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="'+pct+'"><span style="width:'+pct+'%"></span></div>'+
        '<div class="prueba-import-progress-message">'+safeEsc(message||'Procesando...')+'</div>'+
      '</div>';
    }
    setActions(job.target,'busy');
  }

  function clearTargetDraft(target){
    var cfg=configs[target];
    if(!cfg)return;
    if(target==='conciliacion'){
      pendingConciliacionImport=[];
    }else if(typeof pendingSpecialImport!=='undefined'&&pendingSpecialImport){
      pendingSpecialImport[target]=[];
    }
    readyJobs[target]=null;
    var preview=document.getElementById(cfg.previewId);
    var count=document.getElementById(cfg.countId);
    if(preview)preview.innerHTML='';
    if(count)count.textContent='0';
    setActions(target,'hidden');
  }

  function cancelActive(silent){
    var job=activeJob;
    if(!job)return;
    job.cancelled=true;
    if(job.reader&&job.reader.readyState===FileReader.LOADING){
      try{job.reader.abort();}catch(e){}
    }
    activeJob=null;
    clearTargetDraft(job.target);
    if(!silent&&typeof toast==='function')toast('Carga cancelada. No se guardó ningún dato.','info');
  }

  function beginJob(target,file){
    cancelActive(true);
    Object.keys(configs).forEach(function(name){clearTargetDraft(name);});
    var job={
      id:++seq,target:target,fileName:file&&file.name||'Archivo seleccionado',file:file,
      reader:null,cancelled:false,phase:'reading',result:null
    };
    activeJob=job;
    renderProgress(job,'Leyendo el archivo...',2);
    return job;
  }

  function isCurrent(job){
    return !!job&&!job.cancelled&&activeJob===job;
  }

  function failJob(job,message,error){
    if(!isCurrent(job))return;
    activeJob=null;
    readyJobs[job.target]=null;
    if(job.target==='conciliacion'){
      pendingConciliacionImport=[];
      showConciliacionImportError(message,error);
    }else{
      pendingSpecialImport[job.target]=[];
      showSpecialImportError(job.target,message,error);
    }
    setActions(job.target,'hidden');
  }

  function normalizeHeaders(headers){
    return (headers||[]).map(importHeaderKey);
  }

  function hasHeader(headers,names){
    var normalized=normalizeHeaders(headers);
    return names.some(function(name){return normalized.indexOf(normalizeImportHeader(name))>=0;});
  }

  function validateTargetHeaders(headers,target){
    var normalized=normalizeHeaders(headers);
    var hasProyecto=normalized.indexOf('proyecto')>=0;
    var hasCliente=normalized.indexOf('cliente')>=0;
    var hasRut=normalized.some(function(h){return h==='rut'||h==='rut cliente'||h==='run'||h==='r u t';});
    var hasConcepto=normalized.indexOf('concepto')>=0;
    var hasDesist=normalized.some(function(h){return h.indexOf('desistimiento')>=0;});
    var hasRescil=normalized.some(function(h){return h.indexOf('resciliacion')>=0||h.indexOf('resiliacion')>=0;});

    if(target==='conciliacion'){
      if(hasDesist||hasRescil)return {ok:false,message:'Este archivo corresponde a desistimientos o resciliaciones, no a Conciliaciones.'};
      if(!hasProyecto||!hasConcepto||!hasRut)return {ok:false,message:'La carga de Conciliaciones requiere las columnas Proyecto, Concepto y RUT Cliente.'};
    }
    if(target==='rescil'){
      if(hasDesist&&!hasRescil)return {ok:false,message:'Este archivo corresponde a Desistimientos. Cárgalo en el importador Histórico de Desistimientos.'};
      if(hasConcepto)return {ok:false,message:'Este archivo corresponde a un Plan de Pago. Cárgalo en el importador de Conciliaciones.'};
      if(!hasProyecto||!hasCliente||!hasRut)return {ok:false,message:'La carga de Solicitudes de Resciliación requiere Proyecto, Cliente y RUT.'};
    }
    if(target==='desist'){
      if(hasRescil&&!hasDesist)return {ok:false,message:'Este archivo corresponde a Solicitudes de Resciliación. Cárgalo en ese importador.'};
      if(hasConcepto)return {ok:false,message:'Este archivo corresponde a un Plan de Pago. Cárgalo en el importador de Conciliaciones.'};
      if(!hasProyecto||!hasCliente||!hasRut)return {ok:false,message:'La carga de Desistimientos requiere Proyecto, Cliente y RUT.'};
    }
    return {ok:true,message:''};
  }

  function findHeaderIndex(rows,target){
    for(var i=0;i<rows.length;i++){
      var h=normalizeHeaders(rows[i]);
      if(target==='conciliacion'){
        if(h.indexOf('proyecto')>=0&&h.indexOf('concepto')>=0)return i;
      }else if(h.indexOf('proyecto')>=0&&h.indexOf('cliente')>=0){
        return i;
      }
    }
    return -1;
  }

  function makeAccessor(headers){
    var indexes={},allIndexes={};
    normalizeHeaders(headers).forEach(function(header,index){
      if(indexes[header]===undefined)indexes[header]=index;
      if(!allIndexes[header])allIndexes[header]=[];
      allIndexes[header].push(index);
    });
    function raw(row,names){
      var blank='';
      for(var i=0;i<names.length;i++){
        var candidates=allIndexes[importHeaderKey(names[i])]||[];
        for(var j=0;j<candidates.length;j++){
          var value=row[candidates[j]];
          if(value!==undefined&&value!==null&&String(value).trim()!=='')return value;
          if(value!==undefined)blank=value;
        }
      }
      return blank;
    }
    function text(row,names){var value=raw(row,names);return String(value===undefined||value===null?'':value).trim();}
    return {raw:raw,text:text,indexes:indexes};
  }

  function parseImportDate(value){
    if(!value)return '';
    var isDate=(value instanceof Date)||(Object.prototype.toString.call(value)==='[object Date]');
    if(isDate&&!isNaN(value.getTime()))return value.getFullYear()+'-'+String(value.getMonth()+1).padStart(2,'0')+'-'+String(value.getDate()).padStart(2,'0');
    if(typeof value==='number'){
      var excelDate=new Date(Math.round((value-25569)*86400*1000));
      return excelDate.getFullYear()+'-'+String(excelDate.getMonth()+1).padStart(2,'0')+'-'+String(excelDate.getDate()).padStart(2,'0');
    }
    var s=String(value).trim();
    if(/^\d{2}-\d{2}-\d{4}$/.test(s)){var p=s.split('-');return p[2]+'-'+p[1]+'-'+p[0];}
    if(/^\d{2}\/\d{2}\/\d{4}$/.test(s)){var p2=s.split('/');return p2[2]+'-'+p2[1]+'-'+p2[0];}
    if(/^\d{4}-\d{2}-\d{2}$/.test(s))return s;
    if(/^\d+(\.\d+)?$/.test(s)){
      var n=parseFloat(s);
      if(n>20000&&n<80000){
        var serialDate=new Date(Math.round((n-25569)*86400*1000));
        return serialDate.getFullYear()+'-'+String(serialDate.getMonth()+1).padStart(2,'0')+'-'+String(serialDate.getDate()).padStart(2,'0');
      }
    }
    return s;
  }

  function pumpRows(job,rows,startIndex,onRow,onDone){
    var cursor=startIndex;
    var total=Math.max(1,rows.length-startIndex);
    function pump(){
      if(!isCurrent(job))return;
      var started=Date.now();
      var processed=0;
      try{
        while(cursor<rows.length&&processed<350&&(Date.now()-started)<12){
          onRow(rows[cursor],cursor);
          cursor++;
          processed++;
        }
      }catch(error){
        failJob(job,'No se pudo procesar la fila '+(cursor+1)+'.',error);
        return;
      }
      var done=cursor-startIndex;
      renderProgress(job,'Validando '+done+' de '+total+' filas...',25+(done/total)*70);
      if(cursor<rows.length){
        setTimeout(pump,0);
      }else{
        setTimeout(function(){if(isCurrent(job))onDone();},0);
      }
    }
    setTimeout(pump,0);
  }

  function parseCsvAsync(job,text,onDone){
    var firstLine=(String(text||'').split(/\r?\n/).find(function(line){return line.trim();})||'');
    var separator=(firstLine.split(';').length>=firstLine.split(',').length)?';':',';
    var source=String(text||'').replace(/^\uFEFF/,'');
    var rows=[],row=[],current='',quoted=false,index=0;
    function pump(){
      if(!isCurrent(job))return;
      var started=Date.now();
      while(index<source.length&&(Date.now()-started)<12){
        var ch=source[index],next=source[index+1];
        if(ch==='"'){
          if(quoted&&next==='"'){current+='"';index++;}
          else quoted=!quoted;
        }else if(ch===separator&&!quoted){
          row.push(current);current='';
        }else if((ch==='\n'||ch==='\r')&&!quoted){
          if(ch==='\r'&&next==='\n')index++;
          row.push(current);current='';
          if(row.some(function(cell){return String(cell||'').trim()!=='';}))rows.push(row);
          row=[];
        }else current+=ch;
        index++;
      }
      renderProgress(job,'Separando filas del CSV...',8+(index/Math.max(1,source.length))*15);
      if(index<source.length){setTimeout(pump,0);return;}
      row.push(current);
      if(row.some(function(cell){return String(cell||'').trim()!=='';}))rows.push(row);
      setTimeout(function(){if(isCurrent(job))onDone(rows);},0);
    }
    setTimeout(pump,0);
  }

  function makeLotProjectIndex(){
    var data=typeof getLotesData==='function'?getLotesData():{};
    var index={};
    Object.keys(data||{}).forEach(function(project){
      (data[project]||[]).forEach(function(lot){
        var key=normalizeLoteValue(lot);
        if(!index[key])index[key]=[];
        index[key].push(project);
      });
    });
    return index;
  }

  var specialImportSignatureFields=[
    'estado','proyecto','name','cotizacionFolio','cliente','rut','terreno','remoto','precio','montoReservaCotizacion',
    'fechaReserva','fechaFirma','fechaReunion','horaReunion','estadoReunion','obs','abogada','horaAgenda',
    'desistMot','desistFecha','sinLote'
  ];

  function specialImportSignature(record){
    record=record||{};
    return JSON.stringify(specialImportSignatureFields.map(function(field){
      var value=record[field];
      if(field==='precio'||field==='montoReservaCotizacion')return Number(value)||0;
      if(field==='sinLote')return !!value;
      return value===undefined||value===null?'':String(value).trim();
    }));
  }

  function buildExistingSpecialImportIndex(){
    var index={};
    (state.registros||[]).forEach(function(record){
      var signature=specialImportSignature(record);
      if(!index[signature])index[signature]=record;
    });
    return index;
  }

  function renderSpecialDedupPreview(target,resultado,issues,ajustes,stats){
    if(typeof baseRenderSpecialImportPreview==='function')baseRenderSpecialImportPreview(target,resultado,issues,ajustes);
    var cfg=configs[target];
    var preview=document.getElementById(cfg.previewId);
    var count=document.getElementById(cfg.countId);
    if(count)count.textContent=String(resultado.length);
    if(!preview||!stats)return;

    var duplicates=stats.duplicates||[];
    var html='<div style="margin-top:8px;border:1px solid var(--border);border-radius:var(--r);background:var(--bg2);padding:10px">'+
      '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(135px,1fr));gap:6px">'+
        '<div style="padding:7px 9px;border-left:3px solid var(--accent);background:var(--acl)"><strong style="display:block;font-size:15px;color:var(--text)">'+stats.validRows+'</strong><span style="font-size:10px;color:var(--text2)">Filas válidas leídas</span></div>'+
        '<div style="padding:7px 9px;border-left:3px solid var(--yellow);background:var(--yellowl)"><strong style="display:block;font-size:15px;color:var(--text)">'+duplicates.length+'</strong><span style="font-size:10px;color:var(--text2)">Duplicados exactos omitidos</span></div>'+
        '<div style="padding:7px 9px;border-left:3px solid var(--green);background:var(--greenl)"><strong style="display:block;font-size:15px;color:var(--text)">'+resultado.length+'</strong><span style="font-size:10px;color:var(--text2)">Registros nuevos para cargar</span></div>'+
      '</div>';
    if(duplicates.length){
      html+='<div style="margin-top:8px;padding:8px 9px;background:var(--yellowl);border:1px solid var(--yellow);border-radius:var(--r);color:var(--text)">'+
        '<strong>'+duplicates.length+' duplicado'+(duplicates.length!==1?'s':'')+' exacto'+(duplicates.length!==1?'s':'')+' no se cargarán.</strong> Sólo se guardarán los '+resultado.length+' registros que no están repetidos.'+
        '<div style="overflow:auto;margin-top:7px"><table style="width:100%;border-collapse:collapse;font-size:10px;min-width:620px"><thead><tr>'+
          '<th style="text-align:left;padding:4px 6px;border-bottom:1px solid var(--border)">Fila</th><th style="text-align:left;padding:4px 6px;border-bottom:1px solid var(--border)">Cliente</th><th style="text-align:left;padding:4px 6px;border-bottom:1px solid var(--border)">RUT</th><th style="text-align:left;padding:4px 6px;border-bottom:1px solid var(--border)">Proyecto / lote</th><th style="text-align:left;padding:4px 6px;border-bottom:1px solid var(--border)">Coincide con</th>'+
        '</tr></thead><tbody>';
      duplicates.slice(0,20).forEach(function(item){
        html+='<tr><td style="padding:4px 6px">'+safeEsc(item.fila)+'</td><td style="padding:4px 6px">'+safeEsc(item.cliente)+'</td><td style="padding:4px 6px;font-family:var(--mono)">'+safeEsc(item.rut)+'</td><td style="padding:4px 6px">'+safeEsc(item.proyecto)+' / '+safeEsc(item.lote)+'</td><td style="padding:4px 6px">'+safeEsc(item.coincideCon)+'</td></tr>';
      });
      if(duplicates.length>20)html+='<tr><td colspan="5" style="padding:4px 6px;color:var(--text3)">...y '+(duplicates.length-20)+' duplicados más</td></tr>';
      html+='</tbody></table></div></div>';
    }else{
      html+='<div style="margin-top:8px;padding:7px 9px;background:var(--greenl);border:1px solid var(--green);border-radius:var(--r);color:var(--green)"><strong>No se encontraron duplicados exactos.</strong></div>';
    }
    html+='</div>';
    preview.innerHTML=html+preview.innerHTML;
  }

  function startSpecialRows(job,rows){
    var target=job.target;
    var headerIndex=findHeaderIndex(rows,target);
    if(headerIndex<0){failJob(job,'No se encontró un encabezado válido.',new Error('Usa columnas Proyecto, Cliente y RUT.'));return;}
    var validation=validateTargetHeaders(rows[headerIndex],target);
    if(!validation.ok){failJob(job,validation.message,new Error('El archivo no coincide con el destino seleccionado.'));return;}

    var access=makeAccessor(rows[headerIndex]);
    var col=access.text,colRaw=access.raw;
    var esDesist=target==='desist';
    var resultado=[],issues=[],ajustes=[],duplicates=[],validRows=0;
    var seenFile={};
    var existingIndex=buildExistingSpecialImportIndex();
    var lotProjectIndex=makeLotProjectIndex();

    function isSinLote(value){
      var s=normalizeLookupText(value);
      return !s||s==='*'||s==='-'||s==='--'||s==='s/l'||s==='sl'||s==='sin lote'||s==='sinlote';
    }
    function suggestProject(lot,currentProject){
      var candidates=lotProjectIndex[normalizeLoteValue(lot)]||[];
      var currentNorm=normalizeLookupText(currentProject);
      var others=candidates.filter(function(project){return normalizeLookupText(project)!==currentNorm;});
      return others.find(function(project){return currentNorm.indexOf('raices de rancagua')>=0&&normalizeLookupText(project)==='raices de rancagua ii';})||others[0]||'';
    }

    pumpRows(job,rows,headerIndex+1,function(row,rowIndex){
      var fila='Fila '+(rowIndex+1);
      var nameOriginal=col(row,['N°','N','Nº','Numero','Número']);
      var cotizacionFolio=col(row,['N° Cotización','Nro Cotización','N° Cotizacion','Nro Cotizacion','N Cotización','N Cotizacion','Número Cotización','Numero Cotizacion','Folio Cotización','Folio Cotizacion']);
      var proyectoOriginal=col(row,['Proyecto']);
      var cliente=col(row,['Cliente']);
      var rut=col(row,['RUT','Rut','rut','RUN','Run','R.U.T']);
      if(!nameOriginal&&!proyectoOriginal&&!cliente)return;
      if(!proyectoOriginal||!cliente||!rut){
        issues.push({tipo:'error',fila:fila,campo:'Campos obligatorios',valor:[nameOriginal,proyectoOriginal,cliente,rut].join(' / '),detalle:'Falta Proyecto, Cliente o RUT. El RUT es obligatorio.',accion:'Completar la fila o eliminarla del archivo.'});
        return;
      }
      var proyectoCanonico=findCanonicalProyecto(proyectoOriginal)||toTitleCase(proyectoOriginal);
      var sinLote=isSinLote(nameOriginal);
      var loteCanonico=sinLote?'Sin lote':(findCanonicalLote(proyectoCanonico,nameOriginal)||nameOriginal);
      if(sinLote){
        issues.push({tipo:'warn',fila:fila,campo:'N° Lote',valor:(nameOriginal||'(vacío)')+' ('+proyectoCanonico+')',detalle:'El registro se importará igual como histórico sin lote asociado.',accion:'Si después conocen el lote, editar el registro manualmente.'});
      }else if(String(loteCanonico)!==String(nameOriginal)){
        ajustes.push({fila:fila,campo:'N° Lote',valor:nameOriginal+' → '+loteCanonico,detalle:'Se ajustó al formato usado por el proyecto.'});
      }else if(getLotesDeProyecto(proyectoCanonico).length>0&&!findCanonicalLote(proyectoCanonico,nameOriginal)){
        var suggested=suggestProject(nameOriginal,proyectoCanonico);
        issues.push({tipo:'warn',fila:fila,campo:'N° Lote',valor:nameOriginal+' ('+proyectoCanonico+')',detalle:'El lote no aparece en la lista del proyecto.',accion:suggested?'Probable proyecto correcto: '+suggested+'. Corregir en el Excel si corresponde.':'Revisar N° de lote en Admin → Lotes.'});
      }
      if(proyectoCanonico!==proyectoOriginal)ajustes.push({fila:fila,campo:'Proyecto',valor:proyectoOriginal+' → '+proyectoCanonico,detalle:'Se ajustó el nombre al proyecto registrado.'});

      var motivo=esDesist?col(row,['Motivo Desistimiento','Motivo']):col(row,['Motivo Resciliación','Motivo Resciliacion','Motivo']);
      var fechaMot=parseImportDate(esDesist?colRaw(row,['Fecha Desistimiento','Fecha Desist','Fecha']):colRaw(row,['Fecha Resciliación','Fecha Resciliacion','Fecha Rescil','Fecha']));
      if(!motivo)issues.push({tipo:'warn',fila:fila,campo:'Motivo',valor:'(vacío)',detalle:'El registro se importará sin motivo.',accion:'Completar motivo si corresponde.'});
      if(!fechaMot)issues.push({tipo:'warn',fila:fila,campo:'Fecha',valor:'(vacía)',detalle:'El registro se importará sin fecha del proceso.',accion:'Completar fecha si corresponde.'});
      var item={
        id:'r'+Date.now()+job.id+rowIndex+Math.random().toString(36).substr(2,4),proyecto:proyectoCanonico,
        estado:esDesist?'Desistido':'Resciliación',estadoReserva:'',name:loteCanonico,cotizacionFolio:cotizacionFolio,sinLote:sinLote,
        cliente:String(cliente||'').trim().toLocaleUpperCase('es-CL'),rut:rut,terreno:col(row,['Terreno']),remoto:col(row,['Remoto']),
        precio:parseClpValue(col(row,['Precio Venta','Precio'])),montoReservaCotizacion:parseClpValue(col(row,['Monto Reserva','Monto de Reserva','Reserva'])),
        fechaReserva:parseImportDate(colRaw(row,['Fecha Reserva'])),fechaFirma:parseImportDate(colRaw(row,['Fecha Firma'])),
        fechaReunion:parseImportDate(colRaw(row,['Fecha Reunión','Fecha Reunion'])),horaReunion:normalizeHoraAgenda(col(row,['Hora Reunión','Hora Reunion'])),
        estadoReunion:normalizeEstadoReunion(col(row,['Estado Reunión','Estado Reunion','ESTADO REUNION'])),obs:col(row,['Observación','Obs']),obsHistorial:[],
        prioridad:'',admVentas:'',fechaVisita:'',notaria:'',formaPago:'',abogada:canonicalAbogada(col(row,['Abogada'])),
        horaAgenda:normalizeHoraAgenda(col(row,['Hora Firma','Hora Agenda','Hora'])),acompanante:'',datosBancarios:'',desistMot:motivo,desistFecha:fechaMot,
        rescilEstado:esDesist?'':'pendiente',
        actividad:[{ts:nowTs(),user:currentUser?currentUser.nombre:'Importación',msg:esDesist?'Importado como histórico Desistimiento':'Importado como Solicitud de Resciliación'}]
      };
      var reunion=cleanReunionItem({fecha:item.fechaReunion,hora:item.horaReunion,abogada:item.abogada,estado:item.estadoReunion},item);
      item.reuniones=reunion?[reunion]:[];
      validRows++;
      var signature=specialImportSignature(item);
      var firstFileRow=seenFile[signature];
      var existingRecord=existingIndex[signature];
      if(firstFileRow||existingRecord){
        duplicates.push({
          fila:fila,cliente:item.cliente,rut:item.rut,proyecto:item.proyecto,lote:item.name,
          coincideCon:firstFileRow?firstFileRow:'registro ya cargado'+(existingRecord&&existingRecord.numReserva?' (reserva '+existingRecord.numReserva+')':'')
        });
        return;
      }
      seenFile[signature]=fila;
      resultado.push(item);
    },function(){
      if(!isCurrent(job))return;
      pendingSpecialImport[target]=resultado;
      job.phase='ready';job.result=resultado;job.duplicates=duplicates;job.validRows=validRows;readyJobs[target]=job;
      renderSpecialDedupPreview(target,resultado,issues,ajustes,{validRows:validRows,duplicates:duplicates});
      setActions(target,resultado.length?'ready':'hidden');
      if(!resultado.length){
        if(duplicates.length)toast('No hay registros nuevos: los '+duplicates.length+' registros válidos son duplicados exactos.','info');
        else toast('No se encontraron registros válidos para '+configs[target].shortLabel+'.','error');
      }
    });
  }

  function buildFirmadoIndex(){
    var index={};
    (state.registros||[]).forEach(function(record){
      if(record.estado!=='Firmado')return;
      var key=normalizeLookupText(record.proyecto)+'|'+normalizeLoteValue(record.name);
      if(!index[key])index[key]=[];
      index[key].push(record);
    });
    return index;
  }

  function startConciliacionRows(job,rows){
    var headerIndex=findHeaderIndex(rows,'conciliacion');
    if(headerIndex<0){failJob(job,'No se encontró un encabezado válido.',new Error('Usa columnas Proyecto, N° Lote, RUT Cliente y Concepto.'));return;}
    var validation=validateTargetHeaders(rows[headerIndex],'conciliacion');
    if(!validation.ok){failJob(job,validation.message,new Error('El archivo no coincide con el destino seleccionado.'));return;}

    var access=makeAccessor(rows[headerIndex]);
    var col=access.text,colRaw=access.raw;
    var issues=[],groups={},order=[];
    var sourceRows=0,acceptedRows=0,sourceAmountMinor=0,acceptedAmountMinor=0;
    var firmadoIndex=buildFirmadoIndex();
    var recordIdCounts={},checkedExistingLinks={},invalidExistingLinks={};
    (state.registros||[]).forEach(function(record){
      var id=String(record&&record.id||'');
      if(id)recordIdCounts[id]=(recordIdCounts[id]||0)+1;
    });

    pumpRows(job,rows,headerIndex+1,function(row,rowIndex){
      var fila='Fila '+(rowIndex+1);
      var proyectoOriginal=col(row,['Proyecto']);
      var loteOriginal=col(row,['N°','N° Lote','Lote','N','Numero','Número']);
      var cotizacionFolio=col(row,['N° Cotización','Nro Cotización','N° Cotizacion','Nro Cotizacion','N Cotización','N Cotizacion','Número Cotización','Numero Cotizacion','Folio Cotización','Folio Cotizacion']);
      var cliente=col(row,['Cliente']);
      var rut=col(row,['RUT Cliente','RUT','Rut']);
      var concepto=col(row,['Concepto']);
      var nCuota=col(row,['N° Cuota','Nro Cuota','Cuota N°','N Cuota']);
      // El archivo puede traer conversiones UF con decimales. Conservar el
      // valor exacto evita diferencias acumuladas al volver a exportar.
      var montoRaw=colRaw(row,['Monto','Monto Ajustado CLP']);
      var montoParsed=parseMoneyImport(montoRaw);
      var monto=montoParsed.value;
      var fecha=parseImportDate(colRaw(row,['Fecha','Fecha Vencimiento']));
      var tipoMoneda=col(row,['Tipo Moneda','Moneda']).toUpperCase();
      var isUf=tipoMoneda==='UF';
      var valorUfParsed=isUf?parseMoneyImport(colRaw(row,['Valor UF'])):{valid:true,value:0};
      var montoVentaRaw=colRaw(row,['Monto Venta']);
      var hasMontoVenta=montoVentaRaw!==''&&montoVentaRaw!==undefined&&montoVentaRaw!==null;
      var montoVentaParsed=hasMontoVenta?parseMoneyImport(montoVentaRaw,isUf):{valid:true,value:null};
      var montoUfParsed=isUf?montoVentaParsed:{valid:true,value:0};
      var valorUf=valorUfParsed.valid?valorUfParsed.value:0;
      var montoUf=montoUfParsed.valid?montoUfParsed.value:0;
      var fechaTipoCambio=isUf?parseImportDate(colRaw(row,['Fecha Tipo Cambio'])):'';
      var interesRaw=colRaw(row,['Interés %','Interes %','% Interés','% Interes','Interés','Interes']);
      var observacionPlan=col(row,['Observación','Observacion','Notas','Nota']);
      var fechaRegistroPlan=parseImportDate(colRaw(row,['Fecha Registro','Fecha de Registro','Fecha Conciliación','Fecha Conciliacion']));
      var fechaFirmaPlan=parseImportDate(colRaw(row,['Fecha Firma','Fecha de Firma','F. Firma']));
      if(!proyectoOriginal&&!loteOriginal&&!cliente&&!concepto)return;
      sourceRows++;
      if(hasMontoVenta&&(!montoVentaParsed.valid||montoVentaParsed.value<0)){
        issues.push({tipo:'error',fila:fila,campo:'Monto Venta',valor:String(montoVentaRaw),detalle:'El Monto Venta no es válido.',accion:'Corregir el monto antes de agrupar.'});
        return;
      }
      if(nCuota&&!/^[0-9]+$/.test(nCuota)){
        issues.push({tipo:'error',fila:fila,campo:'N° Cuota',valor:nCuota,detalle:'El número de cuota debe ser un entero.',accion:'Usar el mismo número en las partidas del mismo concepto.'});
        return;
      }
      if(!montoParsed.valid){
        issues.push({tipo:'error',fila:fila,campo:'Monto',valor:String(montoRaw||'(vacío)'),detalle:'El monto no es un número válido. La carga se bloqueó para evitar diferencias.',accion:'Corregir el monto en el archivo.'});
        return;
      }
      sourceAmountMinor+=montoParsed.minor;
      if(montoParsed.minor<0){
        issues.push({tipo:'error',fila:fila,campo:'Monto',valor:String(montoRaw),detalle:'Los montos negativos no son válidos en un Plan de Pago.',accion:'Corregir el signo o registrar el ajuste por el flujo correspondiente.'});
        return;
      }
      if(montoParsed.minor===0){
        issues.push({tipo:'warn',fila:fila,campo:'Monto',valor:String(montoRaw),detalle:'La línea tiene monto cero y se conservará así.',accion:'Confirmar que el valor cero sea intencional.'});
      }
      if(!proyectoOriginal||!loteOriginal||!concepto){
        issues.push({tipo:'error',fila:fila,campo:'Campos obligatorios',valor:[proyectoOriginal,loteOriginal,concepto].join(' / '),detalle:'Falta Proyecto, N° Lote o Concepto.',accion:'Completar la fila o eliminarla del archivo.'});
        return;
      }
      var proyectoCanonico=findCanonicalProyecto(proyectoOriginal)||toTitleCase(proyectoOriginal);
      var loteCanonico=findCanonicalLote(proyectoCanonico,loteOriginal)||loteOriginal;
      var candidates=firmadoIndex[normalizeLookupText(proyectoCanonico)+'|'+normalizeLoteValue(loteCanonico)]||[];
      if(!candidates.length){
        issues.push({tipo:'error',fila:fila,campo:'Registro Firmado',valor:loteOriginal+' — '+proyectoCanonico,detalle:'No existe un registro en estado Firmado con ese Proyecto y N° Lote.',accion:'Verificar que el cliente ya esté Firmado en VRQ.'});
        return;
      }
      var rutNorm=normalizeRutValue(rut);
      if(!rutNorm){
        issues.push({tipo:'error',fila:fila,campo:'RUT Cliente',valor:cliente||'(vacío)',detalle:'El archivo no trae RUT de Cliente para esta fila. El RUT es obligatorio para validar la carga.',accion:'Completar el RUT del cliente en el archivo.'});
        return;
      }
      var candidatesWithRut=candidates.filter(function(record){return !!normalizeRutValue(record.rut);});
      if(!candidatesWithRut.length){
        issues.push({tipo:'error',fila:fila,campo:'RUT Cliente',valor:loteOriginal+' — '+proyectoCanonico,detalle:'El registro Firmado de este lote no tiene RUT guardado en VRQ.',accion:'Completar el RUT del titular en VRQ antes de importar esta fila.'});
        return;
      }
      var matchingRecords=candidatesWithRut.filter(function(record){return normalizeRutValue(record.rut)===rutNorm;});
      var match=matchingRecords[0];
      if(!match){
        issues.push({tipo:'error',fila:fila,campo:'RUT Cliente',valor:rut+' (Cliente: '+(cliente||'—')+')',detalle:'El RUT no coincide con el titular registrado para este lote ('+candidatesWithRut.map(function(record){return record.cliente+' — RUT '+record.rut;}).join(', ')+').',accion:'Verificar el RUT en el archivo o confirmar el titular real de este lote.'});
        return;
      }
      if(cotizacionFolio){
        var quoteMatches=matchingRecords.filter(function(record){return normalizeLookupText(record.cotizacionFolio)===normalizeLookupText(cotizacionFolio);});
        if(quoteMatches.length)matchingRecords=quoteMatches;
        else matchingRecords=matchingRecords.filter(function(record){return !String(record.cotizacionFolio||'').trim();});
      }
      if(matchingRecords.length!==1){
        issues.push({tipo:'error',fila:fila,campo:'N° Cotización',valor:cotizacionFolio||'(vacío)',detalle:'La compra no se puede identificar de forma única por RUT, proyecto, lote y cotización.',accion:'Verificar el folio y los registros Firmados antes de importar.'});
        return;
      }
      match=matchingRecords[0];
      if(recordIdCounts[String(match.id)]!==1){
        issues.push({tipo:'error',fila:fila,campo:'Identificador interno',valor:match.id,detalle:'El registro Firmado no tiene un identificador interno único.',accion:'Corregir el registro antes de importar para evitar mezclar clientes.'});
        return;
      }
      if(!checkedExistingLinks[match.id]){
        checkedExistingLinks[match.id]=true;
        var linkedPlans=(state.conciliaciones||[]).filter(function(plan){return String(plan.registroId||'')===String(match.id);});
        var linkedAccounting=(state.conciliacionesContables||[]).filter(function(cc){return String(cc.registroId||'')===String(match.id);});
        if(linkedPlans.length>1||(linkedPlans.length===1&&!sameBusinessIdentity(linkedPlans[0],match))||linkedAccounting.length>1||(linkedAccounting.length===1&&!sameBusinessIdentity(linkedAccounting[0],match))){
          invalidExistingLinks[match.id]=true;
          issues.push({tipo:'error',fila:fila,campo:'Vínculo existente',valor:match.proyecto+' · Lote '+match.name,detalle:'Hay un Plan de Pago o una conciliación enlazada a otro cliente.',accion:'La carga queda bloqueada hasta reparar el vínculo interno.'});
        }
      }
      if(invalidExistingLinks[match.id])return;

      var issueStart=issues.length;
      var detalle=buildImportedAccountingDetail(row,col,colRaw,parseImportDate,fila,issues);
      var montoAbonadoRaw=colRaw(row,['Monto Abonado','Abonado','Monto Pagado']);
      if(montoAbonadoRaw!==''&&montoAbonadoRaw!==undefined&&montoAbonadoRaw!==null){
        var montoAbonadoParsed=parseMoneyImport(montoAbonadoRaw);
        if(!montoAbonadoParsed.valid||montoAbonadoParsed.minor<0){
          issues.push({tipo:'error',fila:fila,campo:'Monto Abonado',valor:String(montoAbonadoRaw),detalle:'El monto abonado no es válido.',accion:'Corregir el valor antes de importar.'});
        }else if(montoAbonadoParsed.minor>montoParsed.minor){
          issues.push({tipo:'error',fila:fila,campo:'Monto Abonado',valor:String(montoAbonadoRaw),detalle:'El monto abonado supera el monto de la línea.',accion:'Revisar el pago o dividirlo entre las líneas correspondientes.'});
        }else detalle.montoAbonado=montoAbonadoParsed.value;
      }
      for(var issueIndex=issueStart;issueIndex<issues.length;issueIndex++){
        if(issues[issueIndex].campo==='Estado'&&issues[issueIndex].tipo==='warn')issues[issueIndex].tipo='error';
      }
      var conceptoNorm=normalizeLookupText(concepto);
      var group=groups[match.id];
      if(group&&cotizacionFolio&&group.cotizacionFolio&&normalizeLookupText(cotizacionFolio)!==normalizeLookupText(group.cotizacionFolio)){
        issues.push({tipo:'error',fila:fila,campo:'N° Cotización',valor:cotizacionFolio,detalle:'El archivo contiene folios distintos para la misma compra.',accion:'Separar o corregir las cotizaciones; no se mezclarán los montos.'});
        return;
      }
      if(!group){
        group={
          registroId:match.id,cliente:String(match.cliente||cliente||'').trim().toLocaleUpperCase('es-CL'),proyecto:match.proyecto,name:match.name,precio:parseFloat(match.precio)||0,
          cotizacionFolio:cotizacionFolio||(match.cotizacionFolio||''),moneda:match.moneda||'CLP',precioUf:parseFloat(match.precioUf)||0,
          valorUf:parseFloat(match.valorUf)||0,fechaTipoCambio:match.fechaTipoCambio||'',interesPct:0,obs:'',fechaConciliacion:'',fechaFirma:match.fechaFirma||'',
          reserva:{monto:0,fecha:'',detalle:null,valorUf:0,montoUf:0},contraPromesa:{monto:0,fecha:'',detalle:null,valorUf:0,montoUf:0},
           pieDiferido:{cantidad:0,rows:[]},diferidas:{cantidad:0,rows:[]},cuotas:{cantidad:0,rows:[]},contraEscritura:{monto:0,fecha:'',detalle:null,valorUf:0,montoUf:0},filas:0,
          _singleLineCounts:{reserva:0,contraPromesa:0,contraEscritura:0},
          _importAudit:{sourceRows:0,sourceAmountMinor:0,preparedRows:0,preparedAmountMinor:0}
        };
        groups[match.id]=group;order.push(match.id);
      }
      group.filas++;
      if(cotizacionFolio)group.cotizacionFolio=cotizacionFolio;
      if(interesRaw!==''&&interesRaw!==undefined&&interesRaw!==null)group.interesPct=Math.max(0,parseImportedNumber(interesRaw));
      if(observacionPlan)group.obs=observacionPlan;
      if(fechaRegistroPlan)group.fechaConciliacion=fechaRegistroPlan;
      if(fechaFirmaPlan)group.fechaFirma=fechaFirmaPlan;
      if(tipoMoneda==='CLP'){group.moneda='CLP';group.precioUf=0;group.valorUf=0;group.fechaTipoCambio='';}
      if(isUf){group.moneda='UF';if(valorUf){group.valorUf=valorUf;group.fechaTipoCambio=fechaTipoCambio||group.fechaTipoCambio;}}
      function assignSingleLine(type,label,data){
        var count=group._singleLineCounts[type]||0;
        if(count===0){
          group[type]=data;
        }else{
          data.tipoOriginal=type;
          data.labelOriginal=label+' '+(count+1);
          data.conceptoImportado=concepto;
          data._sourceOrder=rowIndex;
          data.manual=true;
          group.diferidas.rows.push(data);
        }
        group._singleLineCounts[type]=count+1;
      }
      var isPieDiferido=conceptoNorm.indexOf('pie diferido')>=0||conceptoNorm.indexOf('pie diferida')>=0;
      var originalType=isPieDiferido?'pieDiferido':conceptoNorm==='reserva'||conceptoNorm==='reservado'?'reserva':
        (conceptoNorm.indexOf('contra promesa')>=0||conceptoNorm.indexOf('contrapromesa')>=0||conceptoNorm==='pie'?'contraPromesa':
        (conceptoNorm.indexOf('escritura')>=0?'contraEscritura':(conceptoNorm.indexOf('diferida')>=0?'diferidas':'cuotas')));
      var importConcept={tipo:originalType,numeroCuota:nCuota?String(Number(nCuota)):'',moneda:tipoMoneda||group.moneda||'CLP',montoVenta:montoVentaParsed.value,sourceRow:rowIndex+1};
      var importedLine={monto:monto,fecha:fecha,detalle:detalle,valorUf:valorUf,montoUf:montoUf,importConcept:importConcept};
      var recognized=true;
      if(conceptoNorm==='reserva'||conceptoNorm==='reservado')assignSingleLine('reserva','Reserva',importedLine);
      else if(conceptoNorm.indexOf('contra promesa')>=0||conceptoNorm.indexOf('contrapromesa')>=0||conceptoNorm==='pie')assignSingleLine('contraPromesa','Contra Promesa',importedLine);
      else if(conceptoNorm.indexOf('escritura')>=0)assignSingleLine('contraEscritura','Contra Escritura',importedLine);
      else if(isPieDiferido)group.pieDiferido.rows.push(Object.assign(importedLine,{_nCuota:parseInt(nCuota,10)||0,_sourceOrder:rowIndex}));
      else if(conceptoNorm.indexOf('diferida')>=0)group.diferidas.rows.push(Object.assign(importedLine,{_nCuota:parseInt(nCuota,10)||0,_sourceOrder:rowIndex}));
      else if(conceptoNorm==='cuota'||/^cuota(\s|$)/.test(conceptoNorm))group.cuotas.rows.push(Object.assign(importedLine,{manual:true,_nCuota:parseInt(nCuota,10)||0,_sourceOrder:rowIndex}));
      else{
        recognized=false;
        issues.push({tipo:'error',fila:fila,campo:'Concepto',valor:concepto,detalle:'Concepto no reconocido; la carga se bloqueó para no omitir dinero.',accion:'Usar: Reserva, Contra Promesa, Pie Diferido, Cuota Diferida, Cuota o Contra Escritura.'});
      }
      if(recognized){
        acceptedRows++;
        acceptedAmountMinor+=montoParsed.minor;
        group._importAudit.sourceRows++;
        group._importAudit.sourceAmountMinor+=montoParsed.minor;
      }
    },function(){
      function sortLines(lines){
        return lines.slice().sort(function(a,b){
          var fa=a.fecha||'9999-99-99',fb=b.fecha||'9999-99-99';
          if(fa!==fb)return fa<fb?-1:1;
          var na=a._nCuota||0,nb=b._nCuota||0;
          if(na!==nb)return na-nb;
          return (a._sourceOrder||0)-(b._sourceOrder||0);
        }).map(function(row){var clean={};for(var key in row){if(key!=='_nCuota'&&key!=='_sourceOrder')clean[key]=row[key];}return clean;});
      }
      var result=order.map(function(id){
        var group=consolidateImportedConcepts(groups[id]);
        group.pieDiferido.rows=sortLines(group.pieDiferido.rows);group.pieDiferido.cantidad=group.pieDiferido.rows.length;
        group.diferidas.rows=sortLines(group.diferidas.rows);group.diferidas.cantidad=group.diferidas.rows.length;
        group.cuotas.rows=sortLines(group.cuotas.rows);group.cuotas.cantidad=group.cuotas.rows.length;
        group._importAudit.preparedRows=planLineRefs(group).filter(function(ref){return !!ref.data.importConcept;}).length;
        group._importAudit.preparedAmountMinor=planAmountMinor(group);
        if(group._importAudit.preparedRows>group._importAudit.sourceRows||group._importAudit.sourceAmountMinor!==group._importAudit.preparedAmountMinor){
          issues.push({tipo:'error',fila:'Plan de '+group.cliente,campo:'Conciliación individual',valor:group.proyecto+' · Lote '+group.name,detalle:'El origen trae '+group._importAudit.sourceRows+' pagos por '+formatMoney(moneyFromMinor(group._importAudit.sourceAmountMinor))+' y el sistema preparó '+group._importAudit.preparedRows+' conceptos por '+formatMoney(moneyFromMinor(group._importAudit.preparedAmountMinor))+'.',accion:'La carga queda bloqueada; revisar las filas de este cliente.'});
        }
        delete group._singleLineCounts;
        return group;
      });
      var preparedAmountMinor=result.reduce(function(total,group){return total+group._importAudit.preparedAmountMinor;},0);
      var conceptTotals=[];
      result.forEach(function(plan){
        var totals=groupConceptRows(planConceptRows(plan));
        plan._importAudit.conceptCount=totals.length;
        totals.filter(function(total){return (total.rows[0].importConcept.sourceCount||1)>1;}).forEach(function(total){
          total.sourceCount=total.rows[0].importConcept.sourceCount;
          conceptTotals.push({plan:plan,total:total});
        });
      });
      var blockingIssues=issues.filter(function(issue){return issue.tipo==='error';}).length;
      var amountDifferenceMinor=sourceAmountMinor-preparedAmountMinor;
      var blocked=blockingIssues>0||acceptedRows!==sourceRows||acceptedAmountMinor!==preparedAmountMinor||amountDifferenceMinor!==0;
      pendingConciliacionImport=result;
      job.phase=blocked?'blocked':'ready';job.result=result;job.blocked=blocked;readyJobs.conciliacion=job;
      renderConciliacionImportPreview(result,issues);
      var preview=document.getElementById(configs.conciliacion.previewId);
      if(preview){
        if(conceptTotals.length){
          preview.insertAdjacentHTML('afterbegin','<details class="cc-import-groups"><summary>'+conceptTotals.length+' conceptos con partidas agrupadas</summary><div class="table-wrap"><table><thead><tr><th>Cliente / Proyecto / Lote</th><th>Concepto</th><th>Partidas</th><th>Monto Venta</th><th>Monto CLP</th></tr></thead><tbody>'+
            conceptTotals.map(function(item){return '<tr><td>'+safeEsc(item.plan.cliente+' / '+item.plan.proyecto+' / '+item.plan.name)+'</td><td>'+safeEsc(item.total.label)+'</td><td>'+item.total.sourceCount+'</td><td>'+formatMontoVenta(item.total)+'</td><td>'+formatMoney(item.total.monto)+'</td></tr>';}).join('')+'</tbody></table></div></details>');
        }
        var tone=blocked?'#dc2626':'#0d9f6e';
        var title=blocked?'Carga bloqueada: el archivo no cuadra':'Archivo conciliado: listo para importar';
        preview.insertAdjacentHTML('afterbegin','<div style="margin-bottom:9px;padding:9px 11px;border:1px solid '+tone+'55;border-left:4px solid '+tone+';border-radius:6px;background:'+tone+'12;font-size:10px;line-height:1.5">'+
          '<strong style="color:'+tone+'">'+title+'</strong><br>'+acceptedRows+' de '+sourceRows+' pagos válidos · '+result.reduce(function(total,group){return total+group._importAudit.preparedRows;},0)+' conceptos preparados · Origen: '+formatMoney(moneyFromMinor(sourceAmountMinor))+' · Preparado: '+formatMoney(moneyFromMinor(preparedAmountMinor))+' · Diferencia: '+formatMoney(moneyFromMinor(amountDifferenceMinor))+
          (blocked?'<br>Corrige los errores señalados o cancela la carga. No se guardó ningún dato.':'')+'</div>');
      }
      setActions('conciliacion',result.length?(blocked?'blocked':'ready'):'hidden');
      if(!result.length)toast('No se encontraron líneas de pago que coincidan con registros Firmados.','error');
      else if(blocked)toast('La carga se bloqueó porque faltan líneas o montos por conciliar.','error');
    });
  }

  function processRows(job,rows){
    if(!isCurrent(job))return;
    job.phase='validating';
    renderProgress(job,'Preparando la validación...',24);
    if(job.target==='conciliacion')startConciliacionRows(job,rows);
    else startSpecialRows(job,rows);
  }

  function processFile(file,target){
    target=normalizeTarget(target);
    if(!target||!file)return;
    var lower=String(file.name||'').toLowerCase();
    if(!/\.(xlsx|xls|csv)$/.test(lower)){
      toast('Selecciona un archivo .xlsx, .xls o .csv.','error');
      return;
    }
    var job=beginJob(target,file);
    var reader=new FileReader();
    job.reader=reader;
    reader.onerror=function(){failJob(job,'No se pudo leer el archivo seleccionado.',reader.error);};
    reader.onabort=function(){};
    reader.onprogress=function(event){
      if(event.lengthComputable)renderProgress(job,'Leyendo el archivo...',2+(event.loaded/event.total)*6);
    };
    reader.onload=function(event){
      if(!isCurrent(job))return;
      if(lower.endsWith('.csv')){
        job.phase='decoding';
        parseCsvAsync(job,String(event.target.result||''),function(rows){processRows(job,rows);});
        return;
      }
      job.phase='decoding';
      renderProgress(job,'Abriendo el libro de Excel...',10);
      setTimeout(function(){
        if(!isCurrent(job))return;
        try{
          if(typeof XLSX==='undefined')throw new Error('No se cargó la librería de Excel. Recarga la página e intenta nuevamente.');
          var workbook=XLSX.read(event.target.result,{type:'array',cellDates:true,dense:true});
          if(!workbook.SheetNames||!workbook.SheetNames.length)throw new Error('El archivo no tiene hojas.');
          renderProgress(job,'Convirtiendo la primera hoja...',18);
          setTimeout(function(){
            if(!isCurrent(job))return;
            try{
              var sheet=workbook.Sheets[workbook.SheetNames[0]];
              var rows=XLSX.utils.sheet_to_json(sheet,{header:1,defval:'',raw:true});
              processRows(job,rows);
            }catch(error){failJob(job,'El Excel se leyó, pero no se pudo procesar.',error);}
          },0);
        }catch(error){failJob(job,'El Excel se leyó, pero no se pudo procesar.',error);}
      },0);
    };
    if(lower.endsWith('.csv'))reader.readAsText(file,'UTF-8');
    else reader.readAsArrayBuffer(file);
  }

  function ensureInput(target){
    var cfg=configs[target];
    var input=document.getElementById(cfg.inputId);
    if(input)return input;
    input=document.createElement('input');
    input.type='file';input.id=cfg.inputId;input.accept='.xlsx,.xls,.csv';input.hidden=true;
    input.setAttribute('data-import-target',target);
    input.addEventListener('change',function(){
      var file=input.files&&input.files[0];
      input.value='';
      if(file)processFile(file,target);
    });
    document.body.appendChild(input);
    return input;
  }

  function trigger(target){
    var input=ensureInput(target);
    input.value='';
    input.click();
  }

  function bindDropzone(target){
    var cfg=configs[target];
    var dropzone=document.getElementById(cfg.dropzoneId);
    if(!dropzone||dropzone.dataset.isolatedImportBound==='1')return;
    dropzone.dataset.isolatedImportBound='1';
    dropzone.setAttribute('aria-label','Cargar archivo en '+cfg.label);
    dropzone.addEventListener('dragover',function(event){event.preventDefault();dropzone.classList.add('drag-over');});
    dropzone.addEventListener('dragleave',function(){dropzone.classList.remove('drag-over');});
    dropzone.addEventListener('drop',function(event){
      event.preventDefault();event.stopPropagation();dropzone.classList.remove('drag-over');
      var file=event.dataTransfer&&event.dataTransfer.files&&event.dataTransfer.files[0];
      if(file)processFile(file,target);
    });
  }

  function cancelTarget(target){
    target=normalizeTarget(target);
    if(activeJob&&activeJob.target===target){cancelActive(false);return;}
    clearTargetDraft(target);
    if(typeof toast==='function')toast('Carga cancelada. No se guardó ningún dato.','info');
  }

  window.triggerDesistInput=function(){trigger('desist');};
  window.triggerRescilInput=function(){trigger('rescil');};
  window.triggerConciliacionImportInput=function(){trigger('conciliacion');};
  window.processSpecialFile=function(file,target){processFile(file,normalizeTarget(target));};
  window.processConciliacionImportFile=function(file){processFile(file,'conciliacion');};
  window.cancelSpecialImport=function(target){cancelTarget(target);};
  window.cancelConciliacionImport=function(){cancelTarget('conciliacion');};

  function commitSpecialImport(target,ready){
    var records=pendingSpecialImport[target]||[];
    var signatures=buildExistingSpecialImportIndex();
    var added=0,lateDuplicates=0;
    if(!Array.isArray(state.proyectos))state.proyectos=[];
    if(!Array.isArray(state.motivos))state.motivos=[];
    if(!Array.isArray(state.motivosRescil))state.motivosRescil=[];

    records.forEach(function(record){
      var signature=specialImportSignature(record);
      if(signatures[signature]){lateDuplicates++;return;}
      if(record.proyecto&&state.proyectos.indexOf(record.proyecto)<0)state.proyectos.push(record.proyecto);
      if(record.desistMot){
        var motives=target==='desist'?state.motivos:state.motivosRescil;
        if(!motives.some(function(value){return normalizeLookupText(value)===normalizeLookupText(record.desistMot);}))motives.push(toTitleCase(record.desistMot));
      }
      if(!record.numReserva&&typeof asignarNumReserva==='function')asignarNumReserva(record);
      state.registros.push(record);
      signatures[signature]=record;
      added++;
    });

    pendingSpecialImport[target]=[];
    var preview=document.getElementById(configs[target].previewId);
    var count=document.getElementById(configs[target].countId);
    if(preview)preview.innerHTML='';
    if(count)count.textContent='0';
    setActions(target,'hidden');
    if(typeof saveState==='function')saveState();
    if(typeof renderAll==='function')renderAll();
    if(typeof populateFilters==='function')populateFilters();

    var omitted=(ready.duplicates||[]).length+lateDuplicates;
    var label=target==='desist'?'desistimientos históricos importados':'solicitudes de resciliación importadas';
    var message=added+' '+label;
    if(omitted)message+=' · '+omitted+' duplicado'+(omitted!==1?'s':'')+' exacto'+(omitted!==1?'s':'')+' omitido'+(omitted!==1?'s':'');
    toast(message,'success');
  }

  window.confirmSpecialImport=function(target){
    target=normalizeTarget(target);
    var ready=readyJobs[target];
    if(!ready||ready.phase!=='ready'||pendingSpecialImport[target]!==ready.result){
      toast('Primero carga y valida un archivo para '+configs[target].shortLabel+'.','error');
      return;
    }
    commitSpecialImport(target,ready);
    readyJobs[target]=null;
    if(activeJob===ready)activeJob=null;
    var tab=target==='rescil'?'rescil':'desist';
    var button=document.getElementById(target==='rescil'?'tbtn-rescil':'tbtn-desist');
    if(typeof setTab==='function'&&button)setTab(tab,button);
  };

  function verifyImportedGroups(groups){
    var recordIds=groups.map(function(group){return group.registroId;});
    var issues=storedConciliacionIssues(recordIds,typeof crearOActualizarCCDesdePlan==='function');
    groups.forEach(function(group){
      var plans=(state.conciliaciones||[]).filter(function(plan){return String(plan.registroId||'')===String(group.registroId||'');});
      if(plans.length!==1)return;
      var plan=plans[0];
      var record=(state.registros||[]).find(function(item){return String(item.id||'')===String(group.registroId||'');});
      if(record&&record.cliente!==group.cliente)issues.push('El nombre de '+group.cliente+' no quedó normalizado en mayúsculas.');
      if(group.fechaFirma&&record&&record.fechaFirma!==group.fechaFirma)issues.push('No se conservó la Fecha Firma de '+group.cliente+'.');
      if(group.fechaFirma&&plan.fechaFirma!==group.fechaFirma)issues.push('El Plan de Pago no conservó la Fecha Firma de '+group.cliente+'.');
      var expected=group._importAudit&&group._importAudit.sourceAmountMinor;
      var stored=planAmountMinor(plan);
      if(!Number.isFinite(expected)||stored!==expected){
        issues.push('El total guardado de '+group.cliente+' no coincide con el archivo de origen.');
      }
      var planDiferidas=plan.diferidas&&plan.diferidas.rows||[];
      var planCuotas=plan.cuotas&&plan.cuotas.rows||[];
      if(planDiferidas.length!==(group.diferidas&&group.diferidas.rows||[]).length||planCuotas.length!==(group.cuotas&&group.cuotas.rows||[]).length){
        issues.push('La cantidad de líneas guardadas de '+group.cliente+' cambió durante la importación.');
      }
      var storedRefs=planLineRefs(plan),expectedRefs=planLineRefs(group);
      expectedRefs.forEach(function(ref,index){
        var storedRef=storedRefs[index];
        if(!storedRef||JSON.stringify(storedRef.data.importConcept)!==JSON.stringify(ref.data.importConcept)){
          issues.push('No se conservó el concepto, número de cuota o Monto Venta de '+group.cliente+'.');
        }
      });
      var accounting=(state.conciliacionesContables||[]).filter(function(item){return String(item.registroId||'')===String(group.registroId||'');});
      if(accounting.length===1){
        expectedRefs.forEach(function(ref,index){
          var expectedDetail=ref.data&&ref.data.detalle||{};
          var storedRef=storedRefs[index];
          var storedLine=storedRef?accountingLineForRef(accounting[0],storedRef):null;
          if(!storedLine)return;
          var expectedPayments=Array.isArray(expectedDetail.abonos)?expectedDetail.abonos:[];
          var storedPayments=Array.isArray(storedLine.abonos)?storedLine.abonos:[];
          function paymentSignature(payment){
            payment=payment||{};
            return JSON.stringify([
              moneyMinor(payment.monto||0),String(payment.fecha||payment.fechaDeposito||'').trim(),
              String(payment.medioPago||'').trim(),String(payment.banco||'').trim(),identifierText(payment.nroDocumento),
              identifierText(payment.nroCuentaCliente),String(payment.rutPago||'').trim(),String(payment.titularPago||'').trim()
            ]);
          }
          if(JSON.stringify(expectedPayments.map(paymentSignature))!==JSON.stringify(storedPayments.map(paymentSignature))){
            issues.push('No se conservaron todos los abonos, bancos o documentos de '+group.cliente+'.');
          }
          ['estado','medioPago','banco','nroDocumento','fechaDeposito','nroCuentaCliente','rutPago','titularPago'].forEach(function(field){
            var expected=field==='nroDocumento'||field==='nroCuentaCliente'?identifierText(expectedDetail[field]):String(expectedDetail[field]||'').trim();
            var stored=field==='nroDocumento'||field==='nroCuentaCliente'?identifierText(storedLine[field]):String(storedLine[field]||'').trim();
            if(expected&&expected!==stored)issues.push('No se conservó '+field+' de '+group.cliente+'.');
          });
        });
      }
    });
    return issues.filter(function(issue,index,list){return list.indexOf(issue)===index;});
  }

  window.confirmConciliacionImport=function(){
    var ready=readyJobs.conciliacion;
    if(!ready||ready.phase!=='ready'||pendingConciliacionImport!==ready.result){
      toast(ready&&ready.blocked?'La carga está bloqueada porque el archivo no cuadra. Corrige los errores antes de importar.':'Primero carga y valida un archivo de Plan de Pago para Conciliaciones.','error');
      return;
    }
    var importedGroups=ready.result.slice();
    var rollback={
      registros:cloneJson(state.registros||[]),
      conciliaciones:cloneJson(state.conciliaciones||[]),
      conciliacionesContables:cloneJson(state.conciliacionesContables||[])
    };
    importedGroups.forEach(function(group){
      group.cliente=String(group.cliente||'').trim().toLocaleUpperCase('es-CL');
      var record=(state.registros||[]).find(function(item){return String(item.id||'')===String(group.registroId||'');});
      if(!record)return;
      record.cliente=group.cliente;
      if(group.fechaFirma)record.fechaFirma=group.fechaFirma;
    });
    // Autorizar el detalle como parte de la misma operación de importación.
    // Quien puede crear el Plan de Pago no debe perder campos por carecer del
    // permiso separado que controla la edición manual posterior.
    var originalCanDo=window.canDo;
    if(typeof originalCanDo==='function'){
      window.canDo=function(action){
        if(action==='Editar Conciliación Contable')return true;
        return originalCanDo.apply(this,arguments);
      };
    }
    try{
      baseConfirmConciliacion();
    }finally{
      if(typeof originalCanDo==='function')window.canDo=originalCanDo;
    }
    // Mantener la identidad del concepto consolidado. Los pagos individuales
    // ya estan contenidos en detalle.abonos y no crean nuevas obligaciones.
    importedGroups.forEach(function(group){
      var plan=typeof getConciliacionByRegistroId==='function'?getConciliacionByRegistroId(group.registroId):null;
      if(!plan)return;
      var refs=planLineRefs(plan);
      planLineRefs(group).forEach(function(sourceRef,index){
        if(refs[index]&&sourceRef.data.importConcept)refs[index].data.importConcept=cloneJson(sourceRef.data.importConcept);
      });
      if(!plan.diferidas||!Array.isArray(plan.diferidas.rows))return;
      group.diferidas.rows.forEach(function(sourceRow,index){
        if(!sourceRow.tipoOriginal||!plan.diferidas.rows[index])return;
        plan.diferidas.rows[index].tipoOriginal=sourceRow.tipoOriginal;
        plan.diferidas.rows[index].labelOriginal=sourceRow.labelOriginal||sourceRow.conceptoImportado||'Línea adicional';
        plan.diferidas.rows[index].conceptoImportado=sourceRow.conceptoImportado||'';
      });
    });
    var verificationIssues=verifyImportedGroups(importedGroups);
    if(verificationIssues.length){
      state.registros=rollback.registros;
      state.conciliaciones=rollback.conciliaciones;
      state.conciliacionesContables=rollback.conciliacionesContables;
      pendingConciliacionImport=ready.result;
      readyJobs.conciliacion=ready;
      if(typeof saveState==='function')saveState();
      if(typeof renderAll==='function')renderAll();
      console.error('Importación revertida por control de integridad:',verificationIssues);
      toast('Importación revertida: los totales o vínculos no quedaron exactos. No se guardó ningún cambio.','error');
      return;
    }
    var verifiedAt=new Date().toISOString();
    importedGroups.forEach(function(group){
      var plan=(state.conciliaciones||[]).find(function(item){return String(item.registroId||'')===String(group.registroId||'');});
      var cc=(state.conciliacionesContables||[]).find(function(item){return String(item.registroId||'')===String(group.registroId||'');});
      var audit={
        version:'2026-09-07.2',sourceFile:ready.fileName||'',sourceRows:group._importAudit.sourceRows,conceptCount:group._importAudit.conceptCount,
        sourceAmount:moneyFromMinor(group._importAudit.sourceAmountMinor),verifiedAt:verifiedAt,
        verifiedBy:currentUser&&currentUser.nombre||''
      };
      if(plan){delete plan._importAudit;plan.importAudit=cloneJson(audit);}
      if(cc)cc.importAudit=cloneJson(audit);
    });
    if(typeof saveState==='function')saveState();
    readyJobs.conciliacion=null;
    if(activeJob===ready)activeJob=null;
    var button=document.getElementById('tbtn-conciliacion-contable');
    if(typeof setTab==='function'&&button)setTab('conciliacion-contable',button);
  };

  function annotateImportedExtraRows(rows,forDashboard){
    var plansByRecord={};
    (state.conciliaciones||[]).forEach(function(plan){plansByRecord[plan.registroId]=plan;});
    (rows||[]).forEach(function(row){
      var plan=plansByRecord[row.registroId];
      var section=plan&&plan[row.tipo];
      var source=(row.tipo==='cuotas'||row.tipo==='diferidas'||row.tipo==='pieDiferido')?(section&&section.rows&&section.rows[row.idx]):section;
      if(!source)return;
      if(source.importConcept){
        row.importConcept=source.importConcept;
        if(source.importConcept.numeroCuota)row.label=conceptLabels[source.importConcept.tipo]+' '+source.importConcept.numeroCuota;
      }
      if(source.tipoOriginal){
        if(!source.importConcept||!source.importConcept.numeroCuota)row.label=source.labelOriginal||source.conceptoImportado||'Línea adicional';
        row.sourceTipo=source.tipoOriginal;
        if(forDashboard)row.tipo=source.tipoOriginal;
      }
    });
    return rows;
  }

  function paymentRowSemanticType(row){
    return String(row&&row.importConcept&&row.importConcept.tipo||row&&row.sourceTipo||row&&row.tipo||'');
  }

  function paymentRowNumber(row){
    var imported=String(row&&row.importConcept&&row.importConcept.numeroCuota||'').trim();
    if(/^\d+$/.test(imported))return parseInt(imported,10);
    var index=Number(row&&row.idx);
    return Number.isFinite(index)?index+1:0;
  }

  function comparePaymentRows(left,right){
    var rank={reserva:0,contraPromesa:1,pieDiferido:2,diferidas:3,cuotas:4,contraEscritura:5,prontopago:10};
    var leftType=paymentRowSemanticType(left.row),rightType=paymentRowSemanticType(right.row);
    var leftRank=Object.prototype.hasOwnProperty.call(rank,leftType)?rank[leftType]:9;
    var rightRank=Object.prototype.hasOwnProperty.call(rank,rightType)?rank[rightType]:9;
    if(leftRank!==rightRank)return leftRank-rightRank;
    if((leftType==='pieDiferido'||leftType==='diferidas'||leftType==='cuotas')&&leftType===rightType){
      var numberDifference=paymentRowNumber(left.row)-paymentRowNumber(right.row);
      if(numberDifference)return numberDifference;
    }
    return left.position-right.position;
  }

  function orderAnnotatedPaymentRows(rows){
    var groups=[],byRecord={};
    (rows||[]).forEach(function(row,position){
      var key=String(row&&row.registroId||'__row_'+position);
      var group=byRecord[key];
      if(!group){group={items:[]};byRecord[key]=group;groups.push(group);}
      group.items.push({row:row,position:position});
    });
    var ordered=[];
    groups.forEach(function(group){
      group.items.sort(comparePaymentRows).forEach(function(entry){ordered.push(entry.row);});
    });
    return ordered;
  }

  if(typeof window.getCCFlatRows==='function'){
    var baseGetCCFlatRows=window.getCCFlatRows;
    window.getCCFlatRows=function(){migrateStoredImportedConcepts();return orderAnnotatedPaymentRows(annotateImportedExtraRows(baseGetCCFlatRows(),false));};
  }
  if(typeof window.getCCFlatRowsAll==='function'){
    var baseGetCCFlatRowsAll=window.getCCFlatRowsAll;
    window.getCCFlatRowsAll=function(project){return orderAnnotatedPaymentRows(annotateImportedExtraRows(baseGetCCFlatRowsAll(project),true));};
  }
  if(typeof window.getCCFlatRowsAgendados==='function'){
    var baseGetCCFlatRowsAgendados=window.getCCFlatRowsAgendados;
    window.getCCFlatRowsAgendados=function(project){return orderAnnotatedPaymentRows(annotateImportedExtraRows(baseGetCCFlatRowsAgendados(project),true));};
  }
  if(typeof window.buildConciliacionDetalleParaDocumento==='function'){
    var baseBuildConciliacionDetalle=window.buildConciliacionDetalleParaDocumento;
    window.buildConciliacionDetalleParaDocumento=function(registroId){
      // El detalle de Devolución pasa líneas de vista y estado de cierre.
      // Conservamos todos los argumentos para no volver a mostrar Mora/Vigente.
      var detail=baseBuildConciliacionDetalle.apply(this,arguments);
      var plan=typeof getConciliacionByRegistroId==='function'?getConciliacionByRegistroId(registroId):null;
      if(!detail||!plan||!plan.diferidas||!Array.isArray(plan.diferidas.rows))return detail;
      planLineRefs(plan).forEach(function(ref){
        var row=ref.data,meta=row.importConcept;
        var oldLabel=ref.tipo==='pieDiferido'?'Pie Diferido '+(ref.idx+1):(ref.tipo==='diferidas'?'Cuota Diferida '+(ref.idx+1):(ref.tipo==='cuotas'?'Cuota '+(ref.idx+1):(ref.tipo==='contraPromesa'?'Contra Promesa (Pie)':conceptLabels[ref.tipo])));
        var label=meta&&meta.numeroCuota?conceptLabels[meta.tipo]+' '+meta.numeroCuota:row.labelOriginal;
        if(label)detail.filasHtml=detail.filasHtml.replace('<td>'+oldLabel+'</td>','<td data-import-line="'+ref.tipo+'-'+ref.idx+'">'+safeEsc(label)+'</td>');
      });
      return detail;
    };
  }

  function allowMoneyExport(){
    var issues=storedConciliacionIssues(null,true);
    if(!issues.length)return true;
    console.error('PDF bloqueado por control de integridad:',issues);
    toast('El PDF sigue bloqueado por una inconsistencia. Usa CSV o Excel para descargar todos los datos y revisar las incidencias.','error');
    return false;
  }

  function plansForExport(){
    var plans=typeof getConciliacionesFiltered==='function'?getConciliacionesFiltered():[];
    if(typeof shouldScopeRecordsToUser==='function'&&shouldScopeRecordsToUser()){
      var hasUnownedRecord=plans.some(function(plan){
        var record=(state.registros||[]).find(function(item){return String(item.id||'')===String(plan.registroId||'');});
        return !record||typeof userOwnsRecord!=='function'||!userOwnsRecord(record);
      });
      if(hasUnownedRecord){
        toast('No se descargó el archivo: un Plan de Pago visible no corresponde a una ficha autorizada para tu usuario.','error');
        return null;
      }
    }
    return plans;
  }

  function warningTextByRecordId(warnings){
    var out={};
    (warnings||[]).forEach(function(warning){out[String(warning.registroId)]=warning.message;});
    return out;
  }

  function appendMoneyExportWarningSheet(book,warnings){
    if(!warnings||!warnings.length)return;
    // Los nombres y proyectos pueden venir de datos ingresados por personas: nunca interpretarlos como fórmulas.
    function cellText(value){
      var result=String(value===undefined||value===null?'':value);
      return /^[=+\-@\t\r]/.test(result)?"'"+result:result;
    }
    var headers=['ID Registro','RUT Ficha','Proyecto Ficha','Proyecto Plan de Pago','Proyecto Conciliación','Lote Ficha','Lote Plan de Pago','Lote Conciliación','Cliente Ficha','Cliente Plan de Pago','Cliente Conciliación','Diferencia detectada'];
    var data=[
      ['ADVERTENCIA: DATOS CON DIFERENCIAS — REVISAR ANTES DE USAR ESTE ARCHIVO'],
      ['Se exportaron los datos originales sin corregir la ficha, el Plan de Pago ni la Conciliación.'],
      [],headers
    ];
    warnings.forEach(function(warning){
      data.push([
        warning.registroId,formatRutParaExportar(warning.rutFicha),warning.proyectoFicha,warning.proyectoPlan,warning.proyectoConciliacion,
        warning.loteFicha,warning.lotePlan,warning.loteConciliacion,
        warning.clienteFicha,warning.clientePlan,warning.clienteConciliacion,warning.message
      ].map(cellText));
    });
    var sheet=XLSX.utils.aoa_to_sheet(data);
    sheet['!cols']=[18,18,27,27,27,16,16,16,34,34,34,90].map(function(width){return {wch:width};});
    if(XLSX.utils.encode_range)sheet['!autofilter']={ref:XLSX.utils.encode_range({s:{r:3,c:0},e:{r:data.length-1,c:headers.length-1}})};
    XLSX.utils.book_append_sheet(book,sheet,'Advertencias');
  }

  function accountingFilteredFlatRows(){
    // Misma fuente que la tabla: búsqueda, proyecto, estado, conceptos, fechas y permisos.
    // Exportar todas las coincidencias, aunque un cliente esté contraído en pantalla.
    return (typeof getCCFlatRows==='function'?getCCFlatRows():[]).map(function(row){
      var value=getCCReportValues(row);
      var line=Object.assign({},value.linea);
      if(Array.isArray(line.abonos))line.abonos=line.abonos.map(function(payment){return Object.assign({},payment);});
      // Fijar exactamente la vista al descargar; cargar contactos es asíncrono.
      return Object.assign({},row,{linea:line,ccExportSnapshot:true,ccSinGuardar:value.sinGuardar});
    });
  }

  function clpReportAmount(value){
    return ccReportAmount(value);
  }

  function accountingExportTable(flatRows,warnings,contacts){
    var headers=['N°','Proyecto','Cliente','RUT Cliente','Teléfono','Correo','Línea','N° Abono','Cantidad Abonos','Monto','Fecha Vencimiento','Estado','Monto Abonado','Diferencia','Tipo de Cambio (UF)','Fecha Tipo de Cambio','Medio de Pago','Banco','N° Documento','Fecha Depósito','N° Cuenta Cliente','RUT Pago','Titular Pago','N° Cotización','Fecha Firma','Moneda','ID Registro','Medio visita','Estado conciliación','Monto Abono (detalle)','Suma Abonos (detalle)','Descuadre con abonos','Cambios sin guardar','Prontopago (%)','Base Prontopago'];
    var dataRows=[],clientProfiles=[];
    var warningById=warningTextByRecordId(warnings);
    if(warnings&&warnings.length)headers.push('Incidencias detectadas');
    if(!Array.isArray(flatRows))flatRows=accountingFilteredFlatRows();
    flatRows.forEach(function(row){
      var value=getCCReportValues(row),line=value.linea;
      var record=(state.registros||[]).find(function(item){return String(item.id||'')===String(row.registroId||'');})||{};
      var contact=contactoDeFilaInforme(row,contacts);
      var payments=Array.isArray(line.abonos)&&line.abonos.length?line.abonos.map(cloneAbonoForEditor):[cloneAbonoForEditor({
        monto:line.montoAbonado,fecha:line.fechaDeposito,medioPago:line.medioPago,banco:line.banco,
        nroDocumento:line.nroDocumento,nroCuentaCliente:line.nroCuentaCliente,rutPago:line.rutPago,titularPago:line.titularPago
      })];
      payments.forEach(function(payment,index){
        var first=index===0;
        var paymentNumber=Array.isArray(line.abonos)&&line.abonos.length?index+1:'';
        var dataRow=[
          row.name,row.proyecto,row.cliente,contact.rut,contact.telefono,contact.correo,row.label,paymentNumber,Array.isArray(line.abonos)?line.abonos.length:'',
          first?value.monto:'',row.fecha,value.estado,first?value.abonado:'',first?value.saldo:'',
          row.moneda==='UF'?(row.valorUf||''):'',row.moneda==='UF'?(row.fechaTipoCambio||''):'',
          payment.medioPago||'',payment.banco||'',payment.nroDocumento||'',payment.fecha||'',
          payment.nroCuentaCliente||'',formatRutParaExportar(payment.rutPago),payment.titularPago||'',
          row.cotizacionFolio||record.cotizacionFolio||'',row.fechaFirma||record.fechaFirma||'',row.moneda||record.moneda||'CLP',row.registroId||'',medioVisitaParaInforme(record),
          value.estadoOriginal,Number(payment.monto)||0,first&&value.detalle!==null?value.detalle:'',first&&value.descuadre!==null?value.descuadre:'',value.sinGuardar?'Sí':'No',
          first&&row.prontopagoPorcentaje!==undefined?row.prontopagoPorcentaje:'',first&&row.prontopagoBase!==undefined?row.prontopagoBase:''
        ];
        if(warnings&&warnings.length)dataRow.push(warningById[String(row.registroId||'')]||'');
        dataRows.push(dataRow);clientProfiles.push(contact);
      });
    });
    return CarteraClientesInforme.table(headers,dataRows,clientProfiles);
  }

  function accountingClientSummaryTable(flatRows,warnings,contacts){
    var headers=['N°','N° Cotización','Proyecto','Cliente','RUT Cliente','Teléfono','Correo','Fecha Firma','Moneda','Precio Venta','Cantidad Líneas','Reserva','Contra Promesa','Cant. Pie Diferido','Total Pie Diferido','Cant. Cuotas Diferidas','Total Cuotas Diferidas','Cant. Cuotas','Total Cuotas','Contra Escritura','Prontopago (%)','Base Prontopago','Prontopago','Total Plan','Total Abonado','Pagado en Confirmación','Saldo Pendiente','Medio visita','Total Pagado','Abonos en otros estados','Resguardo en Notaría','Cambios sin guardar'];
    var warningById=warningTextByRecordId(warnings);
    if(warnings&&warnings.length)headers.push('Incidencias detectadas');
    if(!Array.isArray(flatRows))flatRows=accountingFilteredFlatRows();
    var groups={};
    var order=[];
    flatRows.forEach(function(row){
      var key=String(row.registroId||'');
      var record=(state.registros||[]).find(function(item){return String(item.id||'')===key;})||{};
      if(!groups[key]){
        groups[key]={name:row.name,folio:row.cotizacionFolio||record.cotizacionFolio||'',proyecto:row.proyecto,cliente:row.cliente,rut:formatRutParaExportar(record.rut),fechaFirma:row.fechaFirma||record.fechaFirma||'',moneda:row.moneda||record.moneda||'CLP',precio:clpReportAmount(record.precio),lineas:0,reserva:0,contraPromesa:0,cantPie:0,totalPie:0,cantDif:0,totalDif:0,cantCuo:0,totalCuo:0,contraEscritura:0,total:0,abonado:0,pagado:0,otrosAbonos:0,resguardo:0,pendiente:0,sinGuardar:false,enConfirmacion:0,medioVisita:medioVisitaParaInforme(record)};
        order.push(key);
      }
      var group=groups[key];
      if(group.prontopago===undefined)group.prontopago=0;
      group.contact=contactoDeFilaInforme(row,contacts);
      var value=getCCReportValues(row),amount=value.monto,paid=value.abonado;
      group.lineas++;
      group.total+=amount;
      group.abonado+=paid;
      group.pendiente+=value.pendiente;
      if(value.pagado)group.pagado+=paid;
      else if(value.enNotaria)group.resguardo+=paid;
      else group.otrosAbonos+=paid;
      if(value.sinGuardar)group.sinGuardar=true;
      if(value.estadoOriginal==='Pagado (En confirmación)')group.enConfirmacion+=paid;
      if(row.tipo==='reserva')group.reserva+=amount;
       else if(row.tipo==='contraPromesa')group.contraPromesa+=amount;
       else if(row.tipo==='pieDiferido'){group.cantPie++;group.totalPie+=amount;}
      else if(row.tipo==='diferidas'){group.cantDif++;group.totalDif+=amount;}
      else if(row.tipo==='cuotas'){group.cantCuo++;group.totalCuo+=amount;}
      else if(row.tipo==='contraEscritura')group.contraEscritura+=amount;
      else if(row.tipo==='prontopago')group.prontopago+=amount;
      if(row.tipo==='prontopago'){
        group.prontopagoPorcentaje=row.prontopagoPorcentaje;
        group.prontopagoBase=row.prontopagoBase;
      }
    });
    return CarteraClientesInforme.table(headers,order.map(function(key){
      var group=groups[key];
      var dataRow=[group.name,group.folio,group.proyecto,group.cliente,group.contact.rut,group.contact.telefono,group.contact.correo,group.fechaFirma,group.moneda,group.precio,group.lineas,group.reserva,group.contraPromesa,group.cantPie,group.totalPie,group.cantDif,group.totalDif,group.cantCuo,group.totalCuo,group.contraEscritura,group.prontopagoPorcentaje===undefined?'':group.prontopagoPorcentaje,group.prontopagoBase===undefined?'':group.prontopagoBase,group.prontopago,group.total,group.abonado,group.enConfirmacion,group.pendiente,group.medioVisita,group.pagado,group.otrosAbonos,group.resguardo,group.sinGuardar?'Sí':'No'];
      if(warnings&&warnings.length)dataRow.push(warningById[key]||'');
      return dataRow;
    }),order.map(function(key){return groups[key].contact;}));
  }

  function accountingTotalsTable(rows){
    var totals=getConciliacionKpiTotals(rows);
    var drafts=rows.some(function(row){return getCCReportValues(row).sinGuardar;});
    return {headers:['Indicador','Monto','Criterio'],rows:[
      ['Total pagado',totals.pagado,'Solo estado Pagado. Excluye resguardo en notaría. En Detalle Pagos, filtrar Estado = Pagado.'],
      ['Resguardo en notaría',totals.resguardo,'Fuera de caja. Estado independiente, no incluido en Total pagado ni en Abonos en otros estados.'],
      ['Abonos en otros estados',totals.otrosAbonos,'Excluye Pagado y Resguardo en notaría.'],
      ['Total abonado (todos los estados)',totals.abonado,'Total pagado + Resguardo en notaría + Abonos en otros estados. No representa dinero en caja.'],
      ['Pagado en confirmación',totals.enConfirmacion,'Ya incluido en Abonos en otros estados.'],
      ['Total plan',totals.totalPlan,'Suma de Monto de las líneas visibles.'],
      ['Cuentas por cobrar',totals.pendiente,'Suma de saldos pendientes menos Prontopago; los sobrepagos se revisan aparte.'],
      ['En mora',totals.montoMora,'Saldo pendiente de las líneas en mora.'],
      ['Redondeo','','Pesos enteros por línea antes de sumar, igual que en pantalla.'],
      ['Detalle Pagos','','Monto y Monto Abonado figuran una sola vez por línea. Monto Abono (detalle) conserva cada abono original, incluidos sus decimales.'],
      ['Estado conciliación','','Estado y Estado conciliación conservan el estado original. Resguardo en notaría se exporta por separado de Pagado.'],
      ['Cambios sin guardar','',drafts?'Incluye borradores visibles en pantalla, señalados como Sí.':'No incluye borradores.']
    ]};
  }

  async function exportAccountingXlsx(){
    if(typeof XLSX==='undefined'){toast('La librería de Excel no está disponible en este momento.','error');return;}
    try{
      var flatRows=accountingFilteredFlatRows();
      var warnings=moneyExportWarnings(flatRows.map(function(row){return row.registroId;}));
      if(!(await confirmarDescargaConciliaciones(warnings,'Excel')))return;
      await cargarMediosVisitaInforme(flatRows);
      var contacts=await cargarContactosInforme(flatRows);
      var summary=accountingClientSummaryTable(flatRows,warnings,contacts);
      var detail=accountingExportTable(flatRows,warnings,contacts);
      var totals=accountingTotalsTable(flatRows);
      var totalsSheet=XLSX.utils.aoa_to_sheet([totals.headers].concat(totals.rows));
      totalsSheet['!cols']=[36,22,110].map(function(width){return {wch:width};});
      for(var t=1;t<=8;t++){var totalCell=totalsSheet[XLSX.utils.encode_cell({r:t,c:1})];if(totalCell)totalCell.z='$ #,##0';}
      var summarySheet=XLSX.utils.aoa_to_sheet([summary.headers].concat(summary.rows));
      var detailSheet=XLSX.utils.aoa_to_sheet([detail.headers].concat(detail.rows));
      summarySheet['!cols']=[12,18,24,34,16,20,44,14,10,16,12,16,16,12,18,12,18,12,16,16,16,16,20,16,22,20,24,24,22].map(function(width){return {wch:width};});
      detailSheet['!cols']=[12,24,34,16,20,44,22,10,12,16,16,22,16,16,18,18,22,22,22,16,20,16,28,18,14,10,22,22,26,24,24,24,22].map(function(width){return {wch:width};});
      [[summary,summarySheet],[detail,detailSheet]].forEach(function(pair){
        ['Cliente','RUT Cliente','Teléfono','Correo'].forEach(function(header){
          var index=pair[0].headers.indexOf(header),width=pair[1]['!cols'][index].wch;
          pair[0].rows.forEach(function(row){width=Math.max(width,String(row[index]||'').length+2);});
          pair[1]['!cols'][index]={wch:Math.min(90,width)};
        });
      });
      if(warnings.length){summarySheet['!cols'].push({wch:90});detailSheet['!cols'].push({wch:90});}
      [[summary,summarySheet],[detail,detailSheet]].forEach(function(pair){pair[1]['!cols']=pair[0].headers.map(function(h,i){return pair[1]['!cols'][i]||{wch:Math.max(20,h.length+2)};});});
      if(summary.rows.length&&XLSX.utils.encode_range)summarySheet['!autofilter']={ref:XLSX.utils.encode_range({s:{r:0,c:0},e:{r:summary.rows.length,c:summary.headers.length-1}})};
      if(detail.rows.length&&XLSX.utils.encode_range)detailSheet['!autofilter']={ref:XLSX.utils.encode_range({s:{r:0,c:0},e:{r:detail.rows.length,c:detail.headers.length-1}})};
      for(var rowIndex=1;rowIndex<=detail.rows.length;rowIndex++){
        ['Monto','Monto Abonado','Diferencia','Suma Abonos (detalle)','Descuadre con abonos','Base Prontopago'].forEach(function(header){var cell=detailSheet[XLSX.utils.encode_cell({r:rowIndex,c:detail.headers.indexOf(header)})];if(cell&&cell.v!==''){cell.t='n';cell.z='$ #,##0';}});
        var originalCell=detailSheet[XLSX.utils.encode_cell({r:rowIndex,c:detail.headers.indexOf('Monto Abono (detalle)')})];if(originalCell)originalCell.z='$ #,##0.00';
      }
      for(var summaryIndex=1;summaryIndex<=summary.rows.length;summaryIndex++){
         ['Precio Venta','Reserva','Contra Promesa','Total Pie Diferido','Total Cuotas Diferidas','Total Cuotas','Total Pagado','Abonos en otros estados','Resguardo en Notaría','Contra Escritura','Base Prontopago','Prontopago','Total Plan','Total Abonado','Pagado en Confirmación','Saldo Pendiente'].forEach(function(header){
          var cell=summarySheet[XLSX.utils.encode_cell({r:summaryIndex,c:summary.headers.indexOf(header)})];
          if(cell&&cell.v!==''){cell.t='n';cell.z='$ #,##0';}
        });
      }
      var book=XLSX.utils.book_new();
      appendMoneyExportWarningSheet(book,warnings);
      XLSX.utils.book_append_sheet(book,totalsSheet,'Resumen');
      XLSX.utils.book_append_sheet(book,summarySheet,'Clientes');
      XLSX.utils.book_append_sheet(book,detailSheet,'Detalle Pagos');
      XLSX.writeFile(book,'conciliacion_contable_'+new Date().toISOString().substr(0,10)+'.xlsx');
      toast(warnings.length?'Excel filtrado descargado con '+warnings.length+' incidencia(s). Revise «Advertencias».':'Excel descargado con los filtros actuales: clientes y detalle de pagos',warnings.length?'warning':'success');
    }catch(error){
      console.error('No se pudo exportar el detalle contable:',error);
      toast('No se pudo generar el archivo Excel.','error');
    }
  }

  async function exportAccountingCsv(format){
    try{
    var flatRows=accountingFilteredFlatRows();
    var warnings=format==='pdf'?[]:moneyExportWarnings(flatRows.map(function(row){return row.registroId;}));
    if(!(await confirmarDescargaConciliaciones(warnings,'CSV')))return;
    await cargarMediosVisitaInforme(flatRows);
    var contacts=await cargarContactosInforme(flatRows);
    var table=accountingExportTable(flatRows,warnings,contacts);
    if(format==='pdf')return downloadTablePDF({title:'Conciliación contable · detalle de pagos',filename:'cartera_conciliacion_contable_'+new Date().toISOString().substr(0,10)+'.pdf',headers:table.headers,rows:table.rows,wrapColumns:['Cliente','RUT Cliente','Teléfono','Correo']});
    var lines=[table.headers].concat(table.rows).map(function(values,rowIndex){
      return values.map(function(value,columnIndex){
        // Con separador ';', Excel chileno reconoce la coma decimal de la UF.
        // Monto, Monto Abonado y Diferencia salen como pesos enteros.
        if(rowIndex>0&&['Tipo de Cambio (UF)','Monto Abono (detalle)'].indexOf(table.headers[columnIndex])>=0&&typeof value==='number')value=String(value).replace('.',',');
        return '"'+String(value===undefined||value===null?'':value).replace(/"/g,'""')+'"';
      }).join(';');
    });
    var blob=new Blob(['\uFEFF'+lines.join('\r\n')],{type:'text/csv;charset=utf-8'});
    var anchor=document.createElement('a');anchor.href=URL.createObjectURL(blob);
    anchor.download='cartera_conciliacion_contable_'+new Date().toISOString().substr(0,10)+'.csv';anchor.click();
    setTimeout(function(){URL.revokeObjectURL(anchor.href);},0);
    toast(warnings.length?'CSV filtrado descargado con '+warnings.length+' incidencia(s) en la última columna.':'CSV descargado con los filtros actuales y el detalle de abonos',warnings.length?'warning':'success');
    }catch(error){
      console.error('No se pudo exportar el detalle contable:',error);
      toast('No se pudo reunir la información para exportar. Intenta nuevamente.','error');
    }
  }

  if(typeof window.exportXLSX==='function'){
    var baseExportXLSX=window.exportXLSX;
    window.exportXLSX=function(view){
      if(view==='conciliacion-contable')return exportAccountingXlsx();
      if(view==='conciliaciones'){
        var plans=plansForExport();
        if(!plans)return;
        var warnings=moneyExportWarnings(plans.map(function(plan){return plan.registroId;}));
        var exportContext=this;
        return exportarTrasConfirmarIncidencias(warnings,'Excel',function(){return baseExportXLSX.call(exportContext,view,warnings);});
      }
      return baseExportXLSX.apply(this,arguments);
    };
  }
  if(typeof window.exportCSV==='function'){
    var baseExportCSV=window.exportCSV;
    window.exportCSV=function(view,format){
      if(format==='pdf'&&(view==='conciliaciones'||view==='conciliacion-contable')&&!allowMoneyExport())return;
      if(view==='conciliacion-contable')return exportAccountingCsv(format);
      if(view==='conciliaciones'){
        var plans=plansForExport();
        if(!plans)return;
        var warnings=moneyExportWarnings(plans.map(function(plan){return plan.registroId;}));
        if(format==='pdf')return baseExportCSV.call(this,view,format,warnings);
        var exportContext=this;
        return exportarTrasConfirmarIncidencias(warnings,'CSV',function(){return baseExportCSV.call(exportContext,view,format,warnings);});
      }
      return baseExportCSV.apply(this,arguments);
    };
  }
  if(typeof window.exportProyeccionCobranzaExcel==='function'){
    var baseExportProyeccion=window.exportProyeccionCobranzaExcel;
    window.exportProyeccionCobranzaExcel=function(format){
      if(format==='pdf'){
        if(!allowMoneyExport())return;
        return baseExportProyeccion.apply(this,arguments);
      }
      var projectFilter=document.getElementById('dashcc-proyecto');
      var rows=typeof getCCFlatRowsAll==='function'?getCCFlatRowsAll(projectFilter&&projectFilter.value||''):[];
      return baseExportProyeccion.call(this,format,moneyExportWarnings(rows.map(function(row){return row.registroId;})));
    };
  }

  function abonoField(value){return value===undefined||value===null?'':value;}

  function cloneAbonoForEditor(payment){
    payment=payment||{};
    return {
      monto:parseFloat(payment.monto)||0,
      fecha:abonoField(payment.fecha),
      medioPago:abonoField(payment.medioPago),
      banco:abonoField(payment.banco),
      nroDocumento:abonoField(payment.nroDocumento),
      nroCuentaCliente:abonoField(payment.nroCuentaCliente),
      rutPago:abonoField(payment.rutPago),
      titularPago:abonoField(payment.titularPago)
    };
  }

  function importedLineLabel(registroId,tipo,idx){
    var fallback=typeof labelConceptoCC==='function'?labelConceptoCC(tipo,idx):'Concepto de pago';
    var plan=typeof getConciliacionByRegistroId==='function'?getConciliacionByRegistroId(registroId):null;
    if(!plan)return fallback;
    var ref=planLineRefs(plan).find(function(item){return item.tipo===tipo&&String(item.idx)===String(idx);});
    var meta=ref&&ref.data&&ref.data.importConcept;
    return meta&&meta.numeroCuota?(conceptLabels[meta.tipo]+' '+meta.numeroCuota):fallback;
  }

  function enhanceAbonosModal(){
    var overlay=document.getElementById('modal-abonos');
    if(!overlay)return;
    var modal=overlay.querySelector&&overlay.querySelector('.modal');
    var body=overlay.querySelector&&overlay.querySelector('.modal-body');
    if(modal)modal.classList.add('abonos-modal');
    if(body)body.classList.add('abonos-modal-body');
    var intro=body&&body.firstElementChild;
    if(intro){intro.className='abonos-intro';intro.textContent='Detalle de pagos del concepto';intro.removeAttribute('style');}
    var list=document.getElementById('abonos-lista');
    if(list){list.className='abonos-list';list.removeAttribute('style');}
    var addButton=list&&list.nextElementSibling;
    if(addButton){addButton.classList.add('abonos-add');addButton.removeAttribute('style');addButton.textContent='+ Agregar abono';}
    var total=document.getElementById('abonos-total');
    if(total&&total.parentElement){total.parentElement.className='abonos-total';total.parentElement.removeAttribute('style');total.removeAttribute('style');}
  }

  function installAbonosEditor(){
    if(typeof window.abrirAbonosLinea!=='function'||typeof window.getCCLineaLiveRef!=='function')return;
    window.abrirAbonosLinea=function(registroId,tipo,idx){
      if(!canDo('Editar Conciliación Contable')){toast('Sin permiso.','error');return;}
      var linea=getCCLineaLiveRef(registroId,tipo,idx);
      if(!linea)return;
      linea=getCCLineaVista({registroId:registroId,tipo:tipo,idx:idx,linea:linea});
      abonosModalCtx={registroId:registroId,tipo:tipo,idx:idx};
      abonosDraft=(linea.abonos||[]).map(cloneAbonoForEditor);
      if(!abonosDraft.length&&linea.montoAbonado){
        abonosDraft.push(cloneAbonoForEditor({
          monto:linea.montoAbonado,fecha:linea.fechaDeposito,medioPago:linea.medioPago,banco:linea.banco,
          nroDocumento:linea.nroDocumento,nroCuentaCliente:linea.nroCuentaCliente,rutPago:linea.rutPago,titularPago:linea.titularPago
        }));
      }
      document.getElementById('abonos-modal-title').textContent='Abonos — '+importedLineLabel(registroId,tipo,idx);
      pintarAbonosDraft();
      openModal('modal-abonos');
    };

    window.pintarAbonosDraft=function(){
      var cont=document.getElementById('abonos-lista');
      if(!cont)return;
      var paymentOptions=(typeof CC_MEDIO_PAGO_OPTS!=='undefined'?CC_MEDIO_PAGO_OPTS:['','Transferencia Electrónica','Depósito','Efectivo','Cheque','Tarjeta Débito','Tarjeta Crédito','Vale Vista','Otro']);
      cont.innerHTML=abonosDraft.map(function(a,i){
        var options=paymentOptions.map(function(option){return '<option value="'+safeEsc(option)+'"'+(option===a.medioPago?' selected':'')+'>'+(option||'Seleccionar')+'</option>';}).join('');
        return '<section class="abono-card">'+
          '<header class="abono-card-head"><strong>Abono '+String(i+1).padStart(2,'0')+'</strong><button type="button" class="abono-remove" title="Eliminar este abono" aria-label="Eliminar abono '+(i+1)+'" onclick="eliminarAbonoRow('+i+')">×</button></header>'+
          '<div class="abono-grid">'+
            '<label><span>Fecha de pago</span><input type="date" id="cc-abono-fecha-'+i+'" value="'+safeEsc(a.fecha||'')+'" onchange="abonoDraftUpdate('+i+',\'fecha\',this.value)"></label>'+
            '<label><span>Monto abonado</span><input type="text" value="'+safeEsc(a.monto?('$ '+new Intl.NumberFormat('es-CL').format(a.monto)):'')+'" placeholder="$ 0" class="abono-money" oninput="fmtPrecioInput(this);abonoDraftUpdate('+i+',\'monto\',parseClpValue(this.value))"></label>'+
            '<label><span>Medio de pago</span><select onchange="abonoDraftUpdate('+i+',\'medioPago\',this.value)">'+options+'</select></label>'+
            '<label><span>Banco</span><input type="text" value="'+safeEsc(a.banco||'')+'" placeholder="Banco" onchange="abonoDraftUpdate('+i+',\'banco\',this.value)"></label>'+
            '<label><span>N° documento</span><input type="text" value="'+safeEsc(a.nroDocumento||'')+'" placeholder="N° documento" onchange="abonoDraftUpdate('+i+',\'nroDocumento\',this.value)"></label>'+
            '<label><span>N° cuenta cliente</span><input type="text" value="'+safeEsc(a.nroCuentaCliente||'')+'" placeholder="N° cuenta" onchange="abonoDraftUpdate('+i+',\'nroCuentaCliente\',this.value)"></label>'+
            '<label><span>RUT pago</span><input type="text" value="'+safeEsc(a.rutPago||'')+'" placeholder="RUT" onchange="abonoDraftUpdate('+i+',\'rutPago\',this.value)"></label>'+
            '<label class="abono-holder"><span>Titular pago</span><input type="text" value="'+safeEsc(a.titularPago||'')+'" placeholder="Titular" onchange="abonoDraftUpdate('+i+',\'titularPago\',this.value)"></label>'+
          '</div></section>';
      }).join('')||'<div class="abonos-empty">Sin abonos registrados.</div>';
      var total=abonosDraft.reduce(function(sum,item){return sum+(parseFloat(item.monto)||0);},0);
      var totalElement=document.getElementById('abonos-total');
      if(totalElement)totalElement.textContent=formatMoney(total);
    };

    window.abonoDraftUpdate=function(index,field,value){
      if(!abonosDraft[index])return;
      abonosDraft[index][field]=value;
      if(field==='monto'){
        var total=abonosDraft.reduce(function(sum,item){return sum+(parseFloat(item.monto)||0);},0);
        var totalElement=document.getElementById('abonos-total');
        if(totalElement)totalElement.textContent=formatMoney(total);
      }
    };
    window.agregarAbonoRow=function(){abonosDraft.push(cloneAbonoForEditor({}));pintarAbonosDraft();};
    window.eliminarAbonoRow=function(index){abonosDraft.splice(index,1);pintarAbonosDraft();};
    window.guardarAbonosLinea=function(){
      if(!abonosModalCtx)return;
      if(!canDo('Editar Conciliación Contable')){toast('Sin permiso.','error');return;}
      var ctx=abonosModalCtx;
      var linea=getCCLineaLiveRef(ctx.registroId,ctx.tipo,ctx.idx);
      if(!linea)return;
      var next=Object.assign({},getCCLineaVista(Object.assign({linea:linea},ctx)));
      next.abonos=abonosDraft.filter(function(a){return (parseFloat(a.monto)||0)>0;}).map(cloneAbonoForEditor);
      next.montoAbonado=typeof sumaAbonos==='function'?sumaAbonos(next):next.abonos.reduce(function(sum,a){return sum+a.monto;},0);
      if(next.abonos.length){
        var first=next.abonos[0];
        next.fechaDeposito=first.fecha||'';
        next.medioPago=first.medioPago||'';
        next.banco=first.banco||'';
        next.nroDocumento=first.nroDocumento||'';
        next.nroCuentaCliente=first.nroCuentaCliente||'';
        next.rutPago=first.rutPago||'';
        next.titularPago=first.titularPago||'';
      }
      return persistirAbonosLineaCC(ctx,linea,next,importedLineLabel(ctx.registroId,ctx.tipo,ctx.idx));
    };
  }

  function init(){
    Object.keys(configs).forEach(function(target){ensureInput(target);bindDropzone(target);});
    enhanceAbonosModal();
    installAbonosEditor();
  }

  window.__pruebaImportRuntime={
    validateTargetHeaders:validateTargetHeaders,
    makeAccessor:makeAccessor,
    buildImportedAccountingDetail:buildImportedAccountingDetail,
    canonicalPaymentMethod:canonicalPaymentMethod,
    identifierText:identifierText,
    parseImportDate:parseImportDate,
    parseMoneyImport:parseMoneyImport,
    groupConceptRows:groupConceptRows,
    consolidateImportedConcepts:consolidateImportedConcepts,
    planConceptRows:planConceptRows,
    conceptPlanTotals:conceptPlanTotals,
    accountingExportTable:accountingExportTable,
    accountingClientSummaryTable:accountingClientSummaryTable,
    accountingTotalsTable:accountingTotalsTable,
    accountingFilteredFlatRows:accountingFilteredFlatRows,
    moneyExportDiagnostics:moneyExportDiagnostics,
    moneyExportWarnings:moneyExportWarnings,
    appendMoneyExportWarningSheet:appendMoneyExportWarningSheet,
    migrateStoredImportedConcepts:migrateStoredImportedConcepts,
    auditConciliaciones:function(){return storedConciliacionIssues(null,true);},
    processFile:processFile,
    cancel:function(){cancelActive(false);},
    getActive:function(){return activeJob?{target:activeJob.target,phase:activeJob.phase,fileName:activeJob.fileName}:null;}
  };

  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});
  else init();
})();
