(function(){
  'use strict';
  var model=window.CarteraAgendaEscritura,subscriptions=new Map(),receipts=new Map(),announcements=new Set();
  var pending=new Set();window.agendaEscrituraPending=pending;
  function record(id){return (state.registros||[]).find(function(r){return String(r.id)===String(id);});}
  function allowed(r){return !!r&&esPromesadoLegal(r)&&canManagePromesado()&&(!shouldScopeRecordsToUser()||userOwnsRecord(r));}
  function recipient(r){return abogadaEscrituraConCorreo(r);}
  function requestId(){return 'agenda-'+crypto.randomUUID();}
  function key(r){return String(r.id)+'|'+model.signature(r);}
  function element(id){return document.getElementById('agenda-escritura-aviso-'+id);}
  function receiptFor(r){var value=receipts.get(String(r.id));return model.receiptMatches(r,value)?value:null;}
  function status(r){
    if(!r.abogada)return {state:'warning',text:'Sin abogada: selecciónala en la ficha.',action:'lawyer'};
    if(!recipient(r))return {state:'warning',text:'Abogada sin correo válido o inactiva. Revisa la ficha.',action:'lawyer'};
    if(!model.complete(r))return {state:'muted',text:'Completa fecha y hora para notificar.'};
    if(typeof SNAPSHOT_MODE!=='undefined'&&SNAPSHOT_MODE)return {state:'muted',text:'Modo de prueba: no envía correos.'};
    var item=receiptFor(r);
    if(item){
      if(item.status==='sent')return {state:'sent',text:'Notificación enviada a '+item.abogada+'.'};
      if(item.status==='failed')return {state:'warning',text:'Agenda guardada. No se pudo enviar el aviso; se reintentará.',action:'retry'};
      if(item.status==='needs_lawyer')return {state:'warning',text:'No hay abogada Legal activa con correo. Selecciónala en la ficha.',action:'lawyer'};
      if(item.status==='unavailable')return {state:'warning',text:'Agenda guardada. No se pudo consultar el estado del correo.'};
    }
    return r.agendaEscrituraAvisoId?{state:'pending',text:'Agenda guardada. Aviso pendiente de confirmación.'}:{state:'muted',text:'Sin aviso de agenda registrado.',action:'send'};
  }
  function paint(r){
    var target=element(r.id);if(!target)return;
    var info=status(r);target.className='agenda-escritura-aviso '+info.state;target.replaceChildren();
    target.title=info.state==='sent'?'El servicio de correo aceptó el envío. No confirma lectura ni entrega en la bandeja de entrada.':'';
    var label=document.createElement('span');label.textContent=info.text;target.appendChild(label);
    if(info.action&&allowed(r)){
      var button=document.createElement('button');button.type='button';button.className='btn btn-sm';button.disabled=pending.has(String(r.id));
      button.textContent=info.action==='lawyer'?'Seleccionar abogada':info.action==='retry'?'Reintentar aviso':'Enviar aviso';
      button.addEventListener('click',function(){
        if(info.action==='lawyer'){
          openEdit(r.id);setTimeout(function(){var select=document.getElementById('m-abogada');if(select){select.scrollIntoView({block:'center'});select.focus();}},0);
        }else window.reintentarAvisoAgendaEscritura(r.id);
      });target.appendChild(button);
    }
  }
  function consume(r,snapshot){
    if(snapshot.metadata&&(snapshot.metadata.fromCache||snapshot.metadata.hasPendingWrites))return;
    var value=snapshot.exists?snapshot.data():null;if(value)receipts.set(String(r.id),value);
    var actual=record(r.id);if(!actual)return;paint(actual);
    if(value&&model.receiptMatches(actual,value)&&announcements.has(key(actual))){
      if(value.status==='sent'){
        announcements.delete(key(actual));toast('Notificación enviada a '+value.abogada+'.','success');
      }else if(value.status==='failed')toast('La agenda se guardó, pero el correo no pudo enviarse. Se reintentará automáticamente.','error');
    }
  }
  function watch(r){
    var id=String(r.id);
    if(subscriptions.has(id)||!model.complete(r)||!currentFirebaseUser||!stateLoadedFromCloud||SNAPSHOT_MODE)return;
    subscriptions.set(id,function(){});
    var off=fbDb.collection('escritura_agenda_avisos').doc(CarteraPortfolioModel.key(id)).onSnapshot({includeMetadataChanges:true},function(snapshot){consume(r,snapshot);},function(){
      subscriptions.delete(id);var actual=record(id);if(actual){receipts.set(id,{registroId:id,signature:model.signature(actual),status:'unavailable'});paint(actual);}
    });subscriptions.set(id,off);
  }
  window.agendaEscrituraAvisoMarkup=function(r){return '<div id="agenda-escritura-aviso-'+esc(r.id)+'" class="agenda-escritura-aviso" role="status" aria-live="polite"></div>';};
  window.syncAgendaEscrituraAvisos=function(rows){
    var ids=new Set(rows.filter(model.complete).map(function(r){return String(r.id);}));
    subscriptions.forEach(function(off,id){if(!ids.has(id)){off();subscriptions.delete(id);}});
    rows.forEach(function(r){paint(r);watch(r);});
  };
  function inputs(r,disabled){
    ['fecha','hora'].forEach(function(field){var input=document.getElementById('agenda-escritura-'+field+'-'+r.id);if(input){input.value=r[field==='fecha'?'fechaAgendaEscritura':'horaAgendaEscritura']||'';input.disabled=disabled||!allowed(r);}});
  }
  async function save(r,fecha,hora,force){
    var id=String(r.id);if(!allowed(r)){toast('Sin permiso.','error');return false;}
    if(pending.has(id)||escrituraTieneGuardadoPendiente(id)){toast('Espera a que termine el guardado.','info');return false;}
    if(!SNAPSHOT_MODE&&(!currentFirebaseUser||!stateLoadedFromCloud)){inputs(r,false);toast('Espera a que cargue la sesión antes de guardar.','error');return false;}
    if((fecha&&!model.validDate(fecha))||(hora&&!/^([01]\d|2[0-3]):[0-5]\d$/.test(hora))){inputs(r,false);toast('Indica una fecha y hora válidas.','error');return false;}
    if(!fecha&&hora){inputs(r,false);toast('Indica primero la fecha de escritura.','error');return false;}
    if(fecha&&hora&&!recipient(r)){
      inputs(r,false);paint(r);toast(!r.abogada?'No hay abogada asignada. Selecciónala en la ficha antes de completar la agenda.':'Selecciona una abogada Legal activa con correo válido en la ficha.','error');return false;
    }
    if(!force&&(r.fechaAgendaEscritura||'')===fecha&&(r.horaAgendaEscritura||'')===hora)return true;
    var previous={},changes={fechaAgendaEscritura:fecha,horaAgendaEscritura:hora,agendaEscrituraAvisoId:fecha&&hora?requestId():''};
    Object.keys(changes).forEach(function(field){previous[field]={exists:Object.prototype.hasOwnProperty.call(r,field),value:r[field]};r[field]=changes[field];});
    var activity={id:'agenda-'+crypto.randomUUID(),ts:nowTs(),user:currentUser.nombre,msg:(force?'Reintento de aviso de escritura para ':'Escritura agendada para ')+(fecha?fmtDate(fecha)+(hora?' a las '+hora:' (hora pendiente)'):'sin fecha')};
    (r.actividad=r.actividad||[]).push(activity);pending.add(id);inputs(r,true);
    var announcement=key(r);if(fecha&&hora)announcements.add(announcement);
    try{
      await saveStateImmediate();
      var actual=record(id);if(!actual)return true;
      inputs(actual,true);paint(actual);watch(actual);updateTabCounts();
      if(model.signature(actual)!==model.signature(Object.assign({},actual,changes))){announcements.delete(announcement);toast('La agenda cambió en otra sesión. Revisa los datos vigentes.','info');return true;}
      toast(fecha&&hora?(SNAPSHOT_MODE?'Agenda guardada en prueba; no se envían correos.':'Agenda guardada. Enviando aviso a '+actual.abogada+'…'):'Agenda guardada. Completa fecha y hora para notificar.','success');
      return true;
    }catch(error){
      announcements.delete(announcement);var live=record(id);
      if(live){Object.keys(changes).forEach(function(field){if(live[field]===changes[field]){if(previous[field].exists)live[field]=previous[field].value;else delete live[field];}});live.actividad=(live.actividad||[]).filter(function(item){return item.id!==activity.id;});}
      stateChangeVersion++;try{localStorage.setItem(SK,JSON.stringify(state));}catch(ignore){}
      toast('No se pudo confirmar el guardado de la agenda. Revisa los datos e inténtalo nuevamente.','error');console.error('Guardar agenda de escritura:',error);return false;
    }finally{pending.delete(id);var saved=record(id);if(saved){inputs(saved,false);paint(saved);}}
  }
  window.guardarAgendaEscrituraDesdeFila=async function(id,source){
    var r=record(id),fechaEl=document.getElementById('agenda-escritura-fecha-'+id),horaEl=document.getElementById('agenda-escritura-hora-'+id);
    if(!r||!fechaEl||!horaEl)return false;
    var fecha=fechaEl.value,hora=horaEl.value;if(!fecha&&source==='fecha')hora='';
    return save(r,fecha,hora,false);
  };
  window.reintentarAvisoAgendaEscritura=function(id){var r=record(id);if(!r||!model.complete(r))return;return save(r,r.fechaAgendaEscritura,r.horaAgendaEscritura,true);};
  window.prepararAvisoAgendaAlEditarFicha=function(before,after){
    if(model.promesado(after)&&model.complete(after)&&model.normalize(before.abogada)!==model.normalize(after.abogada)){
      after.agendaEscrituraAvisoId=requestId();if(recipient(after))announcements.add(key(after));
    }
  };
  window.confirmarAvisoAgendaAlGuardarFicha=function(id){var r=record(id);if(r&&model.promesado(r)&&model.complete(r)){watch(r);paint(r);if(!recipient(r))toast('La ficha se guardó, pero falta una abogada Legal activa con correo para notificar la escritura.','error');}};
  function cleanup(){subscriptions.forEach(function(off){off();});subscriptions.clear();receipts.clear();announcements.clear();}
  if(typeof fbAuth!=='undefined'&&fbAuth)fbAuth.onAuthStateChanged(function(user){if(!user)cleanup();});
  window.addEventListener('beforeunload',cleanup);
  // Auth can finish while this last script is downloading; attach the status UI then too.
  if(stateLoadedFromCloud&&currentUser&&typeof renderPromesado==='function')renderPromesado();
})();
