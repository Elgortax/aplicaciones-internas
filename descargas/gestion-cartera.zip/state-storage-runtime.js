(function(){
  if(typeof fbDb==='undefined'||typeof stateRef==='undefined')return;
  var portfolioStore=CarteraPortfolioClient.create(fbDb);

  var planesProduccionRef=fbDb.collection('conciliaciones');
  var conciliacionesContablesProduccionRef=fbDb.collection('conciliaciones_contables');
  var validacionAdjuntosProduccionRef=fbDb.collection('validacion_adjuntos');
  var reservaAdjuntosProduccionRef=fbDb.collection('reserva_adjuntos');
  var sidecarBaselines={planes:{},contables:{},validacionAdjuntos:{}};
  var sidecarLoaded=false;
  var pendingRemoteSnapshot=null;
  var remoteApplyInFlight=false;
  var sharedRefreshPromise=null;
  var lastForegroundRefreshAt=0;
  var sidecarLoadPromise=null;
  var lastAppliedSharedVersion='';
  var recoveringFromSaveError=false;

  function sidecarClone(value){
    return JSON.parse(JSON.stringify(value==null?null:value));
  }

  function saveStep(stage,operation){
    return Promise.resolve().then(operation).catch(function(error){
      // Keep the original Firebase code, but never expose its raw message.
      if(!error||typeof error!=='object')error=new Error('No se pudo completar el guardado.');
      if(!error.syncStage)error.syncStage=stage;
      throw error;
    });
  }

  function sharedDocVersion(doc){
    try{
      var data=doc&&doc.data?doc.data():null;
      return String(data&&data.stateRevision||(doc&&doc.updateTime&&doc.updateTime.toMillis?doc.updateTime.toMillis():'')||'');
    }catch(e){return '';}
  }

  function updateSharedDataStatus(status,doc,message){
    var button=document.getElementById('shared-data-sync');
    var version=sharedDocVersion(doc)||lastAppliedSharedVersion;
    window.__sharedDataSync={
      status:status,
      version:version,
      records:Array.isArray(state&&state.registros)?state.registros.length:0,
      updatedAt:new Date().toISOString()
    };
    if(!button)return;
    button.dataset.status=status;
    button.disabled=false;
    button.setAttribute('aria-busy',status==='syncing'?'true':'false');
    var label=status==='synced'?'Datos guardados en este navegador':status==='syncing'?'Actualizando información en segundo plano':'No se pudo comprobar la última información';
    var icon=button.querySelector('span');
    if(icon)icon.textContent=status==='synced'?'✓':status==='syncing'?'↻':'!';
    button.setAttribute('aria-label',label);
    button.title=message||label+(version?' · version '+version:'');
  }

  function sidecarStable(value){
    if(Array.isArray(value))return '['+value.map(sidecarStable).join(',')+']';
    if(value&&typeof value==='object'){
      return '{'+Object.keys(value).sort().map(function(key){
        return JSON.stringify(key)+':'+sidecarStable(value[key]);
      }).join(',')+'}';
    }
    return JSON.stringify(value);
  }

  function sidecarDocId(id){
    return encodeURIComponent(String(id||'')).replace(/\./g,'%2E');
  }

  function stateWithoutHeavyCollections(value){
    var clean=sanitizeStateForCloud(value);
    delete clean.conciliaciones;
    delete clean.conciliacionesContables;
    if(Array.isArray(clean.registros))clean.registros=clean.registros.map(function(registro){
      var compacta=sidecarClone(registro||{});
      delete compacta.adjuntos;
      return compacta;
    });
    if(Array.isArray(clean.validacionesReserva)){
      clean.validacionesReserva=clean.validacionesReserva.map(function(validacion){
        var compacta=sidecarClone(validacion||{});
        delete compacta.documentos;
        return compacta;
      });
    }
    return clean;
  }

  function compactMainState(value){
    // Optional blank form values and absent values mean the same thing. Do not
    // spend the single-document budget repeating them on every record. Keep
    // histories, amounts (including 0), false, arrays and all nonempty data.
    // Compact AFTER the three-way merge so clearing a field still wins over
    // its previous remote value. Never touch roles, permissions or identities.
    var clean=sidecarClone(value);
    var optionalFields=('datosBancarios desistMot horaAgenda rut instruccion fechaFirma fechaReunion rescilEstado prioridad desistFecha rescilEstadoReserva formaPago acompanante horaReunion notaria estadoReunion desistEstado estadoPrevioDesist fechaAgendaEscritura horaAgendaEscritura desistAprobadoEmail fechaTipoCambio desistAprobadoUid desistAprobadoPor desistAprobadoEn fechaVisita cotizacionFolio admVentas obs estadoReserva abogada fechaEscritura rescilAprobadoUid rescilAprobadoPor rescilAprobadoEn rescilAprobadoEmail estadoReservaAntesEscritura email subEstadoVisita hijos edad horaVisita').split(' ');
    (clean.registros||[]).forEach(function(record){
      optionalFields.forEach(function(field){if(record[field]==='')delete record[field];});
    });
    return clean;
  }

  function validationAttachmentItems(value){
    var validations=value&&Array.isArray(value.validacionesReserva)?value.validacionesReserva:[];
    return validations.filter(function(validacion){return validacion&&validacion.id;}).map(function(validacion){
      return {
        id:String(validacion.id),
        registroId:String(validacion.registroId||validacion.reservaId||''),
        documentos:sidecarClone(Array.isArray(validacion.documentos)?validacion.documentos:[])
      };
    });
  }

  function sidecarItemsFromSnapshot(snapshot){
    return snapshot.docs.map(function(doc,index){
      var stored=doc.data()||{};
      if(stored.deleted)return null;
      return {
        position:typeof stored.position==='number'?stored.position:index,
        data:sidecarClone(stored.data||stored.item||stored)
      };
    }).filter(function(entry){return entry&&entry.data&&entry.data.id;})
      .sort(function(a,b){return a.position-b.position;})
      .map(function(entry){return entry.data;});
  }

  function validationChunkId(validationId,documentId,index){
    return sidecarDocId(validationId)+'__doc__'+sidecarDocId(documentId)+'__'+String(index).padStart(3,'0');
  }

  function validationItemsFromSnapshot(snapshot){
    var chunks={};
    snapshot.docs.forEach(function(doc){
      var stored=doc.data()||{};
      if(stored.kind==='chunk'&&stored.validationId&&stored.documentId){
        chunks[validationChunkId(stored.validationId,stored.documentId,stored.index)]=stored.data;
      }
    });
    return sidecarItemsFromSnapshot(snapshot).map(function(item){
      (item.documentos||[]).forEach(function(documento){
        if(documento.storage!=='chunks')return;
        var parts=[];
        for(var index=0;index<documento.chunkCount;index++){
          var part=chunks[validationChunkId(item.id,documento.id,index)];
          if(typeof part!=='string')throw new Error('Archivo incompleto en Validación de Reserva: '+(documento.name||documento.id));
          parts.push(part);
        }
        documento.dataUrl=parts.join('');
      });
      return item;
    });
  }

  function sidecarBaseline(items){
    var baseline={};
    (items||[]).forEach(function(item){
      if(item&&item.id)baseline[String(item.id)]=sidecarClone(item);
    });
    return baseline;
  }

  function loadSidecarCollections(forceServer){
    if(sidecarLoadPromise)return sidecarLoadPromise;
    function read(ref){return forceServer?ref.get({source:'server'}):ref.get();}
    sidecarLoadPromise=Promise.all([read(planesProduccionRef),read(conciliacionesContablesProduccionRef),read(validacionAdjuntosProduccionRef)]).then(function(results){
      var planes=sidecarItemsFromSnapshot(results[0]);
      var contables=sidecarItemsFromSnapshot(results[1]);
      var validacionAdjuntos=validationItemsFromSnapshot(results[2]);
      sidecarBaselines.planes=sidecarBaseline(planes);
      sidecarBaselines.contables=sidecarBaseline(contables);
      sidecarBaselines.validacionAdjuntos=sidecarBaseline(validacionAdjuntos);
      sidecarLoaded=true;
      return {planes:planes,contables:contables,validacionAdjuntos:validacionAdjuntos};
    });
    sidecarLoadPromise=sidecarLoadPromise.then(function(result){sidecarLoadPromise=null;return result;},function(error){sidecarLoadPromise=null;throw error;});
    return sidecarLoadPromise;
  }

  function hydrateStateWithSidecars(raw,sidecars){
    var hydrated=sidecarClone(raw||{});
    var legacyPlanes=Array.isArray(hydrated.conciliaciones)?hydrated.conciliaciones:[];
    var legacyContables=Array.isArray(hydrated.conciliacionesContables)?hydrated.conciliacionesContables:[];
    hydrated.conciliaciones=sidecars.planes.length?sidecars.planes:legacyPlanes;
    hydrated.conciliacionesContables=sidecars.contables.length?sidecars.contables:legacyContables;
    var adjuntosPorValidacion={};
    (sidecars.validacionAdjuntos||[]).forEach(function(item){
      if(item&&item.id)adjuntosPorValidacion[String(item.id)]=item;
    });
    if(Array.isArray(hydrated.validacionesReserva)){
      hydrated.validacionesReserva=hydrated.validacionesReserva.map(function(validacion){
        var completa=sidecarClone(validacion||{});
        var adjuntos=adjuntosPorValidacion[String(completa.id||'')];
        if(adjuntos)completa.documentos=sidecarClone(Array.isArray(adjuntos.documentos)?adjuntos.documentos:[]);
        else if(!Array.isArray(completa.documentos))completa.documentos=[];
        return completa;
      });
    }
    return hydrated;
  }

  function commitSidecarWrites(writes,batchLimit){
    var chain=Promise.resolve();
    var limit=batchLimit||400;
    for(var offset=0;offset<writes.length;offset+=limit){
      (function(group){
        chain=chain.then(function(){
          var batch=fbDb.batch();
          group.forEach(function(write){
            if(write.type==='hardDelete')batch.delete(write.ref);
            else if(write.type==='delete'){
              batch.set(write.ref,{
                deleted:true,
                deletedAt:firebase.firestore.FieldValue.serverTimestamp(),
                deletedBy:currentUser?{id:currentUser.id||'',uid:currentUser.uid||'',email:currentUser.email||'',nombre:currentUser.nombre||''}:null
              },{merge:true});
            }else batch.set(write.ref,write.data);
          });
          return batch.commit();
        });
      })(writes.slice(offset,offset+limit));
    }
    return chain;
  }

  function syncLegacyReservationAttachments(records){
    return Promise.resolve().then(function(){
    var metadataWrites=[];
    var chunkWrites=[];
    (records||[]).forEach(function(record){
      (Array.isArray(record&&record.adjuntos)?record.adjuntos:[]).forEach(function(file,index){
        var dataUrl=String(file&&file.dataUrl||'');
        var match=/^data:([^,]*);base64,([A-Za-z0-9+/=]+)$/i.exec(dataUrl);
        if(!match)throw new Error('Un adjunto antiguo de Reserva no se puede migrar; se detuvo el guardado para conservarlo.');
        var id='legacy_'+sidecarDocId(record.id)+'_'+sidecarDocId(file.id||index);
        var base64=match[2];
        var chunks=[];
        for(var offset=0;offset<base64.length;offset+=460800)chunks.push(base64.slice(offset,offset+460800));
        metadataWrites.push({type:'set',ref:reservaAdjuntosProduccionRef.doc(id),data:{
          kind:'meta',id:id,registroId:String(record.id),metaRegistroId:String(record.id),
          conceptKey:'reservaGeneral',metaConceptKey:'reservaGeneral',conceptType:'reservaGeneral',conceptLabel:'Reserva',
          name:String(file.name||'Archivo'),mime:String(file.type||match[1]||'application/octet-stream'),
          size:Number(file.size)||0,chunkCount:chunks.length,createdAtText:String(file.addedAt||''),
          createdBy:String(file.addedBy||'')
        }});
        chunks.forEach(function(chunk,chunkIndex){chunkWrites.push({type:'set',ref:reservaAdjuntosProduccionRef.doc(id+'_chunk_'+String(chunkIndex).padStart(3,'0')),data:{
          kind:'chunk',attachmentId:id,registroId:String(record.id),conceptKey:'reservaGeneral',index:chunkIndex,data:chunk
        }});});
      });
    });
    return commitSidecarWrites(chunkWrites,12).then(function(){
      return commitSidecarWrites(metadataWrites,100);
    });
    });
  }

  function collectPaymentWrites(ref,items,baselineKey){
    var baseline=sidecarBaselines[baselineKey]||{};
    var current={};
    var writes=[];
    (items||[]).forEach(function(item,index){
      if(!item)return;
      if(!item.id)item.id=(baselineKey==='planes'?'cc':'ccc')+Date.now()+Math.random().toString(36).slice(2,7);
      var id=String(item.id);
      current[id]=sidecarClone(item);
      if(!baseline[id]||sidecarStable(baseline[id])!==sidecarStable(item)){
        writes.push({
          type:'set',
          ref:ref.doc(sidecarDocId(id)),
          registroId:item.registroId,
          data:{
            data:sidecarClone(item),
            position:index,
            updatedAt:firebase.firestore.FieldValue.serverTimestamp(),
            updatedBy:currentUser?{id:currentUser.id||'',uid:currentUser.uid||'',email:currentUser.email||'',nombre:currentUser.nombre||''}:null
          }
        });
      }
    });
    Object.keys(baseline).forEach(function(id){
      if(!current[id])writes.push({type:'delete',ref:ref.doc(sidecarDocId(id)),registroId:baseline[id].registroId});
    });
    return {writes:writes,current:current};
  }

  function syncPaymentSidecars(capturedState){
    var planes=collectPaymentWrites(planesProduccionRef,capturedState.conciliaciones,'planes');
    var contables=collectPaymentWrites(conciliacionesContablesProduccionRef,capturedState.conciliacionesContables,'contables');
    // Un pago en UF puede cambiar ambos documentos. Mantener las escrituras
    // de una misma ficha en el mismo lote atómico, incluso al dividir tandas.
    var porFicha=new Map();
    planes.writes.concat(contables.writes).forEach(function(write){
      var key=write.registroId?String(write.registroId):write;
      if(!porFicha.has(key))porFicha.set(key,[]);
      porFicha.get(key).push(write);
    });
    var batches=[],batch=[];
    porFicha.forEach(function(writes){
      if(batch.length+writes.length>400&&batch.length){
        batches.push(batch);
        batch=[];
      }
      batch=batch.concat(writes);
    });
    batches.push(batch);
    return batches.reduce(function(chain,writes){
      return chain.then(function(){return commitSidecarWrites(writes);});
    },Promise.resolve()).then(function(){
      sidecarBaselines.planes=planes.current;
      sidecarBaselines.contables=contables.current;
    });
  }

  function syncValidationAttachments(items){
    var baseline=sidecarBaselines.validacionAdjuntos||{};
    var current={};
    var chain=Promise.resolve();
    (items||[]).forEach(function(item,index){
      if(!item||!item.id)return;
      var id=String(item.id);
      current[id]=sidecarClone(item);
      if(baseline[id]&&sidecarStable(baseline[id])===sidecarStable(item))return;
      var oldDocs=Array.isArray(baseline[id]&&baseline[id].documentos)?baseline[id].documentos:[];
      var localDocs=Array.isArray(item.documentos)?item.documentos:[];
      localDocs.forEach(function(doc,docIndex){
        if(!doc.id)doc.id='doc'+docIndex;
        var previous=oldDocs.find(function(old){return String(old.id)===String(doc.id);})||null;
        if(previous&&sidecarStable(previous)===sidecarStable(doc))return;
        chain=chain.then(function(){return syncValidationFile(item,index,previous,doc);});
      });
      oldDocs.forEach(function(old){
        if(localDocs.some(function(doc){return String(doc.id)===String(old.id);}))return;
        // La copia automática no se elimina al editar una ficha o comprobante.
        if(old.documentKind==='cotizacion'&&old.automatico===true)return;
        chain=chain.then(function(){return syncValidationFile(item,index,old,null);});
      });
      // Una validación recibida al fusionar otra sesión puede no tener sus
      // documentos cargados. Leerlos, nunca reemplazarlos por una lista vacía.
      chain=chain.then(function(){return readValidationAttachmentItem(item);}).then(function(complete){current[id]=complete;});
    });
    Object.keys(baseline).forEach(function(id){
      if(current[id])return;
      chain=chain.then(function(){return fbDb.runTransaction(function(tx){
        var ref=validacionAdjuntosProduccionRef.doc(sidecarDocId(id));
        return tx.get(ref).then(function(snapshot){
          if(!snapshot.exists||snapshot.data().deleted)return;
          var remote=snapshot.data().data;
          var expected=sidecarClone(baseline[id]);
          expected.documentos=expected.documentos.map(validationStoredFile);
          if(sidecarStable(remote)!==sidecarStable(expected))throw new Error('Los adjuntos cambiaron en otra sesión. Actualiza antes de eliminar la validación.');
          tx.set(ref,{deleted:true,deletedAt:firebase.firestore.FieldValue.serverTimestamp(),deletedBy:currentUser?{uid:currentUser.uid||''}:null},{merge:true});
        });
      });});
    });
    return chain.then(function(){
      sidecarBaselines.validacionAdjuntos=current;
      return Object.keys(current).map(function(id){return sidecarClone(current[id]);});
    });
  }

  function validationStoredFile(file){
    var stored=sidecarClone(file);
    if(stored.storage==='chunks')delete stored.dataUrl;
    return stored;
  }

  function readValidationFile(file,validationId,read){
    if(file.storage!=='chunks')return Promise.resolve(sidecarClone(file));
    if(!Number.isInteger(file.chunkCount)||file.chunkCount<1)return Promise.reject(new Error('Archivo incompleto en Validación.'));
    var reads=[];
    for(var i=0;i<file.chunkCount;i++)reads.push(read(validacionAdjuntosProduccionRef.doc(validationChunkId(validationId,file.id,i))));
    return Promise.all(reads).then(function(parts){
      var complete=sidecarClone(file);
      complete.dataUrl=parts.map(function(part){if(!part.exists||typeof part.data().data!=='string')throw new Error('Fragmento ausente en Validación.');return part.data().data;}).join('');
      return complete;
    });
  }

  function readValidationAttachmentItem(item){
    return validacionAdjuntosProduccionRef.doc(sidecarDocId(item.id)).get({source:'server'}).then(function(snapshot){
      if(!snapshot.exists)return {id:String(item.id),registroId:String(item.registroId||''),documentos:[]};
      if(snapshot.data().deleted)throw new Error('La validación fue eliminada en otra sesión. Actualiza los datos.');
      var complete=sidecarClone(snapshot.data().data);
      if(String(complete.registroId)!==String(item.registroId))throw new Error('La validación pertenece a otra ficha.');
      return Promise.all((complete.documentos||[]).map(function(file){return readValidationFile(file,item.id,function(ref){return ref.get({source:'server'});});})).then(function(files){complete.documentos=files;return complete;});
    });
  }

  function syncValidationFile(item,position,previous,next){
    var validationId=String(item.id),fileId=String((next||previous).id);
    var ref=validacionAdjuntosProduccionRef.doc(sidecarDocId(validationId));
    // Una transacción por archivo mantiene los límites actuales (5 MB por
    // archivo / 8 MB total) y publica contenido + referencia juntos.
    return fbDb.runTransaction(function(tx){
      return tx.get(ref).then(function(snapshot){
        var stored=snapshot.exists?snapshot.data():{};
        if(stored.deleted)throw new Error('La validación fue eliminada en otra sesión. Actualiza los datos.');
        var remote=sidecarClone(stored.data||{id:validationId,registroId:String(item.registroId||''),documentos:[]});
        if(String(remote.registroId)!==String(item.registroId))throw new Error('La validación pertenece a otra ficha.');
        var files=remote.documentos||[],old=files.find(function(file){return String(file.id)===fileId;});
        return (old?readValidationFile(old,validationId,function(chunk){return tx.get(chunk);}):Promise.resolve(null)).then(function(fullOld){
          function sameFile(a,b){
            if(!a||!b)return a===b;
            var x=sidecarClone(a),y=sidecarClone(b);delete x.storage;delete x.chunkCount;delete y.storage;delete y.chunkCount;
            return sidecarStable(x)===sidecarStable(y);
          }
          if(sameFile(fullOld,next))return; // Reintento de una escritura ya confirmada.
          if(!sameFile(fullOld,previous))throw new Error('Este archivo cambió en otra sesión. Actualiza los adjuntos antes de volver a guardar.');
          var parts=[],metadata=next&&sidecarClone(next);
          if(next){
            var dataUrl=String(next.dataUrl||'');
            if(!/^data:[^,]*;base64,/i.test(dataUrl))throw new Error('No se recibió el contenido completo del archivo.');
            for(var offset=0;offset<dataUrl.length;offset+=460800)parts.push(dataUrl.slice(offset,offset+460800));
            delete metadata.dataUrl;metadata.storage='chunks';metadata.chunkCount=parts.length;
          }
          // Todas las lecturas preceden a las escrituras. Los archivos de otras
          // sesiones se conservan; solo cambia el archivo que el usuario editó.
          parts.forEach(function(data,index){tx.set(validacionAdjuntosProduccionRef.doc(validationChunkId(validationId,fileId,index)),{
            kind:'chunk',validationId:validationId,registroId:String(item.registroId||''),documentId:fileId,index:index,data:data
          });});
          for(var index=parts.length;index<(old&&old.storage==='chunks'?old.chunkCount:0);index++)tx.delete(validacionAdjuntosProduccionRef.doc(validationChunkId(validationId,fileId,index)));
          var found=files.findIndex(function(file){return String(file.id)===fileId;});
          if(metadata){if(found>=0)files[found]=metadata;else files.push(metadata);}
          else if(found>=0)files.splice(found,1);
          remote.documentos=files;
          tx.set(ref,{data:remote,position:stored.position==null?position:stored.position,updatedAt:firebase.firestore.FieldValue.serverTimestamp(),
            updatedBy:currentUser?{id:currentUser.id||'',uid:currentUser.uid||'',email:currentUser.email||'',nombre:currentUser.nombre||''}:null});
        });
      });
    });
  }

  function syncHeavyStateCollections(capturedState){
    return Promise.all([
      saveStep('adjuntos-reserva',function(){return syncLegacyReservationAttachments(capturedState.registros||[]);}),
      saveStep('planes-pago y conciliaciones',function(){return syncPaymentSidecars(capturedState);}),
      saveStep('adjuntos-validacion',function(){return syncValidationAttachments(validationAttachmentItems(capturedState)).then(function(items){
        var byId={};items.forEach(function(item){byId[String(item.id)]=item;});
        (capturedState.validacionesReserva||[]).forEach(function(item){if(byId[String(item.id)])item.documentos=sidecarClone(byId[String(item.id)].documentos);});
      });})
    ]);
  }

  function assertNoUnexpectedMassDeletion(base,current){
    [
      {label:'registros',before:base.registros,after:current.registros,min:50},
      {label:'planes de pago',before:base.conciliaciones,after:current.conciliaciones,min:20},
      {label:'conciliaciones',before:base.conciliacionesContables,after:current.conciliacionesContables,min:20}
    ].forEach(function(group){
      var before=Array.isArray(group.before)?group.before.length:0;
      var after=Array.isArray(group.after)?group.after.length:0;
      var recordsMustNeverShrink=group.label==='registros'&&after<before;
      var otherMassDeletion=group.label!=='registros'&&before>=group.min&&after<Math.ceil(before*.8);
      if(recordsMustNeverShrink||otherMassDeletion){
        throw new Error('Proteccion activa: se bloqueo una eliminacion masiva de '+group.label+' ('+before+' a '+after+').');
      }
    });
  }

  function rerenderSharedState(){
    if(currentUser)currentUser=findProfileForFirebaseUser(currentFirebaseUser)||currentUser;
    try{localStorage.setItem(SK,JSON.stringify(state));}catch(e){}
    if(currentUser&&document.getElementById('app').style.display!=='none'){
      populateFilters();
      renderAll();
      if(document.getElementById('panel-admin').classList.contains('active'))renderAdmin();
      if(document.getElementById('panel-graficos').classList.contains('active'))renderCharts();
      if(document.getElementById('panel-dash-reserva').classList.contains('active'))renderReservaDash();
      if(document.getElementById('panel-vendedor').classList.contains('active'))renderVendedorDash();
      if(document.getElementById('panel-reuniones').classList.contains('active'))renderReuniones();
    }
  }

  function applySharedSnapshot(doc,sidecars){
    state=normalizeStateShape(hydrateStateWithSidecars(doc.data().state,sidecars));
    syncPermisos();
    cloudBaselineState=sanitizeStateForCloud(state);
    stateDirty=false;
    lastAppliedSharedVersion=sharedDocVersion(doc)||lastAppliedSharedVersion;
    rerenderSharedState();
    updateSharedDataStatus(doc.metadata&&doc.metadata.fromCache?'stale':'synced',doc);
  }

  function drainRemoteSnapshot(){
    if(remoteApplyInFlight||!pendingRemoteSnapshot)return Promise.resolve(false);
    if(stateDirty||cloudSaveInFlight){
      updateSharedDataStatus('syncing',null,'Guardando cambios antes de recibir la ultima version');
      return Promise.resolve(false);
    }
    var doc=pendingRemoteSnapshot;
    pendingRemoteSnapshot=null;
    var version=sharedDocVersion(doc);
    if(sidecarLoaded&&version&&version===lastAppliedSharedVersion){
      updateSharedDataStatus('synced',doc,'Información confirmada; no hubo cambios');
      return Promise.resolve(false);
    }
    remoteApplyInFlight=true;
    var remoteApplyFailed=false;
    return portfolioStore.read().then(function(completeDoc){
      doc=completeDoc;
      return loadSidecarCollections(true);
    }).then(function(sidecars){
      if(stateDirty||cloudSaveInFlight){
        pendingRemoteSnapshot=doc;
        return false;
      }
      applySharedSnapshot(doc,sidecars);
      return true;
    }).catch(function(err){
      remoteApplyFailed=true;
      pendingRemoteSnapshot=doc;
      updateSharedDataStatus('stale',doc,'No se pudo recibir la ultima version');
      console.error(err);
      notifyCloudIssue(err,'sincronizar');
      return false;
    }).finally(function(){
      remoteApplyInFlight=false;
      if(pendingRemoteSnapshot&&!stateDirty&&!cloudSaveInFlight)setTimeout(drainRemoteSnapshot,remoteApplyFailed?3000:0);
    });
  }

  saveStateNow=function(){
    if(SNAPSHOT_MODE){stateDirty=false;return Promise.resolve(sanitizeStateForCloud(state));}
    if(!stateLoadedFromCloud)return Promise.reject(new Error('La base compartida todavía no está disponible para guardar.'));
    if(!stateDirty)return Promise.resolve(sanitizeStateForCloud(state));
    if(cloudSaveInFlight)return cloudSavePromise||Promise.resolve();
    cloudSaveInFlight=true;
    updateSharedDataStatus('syncing',null,'Guardando en la demo local');

    function flushChanges(){
      if(!stateDirty)return Promise.resolve(sanitizeStateForCloud(state));
      var capturedVersion=stateChangeVersion;
      var capturedLocal=sanitizeStateForCloud(state);
      var capturedBase=sidecarClone(cloudBaselineState||capturedLocal);
      assertNoUnexpectedMassDeletion(capturedBase,capturedLocal);
      var capturedMain=stateWithoutHeavyCollections(capturedLocal);
      var capturedBaseMain=stateWithoutHeavyCollections(capturedBase);

      return syncHeavyStateCollections(capturedLocal).then(function(){
        return saveStep('guardar-ficha',function(){return portfolioStore.runTransaction(function(tx){
          return tx.get(stateRef).then(function(doc){
            var remoteRecords=doc.exists&&doc.data()&&doc.data().state&&Array.isArray(doc.data().state.registros)?doc.data().state.registros:[];
            remoteRecords.forEach(function(remoteRecord){
              (Array.isArray(remoteRecord.adjuntos)?remoteRecord.adjuntos:[]).forEach(function(remoteFile,index){
                var localRecord=(capturedLocal.registros||[]).find(function(item){return String(item.id)===String(remoteRecord.id);});
                var localFile=localRecord&&(localRecord.adjuntos||[]).find(function(item,localIndex){return String(item.id||localIndex)===String(remoteFile.id||index);});
                if(!localFile||localFile.dataUrl!==remoteFile.dataUrl)throw new Error('Se recibieron adjuntos antiguos nuevos de otra sesión. Actualiza los datos antes de guardar para conservarlos.');
              });
            });
            var remote=doc.exists&&doc.data()&&doc.data().state?stateWithoutHeavyCollections(doc.data().state):{};
            var mergedMain=mergeStateThreeWay(capturedBaseMain,capturedMain,remote);
            var payload={
              state:compactMainState(mergedMain),
              stateRevision:firebase.firestore.FieldValue.increment(1),
              updatedAt:firebase.firestore.FieldValue.serverTimestamp(),
              updatedBy:currentUser?{id:currentUser.id||'',uid:currentUser.uid||'',email:currentUser.email||'',nombre:currentUser.nombre||''}:null
            };
            if(doc.exists)tx.update(stateRef,payload);
            else tx.set(stateRef,payload);
            return mergedMain;
          });
        });});
      }).then(function(mergedMain){
        return saveStep('actualizar-pantalla',function(){
        var merged=hydrateStateWithSidecars(mergedMain,{
          planes:sidecarClone(capturedLocal.conciliaciones||[]),
          contables:sidecarClone(capturedLocal.conciliacionesContables||[]),
          validacionAdjuntos:validationAttachmentItems(capturedLocal)
        });
        var currentLocal=sanitizeStateForCloud(state);
        cloudBaselineState=sidecarClone(merged);
        if(stateChangeVersion===capturedVersion){
          state=normalizeStateShape(merged);
          syncPermisos();
          stateDirty=false;
        }else{
          state=normalizeStateShape(mergeStateThreeWay(capturedLocal,currentLocal,merged));
          syncPermisos();
          stateDirty=true;
        }
        try{localStorage.setItem(SK,JSON.stringify(state));}catch(e){}
        return stateDirty?flushChanges():merged;
        });
      });
    }

    // Synchronous validation/serialization errors must reach catch/finally too;
    // otherwise cloudSaveInFlight stays true and later saves falsely resolve.
    cloudSavePromise=saveStep('preparar-ficha',flushChanges).then(function(result){
      cloudSaveRetryDelay=3000;
      if(cloudSaveRetryTimer){clearTimeout(cloudSaveRetryTimer);cloudSaveRetryTimer=null;}
      updateSharedDataStatus('synced',null,'Cambios guardados localmente');
      if(typeof setReservaSaveError==='function')setReservaSaveError(null);
      if(recoveringFromSaveError){
        recoveringFromSaveError=false;
        if(typeof toast==='function')toast('Los cambios pendientes ya se sincronizaron con el servidor.','success');
      }
      return result;
    }).catch(function(err){
      console.error(err);
      stateDirty=true;
      recoveringFromSaveError=true;
      updateSharedDataStatus('stale',null,'Hay cambios pendientes de sincronizar');
      notifyCloudIssue(err,'guardar');
      scheduleCloudSaveRetry();
      throw err;
    }).finally(function(){
      cloudSaveInFlight=false;
      cloudSavePromise=null;
      if(pendingRemoteSnapshot)setTimeout(drainRemoteSnapshot,0);
    });
    return cloudSavePromise;
  };

  loadCloudState=function(){
    updateSharedDataStatus('syncing',null,'Cargando la base compartida');
    return portfolioStore.read().then(function(doc){
      if(!doc.exists||!doc.data()||!doc.data().state)throw new Error('La base compartida no contiene un estado valido.');
      state=normalizeStateShape(doc.data().state);
      syncPermisos();
      cloudBaselineState=sanitizeStateForCloud(state);
      stateDirty=false;
      stateLoadedFromCloud=true;
      try{localStorage.setItem(SK,JSON.stringify(state));}catch(e){}
      updateSharedDataStatus('syncing',doc,'Cargando conciliaciones en segundo plano');
      loadSidecarCollections(true).then(function(sidecars){
        if(stateDirty||cloudSaveInFlight){pendingRemoteSnapshot=doc;return false;}
        applySharedSnapshot(doc,sidecars);
        return true;
      }).catch(function(err){
        console.error(err);
        updateSharedDataStatus('stale',doc,'No se pudieron cargar las conciliaciones; el resto del sistema sigue disponible');
        notifyCloudIssue(err,'cargar');
      }).finally(function(){startStateListener();});
      return true;
    }).catch(function(err){
      console.error(err);
      stateLoadedFromCloud=false;
      updateSharedDataStatus('stale',null,'Sin conexion con la base compartida');
      notifyCloudIssue(err,'cargar');
      scheduleCloudLoadRetry();
      return false;
    });
  };

  startStateListener=function(){
    if(unsubscribeState)unsubscribeState();
    unsubscribeState=stateRef.onSnapshot(function(doc){
      if(!doc.exists||!doc.data()||!doc.data().state||doc.metadata.hasPendingWrites)return;
      pendingRemoteSnapshot=doc;
      drainRemoteSnapshot();
    },function(err){
      console.error(err);
      notifyCloudIssue(err,'sincronizar');
      setTimeout(function(){if(currentFirebaseUser)startStateListener();},8000);
    });
  };

  window.refreshSharedData=function(manual){
    if(sharedRefreshPromise)return sharedRefreshPromise;
    updateSharedDataStatus('syncing',null,manual?'Actualizando datos':'Comprobando datos');
    var saveFirst=stateDirty?saveStateNow():Promise.resolve();
    sharedRefreshPromise=saveFirst.then(function(){
      return portfolioStore.read();
    }).then(function(doc){
      if(!doc.exists||!doc.data()||!doc.data().state)throw new Error('La base compartida no contiene un estado valido.');
      var version=sharedDocVersion(doc);
      if(sidecarLoaded&&version&&version===lastAppliedSharedVersion){
        updateSharedDataStatus('synced',doc,'Información confirmada; no hubo cambios');
        return window.__sharedDataSync;
      }
      return loadSidecarCollections(true).then(function(sidecars){
        applySharedSnapshot(doc,sidecars);
        return window.__sharedDataSync;
      });
    }).catch(function(err){
      updateSharedDataStatus('stale',null,'No se pudo comprobar la ultima version');
      notifyCloudIssue(err,'sincronizar');
      throw err;
    }).finally(function(){sharedRefreshPromise=null;});
    return sharedRefreshPromise;
  };

  function refreshOnForeground(){
    if(!currentFirebaseUser||document.visibilityState==='hidden')return;
    var now=Date.now();
    if(now-lastForegroundRefreshAt<60000)return;
    lastForegroundRefreshAt=now;
    window.refreshSharedData(false).catch(function(){});
  }

  document.addEventListener('visibilitychange',refreshOnForeground);
  window.addEventListener('focus',refreshOnForeground);
  window.addEventListener('online',function(){lastForegroundRefreshAt=0;refreshOnForeground();});

  window.__productionSidecarStorage={
    version:'2026-09-14.1',
    isLoaded:function(){return sidecarLoaded;},
    reload:loadSidecarCollections,
    compactMainState:compactMainState
  };
})();
