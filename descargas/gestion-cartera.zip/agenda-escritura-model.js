(function(root,factory){
  'use strict';var api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;else root.CarteraAgendaEscritura=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  function text(value){return String(value==null?'':value).trim();}
  function normalize(value){return text(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ');}
  function validDate(value){
    if(!/^\d{4}-\d{2}-\d{2}$/.test(text(value)))return false;
    var date=new Date(value+'T12:00:00Z');return !isNaN(date.getTime())&&date.toISOString().slice(0,10)===value;
  }
  function complete(record){return !!record&&validDate(record.fechaAgendaEscritura)&&/^([01]\d|2[0-3]):[0-5]\d$/.test(text(record.horaAgendaEscritura));}
  function promesado(r){
    if(!r)return false;
    var signed=r.estado==='Firmado'||(r.estado==='Resciliación'&&r.rescilEstado==='pendiente')||(r.estado==='Desistido'&&r.desistEstado==='pendiente'&&r.estadoPrevioDesist==='Firmado');
    return signed&&!['escritura','escriturado'].includes(normalize(r.etapaLegal))&&normalize(r.estadoReserva)!=='escriturado'&&!r.fechaEscritura;
  }
  function signature(r){r=r||{};return JSON.stringify([text(r.fechaAgendaEscritura),text(r.horaAgendaEscritura),normalize(r.abogada),text(r.agendaEscrituraAvisoId)]);}
  function changed(before,after){
    return promesado(after)&&complete(after)&&signature(before)!==signature(after);
  }
  function receiptMatches(record,receipt){return !!receipt&&text(receipt.registroId)===text(record.id)&&receipt.signature===signature(record);}
  return {text:text,normalize:normalize,validDate:validDate,complete:complete,promesado:promesado,signature:signature,changed:changed,receiptMatches:receiptMatches};
});
