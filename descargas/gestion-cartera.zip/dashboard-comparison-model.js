(function(root,factory){
  'use strict';
  var api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.DashboardComparisonModel=api;
})(typeof window!=='undefined'?window:globalThis,function(){
  'use strict';
  function validMonth(value){return typeof value==='string'&&/^\d{4}-(0[1-9]|1[0-2])$/.test(value)&&Number(value.slice(0,4))>=1900;}
  function daysInMonth(month){
    if(!validMonth(month))return 0;
    var year=Number(month.slice(0,4)),m=Number(month.slice(5));
    return m===2?(year%4===0&&(year%100!==0||year%400===0)?29:28):[4,6,9,11].indexOf(m)>=0?30:31;
  }
  function validDate(value){return typeof value==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(value)&&validMonth(value.slice(0,7))&&Number(value.slice(8))>=1&&Number(value.slice(8))<=daysInMonth(value.slice(0,7));}
  function cutoff(month,day){return month+'-'+String(Math.min(day,daysInMonth(month))).padStart(2,'0');}
  function previousMonths(month,count){
    var year=Number(month.slice(0,4)),m=Number(month.slice(5)),out=[];
    for(var i=0;i<count;i++){m--;if(!m){year--;m=12;}out.unshift(year+'-'+String(m).padStart(2,'0'));}
    return out;
  }
  function saleAmount(value){
    if(typeof value==='number')return Number.isFinite(value)&&value>=0?value:null;
    if(typeof value!=='string'||!value.trim())return null;
    var s=value.trim().replace(/^(?:CLP\s*|\$\s*)/i,'').replace(/\s+/g,'');
    if(/^\d{1,3}(\.\d{3})+(,\d+)?$/.test(s))s=s.replace(/\./g,'').replace(',','.');
    else if(/^\d+(,\d+)?$/.test(s))s=s.replace(',','.');
    if(!/^\d+(\.\d+)?$/.test(s))return null;
    var n=Number(s);return Number.isFinite(n)&&n>=0?n:null;
  }
  function metric(){return {count:0,amount:0,missing:0};}
  function add(target,amount){target.count++;if(amount===null)target.missing++;else target.amount+=amount;}
  function build(records,options){
    options=options||{};
    var target=options.month,day=Number(options.day),today=options.today;
    if(!validDate(today))throw new Error('No se pudo determinar la fecha actual.');
    if(!validMonth(target)||target>today.slice(0,7))throw new Error('Elige un mes de comparación válido, hasta el mes actual.');
    if(!Number.isInteger(day)||day<1||day>31)throw new Error('Elige un día de corte entre 1 y 31.');
    var months=Array.from(new Set(options.months||[]));
    if(months.some(function(m){return !validMonth(m)||m>today.slice(0,7);}))throw new Error('Los meses del promedio deben ser válidos y no futuros.');
    months=months.filter(function(m){return m!==target;}).sort();
    var rows=months.concat([target]).map(function(m){var future=cutoff(m,day)>today;return {month:m,cutoff:cutoff(m,day),provisional:m===today.slice(0,7),futureCutoff:future,target:m===target,source:future?'future':'current',accumulated:future?null:metric(),closing:metric()};});
    var byMonth=new Map(rows.map(function(row){return [row.month,row];}));
    var invalidDates=0,seen=new Set();
    var normalizeDate=options.normalizeDate||function(v){return String(v||'');};
    var getState=options.getState||function(r){return r.estado;};
    var scope=options.scope||function(){return true;};
    (records||[]).filter(scope).forEach(function(r){
      if(!r||typeof r!=='object')return;
      // Una ficha por ID, nunca deduplicar por cliente/lote (pueden existir ventas diferentes).
      if(r.id){var id=String(r.id);if(seen.has(id))return;seen.add(id);}
      var state=getState(r),signed=state==='Firmado',rescinded=state==='Resciliación';
      if(!signed&&!rescinded)return;
      // El acumulado usa SOLO Firmado actual y su fecha de firma, no la agenda.
      var date=normalizeDate(r.fechaFirma);
      if(!validDate(date)){invalidDates++;return;}
      var row=byMonth.get(date.slice(0,7));if(!row)return;
      var amount=saleAmount(r.precio);
      // El cierre usa todo el mes de firma, no la fecha posterior de resciliación ni el corte.
      if(signed||rescinded)add(row.closing,amount);
      if(signed&&row.accumulated&&date<=row.cutoff)add(row.accumulated,amount);
    });
    var average={months:months.length,accumulated:metric(),closing:metric()};
    var complete=true;
    rows.filter(function(row){return !row.target;}).forEach(function(row){
      if(!row.accumulated)complete=false;
      ['accumulated','closing'].forEach(function(key){if(row[key])['count','amount','missing'].forEach(function(field){average[key][field]+=row[key][field];});});
    });
    if(months.length)['accumulated','closing'].forEach(function(key){average[key].count/=months.length;average[key].amount/=months.length;});
    if(!complete)average.accumulated=null;
    return {day:day,rows:rows,average:average,invalidDates:invalidDates};
  }
  return {build:build,validMonth:validMonth,validDate:validDate,daysInMonth:daysInMonth,previousMonths:previousMonths,saleAmount:saleAmount,cutoff:cutoff};
});
