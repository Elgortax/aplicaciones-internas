(function(){
  'use strict';
  var model=window.CarteraConciliacionAudit;
  var labels={sobrepago:'Sobrepago',saldo:'Pagado con saldo',detalle:'Descuadre de abonos',estado:'Estado pendiente',invalido:'Monto inválido'};
  function allowed(){return !!currentUser&&puedeVerVista('conciliacion-contable');}
  function el(tag,text,className){
    var node=document.createElement(tag);if(text!=null)node.textContent=text;if(className)node.className=className;return node;
  }
  function money(value){return value==null?'—':'$'+value.toLocaleString('es-CL',{maximumFractionDigits:0});}
  function pending(row){return !!getCCMontoDraft(row.registroId,row.tipo,row.idx);}
  function closeReview(){if(document.getElementById('modal-cc-audit'))closeModal('modal-cc-audit');}
  function report(rows){
    var result=model.analyze(rows,getCCLineaVista);
    result.items.forEach(function(item){item.pending=pending(item);});
    result.hasDrafts=rows.some(pending);
    return result;
  }
  function fresh(){return allowed()?report(getCCFlatRows()):null;}
  function styles(){
    if(document.getElementById('cc-audit-style'))return;
    var style=el('style');style.id='cc-audit-style';
    style.textContent=`
      .cc-audit-banner{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin:0 0 12px;padding:12px 14px;border:1px solid var(--border);border-left:4px solid var(--green);border-radius:var(--r);background:var(--bg2)}
      .cc-audit-banner.has-issues{border-left-color:var(--orange)}
      .cc-audit-banner[hidden]{display:none}
      .cc-audit-banner strong{font-size:12px;color:var(--text)}
      .cc-audit-banner p{margin:4px 0 0;font-size:11px;color:var(--text2);line-height:1.5}
      .cc-audit-banner>div{flex:1;min-width:180px}.cc-audit-banner button{flex-shrink:0}
      #modal-cc-audit .modal{width:min(1180px,96vw);max-width:1180px}
      #modal-cc-audit .modal-body{padding:16px;min-width:0}
      .cc-audit-note{font-size:12px;color:var(--text2);line-height:1.6;margin:0 0 12px}
      .cc-audit-counts{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 14px}
      .cc-audit-counts span{font-size:11px;padding:5px 9px;background:var(--slate);border:1px solid var(--border);border-radius:20px;color:var(--text)}
      .cc-audit-scroll{max-height:55vh;overflow:auto;border:1px solid var(--border);border-radius:var(--r)}
      .cc-audit-table{width:100%;min-width:1040px;border-collapse:collapse;font-size:11px}
      .cc-audit-table th,.cc-audit-table td{padding:10px;border-bottom:1px solid var(--border);text-align:left;vertical-align:top}
      .cc-audit-table th{position:sticky;top:0;background:var(--slate);z-index:1;white-space:nowrap}
      .cc-audit-table td{color:var(--text)}.cc-audit-table .cc-audit-number{text-align:right;white-space:nowrap;font-variant-numeric:tabular-nums}
      .cc-audit-client{min-width:180px;max-width:240px;overflow-wrap:anywhere}.cc-audit-observation{min-width:280px;max-width:370px}
      .cc-audit-observation p{margin:0 0 6px;line-height:1.5}.cc-audit-draft{display:block;color:var(--orange);font-size:10px;margin-top:5px}
      .cc-audit-empty{padding:24px;color:var(--text2);text-align:center}
      @media(max-width:600px){#modal-cc-audit .modal-body{padding:12px}.cc-audit-banner button{width:100%;justify-content:center}}
    `;
    document.head.appendChild(style);
  }
  function ensureModal(){
    if(document.getElementById('modal-cc-audit'))return;
    var overlay=el('div');overlay.id='modal-cc-audit';overlay.className='modal-overlay';
    overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-labelledby','cc-audit-title');
    var modal=el('div',null,'modal'),header=el('div',null,'modal-head');
    var title=el('h3','Inconsistencias en la conciliación');title.id='cc-audit-title';
    var close=el('button','✕','modal-close');close.type='button';close.setAttribute('aria-label','Cerrar revisión');close.onclick=function(){closeModal(overlay.id);};
    header.append(title,close);
    var body=el('div',null,'modal-body');body.id='cc-audit-body';
    var footer=el('div',null,'modal-footer');
    var refresh=el('button','Actualizar','btn btn-ghost');refresh.type='button';refresh.onclick=openReport;
    var download=el('button','↓ Excel de inconsistencias','btn btn-primary');download.id='cc-audit-export';download.type='button';download.onclick=exportReport;
    footer.append(refresh,download);modal.append(header,body,footer);overlay.appendChild(modal);document.body.appendChild(overlay);
  }
  function drawReport(result){
    var body=document.getElementById('cc-audit-body');body.replaceChildren();
    var note=result.linesReviewed+' líneas revisadas con los filtros y permisos actuales. Los importes se comparan en pesos enteros. Una línea puede tener más de una alerta.';
    if(result.hasDrafts)note+=' Incluye cambios sin guardar, identificados en el detalle.';
    body.appendChild(el('p',note,'cc-audit-note'));
    var counts=el('div',null,'cc-audit-counts');
    Object.keys(labels).forEach(function(type){if(result.counts[type])counts.appendChild(el('span',labels[type]+': '+result.counts[type]));});
    body.appendChild(counts);
    document.getElementById('cc-audit-export').disabled=!result.items.length;
    if(!result.items.length){body.appendChild(el('div','Sin inconsistencias detectadas en las líneas visibles.','cc-audit-empty'));return;}
    var scroll=el('div',null,'cc-audit-scroll'),table=el('table',null,'cc-audit-table'),head=el('thead'),header=el('tr');
    ['Proyecto · lote · línea','Cliente','Estado','Monto pactado','Monto abonado','Suma de abonos','Observación','Revisar'].forEach(function(text){var th=el('th',text);th.scope='col';header.appendChild(th);});
    head.appendChild(header);table.appendChild(head);var tbody=el('tbody');
    result.items.forEach(function(item){
      var tr=el('tr');tr.dataset.auditKey=item.key;
      tr.appendChild(el('td',item.proyecto+' · '+item.lote+' · '+item.linea));
      tr.appendChild(el('td',item.cliente,'cc-audit-client'));
      var status=el('td',item.estado);if(item.pending)status.appendChild(el('span','Sin guardar','cc-audit-draft'));tr.appendChild(status);
      [item.monto,item.abonado,item.detalle].forEach(function(value){tr.appendChild(el('td',money(value),'cc-audit-number'));});
      var observations=el('td',null,'cc-audit-observation');
      item.issues.forEach(function(issue){observations.appendChild(el('p',issue.message));});tr.appendChild(observations);
      var action=el('td'),button=el('button','Ver línea','btn btn-ghost btn-sm');button.type='button';button.onclick=function(){showLine(item.key);};action.appendChild(button);tr.appendChild(action);tbody.appendChild(tr);
    });
    table.appendChild(tbody);scroll.appendChild(table);body.appendChild(scroll);
  }
  function openReport(){
    var result=fresh();if(!result){closeReview();return;}
    ensureModal();drawReport(result);openModal('modal-cc-audit');
  }
  function showLine(key){
    if(!allowed()){closeReview();return;}
    var row=getCCFlatRows().find(function(item){return model.key(item)===key;});
    if(!row){openReport();toast('La línea ya no aparece con los filtros actuales.','info');return;}
    closeModal('modal-cc-audit');ccExpandedClientes[row.registroId]=true;renderConciliacionContable();
    var input=document.getElementById(ccFlatFieldId('montoabonado',row.registroId,row.tipo,row.idx));
    if(input){input.closest('tr').scrollIntoView({block:'center',behavior:'smooth'});if(!input.disabled)input.focus({preventScroll:true});}
  }
  async function exportReport(){
    try{
    var result=fresh();if(!result)return;
    if(!result.items.length){toast('Sin inconsistencias con los filtros actuales.','info');return;}
    if(typeof XLSX==='undefined'){toast('La librería de Excel no está disponible.','error');return;}
    var headers=['Proyecto','Lote','Línea','Cliente','Estado','Monto pactado','Monto abonado','Suma de abonos','Saldo pactado menos abonado','Abonado menos detalle','Alertas','Observación','Cambios sin guardar'];
    var rows=result.items.map(function(item){return [item.proyecto,item.lote,item.linea,item.cliente,item.estado,item.monto,item.abonado,item.detalle,item.saldo,item.diferenciaDetalle,item.issues.map(function(i){return labels[i.type];}).join(' · '),item.issues.map(function(i){return i.message;}).join(' '),item.pending?'Sí':'No'];});
    var contacts=await cargarContactosInforme(result.items),clients=CarteraClientesInforme.table(headers,rows,CarteraClientesInforme.forRows(result.items,contacts));headers=clients.headers;rows=clients.rows;
    var sheet=XLSX.utils.aoa_to_sheet([headers].concat(rows));sheet['!cols']=[28,12,24,38,26,20,20,20,24,24,38,100,22].map(function(w){return {wch:w};});
    sheet['!cols']=headers.map(function(h,i){return sheet['!cols'][i]||{wch:Math.max(20,h.length+2)};});
    for(var r=1;r<=rows.length;r++)for(var c=5;c<=9;c++){var cell=sheet[XLSX.utils.encode_cell({r:r,c:c})];if(cell&&typeof cell.v==='number')cell.z='$ #,##0;[Red]-$ #,##0';}
    sheet['!autofilter']={ref:XLSX.utils.encode_range({s:{r:0,c:0},e:{r:rows.length,c:headers.length-1}})};
    var book=XLSX.utils.book_new();XLSX.utils.book_append_sheet(book,sheet,'Inconsistencias');
    XLSX.writeFile(book,'Inconsistencias_Conciliaciones_'+new Date().toLocaleDateString('sv-SE',{timeZone:'America/Santiago'})+'.xlsx');
    }catch(error){console.error('No se pudieron exportar las inconsistencias:',error);toast('No se pudieron consultar los datos de clientes. Intenta nuevamente.','error');}
  }
  window.renderConciliacionInconsistencias=function(rows){
    styles();var banner=document.getElementById('cc-audit-banner');if(!banner)return;
    if(!allowed()){banner.hidden=true;banner.replaceChildren();closeReview();return;}
    banner.hidden=false;var result=report(rows||[]);
    banner.className='cc-audit-banner'+(result.items.length?' has-issues':'');banner.replaceChildren();
    var content=el('div'),title=result.items.length?result.items.length+' línea'+(result.items.length===1?'':'s')+' con inconsistencias para revisar':'Sin inconsistencias detectadas';
    content.appendChild(el('strong',title));
    content.appendChild(el('p','Revisión automática de montos, estados y detalle de abonos. Respeta los filtros actuales.'+(result.hasDrafts?' Incluye cambios sin guardar.':'')));
    var button=el('button','Revisar inconsistencias','btn btn-ghost btn-sm');button.type='button';button.onclick=openReport;content.id='cc-audit-summary';banner.append(content,button);
    var modal=document.getElementById('modal-cc-audit');if(modal&&modal.classList.contains('open'))drawReport(result);
  };
  styles();
  if(typeof fbAuth!=='undefined')fbAuth.onAuthStateChanged(function(user){if(!user){var body=document.getElementById('cc-audit-body');if(body)body.replaceChildren();var banner=document.getElementById('cc-audit-banner');if(banner){banner.hidden=true;banner.replaceChildren();}closeReview();}});
  var panel=document.getElementById('panel-conciliacion-contable');
  if(currentUser&&panel&&panel.classList.contains('active'))renderConciliacionContable();
})();
