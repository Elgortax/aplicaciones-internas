(function(){
  'use strict';

  var activeRecordId='';
  var enhanceTimer=0;
  var contactCache={};
  var RECORD_ACTIONS=[
    'openEdit','openConciliacion','irAConciliacionCliente','generarEstadoPagoCliente',
    'generarComprobanteDevolucion','generarComprobanteDevolucionDesistimiento',
    'openValidacion','aprobarDesistimiento','aprobarResciliacion'
  ];

  function escapeHtml(value){
    if(typeof esc==='function')return esc(String(value==null?'':value));
    return String(value==null?'':value).replace(/[&<>"']/g,function(char){
      return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char];
    });
  }

  function clean(value){
    var text=String(value==null?'':value).trim();
    return text==='—'||text==='-'?'':text;
  }

  function hasOwn(object,field){
    return !!object&&Object.prototype.hasOwnProperty.call(object,field);
  }

  function contactCollection(){
    return typeof fbDb!=='undefined'&&fbDb?fbDb.collection('contactos_registros'):null;
  }

  function loadContactData(recordId,force){
    if(!force&&hasOwn(contactCache,recordId))return Promise.resolve(contactCache[recordId]);
    var collection=contactCollection();
    if(!collection)return Promise.resolve({});
    return collection.doc(String(recordId)).get().then(function(snapshot){
      var data=snapshot.exists?(snapshot.data()||{}):{};
      contactCache[String(recordId)]=data;
      return data;
    });
  }

  function writeContactData(recordId,payload){
    var collection=contactCollection();
    if(!collection)return Promise.reject(new Error('contact-storage-unavailable'));
    var stored=Object.assign({},payload,{registroId:String(recordId)});
    if(typeof firebase!=='undefined'&&firebase.firestore&&firebase.firestore.FieldValue){
      stored.updatedAt=firebase.firestore.FieldValue.serverTimestamp();
    }
    if(typeof currentUser!=='undefined'&&currentUser)stored.updatedBy=currentUser.nombre||currentUser.email||'';
    return collection.doc(String(recordId)).set(stored,{merge:true}).then(function(){
      contactCache[String(recordId)]=Object.assign({},contactCache[String(recordId)]||{},payload);
      if(typeof CustomEvent==='function'&&typeof window.dispatchEvent==='function')window.dispatchEvent(new CustomEvent('record-contact-updated',{detail:{registroId:String(recordId),contact:contactCache[String(recordId)]}}));
      return contactCache[String(recordId)];
    });
  }

  function syncQuoteContactToRecord(recordId,quote){
    var record=recordById(recordId);
    if(!record||!quote||String(record.cotizacionId||'')!==String(quote.id||'')||!canViewRecord(record)){
      return Promise.reject(new Error('quote-contact-link-denied'));
    }
    if(typeof puedeEditarCotizacionVentas!=='function'||!puedeEditarCotizacionVentas(quote)){
      return Promise.reject(new Error('quote-contact-owner-denied'));
    }
    var values={rut:clean(quote.rut),telefono:clean(quote.telefono),correo:clean(quote.correo)||clean(quote.email)};
    return loadContactData(String(recordId),true).then(function(contact){
      var normalizeRut=function(value){return clean(value).toUpperCase().replace(/[^0-9K]/g,'');};
      var oldRut=normalizeRut(contact.rut),newRut=normalizeRut(values.rut);
      var changedPerson=oldRut&&newRut&&oldRut!==newRut;
      var patch={};
      ['rut','telefono','correo'].forEach(function(field){
        if((values[field]||(changedPerson&&field!=='rut'))&&clean(contact[field])!==values[field])patch[field]=values[field];
      });
      return Object.keys(patch).length?writeContactData(recordId,patch):contact;
    });
  }

  function populateConciliationHeader(recordId){
    var record=recordById(recordId);
    var rutElement=document.getElementById('conc-info-rut');
    var emailElement=document.getElementById('conc-info-email');
    var phoneElement=document.getElementById('conc-info-phone');
    if(!record||!rutElement||!emailElement||!phoneElement)return Promise.resolve();
    var id=String(record.id);
    rutElement.setAttribute('data-registro-id',id);
    emailElement.setAttribute('data-registro-id',id);
    phoneElement.setAttribute('data-registro-id',id);
    rutElement.textContent=clean(record.rut)||'—';
    emailElement.textContent=clean(record.correo||record.email)||'—';
    phoneElement.textContent=clean(record.telefono)||'—';
    return loadContactData(id).then(function(contact){
      if(rutElement.getAttribute('data-registro-id')!==id||emailElement.getAttribute('data-registro-id')!==id||phoneElement.getAttribute('data-registro-id')!==id)return;
      rutElement.textContent=(hasOwn(contact,'rut')?clean(contact.rut):clean(record.rut))||'—';
      emailElement.textContent=(hasOwn(contact,'correo')?clean(contact.correo):clean(record.correo||record.email))||'—';
      phoneElement.textContent=(hasOwn(contact,'telefono')?clean(contact.telefono):clean(record.telefono))||'—';
    }).catch(function(){
      // Conserva como respaldo los valores históricos del registro si la ficha no carga.
    });
  }

  function recordById(id){
    return state&&Array.isArray(state.registros)?state.registros.find(function(record){return String(record.id)===String(id);}):null;
  }

  function canViewRecord(record){
    if(!record)return false;
    if(typeof shouldScopeRecordsToUser==='function'&&shouldScopeRecordsToUser()){
      return typeof userOwnsRecord==='function'&&userOwnsRecord(record);
    }
    return true;
  }

  function canEditContact(){
    if(typeof isReadOnlySellerUser==='function'&&isReadOnlySellerUser())return false;
    return typeof canDo==='function'&&canDo('Editar reserva');
  }

  function ensureContactModal(){
    var modal=document.getElementById('modal-record-contact');
    if(modal)return modal;
    modal=document.createElement('div');
    modal.className='modal-overlay';
    modal.id='modal-record-contact';
    modal.style.zIndex='20150';
    modal.innerHTML=
      '<div class="modal" style="max-width:520px">'+
        '<div class="modal-head">'+
          '<h3 id="record-contact-title">Ficha de contacto</h3>'+
          '<button class="modal-close" type="button" aria-label="Cerrar" data-record-contact-close>✕</button>'+
        '</div>'+
        '<div class="modal-body">'+
          '<div style="padding:12px;border:1px solid var(--border);border-radius:var(--r);background:var(--bg3)">'+
            '<div style="font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;color:var(--text3);margin-bottom:5px">Cliente</div>'+
            '<div id="record-contact-name" style="font-size:15px;font-weight:800;color:var(--text)">—</div>'+
            '<div id="record-contact-project" style="font-size:11px;color:var(--text2);margin-top:3px">—</div>'+
          '</div>'+
          '<div class="form-group"><label>RUT</label><input type="text" id="record-contact-rut" placeholder="RUT del cliente" autocomplete="off"></div>'+
          '<div class="form-group"><label>Teléfono</label><input type="tel" id="record-contact-phone" placeholder="Ej: +56 9 XXXX XXXX" autocomplete="tel"></div>'+
          '<div class="form-group"><label>Correo electrónico</label><input type="email" id="record-contact-email" placeholder="contacto-demo-66a210ce@example.invalid" autocomplete="email"></div>'+
          '<div id="record-contact-readonly" style="display:none;font-size:11px;color:var(--text3)">Puedes consultar estos datos, pero tu perfil no tiene permiso para modificarlos.</div>'+
        '</div>'+
        '<div class="modal-footer">'+
          '<button class="btn btn-ghost" type="button" data-record-contact-close>Cerrar</button>'+
          '<button class="btn btn-primary" type="button" id="record-contact-save">Guardar contacto</button>'+
        '</div>'+
      '</div>';
    modal.addEventListener('click',function(event){
      if(event.target===modal||event.target.closest('[data-record-contact-close]'))closeRecordContact();
    });
    document.body.appendChild(modal);
    document.getElementById('record-contact-save').addEventListener('click',saveRecordContact);
    return modal;
  }

  function setContactReadOnly(input,readOnly){
    input.readOnly=!!readOnly;
    input.disabled=!!readOnly;
    input.style.opacity=readOnly?'0.78':'';
  }

  function showContactValues(record,contact){
    var sidecar=contact||{};
    document.getElementById('record-contact-rut').value=hasOwn(sidecar,'rut')?clean(sidecar.rut):clean(record.rut);
    document.getElementById('record-contact-phone').value=hasOwn(sidecar,'telefono')?clean(sidecar.telefono):clean(record.telefono);
    document.getElementById('record-contact-email').value=hasOwn(sidecar,'correo')?clean(sidecar.correo):clean(record.correo||record.email);
    var readOnly=!canEditContact();
    ['record-contact-rut','record-contact-phone','record-contact-email'].forEach(function(field){
      setContactReadOnly(document.getElementById(field),readOnly);
    });
    document.getElementById('record-contact-save').style.display=readOnly?'none':'';
    document.getElementById('record-contact-readonly').style.display=readOnly?'':'none';
  }

  function openRecordContact(id){
    var record=recordById(id);
    if(!record||!canViewRecord(record)){
      if(typeof toast==='function')toast('Sin permiso para ver este contacto.','error');
      return;
    }
    activeRecordId=String(record.id);
    var modal=ensureContactModal();
    document.getElementById('record-contact-title').textContent='Contacto — '+(record.cliente||'Cliente');
    document.getElementById('record-contact-name').textContent=record.cliente||'Sin nombre';
    document.getElementById('record-contact-project').textContent=(record.proyecto||'Sin proyecto')+(record.name?' · Lote '+record.name:'');
    ['record-contact-rut','record-contact-phone','record-contact-email'].forEach(function(field){
      var input=document.getElementById(field);
      input.value='';
      setContactReadOnly(input,true);
    });
    document.getElementById('record-contact-save').style.display='none';
    document.getElementById('record-contact-readonly').style.display='';
    document.getElementById('record-contact-readonly').textContent='Cargando datos de contacto...';
    modal.classList.add('open');
    loadContactData(activeRecordId).then(function(contact){
      if(activeRecordId!==String(record.id))return;
      document.getElementById('record-contact-readonly').textContent='Puedes consultar estos datos, pero tu perfil no tiene permiso para modificarlos.';
      showContactValues(record,contact);
    }).catch(function(){
      if(activeRecordId!==String(record.id))return;
      document.getElementById('record-contact-readonly').textContent='No se pudo cargar el contacto. Intenta nuevamente.';
      if(typeof toast==='function')toast('No se pudo cargar la ficha de contacto.','error');
    });
  }

  function closeRecordContact(){
    var modal=document.getElementById('modal-record-contact');
    if(modal)modal.classList.remove('open');
    activeRecordId='';
  }

  function saveRecordContact(){
    if(!canEditContact())return;
    var record=recordById(activeRecordId);
    if(!record)return;
    var emailInput=document.getElementById('record-contact-email');
    if(emailInput.value.trim()&&!emailInput.checkValidity()){
      if(typeof toast==='function')toast('Revisa el formato del correo electrónico.','error');
      emailInput.focus();
      return;
    }
    var rut=clean(document.getElementById('record-contact-rut').value);
    var phone=clean(document.getElementById('record-contact-phone').value);
    var email=clean(emailInput.value);
    var sidecar=contactCache[String(record.id)]||{};
    var currentRut=hasOwn(sidecar,'rut')?clean(sidecar.rut):clean(record.rut);
    var currentPhone=hasOwn(sidecar,'telefono')?clean(sidecar.telefono):clean(record.telefono);
    var currentEmail=hasOwn(sidecar,'correo')?clean(sidecar.correo):clean(record.correo||record.email);
    var changed=currentRut!==rut||currentPhone!==phone||currentEmail!==email;
    if(!changed){closeRecordContact();return;}
    var button=document.getElementById('record-contact-save');
    button.disabled=true;
    button.textContent='Guardando...';
    writeContactData(record.id,{rut:rut,telefono:phone,correo:email}).then(function(){
      closeRecordContact();
      if(typeof toast==='function')toast('Datos de contacto guardados.','success');
    }).catch(function(){
      if(typeof toast==='function')toast('No se pudo guardar el contacto. Intenta nuevamente.','error');
    }).finally(function(){
      button.disabled=false;
      button.textContent='Guardar contacto';
    });
  }

  function recordIdFromActions(cell){
    var elements=cell.querySelectorAll('[onclick]');
    for(var i=0;i<elements.length;i++){
      var source=elements[i].getAttribute('onclick')||'';
      for(var j=0;j<RECORD_ACTIONS.length;j++){
        var pattern=new RegExp(RECORD_ACTIONS[j]+"\\('([^']+)'\\)");
        var match=source.match(pattern);
        if(match&&recordById(match[1]))return match[1];
      }
    }
    return '';
  }

  function enhanceContactButtons(){
    enhanceTimer=0;
    document.querySelectorAll('.actions-cell').forEach(function(cell){
      if(cell.querySelector('.record-contact-btn'))return;
      var recordId=recordIdFromActions(cell);
      var record=recordId&&recordById(recordId);
      if(!record||!canViewRecord(record))return;
      var button=document.createElement('button');
      button.type='button';
      button.className='ico-btn record-contact-btn';
      button.title='Ver ficha de contacto';
      button.setAttribute('aria-label','Ver ficha de contacto de '+(record.cliente||'cliente'));
      button.textContent='☎';
      button.addEventListener('click',function(event){
        event.preventDefault();
        event.stopPropagation();
        openRecordContact(recordId);
      });
      cell.insertBefore(button,cell.firstChild);
    });
    document.querySelectorAll('.devresc-print-btn').forEach(function(printButton){
      var cell=printButton.closest('td');
      if(!cell||cell.querySelector('.record-contact-btn'))return;
      var source=printButton.getAttribute('onclick')||'';
      var match=source.match(/generarComprobanteDevolucion\('([^']+)'\)/);
      var recordId=match&&match[1];
      var record=recordId&&recordById(recordId);
      if(!record||!canViewRecord(record))return;
      var button=document.createElement('button');
      button.type='button';
      button.className='ico-btn record-contact-btn';
      button.title='Ver ficha de contacto';
      button.setAttribute('aria-label','Ver ficha de contacto de '+(record.cliente||'cliente'));
      button.textContent='☎';
      button.addEventListener('click',function(event){
        event.preventDefault();
        event.stopPropagation();
        openRecordContact(recordId);
      });
      printButton.parentNode.insertBefore(button,printButton);
    });
  }

  function scheduleEnhance(){
    if(enhanceTimer)return;
    enhanceTimer=setTimeout(enhanceContactButtons,20);
  }

  function quoteValue(value){
    var result=clean(value);
    return result==='â€”'?'':result;
  }

  function installQuoteContactBridge(){
    var original=window.crearReservaDesdeCotizacion;
    if(typeof original!=='function'||original.__recordContactWrapped)return;
    var wrapped=async function(c,comprobantes,visitaId,datosManuales){
      var result=await original.apply(this,arguments);
      if(result===false)return result;
      var record=c&&c.reservaId?recordById(c.reservaId):null;
      if(!record)return result;
      var visit=null;
      if(visitaId&&typeof buscarVisitaAgendamiento==='function')visit=buscarVisitaAgendamiento(visitaId);
      var rut=quoteValue(c.rut)||quoteValue(visit&&visit.rut)||clean(record.rut);
      var phone=quoteValue(c.telefono)||quoteValue(visit&&visit.telefono)||clean(record.telefono);
      var email=quoteValue(c.correo)||quoteValue(c.email)||quoteValue(visit&&visit.correo)||quoteValue(visit&&visit.email)||clean(record.correo)||clean(record.email);
      try{
        var stored=await loadContactData(record.id);
        var patch={};
        if(!clean(stored.rut)&&rut)patch.rut=rut;
        if(!clean(stored.telefono)&&phone)patch.telefono=phone;
        if(!clean(stored.correo)&&email)patch.correo=email;
        if(Object.keys(patch).length)await writeContactData(record.id,patch);
      }catch(error){
        console.error('La Reserva quedó creada, pero no se pudo guardar su ficha de contacto:',error);
        if(typeof toast==='function')toast('La Reserva se creó, pero quedó pendiente guardar su contacto.','error');
      }
      scheduleEnhance();
      return result;
    };
    wrapped.__recordContactWrapped=true;
    wrapped.__recordContactOriginal=original;
    window.crearReservaDesdeCotizacion=wrapped;
  }

  function init(){
    ensureContactModal();
    installQuoteContactBridge();
    scheduleEnhance();
    var root=document.getElementById('app')||document.body;
    new MutationObserver(scheduleEnhance).observe(root,{childList:true,subtree:true});
  }

  window.openRecordContact=openRecordContact;
  window.closeRecordContact=closeRecordContact;
  window.RecordContactRuntime={
    clean:clean,
    invalidate:function(id){delete contactCache[String(id)];},
    recordById:recordById,
    getForRecord:function(id){
      var record=recordById(id);
      if(!canViewRecord(record))return Promise.reject(new Error('contact-view-denied'));
      return loadContactData(String(id));
    },
    saveForRecord:function(id,patch){
      var record=recordById(id);
      if(!canViewRecord(record)||!(canEditContact()||(typeof canDo==='function'&&canDo('Editar Conciliación Contable'))))return Promise.reject(new Error('contact-edit-denied'));
      var allowed={};
      ['rut','telefono','correo'].forEach(function(field){if(hasOwn(patch,field))allowed[field]=clean(patch[field]);});
      return writeContactData(String(id),allowed);
    },
    syncQuoteRutToRecord:syncQuoteContactToRecord,
    syncQuoteContactToRecord:syncQuoteContactToRecord,
    open:openRecordContact,
    close:closeRecordContact,
    enhance:enhanceContactButtons,
    populateConciliationHeader:populateConciliationHeader,
    installQuoteContactBridge:installQuoteContactBridge
  };

  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});
  else init();
})();
