(function(){
  'use strict';
  if(typeof fbDb==='undefined')return;

  var views={};
  var suffix=typeof stateRef!=='undefined'&&stateRef.id==='state_prueba'?'_prueba':'';
  var definitions=[
    {source:'reserva',collection:'reserva_adjuntos'+suffix,field:'metaRegistroId'},
    {source:'conciliacion',collection:'conciliacion_adjuntos'+suffix,field:'metaRegistroId'},
    {source:'validacion',collection:'validacion_adjuntos'+suffix,field:'data.registroId'}
  ];

  function escapeText(value){
    return String(value==null?'':value).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
  function fileSize(size){
    var amount=Number(size)||0;
    return amount<1048576?Math.max(1,Math.round(amount/1024))+' KB':(amount/1048576).toFixed(1)+' MB';
  }
  function sidecarId(value){return encodeURIComponent(String(value||'')).replace(/\./g,'%2E');}
  function validationChunkId(validationId,documentId,index){
    return sidecarId(validationId)+'__doc__'+sidecarId(documentId)+'__'+String(index).padStart(3,'0');
  }
  function chunkId(id,index){return id+'_chunk_'+String(index).padStart(3,'0');}

  function itemsFromSnapshot(source,snapshot){
    var items=[];
    snapshot.forEach(function(document){
      var stored=document.data()||{};
      if(stored.deleted)return;
      if(source==='validacion'){
        var validation=stored.data||stored.item||stored;
        if(!validation.id||!Array.isArray(validation.documentos))return;
        validation.documentos.forEach(function(file){
          if(!file||!file.id)return;
          items.push({source:source,id:String(file.id),validationId:String(validation.id),
            name:String(file.name||'Archivo'),mime:String(file.type||''),size:Number(file.size)||0,
            createdBy:String(file.addedBy||''),createdAt:String(file.addedAt||''),
            dataUrl:String(file.dataUrl||''),storage:String(file.storage||''),chunkCount:Number(file.chunkCount)||0,
            documentKind:String(file.documentKind||''),sourceId:String(file.sourceId||''),
            label:file.documentKind==='cotizacion'?'Cotización / Validación':'Validación de Reserva'});
        });
      }else if(stored.kind==='meta'){
        items.push({source:source,id:String(stored.id||document.id),documentId:String(document.id),name:String(stored.name||'Archivo'),
          mime:String(stored.mime||''),size:Number(stored.size)||0,chunkCount:Number(stored.chunkCount)||0,
          createdBy:String(stored.createdBy||''),createdAt:String(stored.createdAtText||''),
          conceptKey:String(stored.metaConceptKey||''),
          label:source==='reserva'?'Reserva / Legal':String(stored.conceptLabel||'Conciliación')});
      }
    });
    return items;
  }

  function shouldShow(view,item){
    if(view.options.excludeSources&&view.options.excludeSources.indexOf(item.source)>=0)return false;
    if(item.source==='conciliacion'&&view.options.excludeConceptKey&&item.conceptKey===view.options.excludeConceptKey)return false;
    return true;
  }

  function render(targetId){
    var view=views[targetId];
    var target=document.getElementById(targetId);
    if(!view||!target)return;
    var all=definitions.reduce(function(items,definition){return items.concat(view.items[definition.source]||[]);},[]);
    view.visible=all.filter(function(item){return shouldShow(view,item);});
    view.visible.sort(function(a,b){return String(b.createdAt).localeCompare(String(a.createdAt))||a.name.localeCompare(b.name);});
    var pending=definitions.some(function(definition){return !view.ready[definition.source];});
    var problem=Object.keys(view.errors).some(function(source){return view.errors[source];});
    var fromCache=definitions.some(function(definition){return view.cached[definition.source];});
    var quoteCopy=all.some(function(item){return item.documentKind==='cotizacion'&&(!view.quoteId||item.sourceId===view.quoteId);});
    var quoteHtml='';
    if(!quoteCopy&&(view.quoteId||view.quoteFolio)){
      var quoteLabel=view.quote&&typeof getFolioCompleto==='function'?getFolioCompleto(view.quote):view.quoteFolio;
      quoteHtml='<div class="conc-attachment-item" data-linked-quote style="margin-bottom:8px"><span>📄</span><div class="file-main"><div class="file-name">Cotización vinculada'+(quoteLabel?' · '+escapeText(quoteLabel):'')+'</div><div class="file-meta">'+
        (view.quote?'Documento guardado en Cotizaciones':view.quoteError?'No se pudo consultar. Pulsa Actualizar para reintentar.':!view.quoteReady?'Cargando cotización...':'La ficha conserva el vínculo, pero el documento original no está disponible en Cotizaciones.')+
        '</div></div>'+(view.quote?'<button type="button" class="btn btn-ghost btn-sm" data-linked-quote-download>Descargar cotización</button>':'')+'</div>';
    }
    var status=problem?'No se pudieron consultar todos los orígenes. Pulsa Actualizar para reintentar.'
      :pending?'Cargando los archivos compartidos...'
      :fromCache?'Mostrando archivos guardados en este equipo; esperando conexión con el servidor.':'';
    var rows=view.visible.map(function(item,index){
      return '<div class="conc-attachment-item" style="margin-bottom:6px">'+
        '<span style="font-size:17px">'+(/pdf/i.test(item.mime)?'📄':/image/i.test(item.mime)?'🖼️':'📎')+'</span>'+
        '<div class="file-main"><div class="file-name" title="'+escapeText(item.name)+'">'+escapeText(item.name)+'</div>'+
        '<div class="file-meta">'+escapeText(item.label)+' · '+fileSize(item.size)+
        (item.createdBy?' · '+escapeText(item.createdBy):'')+(item.createdAt?' · '+escapeText(item.createdAt):'')+'</div></div>'+
        '<button class="ico-btn" type="button" data-shared-download="'+index+'" title="Descargar archivo" aria-label="Descargar '+escapeText(item.name)+'">↓</button>'+
        (typeof view.options.canDelete==='function'&&view.options.canDelete(item)?'<button class="btn btn-ghost btn-sm" type="button" data-shared-delete="'+index+'" aria-label="Eliminar '+escapeText(item.name)+'"'+(view.options.isBusy&&view.options.isBusy()?' disabled':'')+'>Eliminar</button>':'')+'</div>';
    }).join('');
    target.innerHTML='<div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin:12px 0 7px">'+
      '<strong style="font-size:10px;text-transform:uppercase;letter-spacing:.06em;color:var(--text2)">'+escapeText(view.options.title||'Otros archivos de esta persona')+(view.visible.length?' · '+view.visible.length:'')+'</strong>'+
      '<button class="btn btn-ghost btn-sm" type="button" data-shared-refresh>↻ Actualizar</button></div>'+
      (status?'<div role="status" style="font-size:10px;color:var(--text3);margin-bottom:6px">'+escapeText(status)+'</div>':'')+
      quoteHtml+(rows||(!quoteHtml&&!pending&&!problem?'<div style="font-size:10px;color:var(--text3)">'+escapeText(view.options.emptyMessage||'No hay otros archivos. Los de este panel aparecen arriba.')+'</div>':''));
  }

  function unmount(targetId){
    var view=views[targetId];
    if(!view)return;
    view.unsubscribers.forEach(function(stop){try{stop();}catch(error){console.error(error);}});
    delete views[targetId];
  }

  function mount(registroId,targetId,options){
    var target=document.getElementById(targetId);
    if(!target)return;
    unmount(targetId);
    var view=views[targetId]={registroId:String(registroId||''),options:options||{},items:{},ready:{},errors:{},cached:{},unsubscribers:[],visible:[]};
    if(!view.registroId||!currentFirebaseUser){
      view.errors.auth=true;
      render(targetId);
      return;
    }
    var record=(state.registros||[]).find(function(item){return String(item.id)===view.registroId;});
    if(!record||(typeof shouldScopeRecordsToUser==='function'&&shouldScopeRecordsToUser()&&!userOwnsRecord(record))){
      view.errors.auth=true;render(targetId);return;
    }
    view.quoteId=String(record.cotizacionId||'');
    view.quoteFolio=String(record.cotizacionFolio||'');
    view.quoteReady=!view.quoteId;
    if(!target.dataset.sharedAttachmentsBound){
      target.addEventListener('click',function(event){
        var refresh=event.target.closest('[data-shared-refresh]');
        if(refresh){var current=views[targetId];if(current)mount(current.registroId,targetId,current.options);return;}
        if(event.target.closest('[data-linked-quote-download]')){
          var current=views[targetId];
          var record=current&&(state.registros||[]).find(function(item){return String(item.id)===current.registroId;});
          if(current&&currentFirebaseUser&&current.quote&&record&&String(record.cotizacionId||'')===current.quoteId&&
            !(typeof shouldScopeRecordsToUser==='function'&&shouldScopeRecordsToUser()&&!userOwnsRecord(record))&&typeof descargarCotizacionGuardadaBonita==='function'){
            descargarCotizacionGuardadaBonita(current.quote.id,{cotizacion:current.quote});
          }
          return;
        }
        var remove=event.target.closest('[data-shared-delete]');
        if(remove){
          var current=views[targetId],item=current&&current.visible[Number(remove.dataset.sharedDelete)];
          if(item&&current.options.canDelete&&current.options.canDelete(item)&&!(current.options.isBusy&&current.options.isBusy())&&current.options.onDelete){
            Promise.resolve().then(function(){return current.options.onDelete(item);}).catch(function(error){
              console.error('No se pudo eliminar el adjunto compartido:',error);
              if(typeof toast==='function')toast('No se pudo confirmar la eliminación. Actualiza los archivos antes de reintentar.','error');
            });
          }
          return;
        }
        var button=event.target.closest('[data-shared-download]');
        if(!button)return;
        var current=views[targetId];
        var item=current&&current.visible[Number(button.dataset.sharedDownload)];
        if(item)download(item).catch(function(error){
          console.error('No se pudo descargar el adjunto compartido:',error);
          if(typeof toast==='function')toast('No se pudo descargar el archivo. Actualiza e inténtalo de nuevo.','error');
        });
      });
      target.dataset.sharedAttachmentsBound='1';
    }
    render(targetId);
    if(view.quoteId){
      var quoteStop=fbDb.collection('cotizaciones').doc(view.quoteId).onSnapshot(function(snapshot){
        if(views[targetId]!==view)return;
        var quote=snapshot.exists?Object.assign({},snapshot.data(),{id:snapshot.id}):null;
        // Solo el vínculo explícito de esta ficha; no buscar por nombre/RUT/lote.
        view.quote=quote&&(!quote.reservaId||String(quote.reservaId)===view.registroId)?quote:null;
        view.quoteReady=true;view.quoteError=false;render(targetId);
      },function(error){
        if(views[targetId]!==view)return;
        view.quote=null;view.quoteReady=true;view.quoteError=true;render(targetId);
      });
      view.unsubscribers.push(quoteStop);
    }
    definitions.forEach(function(definition){
      var query=fbDb.collection(definition.collection).where(definition.field,'==',view.registroId);
      var stop=query.onSnapshot(function(snapshot){
        if(views[targetId]!==view)return;
        view.items[definition.source]=itemsFromSnapshot(definition.source,snapshot);
        view.ready[definition.source]=true;
        view.errors[definition.source]=false;
        view.cached[definition.source]=!!(snapshot.metadata&&snapshot.metadata.fromCache);
        render(targetId);
      },function(error){
        if(views[targetId]!==view)return;
        console.error('No se pudieron consultar los adjuntos de '+definition.source+':',error);
        view.ready[definition.source]=true;
        view.errors[definition.source]=true;
        render(targetId);
      });
      view.unsubscribers.push(stop);
    });
  }

  function bytesFromBase64(value){
    var binary=atob(value||'');
    var bytes=new Uint8Array(binary.length);
    for(var index=0;index<binary.length;index++)bytes[index]=binary.charCodeAt(index);
    return bytes;
  }
  function saveBlob(parts,item){
    var blob=new Blob(parts,{type:item.mime||'application/octet-stream'});
    var url=URL.createObjectURL(blob);
    var link=document.createElement('a');
    link.href=url;link.download=item.name||'archivo';document.body.appendChild(link);link.click();document.body.removeChild(link);
    setTimeout(function(){URL.revokeObjectURL(url);},60000);
  }
  function download(item){
    var ids=[];
    if(item.source==='validacion'){
      if(item.storage==='chunks'){
        if(!item.chunkCount)return Promise.reject(new Error('Archivo incompleto.'));
        for(var i=0;i<item.chunkCount;i++)ids.push(validationChunkId(item.validationId,item.id,i));
        return Promise.all(ids.map(function(id){return fbDb.collection('validacion_adjuntos'+suffix).doc(id).get({source:'server'});})).then(function(docs){
          var dataUrl=docs.map(function(doc){if(!doc.exists||typeof doc.data().data!=='string')throw new Error('Fragmento ausente.');return doc.data().data;}).join('');
          var comma=dataUrl.indexOf(',');
          if(comma<0||!/^data:/i.test(dataUrl))throw new Error('Archivo inválido.');
          saveBlob([bytesFromBase64(dataUrl.slice(comma+1))],item);
        });
      }
      var comma=item.dataUrl.indexOf(',');
      if(comma<0||!/^data:/i.test(item.dataUrl))return Promise.reject(new Error('Archivo inválido.'));
      saveBlob([bytesFromBase64(item.dataUrl.slice(comma+1))],item);
      return Promise.resolve();
    }
    if(!item.chunkCount)return Promise.reject(new Error('Archivo incompleto.'));
    var collection=(item.source==='reserva'?'reserva_adjuntos':'conciliacion_adjuntos')+suffix;
    for(var index=0;index<item.chunkCount;index++)ids.push(chunkId(item.id,index));
    return Promise.all(ids.map(function(id){return fbDb.collection(collection).doc(id).get({source:'server'});})).then(function(docs){
      var parts=docs.map(function(doc){if(!doc.exists||typeof doc.data().data!=='string')throw new Error('Fragmento ausente.');return bytesFromBase64(doc.data().data);});
      saveBlob(parts,item);
    });
  }

  window.CarteraAdjuntosCompartidos={mount:mount,unmount:unmount,download:download,render:render};
})();
