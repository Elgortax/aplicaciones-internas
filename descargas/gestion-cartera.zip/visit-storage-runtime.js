(function(){
  'use strict';

  if(typeof fbDb==='undefined')return;

  var isRetiredTest=location.pathname.indexOf('/prueba/')===0;
  var COLLECTION=isRetiredTest?'visitas_propias_prueba':'visitas_propias';
  var SHARDS=8;
  visitasAgendaRef=fbDb.collection(COLLECTION);
  visitasMondayCache=[];

  function clean(value){return String(value==null?'':value).trim();}

  function normalizeVisitStatus(value){
    var status=clean(value);
    var key=status.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
    return ['reagendada','no calificado','no interesado','no logrado'].indexOf(key)>=0?'Visita No Concretada':status;
  }

  function normalizeDate(value){
    if(typeof window.normalizeVisitaDate==='function')return window.normalizeVisitaDate(value);
    var match=clean(value).match(/^(\d{4})-(\d{2})-(\d{2})/);
    return match?match[1]+'-'+match[2]+'-'+match[3]:'';
  }

  function normalizeTime(value){
    if(typeof window.normalizeVisitaTime==='function')return window.normalizeVisitaTime(value);
    var match=clean(value).match(/^([0-2]?\d):([0-5]\d)/);
    return match&&Number(match[1])<=23?String(Number(match[1])).padStart(2,'0')+':'+match[2]:'';
  }

  function cloneVisit(value){
    var copy=JSON.parse(JSON.stringify(value||{}));
    delete copy.mondaySourceId;
    delete copy.mondaySnapshot;
    delete copy.localOverrides;
    delete copy.localOverlayId;
    copy.id=clean(copy.id)||('av'+Date.now()+Math.random().toString(36).slice(2,7));
    copy.source='gestion';
    copy.estado=normalizeVisitStatus(copy.estado);
    copy.fechaVisita=normalizeDate(copy.fechaVisita);
    copy.horaVisita=normalizeTime(copy.horaVisita);
    return copy;
  }

  function shardFor(id){
    var hash=2166136261;
    clean(id).split('').forEach(function(char){hash^=char.charCodeAt(0);hash=Math.imul(hash,16777619);});
    return (hash>>>0)%SHARDS;
  }

  function monthFor(date){return normalizeDate(date).slice(0,7)||'sin-fecha';}
  function docIdFor(id,date){return monthFor(date)+'__s'+shardFor(id);}

  function readItems(snapshot){
    var loaded=[],meta=null;
    snapshot.forEach(function(doc){
      var data=doc.data()||{};
      if(doc.id==='_meta'){meta=data;return;}
      if(Array.isArray(data.items))data.items.forEach(function(item){loaded.push(normalizeVisitaRecord(item,loaded.length));});
    });
    return {items:loaded,meta:meta};
  }

  normalizeVisitaRecord=function(value,index){
    var normalized=cloneVisit(value);
    normalized.proyecto=clean(normalized.proyecto);
    normalized.cliente=clean(normalized.cliente);
    normalized.rut=clean(normalized.rut);
    normalized.telefono=clean(normalized.telefono);
    normalized.email=clean(normalized.email||normalized.correo);
    normalized.lote=clean(normalized.lote);
    normalized.estado=clean(normalized.estado);
    normalized.subEstado=clean(normalized.subEstado);
    normalized.remoto=clean(normalized.remoto);
    normalized.terreno=clean(normalized.terreno);
    normalized.fechaCreacion=normalizeDate(normalized.fechaCreacion);
    normalized.creadoAt=clean(normalized.creadoAt||normalized.createdAt||normalized.fechaCreacion);
    normalized.medio=clean(normalized.medio);
    normalized.observacion=clean(normalized.observacion);
    normalized.manualImportedAt=Number(normalized.manualImportedAt)||0;
    if(!normalized.id&&typeof observationHash==='function')normalized.id='vis_'+observationHash(JSON.stringify(normalized)+'|'+String(index||0));
    return normalized;
  };

  function setOwnStatus(meta,error){
    var status=document.getElementById('visitas-sync-status');
    if(status){
      status.className='visitas-sync-status'+(error?' error':'');
      status.textContent=error?'No se pudo consultar la agenda propia':'Datos guardados en Gestión de Cartera';
      status.title=error?'Revisa el almacenamiento local del navegador':'Agenda ficticia guardada en este navegador';
    }
    var legacy=document.getElementById('monday-visitas-status');
    if(legacy)legacy.innerHTML=error?'<strong>Agenda propia:</strong> no se pudo consultar la base.':'<strong>Agenda propia:</strong> '+Number(meta&&meta.total||0)+' visitas guardadas en Gestión de Cartera.';
  }

  function schedulingRuntime(){return window.PruebaVisitScheduling||null;}

  function invalidateSchedulingCache(){
    var runtime=schedulingRuntime();
    if(runtime&&typeof runtime.invalidateVisitCaches==='function')runtime.invalidateVisitCaches();
  }

  function renderActiveSchedule(){
    var panel=document.getElementById('panel-agendamiento-visita');
    var runtime=schedulingRuntime();
    if(!panel||!panel.classList.contains('active')||!runtime)return;
    if(typeof runtime.renderActive==='function')runtime.renderActive();
    else if(typeof runtime.render==='function')runtime.render();
  }

  startVisitasMetaListener=function(){
    if(unsubscribeVisitasMeta){unsubscribeVisitasMeta();unsubscribeVisitasMeta=null;}
    if(unsubscribeVisitasMondayMeta){unsubscribeVisitasMondayMeta();unsubscribeVisitasMondayMeta=null;}
    visitasMondayCache=[];
    if(!currentFirebaseUser)return;
    unsubscribeVisitasMeta=visitasAgendaRef.doc('_meta').onSnapshot(function(doc){
      if(!doc.exists||doc.metadata.hasPendingWrites)return;
      var data=doc.data()||{};
      var next=data.version||0;
      var previous=visitasMetaVersion;
      visitasMetaVersion=next;
      setOwnStatus(data,null);
      if(previous===null||next===previous)return;
      visitasLoaded=false;
      var panel=document.getElementById('panel-agendamiento-visita');
      if(panel&&panel.classList.contains('active'))ensureVisitasLoaded(true);
    },function(error){setOwnStatus(null,error);console.error('No se pudo sincronizar la agenda propia:',error);});
  };

  ensureVisitasLoaded=function(force,forReservation){
    var puedeAsociarReserva=!!forReservation&&typeof canDo==='function'&&canDo('Crear reserva');
    if(!currentFirebaseUser||(!canAccessVisitas()&&!puedeAsociarReserva))return Promise.resolve([]);
    if(visitasLoaded&&!force)return Promise.resolve(visitasCache);
    if(visitasLoadingPromise)return visitasLoadingPromise;
    var runtime=schedulingRuntime();
    if(runtime&&typeof runtime.showLoading==='function')runtime.showLoading();
    visitasLoadingPromise=visitasAgendaRef.get().then(function(snapshot){
      var loaded=readItems(snapshot);
      visitasManualCache=loaded.items;
      visitasMondayCache=[];
      visitasCache=visitasManualCache.slice();
      visitasMetaVersion=loaded.meta&&loaded.meta.version||visitasMetaVersion;
      visitasLoaded=true;
      invalidateSchedulingCache();
      setOwnStatus(loaded.meta||{total:visitasCache.length},null);
      initVisitasFilters();
      updateTabCounts();
      renderActiveSchedule();
      return visitasCache;
    }).catch(function(error){
      setOwnStatus(null,error);
      console.error(error);
      toast('No se pudo cargar la agenda propia de visitas.','error');
      throw error;
    }).finally(function(){visitasLoadingPromise=null;});
    return visitasLoadingPromise;
  };

  function replaceCache(visit){
    var normalized=normalizeVisitaRecord(visit,0);
    var index=visitasManualCache.findIndex(function(item){return item&&item.id===normalized.id;});
    if(index>=0)visitasManualCache[index]=normalized;
    else visitasManualCache.push(normalized);
    visitasCache=visitasManualCache.slice();
    invalidateSchedulingCache();
    return normalized;
  }

  function removeFromCache(id){
    visitasManualCache=visitasManualCache.filter(function(item){return item&&item.id!==id;});
    visitasCache=visitasManualCache.slice();
    invalidateSchedulingCache();
  }

  window.upsertVisitaPropia=function(value,previousDate){
    if(isRetiredTest)return Promise.reject(new Error('environment-retired'));
    var visit=cloneVisit(value);
    var oldId=docIdFor(visit.id,previousDate||visit.fechaVisita);
    var newId=docIdFor(visit.id,visit.fechaVisita);
    var oldRef=visitasAgendaRef.doc(oldId),newRef=visitasAgendaRef.doc(newId),metaRef=visitasAgendaRef.doc('_meta');
    var refs=oldId===newId?[oldRef,metaRef]:[oldRef,newRef,metaRef];
    return fbDb.runTransaction(function(transaction){
      return Promise.all(refs.map(function(ref){return transaction.get(ref);})).then(function(snapshots){
        var byId={};snapshots.forEach(function(snapshot){byId[snapshot.id]=snapshot;});
        var oldItems=(byId[oldId]&&byId[oldId].exists&&byId[oldId].data().items||[]).slice();
        var newItems=oldId===newId?oldItems:(byId[newId]&&byId[newId].exists&&byId[newId].data().items||[]).slice();
        var existed=oldItems.some(function(item){return item&&item.id===visit.id;})||newItems.some(function(item){return item&&item.id===visit.id;});
        oldItems=oldItems.filter(function(item){return item&&item.id!==visit.id;});
        if(oldId===newId)newItems=oldItems;
        else newItems=newItems.filter(function(item){return item&&item.id!==visit.id;});
        newItems.push(visit);
        newItems.sort(function(a,b){return clean(a.id).localeCompare(clean(b.id));});
        if(oldId!==newId){
          if(oldItems.length)transaction.set(oldRef,{schema:'visitas-propias-v1',month:monthFor(previousDate),shard:shardFor(visit.id),items:oldItems,total:oldItems.length,updatedAt:firebase.firestore.FieldValue.serverTimestamp()});
          else if(byId[oldId]&&byId[oldId].exists)transaction.delete(oldRef);
        }
        transaction.set(newRef,{schema:'visitas-propias-v1',month:monthFor(visit.fechaVisita),shard:shardFor(visit.id),items:newItems,total:newItems.length,updatedAt:firebase.firestore.FieldValue.serverTimestamp()});
        var meta=byId._meta&&byId._meta.exists?byId._meta.data():{};
        transaction.set(metaRef,{schema:'visitas-propias-v1',source:'gestion',mondayDisabled:true,total:Math.max(0,Number(meta.total||visitasManualCache.length)+(existed?0:1)),version:Date.now(),updatedAt:firebase.firestore.FieldValue.serverTimestamp(),updatedBy:currentUser&&currentUser.nombre||''},{merge:true});
      });
    }).then(function(){return replaceCache(visit);});
  };

  window.removeVisitaPropiaFromCache=removeFromCache;
  window.VisitStorageRuntime={collection:COLLECTION,shards:SHARDS,docIdFor:docIdFor,cloneVisit:cloneVisit,normalizeVisitStatus:normalizeVisitStatus,load:ensureVisitasLoaded,upsert:window.upsertVisitaPropia,removeFromCache:removeFromCache};

  visitasMondayCache=[];
  visitasLoaded=false;
  visitasLoadingPromise=null;
  if(currentFirebaseUser)startVisitasMetaListener();
})();
