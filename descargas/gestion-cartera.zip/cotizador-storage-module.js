(function(){
// Cotizador integrado: almacenamiento dentro del mismo Firestore de Gestion.
// Este modulo se ejecuta despues de que la aplicacion compat inicializa Firebase.
const cotizadorDb = firebase.firestore();
const COTIZACIONES_COLLECTION = 'cotizaciones';
const COTIZADOR_CONFIG_PATH = 'cotizador/config';
const cotizacionesGestionRef = cotizadorDb.collection(COTIZACIONES_COLLECTION);
const cotizadorConfigGestionRef = cotizadorDb.doc(COTIZADOR_CONFIG_PATH);

async function cotizadorWaitForFirebaseSession() {
  const auth = firebase.auth();
  const persistenceReady = window.authPersistenceReady;

  if (persistenceReady && typeof persistenceReady.then === 'function') {
    try {
      await persistenceReady;
    } catch (error) {
      console.error('Firebase auth persistence error:', error);
    }
  }

  if (auth.currentUser) return auth.currentUser;

  return new Promise(function(resolve, reject) {
    let unsubscribe = null;
    unsubscribe = auth.onAuthStateChanged(function(user) {
      if (!user) return;
      if (unsubscribe) unsubscribe();
      resolve(user);
    }, function(error) {
      if (unsubscribe) unsubscribe();
      reject(error);
    });
  });
}

function cotizadorSubscribeAfterAuth(subscribe, onError) {
  let cancelled = false;
  let unsubscribeSnapshot = null;

  cotizadorWaitForFirebaseSession().then(function() {
    if (cancelled) return;
    unsubscribeSnapshot = subscribe();
  }).catch(function(error) {
    if (!cancelled) onError(error);
  });

  return function() {
    cancelled = true;
    if (unsubscribeSnapshot) unsubscribeSnapshot();
  };
}

function cotizadorFirestoreValue(value) {
  return JSON.parse(JSON.stringify(value == null ? null : value));
}

function cotizadorConfigValueEqual(left, right) {
  if (left === right) return true;
  if (!left || !right || typeof left !== 'object' || typeof right !== 'object') return false;
  if (Array.isArray(left) !== Array.isArray(right)) return false;
  if (Array.isArray(left)) {
    return left.length === right.length &&
      left.every(function(value, index) { return cotizadorConfigValueEqual(value, right[index]); });
  }
  const leftKeys = Object.keys(left);
  const rightKeys = Object.keys(right);
  return leftKeys.length === rightKeys.length && leftKeys.every(function(key) {
    return Object.prototype.hasOwnProperty.call(right, key) && cotizadorConfigValueEqual(left[key], right[key]);
  });
}

function cotizadorMergeConfigValue(remote, local) {
  if (!local || typeof local !== 'object' || Array.isArray(local)) return local;
  const merged = remote && typeof remote === 'object' && !Array.isArray(remote) ? { ...remote } : {};
  Object.keys(local).forEach(function(key) {
    merged[key] = cotizadorMergeConfigValue(merged[key], local[key]);
  });
  return merged;
}

function cotizacionTimestamp(value) {
  const parsed = Date.parse(value && value.timestamp || '');
  return Number.isFinite(parsed) ? parsed : 0;
}

window._fbGuardarCotizacion = async function(datos, id, opciones) {
  try {
    await cotizadorWaitForFirebaseSession();
    const clean = cotizadorFirestoreValue(datos || {});
    if (opciones && opciones.cambioProducto) {
      if (!window.QuoteProductRuntime) throw new Error('Actualiza la aplicación antes de cambiar proyecto o lote');
      return await window.QuoteProductRuntime.save(cotizadorDb,clean,id,opciones);
    }
    const document = id ? cotizacionesGestionRef.doc(id) : cotizacionesGestionRef.doc();
    if (opciones && opciones.cambioLoteSinReserva) {
      // Validar dentro del mismo guardado: otra sesión puede haber creado una
      // Reserva mientras el usuario cambiaba el lote. Nunca escribir la cartera.
      const rechazar = mensaje => {
        const error = new Error(mensaje);
        error.code = 'cotizacion-cambio-lote';
        throw error;
      };
      if (!id) rechazar('No se encontró la cotización original. Vuelve a abrirla');
      await window.CarteraPortfolioClient.create(cotizadorDb).runTransaction(async function(transaction) {
        const originalDoc = await transaction.get(document);
        const carteraDoc = await transaction.get(cotizadorDb.doc('cartera/state'));
        if (!originalDoc.exists) rechazar('La cotización original ya no existe. Actualiza los datos');
        const original = originalDoc.data() || {};
        const cartera = carteraDoc.exists && carteraDoc.data().state;
        if (!cartera || !Array.isArray(cartera.registros)) rechazar('No se pudo comprobar si existe una Reserva. Actualiza los datos e inténtalo nuevamente');
        const vinculada = original.reservaCreada || original.reservaId || clean.reservaCreada || clean.reservaId
          || cartera.registros.some(registro => registro && String(registro.cotizacionId || '') === String(id));
        if (vinculada) rechazar('Esta cotización ya tiene una Reserva vinculada. No se guardó el cambio de lote; vuelve a abrirla');
        if (String(original.proyecto) !== String(opciones.proyectoOriginal)
            || String(original.lote) !== String(opciones.loteOriginal)) {
          rechazar('El lote de esta cotización cambió desde otra sesión. Vuelve a abrirla antes de guardar');
        }
        if (clean.proyecto !== original.proyecto || !clean.lote || clean.lote === '—') rechazar('Elige un lote válido del mismo proyecto');
        transaction.set(document, clean);
      });
    } else {
      await document.set(clean);
    }
    return document.id;
  } catch (error) {
    console.error('Firestore cotizacion save error:', error);
    if (opciones && (opciones.cambioLoteSinReserva || opciones.cambioProducto)) throw error;
    return null;
  }
};

window._fbActualizarCotizacion = async function(id, datos) {
  try {
    await cotizadorWaitForFirebaseSession();
    await cotizacionesGestionRef.doc(id).set({
      ...cotizadorFirestoreValue(datos || {}),
      actualizadoAt: new Date().toISOString()
    }, { merge: true });
    return true;
  } catch (error) {
    console.error('Firestore cotizacion update error:', error);
    return false;
  }
};

// La interfaz elimina mediante deleteCarteraEntity, que valida Administrador y
// genera una copia recuperable. Esta funcion queda cerrada para evitar bypasses.
window._fbEliminarCotizacion = async function() {
  console.error('La eliminacion directa de cotizaciones esta deshabilitada.');
  return false;
};

window._fbGetNextFolio = async function() {
  try {
    await cotizadorWaitForFirebaseSession();
    const snapshot = await cotizacionesGestionRef.get();
    let maxExistente = snapshot.size;
    snapshot.forEach(function(document) {
      const data = document.data() || {};
      const directo = String(data.folioNum || '').replace(/\D/g, '');
      const completo = String(data.folioCompleto || '').match(/-(\d+)$/);
      const value = Number(directo || (completo ? completo[1] : 0));
      if (value) maxExistente = Math.max(maxExistente, value);
    });
    const nuevo = await cotizadorDb.runTransaction(async function(transaction) {
      const configSnapshot = await transaction.get(cotizadorConfigGestionRef);
      const current = configSnapshot.exists ? Number(configSnapshot.data().folioActual || 0) : 0;
      const next = Math.max(current, maxExistente) + 1;
      transaction.set(cotizadorConfigGestionRef, {
        folioActual: next,
        updatedAt: new Date().toISOString()
      }, { merge: true });
      return next;
    });
    return String(nuevo).padStart(4, '0');
  } catch (error) {
    console.error('Firestore folio error:', error);
    return '';
  }
};

window._fbCargarCotizaciones = function(callback) {
  return cotizadorSubscribeAfterAuth(function() {
    return cotizacionesGestionRef.onSnapshot(function(snapshot) {
        const lista = snapshot.docs.map(function(document) {
          return { id: document.id, ...document.data() };
        }).sort(function(left, right) {
          return cotizacionTimestamp(right) - cotizacionTimestamp(left) ||
            String(right.id || '').localeCompare(String(left.id || ''));
        });
        callback(lista);
      }, function(error) {
        console.error('Firestore cotizaciones listener error:', error);
        callback([]);
      });
  }, function(error) {
    console.error('Firestore cotizaciones load error:', error);
    callback([]);
  });
};

window._fbGuardarConfig = async function(datos, opciones) {
  try {
    await cotizadorWaitForFirebaseSession();
    const clean = cotizadorFirestoreValue(datos || {});
    const replaceDB = !!(opciones && opciones.replaceDB);
    const db = clean.DB || {};
    // Los cambios de descuentos/asignaciones no deben reenviar una copia vieja
    // del catálogo de lotes. Solo saveDB solicita reemplazar ese campo.
    delete clean.DB;
    await cotizadorDb.runTransaction(async function(transaction) {
      const snapshot = await transaction.get(cotizadorConfigGestionRef);
      const remote = snapshot.exists ? snapshot.data() || {} : {};
      const merged = cotizadorMergeConfigValue(remote, clean);
      // merge:true anidado conserva el lote anterior tras un cambio de nombre.
      // Reemplazar DB completo dentro de la transacción sí retira esa clave.
      if (replaceDB) merged.DB = db;
      merged.updatedAt = new Date().toISOString();
      transaction.set(cotizadorConfigGestionRef, merged);
    });
    return true;
  } catch (error) {
    console.error('Firestore cotizador config save error:', error);
    return false;
  }
};

// Actualiza un solo proyecto de forma atomica: conserva los demas proyectos y
// rechaza una planilla preparada sobre una version que otro usuario ya cambio.
window._fbActualizarProyectoCotizador = async function(pid, expectedProject, newProject) {
  await cotizadorWaitForFirebaseSession();
  return cotizadorDb.runTransaction(async function(transaction) {
    const snapshot = await transaction.get(cotizadorConfigGestionRef);
    const remote = snapshot.exists ? snapshot.data() || {} : {};
    const db = remote.DB || {};
    const existe = Object.prototype.hasOwnProperty.call(db, pid);
    if ((expectedProject == null && existe) ||
        (expectedProject != null && (!existe || !cotizadorConfigValueEqual(db[pid], expectedProject)))) {
      throw new Error('PROJECT_CHANGED');
    }
    const nextDB = { ...db };
    if (newProject == null) delete nextDB[pid];
    else nextDB[pid] = cotizadorFirestoreValue(newProject);
    const update = { DB: nextDB, updatedAt: new Date().toISOString() };
    // update({DB}) sustituye el mapa entero, no mezcla sus claves anidadas.
    if (snapshot.exists) transaction.update(cotizadorConfigGestionRef, update);
    else transaction.set(cotizadorConfigGestionRef, update);
    return { ...remote, DB: nextDB };
  });
};

window._fbCargarConfigUnaVez = async function() {
  try {
    await cotizadorWaitForFirebaseSession();
    const snapshot = await cotizadorConfigGestionRef.get();
    return snapshot.exists ? snapshot.data() : null;
  } catch (error) {
    console.error('Firestore cotizador config load error:', error);
    throw error;
  }
};

window._fbEscucharConfig = function(callback) {
  return cotizadorSubscribeAfterAuth(function() {
    return cotizadorConfigGestionRef.onSnapshot(function(snapshot) {
        callback(snapshot.exists ? snapshot.data() : null);
      }, function(error) {
        console.error('Firestore cotizador config listener error:', error);
      });
  }, function(error) {
    console.error('Firestore cotizador config listener error:', error);
  });
};

})();
