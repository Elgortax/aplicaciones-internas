(function initPruebaLotesRuntime(){
  'use strict';

  var REPLACEMENT_CHAR='\uFFFD';
  var FALLBACK_PROJECT_NAMES=[
    'Ra\u00edces de Rancagua',
    'Ra\u00edces de Rancagua II',
    'Cumbres de Da\u00f1icalqui',
    'Casa Torre\u00f3n'
  ];
  var knownNamesCache=null;
  var repairCache={};
  var lotesDataCache={signature:'',value:{}};
  var availabilityListView=false;

  function toggleDisponibilidadListado(){
    if(!currentUser||typeof puedeVerVista!=='function'||!puedeVerVista('lotes-vista'))return;
    availabilityListView=!availabilityListView;
    renderLotesVistaFast();
  }

  function renderAvailabilityList(grid,report,user){
    var colors={Firmado:['#dcfce7','#166534'],Reservado:['#fef9c3','#854d0e'],
      'Solicitud pendiente':['#ffedd5','#9a3412'],Bloqueado:['#fee2e2','#991b1b'],
      'Bloqueo comercial':['#ede9fe','#5b21b6'],Disponible:['var(--slate)','var(--text2)']};
    function price(value,currency){
      if(value===null)return 'Sin precio registrado';
      return currency==='UF'?value.toLocaleString('es-CL',{maximumFractionDigits:4})+' UF':
        '$ '+value.toLocaleString('es-CL',{maximumFractionDigits:0})+' CLP';
    }
    var rows=report.rows.map(function(row,i){
      var color=colors[row.status];
      return '<tr><td>'+esc(row.project)+'</td><td><button type="button" class="btn btn-sm" data-availability-row="'+i+'" aria-label="'+esc('Ver detalle de '+row.project+', lote '+row.lot)+'">Lote '+esc(row.lot)+'</button></td>'+
        '<td><span style="display:inline-block;border-radius:5px;padding:4px 7px;background:'+color[0]+';color:'+color[1]+'">'+esc(row.status)+'</span></td>'+
        '<td class="availability-amount">'+esc(availabilityAreaText(row.totalArea))+'</td>'+
        '<td class="availability-amount">'+esc(availabilityAreaText(row.easementArea))+'</td>'+
        '<td class="availability-amount">'+esc(availabilityAreaText(row.usableArea))+'</td>'+
        '<td class="availability-amount">'+esc(price(row.listPrice,row.currency))+'</td>'+
        '<td class="availability-amount">'+(row.sale===null?(row.client?'Sin precio registrado':'—'):esc(price(row.sale,'CLP')))+'</td>'+
        '<td>'+esc(row.client||'—')+'</td><td>'+esc(row.rol||'Sin dato')+'</td></tr>';
    }).join('');
    grid.innerHTML='<div class="availability-list"><p class="availability-list-note">Precio de lista: Cotizador. Precio de venta: ficha registrada, sin recalcular. Haz clic en un lote para ver su detalle.</p>'+
      '<div class="availability-list-scroll"><table><caption class="availability-list-caption">Disponibilidad por lote · '+esc(report.scope)+'</caption><thead><tr><th>Proyecto</th><th>Lote</th><th>Disponibilidad</th><th>Superficie total (m²)</th><th>Servidumbre (m²)</th><th>Superficie útil (m²)</th><th>Precio de lista (Cotizador)</th><th>Precio de venta (CLP)</th><th>Cliente</th><th>ROL</th></tr></thead><tbody>'+rows+
      (rows?'':'<tr><td colspan="10">No hay lotes que coincidan con los filtros seleccionados.</td></tr>')+'</tbody></table></div></div>';
    grid.querySelectorAll('[data-availability-row]').forEach(function(button){
      button.addEventListener('click',function(){
        if(currentUser!==user||!puedeVerVista('lotes-vista'))return;
        var row=report.rows[Number(button.dataset.availabilityRow)];
        if(row)applyLoteVistaAction(row.project,row.lot);
      });
    });
  }

  function decodeLegacyUtf8(value){
    var text=String(value===undefined||value===null?'':value).normalize('NFC');
    if(!/[\u00c2\u00c3]/.test(text))return text;
    try{
      var encoded='';
      for(var i=0;i<text.length;i++){
        var code=text.charCodeAt(i);
        if(code>255)return text;
        encoded+='%'+code.toString(16).padStart(2,'0');
      }
      var decoded=decodeURIComponent(encoded);
      return decoded.indexOf(REPLACEMENT_CHAR)<0?decoded.normalize('NFC'):text;
    }catch(error){
      return text;
    }
  }

  function plainProjectName(value){
    return String(value||'')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g,'')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g,' ')
      .trim();
  }

  function knownProjectNames(){
    if(knownNamesCache)return knownNamesCache;
    var names=FALLBACK_PROJECT_NAMES.slice();
    try{
      Object.keys(typeof LOTES_DATA==='object'&&LOTES_DATA?LOTES_DATA:{}).forEach(function(name){
        if(names.indexOf(name)<0)names.push(name);
      });
    }catch(error){}
    knownNamesCache=names;
    return knownNamesCache;
  }

  function matchesDamagedName(damaged,candidate){
    var chunks=String(damaged||'').split(/\uFFFD+/).map(plainProjectName).filter(Boolean);
    var target=plainProjectName(candidate);
    if(!chunks.length||!target)return false;
    var cursor=0;
    for(var i=0;i<chunks.length;i++){
      var found=target.indexOf(chunks[i],cursor);
      if(found<0)return false;
      if(i===0&&found!==0)return false;
      if(found-cursor>3)return false;
      cursor=found+chunks[i].length;
    }
    var damagedEndsWithReplacement=/\uFFFD$/.test(String(damaged||''));
    return damagedEndsWithReplacement?target.length-cursor<=3:target.length===cursor;
  }

  function repairProjectName(value){
    var text=decodeLegacyUtf8(value).trim();
    if(!text)return '';
    if(Object.prototype.hasOwnProperty.call(repairCache,text))return repairCache[text];
    var names=knownProjectNames();
    var exact=names.filter(function(name){return plainProjectName(name)===plainProjectName(text);});
    if(exact.length===1){repairCache[text]=exact[0];return exact[0];}
    if(text.indexOf(REPLACEMENT_CHAR)>=0){
      var damaged=names.filter(function(name){return matchesDamagedName(text,name);});
      if(damaged.length===1){repairCache[text]=damaged[0];return damaged[0];}
    }
    repairCache[text]=text;
    return text;
  }

  function sameProject(a,b){
    return plainProjectName(repairProjectName(a))===plainProjectName(repairProjectName(b));
  }

  function signedRecordCount(projects){
    var scoped=Array.isArray(projects);
    var scope=scoped?projects:null;
    return (((typeof state==='object'&&state&&state.registros)||[]).filter(function(record){
      var status=typeof getEstado==='function'?getEstado(record):String(record&&record.estado||'');
      if(status!=='Firmado')return false;
      return !scoped||scope.some(function(project){return sameProject(record.proyecto,project);});
    })).length;
  }

  function loteKey(value){
    if(typeof normalizeLoteValue==='function')return normalizeLoteValue(value);
    return String(value||'').trim().toUpperCase().replace(/\s+/g,'').replace(/^0+(?=\d)/,'');
  }

  function getCotizadorLotesData(){
    var source=typeof DB==='object'&&DB?DB:{};
    var signature=Object.keys(source).map(function(pid){
      var project=source[pid]||{};
      return pid+'\u0001'+String(project.nombre||'')+'\u0001'+Object.keys(project.lotes||{}).join('\u0002');
    }).join('\u0003');
    if(signature===lotesDataCache.signature)return lotesDataCache.value;
    var merged={};
    Object.keys(source).forEach(function(pid){
      var project=source[pid]||{};
      var name=repairProjectName(project.nombre);
      if(!name)return;
      var existing=Object.keys(merged).find(function(current){return sameProject(current,name);});
      var target=existing||name;
      if(!merged[target])merged[target]=[];
      Object.keys(project.lotes||{}).forEach(function(lote){
        if(project.lotes[lote]===null||project.lotes[lote]===undefined)return;
        if(!merged[target].some(function(current){return loteKey(current)===loteKey(lote);}))merged[target].push(String(lote));
      });
    });
    var ordered={};
    Object.keys(merged).sort(function(a,b){return a.localeCompare(b,'es');}).forEach(function(name){ordered[name]=merged[name];});
    lotesDataCache={signature:signature,value:ordered};
    return ordered;
  }

  function normalizedCentralConfig(config){
    if(!config||!config.DB)return config;
    var normalized=Object.assign({},config,{DB:{}});
    Object.keys(config.DB).forEach(function(pid){
      normalized.DB[pid]=Object.assign({},config.DB[pid],{nombre:repairProjectName(config.DB[pid]&&config.DB[pid].nombre)});
    });
    return normalized;
  }

  function normalizeCotizadorNamesInMemory(){
    var source=typeof DB==='object'&&DB?DB:{};
    var changed=false;
    Object.keys(source).forEach(function(pid){
      var project=source[pid];
      if(!project)return;
      var repaired=repairProjectName(project.nombre);
      if(repaired&&repaired!==project.nombre){project.nombre=repaired;changed=true;}
    });
    if(changed){
      try{localStorage.setItem('CotizadorProDB',JSON.stringify(source));}catch(error){}
    }
    return changed;
  }

  function projectBlockKey(project){
    var all=typeof ensureLotesBloqueados==='function'?ensureLotesBloqueados():{};
    return Object.keys(all).find(function(current){return sameProject(current,project);})||repairProjectName(project);
  }

  function getUnifiedBlock(project,lote){
    var all=typeof ensureLotesBloqueados==='function'?ensureLotesBloqueados():{};
    var key=projectBlockKey(project);
    var items=all[key]||{};
    var target=loteKey(lote);
    var itemKey=Object.keys(items).find(function(current){
      var item=items[current]||{};
      return loteKey(current)===target||loteKey(item.lote)===target;
    });
    return itemKey?items[itemKey]:null;
  }

  function setUnifiedBlock(project,lote,type,reason){
    var all=typeof ensureLotesBloqueados==='function'?ensureLotesBloqueados():{};
    var projectKey=projectBlockKey(project);
    var key=loteKey(lote);
    if(!key)return;
    if(!all[projectKey])all[projectKey]={};
    Object.keys(all[projectKey]).forEach(function(current){
      var item=all[projectKey][current]||{};
      if(loteKey(current)===key||loteKey(item.lote)===key)delete all[projectKey][current];
    });
    if(type&&type!=='liberar'){
      all[projectKey][key]={tipo:type==='comercial'?'comercial':'normal',lote:String(lote),motivo:String(reason||'').trim()};
    }
    if(!Object.keys(all[projectKey]).length)delete all[projectKey];
  }

  function isManagementAdminOpen(){
    var panel=document.getElementById('panel-admin');
    return !!(panel&&panel.classList.contains('active')&&typeof getRoleKey==='function'&&getRoleKey(currentUser)==='Administrador');
  }

  function getCotizadorLot(project,lote){
    var source=typeof DB==='object'&&DB?DB:{};
    var matches=[];
    Object.keys(source).forEach(function(pid){
      var entry=source[pid]||{};
      if(!sameProject(entry.nombre,project))return;
      var lots=entry.lotes||{};
      var exact=Object.prototype.hasOwnProperty.call(lots,String(lote));
      var keys=exact?[String(lote)]:Object.keys(lots).filter(function(key){return loteKey(key)===loteKey(lote);});
      keys.forEach(function(key){if(lots[key])matches.push(lots[key]);});
    });
    // No asociar datos arbitrarios si el catálogo tiene nombres duplicados.
    return matches.length===1?matches[0]:null;
  }

  function getCotizadorLotPrice(project,lote){
    var lot=getCotizadorLot(project,lote);
    if(!lot)return null;
    var raw=lot.precio;
    if((typeof raw!=='number'&&typeof raw!=='string')||String(raw).trim()==='')return null;
    var amount=Number(raw),currency=String(lot.moneda||'').trim().toUpperCase();
    if(!Number.isFinite(amount)||amount<0||['UF','CLP'].indexOf(currency)<0)return null;
    return {amount:amount,currency:currency};
  }

  function availabilityArea(value){
    if((typeof value!=='number'&&typeof value!=='string')||String(value).trim()==='')return null;
    var amount=Number(value);
    return Number.isFinite(amount)&&amount>=0?amount:null;
  }

  function availabilityAreaText(value){
    return value===null?'Sin dato':value.toLocaleString('es-CL',{maximumFractionDigits:10})+' m²';
  }

  function getCotizadorLotInfo(project,lote){
    var lot=getCotizadorLot(project,lote)||{};
    return {totalArea:availabilityArea(lot.mts),easementArea:availabilityArea(lot.servidumbre),
      usableArea:availabilityArea(lot.utiles),rol:typeof lot.rol==='string'?lot.rol.trim():''};
  }

  function addCotizadorLotPrice(project,lote){
    var body=document.getElementById('lote-detalle-body');
    if(!body)return;
    var previous=body.querySelector('.lote-cotizador-precio');
    if(previous)previous.remove();
    var price=getCotizadorLotPrice(project,lote);
    var card=document.createElement('div');
    card.className='lote-cotizador-precio';
    card.style.cssText='margin:0 0 14px;padding:12px 14px;background:var(--slate);border:1px solid var(--border);border-radius:var(--r)';
    var label=document.createElement('div');
    label.textContent='Precio de lista · Cotizador';
    label.style.cssText='font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.05em;color:var(--text2);margin-bottom:5px';
    var value=document.createElement('div');
    value.textContent=price?(price.currency==='CLP'?'$ ':'')+price.amount.toLocaleString('es-CL',{maximumFractionDigits:price.currency==='UF'?4:0})+' '+price.currency:'Sin precio registrado en el cotizador';
    value.style.cssText='font-size:'+(price?'21':'12')+'px;font-weight:700;color:var(--text);line-height:1.3';
    card.appendChild(label);card.appendChild(value);
    var info=getCotizadorLotInfo(project,lote);
    var facts=document.createElement('div');
    facts.style.cssText='display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:12px;margin-top:14px';
    [['Superficie total',availabilityAreaText(info.totalArea)],['Servidumbre',availabilityAreaText(info.easementArea)],
      ['Superficie útil',availabilityAreaText(info.usableArea)],['ROL',info.rol||'Sin dato']].forEach(function(item){
      var field=document.createElement('div'),title=document.createElement('div'),text=document.createElement('div');
      title.textContent=item[0];title.style.cssText='font-size:11px;color:var(--text2);margin-bottom:4px';
      text.textContent=item[1];text.style.cssText='font-size:13px;font-weight:700;color:var(--text)';
      field.appendChild(title);field.appendChild(text);facts.appendChild(field);
    });
    card.appendChild(facts);
    // Debajo del proyecto y del estado, antes de los datos de reserva o bloqueo.
    body.insertBefore(card,body.children[1]||null);
  }

  function addAdminBlockActions(project,lote){
    if(!isManagementAdminOpen())return;
    var block=getUnifiedBlock(project,lote);
    if(!block)return;
    var body=document.getElementById('lote-detalle-body');
    if(!body||body.querySelector('.prueba-block-actions'))return;
    var actions=document.createElement('div');
    actions.className='prueba-block-actions';
    actions.style.cssText='display:flex;justify-content:flex-end;gap:8px;flex-wrap:wrap;margin-top:14px;padding-top:12px;border-top:1px solid var(--border)';
    var edit=document.createElement('button');
    edit.type='button';
    edit.className='btn btn-primary btn-sm';
    edit.textContent='Editar bloqueo y motivo';
    edit.addEventListener('click',function(){
      closeModal('modal-lote-detalle');
      openBloqueoLoteModal(project,lote,block.tipo||'normal');
    });
    var release=document.createElement('button');
    release.type='button';
    release.className='btn btn-ghost btn-sm';
    release.textContent='Liberar lote';
    release.addEventListener('click',function(){
      setUnifiedBlock(project,lote,'liberar','');
      Promise.resolve(typeof saveLotesBloqueadosImmediate==='function'?saveLotesBloqueadosImmediate():null).then(function(){
        closeModal('modal-lote-detalle');
        if(typeof renderLotesAdmin==='function')renderLotesAdmin();
        if(typeof renderLotesVista==='function')renderLotesVista();
        if(typeof toast==='function')toast('Bloqueo liberado','success');
      });
    });
    actions.appendChild(edit);
    actions.appendChild(release);
    body.appendChild(actions);
  }

  function emptyAvailabilityCounts(){
    return {total:0,res:0,fir:0,pen:0,disp:0,bn:0,bc:0};
  }

  function isPendingReleaseRequest(record){
    if(typeof esSolicitudLiberacionPendiente==='function')return esSolicitudLiberacionPendiente(record);
    return !!(record&&(
      (record.estado==='Desistido'&&(record.desistEstado||'aprobada')==='pendiente')||
      (record.estado==='Resciliación'&&record.rescilEstado==='pendiente')
    ));
  }

  function addAvailabilityCounts(target,source){
    Object.keys(target).forEach(function(key){target[key]+=source[key]||0;});
    return target;
  }

  function buildAvailabilityModel(data,projects,user){
    var recordsByProject={};
    var blocksByProject={};
    var countsByProject={};
    var projectCache={};
    var ownSaleKeys={};
    var blockSource=typeof ensureLotesBloqueados==='function'?ensureLotesBloqueados():{};
    var blockProjectNames=Object.keys(blockSource);

    projects.forEach(function(project){
      recordsByProject[project]={};
      blocksByProject[project]={};
      countsByProject[project]=emptyAvailabilityCounts();
    });

    function resolveProject(value){
      var cacheKey=String(value||'');
      if(Object.prototype.hasOwnProperty.call(projectCache,cacheKey))return projectCache[cacheKey];
      projectCache[cacheKey]=projects.find(function(project){return sameProject(project,value);})||'';
      return projectCache[cacheKey];
    }

    (((typeof state==='object'&&state&&state.registros)||[])).forEach(function(record){
      if(typeof registroOcupaLote==='function'&&!registroOcupaLote(record))return;
      var project=resolveProject(record&&record.proyecto);
      var key=loteKey(record&&record.name);
      if(!project||!key)return;
      var status=typeof getEstado==='function'?getEstado(record):String(record&&record.estado||'');
      var signed=typeof esEfectivamenteFirmado==='function'?esEfectivamenteFirmado(record):status==='Firmado';
      var pendingApproval=isPendingReleaseRequest(record);
      var candidate={
        record:record,
        estado:status,
        firmado:signed,
        pendienteAprobacion:pendingApproval,
        prioridad:status==='Firmado'?3:(pendingApproval?2:(signed?2:(status==='Reservado'?1:0))),
        propio:typeof isOwnSignedLotRecord==='function'&&isOwnSignedLotRecord(record,user)
      };
      var current=recordsByProject[project][key];
      if(!current||candidate.prioridad>current.prioridad)recordsByProject[project][key]=candidate;
      if(candidate.propio)ownSaleKeys[project+'|'+key]=true;
    });

    projects.forEach(function(project){
      var sourceName=blockProjectNames.find(function(name){return sameProject(name,project);});
      var source=sourceName?blockSource[sourceName]:{};
      Object.keys(source||{}).forEach(function(key){
        var item=source[key]||{};
        var normalized=loteKey(item.lote||key);
        if(normalized)blocksByProject[project][normalized]=item;
      });
      (data[project]||[]).forEach(function(lote){
        var counts=countsByProject[project];
        var key=loteKey(lote);
        var record=recordsByProject[project][key];
        var block=blocksByProject[project][key];
        counts.total++;
        if(record){
          if(record.pendienteAprobacion)counts.pen++;
          else if(record.firmado||record.estado==='Firmado')counts.fir++;
          else counts.res++;
        }else if(block){
          if(block.tipo==='comercial')counts.bc++;
          else counts.bn++;
        }else{
          counts.disp++;
        }
      });
    });

    return {
      recordsByProject:recordsByProject,
      blocksByProject:blocksByProject,
      countsByProject:countsByProject,
      ownSaleCount:Object.keys(ownSaleKeys).length
    };
  }

  function isTerrainAvailabilityUser(user){
    if(!user)return false;
    var explicitRole=plainProjectName(user.rol||'');
    if(explicitRole==='terreno')return true;
    return typeof getRoleKey==='function'&&getRoleKey(user)==='Terreno';
  }

  function terrainAssignment(user){
    user=user||{};
    var aliases=[user.nombre,user.user,String(user.email||'').split('@')[0]]
      .concat(Array.isArray(user.scopeNames)?user.scopeNames:[])
      .concat(Array.isArray(user.aliasesAgente)?user.aliasesAgente:[])
      .map(plainProjectName).filter(Boolean);
    var sellers=typeof VENDEDORES_PROY_DB!=='undefined'&&Array.isArray(VENDEDORES_PROY_DB)?VENDEDORES_PROY_DB:[];
    var matched=sellers.filter(function(seller){
      var candidate=plainProjectName(seller&&seller.nombre||'');
      if(!candidate)return false;
      return aliases.some(function(alias){
        return alias===candidate||(alias.length>=4&&candidate.length>=4&&(alias.indexOf(candidate)>=0||candidate.indexOf(alias)>=0));
      });
    });
    var sellerIds=matched.map(function(seller){return String(seller.id||'');}).filter(Boolean);
    var assignments=typeof VENDEDOR_PROY_DB!=='undefined'&&VENDEDOR_PROY_DB?VENDEDOR_PROY_DB:{};
    var ids=Object.keys(typeof DB==='object'&&DB?DB:{}).filter(function(projectId){
      var assigned=Array.isArray(assignments[projectId])?assignments[projectId].map(String):[];
      return assigned.some(function(sellerId){return sellerIds.indexOf(sellerId)>=0;});
    });
    return {matched:matched.length>0,projectIds:ids};
  }

  function getTerrainAvailabilityProjects(user,data){
    data=data||getCotizadorLotesData();
    var allProjects=Object.keys(data);
    var terrainUser=isTerrainAvailabilityUser(user);
    if(!terrainUser)return allProjects;

    var visible=[];
    function addProject(value){
      if(!value)return;
      var canonical=allProjects.find(function(project){return sameProject(project,value);});
      if(canonical&&visible.indexOf(canonical)<0)visible.push(canonical);
    }

    // Para Terreno, la asignacion Vendedor x Proyecto del administrador del
    // Cotizador es autoritativa. No se amplía con actividad histórica: una
    // reserva o visita antigua no debe volver a habilitar un proyecto.
    var explicit=terrainAssignment(user);
    explicit.projectIds.forEach(function(id){
      addProject(typeof DB==='object'&&DB&&DB[id]&&DB[id].nombre?DB[id].nombre:id);
    });

    // Compatibilidad con perfiles antiguos que todavía viven como ejecutivos
    // del Cotizador. Sólo se usa cuando no existe una ficha de vendedor Terreno.
    if(!explicit.matched){
      try{
        var bridge=window.cotizadorGestionSso;
        var status=bridge&&typeof bridge.status==='function'?bridge.status():null;
        var ids=status&&Array.isArray(status.visibleProjectIds)?status.visibleProjectIds:[];
        ids.forEach(function(id){
          addProject(typeof DB==='object'&&DB&&DB[id]&&DB[id].nombre?DB[id].nombre:id);
        });
      }catch(error){}
    }
    return visible.sort(function(a,b){return a.localeCompare(b,'es');});
  }

  function isSellerAvailabilityUser(user){
    if(!user)return false;
    return typeof isReadOnlySellerUser==='function'
      ?isReadOnlySellerUser(user)
      :isTerrainAvailabilityUser(user)||['remoto','vendedor','vendedora'].indexOf(plainProjectName(user.rol||''))>=0;
  }

  function getSellerAvailabilityProjects(user,data){
    data=data||getCotizadorLotesData();
    var allProjects=Object.keys(data);
    if(!isSellerAvailabilityUser(user))return allProjects;
    if(isTerrainAvailabilityUser(user))return getTerrainAvailabilityProjects(user,data);

    // Remoto usa las mismas asignaciones del Cotizador: no incluir proyectos
    // sin asignar ni recuperar proyectos antiguos por actividad histórica.
    var ids=[];
    try{
      var bridge=window.cotizadorGestionSso;
      var status=bridge&&typeof bridge.status==='function'?bridge.status():null;
      if(status&&Array.isArray(status.visibleProjectIds))ids=status.visibleProjectIds;
      if(!ids.length&&(!status||!status.active)&&bridge&&typeof bridge.findSeller==='function'){
        var seller=bridge.findSeller(user);
        var assignments=typeof ASIG_DB!=='undefined'&&ASIG_DB?ASIG_DB:{};
        if(seller)ids=Object.keys(assignments).filter(function(id){
          return Array.isArray(assignments[id])&&assignments[id].indexOf(seller.id)>=0;
        });
      }
    }catch(error){}
    var visible=[];
    ids.forEach(function(id){
      var name=typeof DB==='object'&&DB&&DB[id]&&DB[id].nombre?DB[id].nombre:id;
      var canonical=allProjects.find(function(project){return sameProject(project,name);});
      if(canonical&&visible.indexOf(canonical)<0)visible.push(canonical);
    });
    return visible.sort(function(a,b){return a.localeCompare(b,'es');});
  }

  // Una sola fotografía de datos para Excel y PDF; misma prioridad y permisos que el panel.
  var availabilityExportBusy=false;
  var availabilityStatusCounts={'Firmado':'fir','Reservado':'res','Solicitud pendiente':'pen','Bloqueado':'bn','Bloqueo comercial':'bc','Disponible':'disp'};
  var availabilityClientHeaders=['Proyecto','Lote','Disponibilidad','Superficie total (m²)','Servidumbre (m²)','Superficie útil (m²)','Precio de lista'];
  var availabilityDetailHeaders=['Proyecto','Lote','Estado','Cliente','RUT','Precio venta (CLP)','Precio lista','Moneda lista','Fecha reserva','Fecha firma / agenda','Detalle','Superficie total (m²)','Servidumbre (m²)','Superficie útil (m²)','ROL'];
  var availabilitySummaryHeaders=['Proyecto','Lotes','Firmados','Monto firmado (CLP)','Reservados','Monto reservado (CLP)','Solicitudes pendientes','Bloqueados','Bloq. comercial','Disponibles','Ventas sin monto'];
  var availabilityExportNote='Precio venta: ficha de cartera (CLP). Precio lista y superficies: Cotizador, por lote. Superficies en m²; ROL vacío si no está registrado. Los montos faltantes no se reemplazan por precio de lista; UF y CLP no se suman entre sí.';

  function availabilitySaleAmount(value){
    if(typeof value==='number')return Number.isFinite(value)&&value>=0?value:null;
    if(typeof value!=='string'||!value.trim())return null;
    var text=value.trim().replace(/^(?:CLP\s*|\$\s*)/i,'').replace(/\s+/g,'');
    if(/^\d{1,3}(\.\d{3})+(,\d+)?$/.test(text))text=text.replace(/\./g,'').replace(',','.');
    else if(/^\d+(,\d+)?$/.test(text))text=text.replace(',','.');
    if(!/^\d+(\.\d+)?$/.test(text))return null;
    var amount=Number(text);return Number.isFinite(amount)&&amount>=0?amount:null;
  }

  function availabilityExportDate(value){
    if(!value)return '';
    var normalized=typeof normalizeDateValue==='function'?normalizeDateValue(value):String(value);
    var match=/^(\d{4})-(\d{2})-(\d{2})$/.exec(normalized||'');
    if(!match)return '';
    var date=new Date(Number(match[1]),Number(match[2])-1,Number(match[3]));
    return date.getFullYear()===Number(match[1])&&date.getMonth()===Number(match[2])-1&&date.getDate()===Number(match[3])?normalized:'';
  }

  function buildAvailabilityExportReport(selectedProject,user,selectedStatus){
    if(!user)throw new Error('Inicia sesión antes de descargar la disponibilidad.');
    selectedStatus=selectedStatus||'';
    if(selectedStatus&&!Object.prototype.hasOwnProperty.call(availabilityStatusCounts,selectedStatus))throw new Error('El filtro de disponibilidad no es válido. Actualiza el panel.');
    var data=getCotizadorLotesData(),allowed=getSellerAvailabilityProjects(user,data);
    var projects=selectedProject?allowed.filter(function(p){return p===selectedProject;}):allowed;
    if(selectedProject&&!projects.length)throw new Error('El proyecto seleccionado no está disponible para tu usuario. Actualiza el panel.');
    var model=buildAvailabilityModel(data,projects,user),rows=[],summary=[];
    projects.forEach(function(project){
      var counts=emptyAvailabilityCounts();
      var totals={project:project,counts:counts,signedAmount:0,reservedAmount:0,missingSales:0};
      var lots=typeof ordenarLotesCorrelativos==='function'?ordenarLotesCorrelativos(data[project]):data[project].slice().sort(function(a,b){return String(a).localeCompare(String(b),'es',{numeric:true});});
      lots.forEach(function(lot){
        var key=loteKey(lot),entry=model.recordsByProject[project][key],block=model.blocksByProject[project][key];
        var status=entry?(entry.pendienteAprobacion?'Solicitud pendiente':entry.firmado||entry.estado==='Firmado'?'Firmado':'Reservado'):block?(block.tipo==='comercial'?'Bloqueo comercial':'Bloqueado'):'Disponible';
        if(selectedStatus&&status!==selectedStatus)return;
        counts.total++;counts[availabilityStatusCounts[status]]++;
        var record=entry&&entry.record,price=getCotizadorLotPrice(project,lot),info=getCotizadorLotInfo(project,lot),detail=[];
        var sale=record?availabilitySaleAmount(record.precio):null;
        if(entry&&entry.estado!==status)detail.push('Estado de ficha: '+entry.estado);
        if(entry&&entry.pendienteAprobacion)detail.push('Liberación pendiente de aprobación');
        if(record&&sale===null)detail.push('Sin precio de venta registrado');
        if(!price)detail.push('Sin precio de lista inequívoco en Cotizador');
        if(!entry&&block&&block.motivo)detail.push(String(block.motivo));
        if(status==='Firmado'||status==='Reservado'){
          if(sale===null)totals.missingSales++;
          else if(status==='Firmado')totals.signedAmount+=sale;
          else totals.reservedAmount+=sale;
        }
        rows.push({recordId:record&&record.id||'',project:project,lot:String(lot),status:status,client:record?String(record.cliente||''):'',
          rut:record?(typeof formatRutParaExportar==='function'?formatRutParaExportar(record.rut):String(record.rut||'')):'',
          sale:sale,listPrice:price?price.amount:null,currency:price?price.currency:'',
          totalArea:info.totalArea,easementArea:info.easementArea,usableArea:info.usableArea,rol:info.rol,
          reservationDate:record?availabilityExportDate(record.fechaReserva):'',signatureDate:record?availabilityExportDate(record.fechaFirma):'',detail:detail.join(' · ')});
      });
      if(counts.total)summary.push(totals);
    });
    return {kind:'commercial',rows:rows,summary:summary,scope:(selectedProject||(isSellerAvailabilityUser(user)?'Todos mis proyectos':'Todos los proyectos'))+' · '+(selectedStatus||'Todos los estados'),
      generated:new Date().toLocaleString('es-CL',{timeZone:'America/Santiago'}),note:availabilityExportNote,
      detailHeaders:availabilityDetailHeaders.slice(),summaryHeaders:availabilitySummaryHeaders.slice()};
  }

  // Lista blanca: el informe Cliente nunca recibe datos personales, ventas,
  // observaciones, ROL ni resúmenes internos, tampoco en hojas ocultas.
  function buildAvailabilityClientReport(report){
    return {kind:'client',scope:report.scope,generated:report.generated,
      note:'Superficies en m². Precio de lista del Cotizador, en la moneda indicada (UF o CLP). Sin dato: información no registrada.',
      detailHeaders:availabilityClientHeaders.slice(),
      rows:report.rows.map(function(r){return {project:r.project,lot:r.lot,status:r.status,
        totalArea:r.totalArea,easementArea:r.easementArea,usableArea:r.usableArea,listPrice:r.listPrice,currency:r.currency};})};
  }

  function availabilitySummaryValues(item){
    var c=item.counts;return [item.project,c.total,c.fir,item.signedAmount,c.res,item.reservedAmount,c.pen,c.bn,c.bc,c.disp,item.missingSales];
  }

  function buildAvailabilityWorkbook(report){
    var xlsx=window.XLSX;
    if(!xlsx||!xlsx.utils)throw new Error('No se pudo cargar Excel. Recarga la página e inténtalo de nuevo.');
    function excelDate(iso){if(!iso)return null;var parts=iso.split('-').map(Number);return new Date(parts[0],parts[1]-1,parts[2]);}
    function sheet(title,headers,body,widths){
      var result=xlsx.utils.aoa_to_sheet([[title],[report.scope+' · Generado '+report.generated+' (Chile)'],[report.note],[],headers].concat(body),{cellDates:true,dateNF:'dd/mm/yyyy'});
      result['!cols']=widths.map(function(width,col){return {wch:Math.min(255,Math.max(width,headers[col].length+2,...body.map(function(row){return typeof row[col]==='string'?row[col].length+2:0;})))};});
      result['!autofilter']={ref:'A5:'+xlsx.utils.encode_col(headers.length-1)+(body.length+5)};
      result['!merges']=[0,1,2].map(function(row){return {s:{r:row,c:0},e:{r:row,c:headers.length-1}};});
      return result;
    }
    if(report.kind==='client'){
      var clientRows=report.rows.map(function(r){return [r.project,r.lot,r.status,
        r.totalArea===null?'Sin dato':r.totalArea,r.easementArea===null?'Sin dato':r.easementArea,
        r.usableArea===null?'Sin dato':r.usableArea,r.listPrice===null?'Sin dato':r.listPrice];});
      var clientSheet=sheet('Disponibilidad Cliente · Detalle de lotes',availabilityClientHeaders,clientRows,[30,12,24,24,22,24,25]);
      report.rows.forEach(function(row,index){
        ['D','E','F'].forEach(function(col){var cell=clientSheet[col+(index+6)];if(cell&&cell.t==='n')cell.z='#,##0.##########';});
        var price=clientSheet['G'+(index+6)];
        if(price&&price.t==='n'){
          var decimals=(row.listPrice.toFixed(4).replace(/0+$/,'').split('.')[1]||'').length;
          price.z=row.currency==='UF'?'#,##0'+(decimals?'.'+'0'.repeat(decimals):'')+'" UF"':'"$"#,##0" CLP"';
        }
        var lot=clientSheet['B'+(index+6)];if(lot)lot.z='@';
      });
      var clientBook=xlsx.utils.book_new();xlsx.utils.book_append_sheet(clientBook,clientSheet,'Disponibilidad');
      return clientBook;
    }
    var detail=report.rows.map(function(r){return [r.project,r.lot,r.status,r.client,r.rut,r.sale===null&&['Firmado','Reservado','Solicitud pendiente'].indexOf(r.status)>=0?'Sin dato':r.sale,r.listPrice===null?'Sin dato':r.listPrice,r.currency,excelDate(r.reservationDate),excelDate(r.signatureDate),r.detail,r.totalArea,r.easementArea,r.usableArea,r.rol];});
    if(report.clientTable){var enriched=CarteraClientesInforme.table(report.detailHeaders,detail,report.rows.map(function(row){return row.clientProfile;}));detail=enriched.rows;report=Object.assign({},report,{detailHeaders:enriched.headers});}
    var summary=report.summary.map(availabilitySummaryValues);
    var detailSheet=sheet('Disponibilidad Comercial · Detalle de lotes',report.detailHeaders,detail,report.detailHeaders.map(function(h,i){return [30,12,24,45,16,22,22,15,18,22,50,24,22,24,20][i]||Math.max(20,h.length+2);}));
    report.rows.forEach(function(row,index){
      ['F','G'].forEach(function(col){var cell=detailSheet[col+(index+6)];if(cell&&cell.t==='n')cell.z=col==='G'&&row.currency==='UF'?'#,##0.####':'"$"#,##0';});
      ['L','M','N'].forEach(function(col){var cell=detailSheet[col+(index+6)];if(cell&&cell.t==='n')cell.z='#,##0.##########';});
      var rolCell=detailSheet['O'+(index+6)];if(rolCell)rolCell.z='@';
    });
    var summarySheet=sheet('Disponibilidad Comercial · Resumen por proyecto',report.summaryHeaders,summary,[30,12,12,25,14,25,23,15,18,15,19]);
    // Fórmulas con valor calculado guardado para Excel y visores sin recálculo.
    var offset=6;
    report.summary.forEach(function(item,index){
      var row=index+6,end=offset+item.counts.total-1;
      if(item.counts.total){
        var states="'Detalle'!$C$"+offset+':$C$'+end,amounts="'Detalle'!$F$"+offset+':$F$'+end;
        var formulas={B:'COUNTA('+states+')',C:'COUNTIF('+states+',"Firmado")',D:'SUMIF('+states+',"Firmado",'+amounts+')',E:'COUNTIF('+states+',"Reservado")',F:'SUMIF('+states+',"Reservado",'+amounts+')',G:'COUNTIF('+states+',"Solicitud pendiente")',H:'COUNTIF('+states+',"Bloqueado")',I:'COUNTIF('+states+',"Bloqueo comercial")',J:'COUNTIF('+states+',"Disponible")',K:'COUNTIFS('+states+',"Firmado",'+amounts+',"Sin dato")+COUNTIFS('+states+',"Reservado",'+amounts+',"Sin dato")'};
        Object.keys(formulas).forEach(function(col){summarySheet[col+row].f=formulas[col];});
      }
      offset=end+1;
    });
    var totalRow=summary.length+6,total=['TOTAL GENERAL'];
    for(var col=1;col<11;col++)total.push(summary.reduce(function(sum,row){return sum+row[col];},0));
    xlsx.utils.sheet_add_aoa(summarySheet,[total],{origin:'A'+totalRow});
    for(var col=1;col<11;col++){
      var letter=xlsx.utils.encode_col(col);
      if(summary.length)summarySheet[letter+totalRow].f='SUM('+letter+'6:'+letter+(totalRow-1)+')';
    }
    for(var row=6;row<=totalRow;row++)['D','F'].forEach(function(col){summarySheet[col+row].z='"$"#,##0';});
    var book=xlsx.utils.book_new();xlsx.utils.book_append_sheet(book,summarySheet,'Resumen');xlsx.utils.book_append_sheet(book,detailSheet,'Detalle');
    return book;
  }

  async function exportDisponibilidad(format,audience){
    if(availabilityExportBusy)return;
    var user=typeof currentUser==='object'?currentUser:null;
    if(!user||typeof puedeVerVista!=='function'||!puedeVerVista('lotes-vista')){toast('No tienes acceso a Disponibilidad.','error');return;}
    if(format!=='excel'&&format!=='pdf')return;
    audience=audience||'commercial';
    if(audience!=='commercial'&&audience!=='client')return;
    var filter=document.getElementById('lotes-vista-fil'),statusFilter=document.getElementById('lotes-vista-estado');
    var selectedProject=filter?filter.value:'',selectedStatus=statusFilter?statusFilter.value:'';
    availabilityExportBusy=true;
    var buttons=['lotes-vista-excel','lotes-vista-pdf','lotes-vista-excel-cliente','lotes-vista-pdf-cliente'].map(function(id){return document.getElementById(id);});
    buttons.forEach(function(button){if(button)button.disabled=true;});
    try{
      if(typeof _configRemotaPromesa!=='undefined'&&_configRemotaPromesa)await _configRemotaPromesa;
      if(typeof stateLoadedFromCloud!=='undefined'&&!stateLoadedFromCloud)throw new Error('Espera a que terminen de cargar los datos y vuelve a descargar.');
      if(currentUser!==user||!puedeVerVista('lotes-vista'))throw new Error('La sesión cambió. Vuelve a abrir Disponibilidad.');
      var report=buildAvailabilityExportReport(selectedProject,user,selectedStatus);
      if(!report.rows.length)throw new Error('No hay lotes para descargar con los filtros seleccionados.');
      if(audience==='client')report=buildAvailabilityClientReport(report);
      else{
        var clientSources=report.rows.filter(function(row){return !!row.recordId;}).map(function(row){return {registroId:row.recordId};});
        var contacts=await cargarContactosInforme(clientSources);
        report.rows.forEach(function(row){row.clientProfile=row.recordId?contactoDeFilaInforme({registroId:row.recordId},contacts):CarteraClientesInforme.profile({}, {}, {});if(row.recordId){row.rut=row.clientProfile.rut;row.client=row.clientProfile.nombre;}});
        report.clientTable=CarteraClientesInforme.clientTable(clientSources,contacts);
      }
      var filename='Disponibilidad_'+(audience==='client'?'Cliente':'Comercial')+'_'+new Date().toLocaleDateString('en-CA',{timeZone:'America/Santiago'}).replace(/[^0-9-]/g,'');
      if(format==='excel'){
        var workbook=buildAvailabilityWorkbook(report);
        window.XLSX.writeFile(workbook,filename+'.xlsx');toast('Excel descargado: '+report.rows.length+' lotes.','success');
      }else{
        if(typeof window.downloadDisponibilidadPDF!=='function')throw new Error('No se pudo cargar PDF. Recarga la página e inténtalo de nuevo.');
        window.downloadDisponibilidadPDF(report,filename+'.pdf');
      }
    }catch(error){console.error('Exportación de disponibilidad:',error);toast(error.message||'No se pudo generar la descarga.','error');}
    finally{availabilityExportBusy=false;buttons.forEach(function(button){if(button)button.disabled=false;});}
  }

  function renderLotesVistaFast(){
    var startedAt=Date.now();
    var data=getCotizadorLotesData();
    var user=typeof currentUser==='object'?currentUser:null;
    var listGrid=document.getElementById('lotes-vista-grid');
    if(!user||typeof puedeVerVista!=='function'||!puedeVerVista('lotes-vista')){if(listGrid)listGrid.innerHTML='';return;}
    if(typeof loteVistaMode!=='undefined')loteVistaMode='';
    var sellerRestricted=isSellerAvailabilityUser(user);
    var projects=getSellerAvailabilityProjects(user,data);
    var filter=document.getElementById('lotes-vista-fil');
    if(!filter)return;
    var current=filter.value;
    filter.innerHTML='<option value="">'+(sellerRestricted?'Todos mis proyectos':'Todos los proyectos')+'</option>';
    projects.forEach(function(project){
      var option=document.createElement('option');
      option.value=project;
      option.textContent=project;
      filter.appendChild(option);
    });
    filter.value=projects.indexOf(current)>=0?current:'';
    var visibleProjects=filter.value?[filter.value]:projects;
    var model=buildAvailabilityModel(data,visibleProjects,user);
    var statusFilter=document.getElementById('lotes-vista-estado');
    var report=buildAvailabilityExportReport(filter.value,user,statusFilter?statusFilter.value:'');
    var visibleLots={},visibleCounts={},ownCount=0;
    report.summary.forEach(function(item){visibleLots[item.project]=[];visibleCounts[item.project]=item.counts;});
    report.rows.forEach(function(row){
      visibleLots[row.project].push(row.lot);
      var entry=model.recordsByProject[row.project][loteKey(row.lot)];
      if(row.status==='Firmado'&&entry&&entry.propio)ownCount++;
    });
    visibleProjects=report.summary.map(function(item){return item.project;});
    var totals=emptyAvailabilityCounts();
    visibleProjects.forEach(function(project){addAvailabilityCounts(totals,visibleCounts[project]);});

    var ownLegend=document.getElementById('lotes-vista-own-legend');
    var readOnlySeller=typeof isReadOnlySellerUser==='function'&&isReadOnlySellerUser(currentUser);
    if(ownLegend)ownLegend.style.display=readOnlySeller?'flex':'none';
    if(typeof setLoteCount==='function')setLoteCount('lotes-vista-count-own','\u2605 '+ownCount);
    if(typeof updateLoteLegendCounts==='function')updateLoteLegendCounts('lotes-vista',totals);
    var totalLabel=document.getElementById('lotes-vista-total');
    if(totalLabel)totalLabel.textContent=totals.total+' lotes';
    var summary=document.getElementById('lotes-vista-resumen');
    if(summary){
      summary.textContent='en '+visibleProjects.length+' proyecto'+(visibleProjects.length===1?'':'s')+' \u00b7 '+totals.res+' reservados \u00b7 '+totals.fir+' firmados \u00b7 '+totals.pen+' solicitudes pendientes \u00b7 '+totals.bn+' bloqueo \u00b7 '+totals.bc+' bloq. comercial \u00b7 '+totals.disp+' disponibles';
    }

    var toggle=document.getElementById('lotes-vista-listado');
    if(toggle){toggle.textContent=availabilityListView?'Ver mapa':'Ver listado';toggle.setAttribute('aria-pressed',String(availabilityListView));}
    if(listGrid)listGrid.setAttribute('data-view',availabilityListView?'list':'map');
    if(availabilityListView&&listGrid){
      if(!user||typeof puedeVerVista!=='function'||!puedeVerVista('lotes-vista')){listGrid.innerHTML='';return;}
      renderAvailabilityList(listGrid,report,user);
      listGrid.setAttribute('data-project-scope',sellerRestricted?(isTerrainAvailabilityUser(user)?'terrain':'remote'):'global');
      listGrid.setAttribute('data-render-ms',String(Date.now()-startedAt));
      return;
    }

    var cards=visibleProjects.map(function(project){
      var lots=visibleLots[project]||[];
      var records=model.recordsByProject[project];
      var blocks=model.blocksByProject[project];
      var counts=visibleCounts[project];
      var html='<div style="background:var(--bg2);border:1px solid var(--border);border-radius:var(--r2);padding:14px;min-width:200px;flex:1;max-width:340px;box-shadow:var(--shadowsm)">';
      html+='<div style="border-bottom:1px solid var(--border);padding-bottom:8px;margin-bottom:10px">'+
        '<div style="display:flex;justify-content:space-between;align-items:center;gap:6px;flex-wrap:wrap;font-size:12px;font-weight:700;color:var(--text);margin-bottom:4px"><span>'+esc(project)+'</span><span style="white-space:nowrap;background:var(--slate);border:1px solid var(--border);border-radius:999px;padding:2px 7px;font-size:10px;font-weight:700;color:var(--text2)">'+lots.length+' lotes</span></div>'+
        '<div style="display:flex;gap:6px;flex-wrap:wrap">'+
          '<span style="font-size:10px;background:#fef9c3;border:1px solid #fde047;border-radius:3px;padding:1px 6px;color:#854d0e;font-weight:600">'+counts.res+' res.</span>'+
          '<span style="font-size:10px;background:#dcfce7;border:1px solid #86efac;border-radius:3px;padding:1px 6px;color:#166534;font-weight:600">'+counts.fir+' firm.</span>'+
          '<span style="font-size:10px;background:#ffedd5;border:1px solid #fdba74;border-radius:3px;padding:1px 6px;color:#c2410c;font-weight:600">'+counts.pen+' pend.</span>'+
          '<span style="font-size:10px;background:#fee2e2;border:1px solid #fca5a5;border-radius:3px;padding:1px 6px;color:#991b1b;font-weight:600">'+counts.bn+' bloq.</span>'+
          '<span style="font-size:10px;background:#ede9fe;border:1px solid #c4b5fd;border-radius:3px;padding:1px 6px;color:#5b21b6;font-weight:600">'+counts.bc+' com.</span>'+
          '<span style="font-size:10px;background:var(--slate);border:1px solid var(--border);border-radius:3px;padding:1px 6px;color:var(--text3)">'+counts.disp+' disp.</span>'+
        '</div></div>'+
        '<div style="display:flex;flex-wrap:wrap;gap:4px">';
      lots.forEach(function(lote){
        var key=loteKey(lote);
        var entry=records[key];
        var block=blocks[key];
        var style='';
        var title='';
        var ownClass='';
        var label=esc(lote);
        if(!entry){
          if(block){
            style=loteStyleByStatus(block.tipo==='comercial'?'bloqueo-comercial':'bloqueo-normal');
            title=' title="'+esc(bloqueoLabel(block))+'"';
          }else{
            style='background:var(--slate);color:var(--text3);border-color:var(--border)';
          }
        }else if(entry.pendienteAprobacion){
          style='background:#ffedd5;color:#c2410c;border-color:#fdba74;font-weight:800';
          title=' title="Solicitud pendiente de aprobación · '+esc(clienteTitle(entry.record))+'"';
        }else if(entry.firmado||entry.estado==='Firmado'){
          if(entry.propio){
            ownClass='lote-own-sale';
            label='<span aria-hidden="true">\u2605</span> '+esc(lote);
            title=' title="Venta propia \u00b7 '+esc(clienteTitle(entry.record))+'"';
          }else{
            style='background:#dcfce7;color:#166534;border-color:#86efac;font-weight:700';
            title=' title="'+esc(clienteTitle(entry.record))+'"';
          }
        }else if(entry.estado==='Reservado'){
          style='background:#fef9c3;color:#854d0e;border-color:#fde047;font-weight:700';
          title=' title="'+esc(clienteTitle(entry.record))+'"';
        }else{
          style='background:var(--slate2);color:var(--text3);border-color:var(--border2)';
        }
        html+='<button type="button" class="'+ownClass+'"'+title+' onclick="applyLoteVistaAction(\''+jsArg(project)+'\',\''+jsArg(lote)+'\')" style="'+style+';border:1px solid;border-radius:3px;padding:2px 6px;font-size:10px;font-family:var(--mono);cursor:pointer">'+label+'</button>';
      });
      return html+'</div></div>';
    });

    var grid=document.getElementById('lotes-vista-grid');
    if(!grid)return;
    grid.innerHTML=cards.length?cards.join(''):'<div style="width:100%;padding:28px;text-align:center;color:var(--text3);background:var(--bg2);border:1px dashed var(--border);border-radius:var(--r2)">'+(sellerRestricted&&!projects.length?'No hay proyectos asignados a tu perfil.':'No hay lotes que coincidan con los filtros seleccionados.')+'</div>';
    grid.setAttribute('data-project-scope',sellerRestricted?(isTerrainAvailabilityUser(user)?'terrain':'remote'):'global');
    grid.setAttribute('data-render-ms',String(Date.now()-startedAt));
  }

  function installOverrides(){
    window.getLotesData=getCotizadorLotesData;
    window.getProyectosUnificados=function(){return Object.keys(getCotizadorLotesData());};
    window.existeProyectoExacto=function(name){
      return Object.keys(getCotizadorLotesData()).some(function(project){return sameProject(project,name);});
    };
    window.findCanonicalProyecto=function(name){
      return Object.keys(getCotizadorLotesData()).find(function(project){return sameProject(project,name);})||'';
    };
    window.findRegistroPorLote=function(project,lote,records){
      records=records||(state&&state.registros)||[];
      var target=loteKey(lote);
      var matches=records.filter(function(record){
        return sameProject(record.proyecto,project)&&loteKey(record.name)===target&&registroOcupaLote(record);
      });
      return matches.find(function(record){return typeof getEstado==='function'&&getEstado(record)==='Firmado';})||
        matches.find(function(record){return typeof esEfectivamenteFirmado==='function'&&esEfectivamenteFirmado(record);})||
        matches[0]||null;
    };
    window.getBloqueoLote=getUnifiedBlock;
    window.setBloqueoLote=setUnifiedBlock;
    window.getBloqueosProyecto=function(project){
      var all=typeof ensureLotesBloqueados==='function'?ensureLotesBloqueados():{};
      return all[projectBlockKey(project)]||{};
    };
    if(typeof renderLotesVista==='function')window.renderLotesVista=renderLotesVistaFast;
    if(typeof getSellerVisibleProjects==='function'){
      window.getSellerVisibleProjects=function(user){
        user=user||currentUser;
        if(!isTerrainAvailabilityUser(user))return [];
        return getTerrainAvailabilityProjects(user,getCotizadorLotesData());
      };
    }
    if(typeof openLoteDetalleModal==='function'){
      var baseOpenLoteDetalleModal=openLoteDetalleModal;
      window.openLoteDetalleModal=function(project,lote){
        if(isSellerAvailabilityUser(currentUser)&&!getSellerAvailabilityProjects(currentUser,getCotizadorLotesData()).some(function(allowed){return sameProject(allowed,project);}))return;
        baseOpenLoteDetalleModal(project,lote);
        addCotizadorLotPrice(project,lote);
        addAdminBlockActions(project,lote);
      };
    }
    if(typeof aplicarConfigCentral==='function'){
      var baseAplicarConfigCentral=aplicarConfigCentral;
      window.aplicarConfigCentral=function(config){
        var result=baseAplicarConfigCentral(normalizedCentralConfig(config));
        setTimeout(function(){
          if(typeof populateFilters==='function')populateFilters();
          var availability=document.getElementById('panel-lotes-vista');
          if(availability&&availability.classList.contains('active')&&typeof renderLotesVista==='function')renderLotesVista();
          var admin=document.getElementById('panel-admin');
          if(admin&&admin.classList.contains('active')&&typeof renderLotesAdmin==='function')renderLotesAdmin();
        },0);
        return result;
      };
    }
    if(typeof parseImportRows==='function'){
      var baseParseImportRows=parseImportRows;
      window.parseImportRows=function(headers,rows){
        return baseParseImportRows(
          (headers||[]).map(decodeLegacyUtf8),
          (rows||[]).map(function(row){return (row||[]).map(decodeLegacyUtf8);})
        );
      };
    }
    if(typeof readCSV==='function'){
      window.readCSV=function(file){
        var reader=new FileReader();
        reader.onload=function(event){
          try{
            var bytes=new Uint8Array(event.target.result);
            var text;
            try{text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);}
            catch(utf8Error){text=new TextDecoder('windows-1252').decode(bytes);}
            text=text.replace(/^\uFEFF/,'');
            var lines=text.trim().split(/\r?\n/);
            if(lines.length<2){showImportStatus('El archivo esta vacio o no tiene datos',false);return;}
            var separator=lines[0].indexOf(';')>=0?';':',';
            var headers=lines[0].split(separator).map(function(value){return value.trim();});
            var rows=lines.slice(1).filter(function(line){return line.trim();}).map(function(line){
              return line.split(separator).map(function(value){return value.trim().replace(/^"|"$/g,'');});
            });
            parseImportRows(headers,rows);
          }catch(error){
            console.error('No se pudo leer el archivo de proyectos:',error);
            showImportStatus('No se pudo leer el archivo. Revisa su formato y codificacion.',false);
          }
        };
        reader.readAsArrayBuffer(file);
      };
    }
  }

  window.PruebaLotes={
    decodeLegacyUtf8:decodeLegacyUtf8,
    plainProjectName:plainProjectName,
    matchesDamagedName:matchesDamagedName,
    repairProjectName:repairProjectName,
    sameProject:sameProject,
    signedRecordCount:signedRecordCount,
    getCotizadorLotesData:getCotizadorLotesData,
    buildAvailabilityModel:buildAvailabilityModel,
    buildAvailabilityExportReport:buildAvailabilityExportReport,
    buildAvailabilityClientReport:buildAvailabilityClientReport,
    buildAvailabilityWorkbook:buildAvailabilityWorkbook,
    availabilitySummaryValues:availabilitySummaryValues,
    isTerrainAvailabilityUser:isTerrainAvailabilityUser,
    terrainAssignment:terrainAssignment,
    getTerrainAvailabilityProjects:getTerrainAvailabilityProjects,
    getSellerAvailabilityProjects:getSellerAvailabilityProjects,
    isPendingReleaseRequest:isPendingReleaseRequest,
    renderLotesVistaFast:renderLotesVistaFast,
    normalizeCotizadorNamesInMemory:normalizeCotizadorNamesInMemory
  };

  window.exportDisponibilidad=exportDisponibilidad;
  window.toggleDisponibilidadListado=toggleDisponibilidadListado;

  normalizeCotizadorNamesInMemory();
  installOverrides();
})();
