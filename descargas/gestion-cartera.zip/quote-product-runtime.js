(function(root){
  'use strict';
  var clone=function(v){return JSON.parse(JSON.stringify(v));};
  function fail(message){var e=new Error(message);e.code='cotizacion-cambio-lote';throw e;}
  function key(v){return encodeURIComponent(String(v)).replace(/\./g,'%2E');}
  function linked(c,records){
    var direct=records.filter(function(r){return String(r.cotizacionId||'')===String(c.id);});
    var explicit=c.reservaId?records.filter(function(r){return String(r.id)===String(c.reservaId);}):[];
    if(c.reservaId&&!explicit.length)fail('No se encontró la Reserva vinculada. Actualiza antes de guardar');
    if(explicit.some(function(r){return r.cotizacionId&&String(r.cotizacionId)!==String(c.id);}))fail('El vínculo de la Reserva no coincide. Actualiza antes de guardar');
    return records.filter(function(r){return direct.indexOf(r)>=0||explicit.indexOf(r)>=0;});
  }
  function sameQuote(a,b){a=clone(a);b=clone(b);delete a.id;delete b.id;return root.CarteraPortfolioModel.stable(a)===root.CarteraPortfolioModel.stable(b);}
  function validate(original,next,cartera,catalog,options){
    if(!puedeEditarCotizacionVentas(original))fail('Ya no tienes permiso para editar esta cotización');
    if(!sameQuote(original,options.original))fail('La cotización cambió desde otra sesión. Vuelve a abrirla para no sobrescribir esos cambios');
    var originalFolio=getFolioCompleto(original);
    if(originalFolio&&getFolioCompleto(next)!==originalFolio)fail('El folio original debe conservarse. Vuelve a abrir la cotización');
    var project=catalog.DB&&catalog.DB[options.proyectoId],lot=project&&project.lotes&&project.lotes[next.lote];
    if(!project||project.nombre!==next.proyecto||!lot)fail('El proyecto o lote ya no existe en el Cotizador. Actualiza y selecciónalo nuevamente');
    if(root.CarteraPortfolioModel.stable(lot)!==root.CarteraPortfolioModel.stable(options.loteCatalogo))fail('El precio o los datos del lote cambiaron. Selecciónalo nuevamente para recalcular');
    if(next.moneda!==lot.moneda||!(getTotalPagarCotizacionNum(next)>0))fail('Revisa el precio y la moneda del nuevo producto');
    if(lot.moneda==='UF'&&!(parseUfValue(next.tipoCambio||next.valorUF)>0))fail('Falta una conversión UF válida para el nuevo lote');
    var matches=linked(original,cartera.registros);
    if(matches.length>1)fail('Hay varias Reservas vinculadas; no se puede cambiar el producto automáticamente');
    var reserva=matches[0]||null;
    if(String(reserva&&reserva.id||'')!==String(options.reservaId||'')||(!reserva&&(original.reservaId||original.reservaCreada)))fail('La Reserva vinculada cambió. Vuelve a abrir la cotización y confirma nuevamente');
    if(!reserva)return null;
    if(getEstado(reserva)!=='Reservado')fail('La Reserva ya no está activa o está firmada. No se cambió proyecto ni lote');
    if(!options.reservaOriginal||reserva.proyecto!==options.reservaOriginal.proyecto||String(reserva.name)!==String(options.reservaOriginal.name))fail('El producto de la Reserva cambió desde otra sesión. Actualiza antes de guardar');
    var conflict=cartera.registros.some(function(r){return r.id!==reserva.id&&normalizeLookupText(r.proyecto)===normalizeLookupText(next.proyecto)&&sameLote(r.name,next.lote)&&registroOcupaLote(r);});
    if(conflict)fail('El nuevo lote ya está ocupado por otra operación. Elige uno disponible');
    Object.keys(cartera.lotesBloqueados||{}).forEach(function(p){
      if(normalizeLookupText(p)!==normalizeLookupText(next.proyecto))return;
      Object.keys(cartera.lotesBloqueados[p]||{}).forEach(function(l){var b=cartera.lotesBloqueados[p][l];if(sameLote(b&&b.lote||l,next.lote))fail('El nuevo lote está bloqueado. No se cambió la cotización ni la Reserva');});
    });
    return reserva;
  }
  async function save(db,datos,id,options){
    if(!id||!options.original)fail('Falta la cotización original. Vuelve a abrirla');
    if(typeof saveStateNow==='function')await saveStateNow();
    if(typeof stateDirty!=='undefined'&&stateDirty)fail('Hay cambios pendientes de sincronización. Guárdalos antes de cambiar el producto');
    var next=clone(datos),quoteRef=db.collection('cotizaciones').doc(id),stateRef=db.doc('cartera/state');
    var adjunto=options.reservaId?crearAdjuntoCotizacionAutomatica(Object.assign({id:id},next)):null;
    if(options.reservaId&&(!adjunto||!adjunto.dataUrl))fail('No se pudo preparar la cotización adjunta. No se hicieron cambios');
    var actor={id:currentUser.id||'',uid:currentUser.uid||'',email:currentUser.email||'',nombre:currentUser.nombre||''};
    var stamp=new Date().toISOString(),ts=nowTs(),FV=firebase.firestore.FieldValue;
    var result=await root.CarteraPortfolioClient.create(db).runTransaction(async function(tx){
      var quoteDoc=await tx.get(quoteRef),stateDoc=await tx.get(stateRef),configDoc=await tx.get(db.doc('cotizador/config'));
      if(!quoteDoc.exists||!stateDoc.exists||!configDoc.exists)fail('No se pudieron comprobar los datos originales. Actualiza e intenta nuevamente');
      var original=Object.assign({id:id},quoteDoc.data()),cartera=clone(stateDoc.data().state);
      if(!cartera||!Array.isArray(cartera.registros))fail('La cartera aún no está disponible');
      var reserva=validate(original,next,cartera,configDoc.data(),options);
      var validation=null,attachmentRef=null,attachmentDoc=null,contactRef=null,contactDoc=null,created=false;
      if(reserva){
        var validations=(cartera.validacionesReserva||[]).filter(function(v){return String(v.registroId)===String(reserva.id);});
        if(validations.length>1)fail('Hay varias validaciones para esta Reserva. Revisa el vínculo antes de cambiarla');
        validation=validations[0];
        if(!validation){crearValidacionReserva(reserva,ts,cartera);validation=cartera.validacionesReserva.find(function(v){return v.registroId===reserva.id;});validation.monto=0;created=true;}
        attachmentRef=db.collection('validacion_adjuntos').doc(key(validation.id));
        attachmentDoc=await tx.get(attachmentRef);
        contactRef=db.collection('contactos_registros').doc(String(reserva.id));contactDoc=await tx.get(contactRef);
      }
      // All remote reads precede writes. Nothing commits unless every check passes.
      var saved=Object.assign({},original,next);delete saved.id;
      var audit={ts:ts,at:stamp,user:actor.nombre,uid:actor.uid,
        anterior:{proyecto:original.proyecto,lote:original.lote,totalPagar:original.totalPagar||original.precioNeto||''},
        nuevo:{proyecto:next.proyecto,lote:next.lote,totalPagar:next.totalPagar||next.precioNeto||''},reservaId:reserva?reserva.id:''};
      saved.productoHistorial=(original.productoHistorial||[]).concat([audit]);
      if(reserva){
        saved.reservaCreada=true;saved.reservaId=reserva.id;
        var stored=attachmentDoc.exists?attachmentDoc.data():{},meta=clone(stored.data||stored.item||{});
        if(stored.deleted||meta.registroId&&String(meta.registroId)!==String(reserva.id))fail('Los documentos de la Reserva cambiaron. Actualiza antes de guardar');
        validation.documentos=clone(Array.isArray(meta.documentos)?meta.documentos:validation.documentos||[]);
        var previous=validation.documentos.find(function(d){return d.documentKind==='cotizacion'&&d.automatico===true&&String(d.sourceId)===String(id);});
        var oldProduct=reserva.proyecto+' · Lote '+reserva.name;
        aplicarCotizacionEnReserva(Object.assign({id:id},saved),reserva,validation,clone(adjunto));
        reserva.proyecto=next.proyecto;reserva.name=next.lote;reserva.sinLote=false;
        reserva.terreno=next.vendedorProyecto&&next.vendedorProyecto!=='—'?next.vendedorProyecto:'';
        validation.proyecto=next.proyecto;validation.name=next.lote;
        var message='Cambio de producto desde Cotización '+(saved.folioCompleto||id)+': '+oldProduct+' → '+next.proyecto+' · Lote '+next.lote+'. Cotización y Reserva guardadas juntas. Comprobantes, agenda y Plan de Pago conservados para revisión.';
        reserva.actividad.push({ts:ts,user:actor.nombre,uid:actor.uid,msg:message});
        (validation.actividad=validation.actividad||[]).push({ts:ts,user:actor.nombre,msg:message+(created?' Validación pendiente creada con pago sin comprobar $0.':'')});
        var newFile=validation.documentos.find(function(d){return d.id===adjunto.id;}),url=newFile.dataUrl,chunks=[];
        if(url.length>3*1024*1024)fail('El documento automático es demasiado grande; no se guardó el cambio');
        for(var offset=0;offset<url.length;offset+=460800)chunks.push(url.slice(offset,offset+460800));
        chunks.forEach(function(part,index){tx.set(db.collection('validacion_adjuntos').doc(key(validation.id)+'__doc__'+key(newFile.id)+'__'+String(index).padStart(3,'0')),{kind:'chunk',validationId:validation.id,registroId:String(reserva.id),documentId:newFile.id,index:index,data:part});});
        // These collection rules allow writes but not deletion. Retire unused
        // automatic fragments without touching any proof or legal attachment.
        for(var n=chunks.length;previous&&previous.id===newFile.id&&n<(previous.chunkCount||0);n++)tx.set(db.collection('validacion_adjuntos').doc(key(validation.id)+'__doc__'+key(newFile.id)+'__'+String(n).padStart(3,'0')),{kind:'chunk',validationId:validation.id,registroId:String(reserva.id),documentId:newFile.id,index:n,deleted:true,deletedAt:FV.serverTimestamp()},{merge:true});
        delete newFile.dataUrl;newFile.storage='chunks';newFile.chunkCount=chunks.length;
        meta=Object.assign(meta,{id:String(validation.id),registroId:String(reserva.id),documentos:validation.documentos});
        tx.set(attachmentRef,Object.assign({},stored,{data:meta,position:typeof stored.position==='number'?stored.position:cartera.validacionesReserva.indexOf(validation),updatedAt:FV.serverTimestamp(),updatedBy:actor}));
        delete validation.documentos;
        var contact=contactDoc.exists?contactDoc.data():{},patch={},clean=function(v){return exportCarteraClean(v);};
        var oldRut=clean(contact.rut).toUpperCase().replace(/[^0-9K]/g,''),newRut=clean(next.rut).toUpperCase().replace(/[^0-9K]/g,'');
        ['rut','telefono','correo'].forEach(function(k){var v=clean(next[k]);if(v||(oldRut&&newRut&&oldRut!==newRut&&k!=='rut'))patch[k]=v;});
        tx.set(contactRef,Object.assign(patch,{registroId:String(reserva.id),updatedAt:FV.serverTimestamp(),updatedBy:actor.nombre}),{merge:true});
        tx.update(stateRef,{state:cartera,stateRevision:FV.increment(1),updatedAt:FV.serverTimestamp(),updatedBy:actor});
      }
      tx.set(quoteRef,saved);
      return {cotizacion:Object.assign({id:id},saved),reservaId:reserva?reserva.id:''};
    });
    options.resultado=result;
    if(result.reservaId&&root.RecordContactRuntime&&root.RecordContactRuntime.invalidate)root.RecordContactRuntime.invalidate(result.reservaId);
    if(result.reservaId&&root.refreshSharedData){
      try{await root.refreshSharedData(false);}catch(e){options.actualizacionPendiente=true;console.warn('Cambio de producto guardado; la pantalla requiere actualización.');}
    }
    return id;
  }
  root.QuoteProductRuntime={save:save,validate:validate,linked:linked};
})(window);
