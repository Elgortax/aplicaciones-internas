(function(root,factory){
  'use strict';
  if(typeof module==='object'&&module.exports)module.exports=factory(require('./portfolio-model'));
  else root.CarteraEscrituraAttachments=factory(root.CarteraPortfolioModel);
})(typeof globalThis!=='undefined'?globalThis:this,function(model){
  'use strict';
  function check(ok,message){if(!ok)throw new Error(message);}
  // The file, its pieces and the activity entry commit together. No local or
  // offline deletion: a failed transaction leaves all documents untouched.
  async function remove(options){
    var db=options.db,ref=options.stateRef,item=options.item,actor=options.actor;
    var recordId=String(options.recordId||'');
    check(ref&&ref.path==='cartera/state','Almacenamiento no compatible.');
    check(item&&item.source==='reserva'&&item.conceptKey==='reservaGeneral','Este archivo se administra en su panel de origen.');
    check(typeof item.id==='string'&&/^[A-Za-z0-9_-]{1,200}$/.test(item.id)&&item.documentId===item.id,'Identificador de archivo inválido.');
    check(actor&&actor.uid&&actor.nombre,'Sesión no disponible.');
    var recordRef=db.collection('cartera_registros').doc(model.key(recordId));
    var files=db.collection('reserva_adjuntos'),fileRef=files.doc(item.id);
    return db.runTransaction(async function(tx){
      var docs=await Promise.all([tx.get(ref),tx.get(recordRef),tx.get(fileRef)]);
      check(docs[0].exists&&docs[1].exists,'La ficha ya no está disponible.');
      var control=docs[0].data(),record=docs[1].data();
      model.assertWritable(control);
      check(!(control.state.archivedRegistroIds||[]).includes(recordId),'La ficha está archivada.');
      check(record.schemaVersion===2&&record.id===recordId&&record.data.id===recordId,'Ficha inconsistente.');
      check(options.canDelete(record.data),'Cambió la sesión o el permiso.');
      if(!docs[2].exists)return {alreadyRemoved:true};
      var meta=docs[2].data();
      check(meta.kind==='meta'&&!meta.deleted&&meta.id===item.id&&meta.registroId===recordId&&meta.metaRegistroId===recordId&&meta.metaConceptKey==='reservaGeneral'&&meta.conceptKey==='reservaGeneral','El archivo no corresponde a esta ficha.');
      check(String(meta.name||'Archivo')===item.name,'El archivo cambió. Actualiza antes de eliminar.');
      check(Number.isInteger(meta.chunkCount)&&meta.chunkCount>=0&&meta.chunkCount<=32,'Archivo inconsistente.');
      var count=record.historyCounts&&record.historyCounts.actividad;
      if(count==null)count=0;
      check(Number.isSafeInteger(count)&&count>=0,'Historial inconsistente.');
      var historyRef=db.collection('cartera_historial').doc(model.historyKey(recordId,'actividad',count));
      var chunks=[];
      for(var i=0;i<meta.chunkCount;i++)chunks.push(files.doc(item.id+'_chunk_'+String(i).padStart(3,'0')));
      var extra=await Promise.all([tx.get(historyRef)].concat(chunks.map(function(chunk){return tx.get(chunk);}))); 
      check(!extra[0].exists,'El historial cambió. Actualiza antes de eliminar.');
      extra.slice(1).forEach(function(doc){
        if(!doc.exists)return;
        var part=doc.data();
        check(part.kind==='chunk'&&part.attachmentId===item.id&&part.registroId===recordId,'Fragmento de archivo inconsistente.');
      });
      check(options.canDelete(record.data),'Cambió la sesión o el permiso.');
      var activity={id:'adjunto-eliminado:'+item.id,ts:options.timestamp(),user:actor.nombre,uid:actor.uid,
        action:'attachment.deleted',attachmentId:item.id,fileName:meta.name||'Archivo',source:'reserva',
        msg:'Archivo eliminado desde Monitor de Escrituras: «'+String(meta.name||'Archivo')+'» (Reserva / Legal).'};
      tx.set(historyRef,{recordId:recordId,field:'actividad',index:count,value:activity});
      tx.update(recordRef,{'historyCounts.actividad':count+1});
      tx.update(ref,{stateRevision:options.fieldValue.increment(1),updatedAt:options.fieldValue.serverTimestamp(),
        updatedBy:{id:actor.id||'',uid:actor.uid,email:actor.email||'',nombre:actor.nombre}});
      tx.delete(fileRef);chunks.forEach(function(chunk){tx.delete(chunk);});
      return {alreadyRemoved:false,activity:activity};
    });
  }
  return {remove:remove};
});
