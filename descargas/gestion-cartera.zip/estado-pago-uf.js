(function(root,factory){
  'use strict';
  if(typeof module==='object'&&module.exports)module.exports=factory();
  else root.EstadoPagoUF=factory();
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  function number(value){var n=Number(value);return Number.isFinite(n)?n:0;}
  function date(value){var s=String(value||'').slice(0,10);return /^\d{4}-\d{2}-\d{2}$/.test(s)&&!isNaN(Date.parse(s))&&new Date(s).toISOString().slice(0,10)===s?s:'';}
  function rate(quote,day){return quote&&quote.fecha===day&&number(quote.valor)>0?number(quote.valor):0;}
  function pending(line){
    var payment=line.linea||{},amount=Math.max(0,number(line.monto)),paid=Math.max(0,number(payment.montoAbonado));
    return payment.estado!=='Anulado'&&(line.tipo==='prontopago'&&number(line.monto)<0||Math.round(amount)>Math.round(paid));
  }
  function payments(line){
    var payment=line.linea||{},paid=Math.max(0,number(payment.montoAbonado));
    if(!paid)return [];
    return Array.isArray(payment.abonos)&&payment.abonos.length?payment.abonos:[{monto:paid,fecha:payment.fechaDeposito||''}];
  }
  function dates(lines){
    var all=[];
    (lines||[]).filter(pending).forEach(function(line){payments(line).forEach(function(p){var day=date(p.fecha);if(number(p.monto)>0&&!number(p.valorUf)&&day&&all.indexOf(day)<0)all.push(day);});});
    return all;
  }
  function sale(record,plan){
    var amount=number(record.precio),uf=0,base=0,day='',derived=false;
    if(record.moneda==='UF'){
      uf=number(record.precioUf);base=number(record.valorUf);day=date(record.fechaTipoCambio);
      if(!uf&&base>0&&amount>0){uf=amount/base;derived=true;}
    }
    // A quantity explicitly recorded on the plan can supply missing sale UF.
    // Its default exchange rate is not assumed to be the historical sale rate.
    if(!uf&&number(plan.precioUf)>0&&Math.abs(number(plan.precio)-amount)<=1){
      uf=number(plan.precioUf);
      if(Math.abs(uf*number(plan.valorUf)-amount)<=1){base=number(plan.valorUf);day=date(plan.fechaTipoCambio);}
    }
    return {clp:amount,uf:uf||null,rate:base||null,date:day,signedDate:date(record.fechaFirma),derived:derived};
  }
  function build(record,plan,lines,day,quotes){
    quotes=quotes||{};var todayQuote=quotes[day],todayRate=rate(todayQuote,day),original=sale(record,plan);
    var groups={},issues=[],derivedLines=0,total=0,nonCash=false;
    (lines||[]).forEach(function(line){
      var payment=line.linea||{};
      if(number(payment.montoAbonado)>0&&payment.estado!=='Pagado')nonCash=true;
      if(payment.estado!=='Anulado'&&number(line.monto)<=0&&number(line.source&&line.source.montoUf)>0){
        issues.push(line.label+': tiene UF registradas pero falta el monto de la obligación.');return;
      }
      if(!pending(line))return;
      var source=line.source||{},quantity=number(source.montoUf),amount=number(line.monto),paid=number(payment.montoAbonado),descuento=line.tipo==='prontopago';
      if(source.importConcept&&source.importConcept.moneda&&source.importConcept.moneda!=='UF'){
        issues.push(line.label+': el concepto está registrado en '+source.importConcept.moneda+', revisar su moneda antes de calcular el saldo UF.');return;
      }
      if(!quantity&&number(line.valorUf)>0){quantity=amount/number(line.valorUf);derivedLines++;}
      if(descuento?quantity>=0:quantity<=0){issues.push(line.label+': falta la cantidad UF o su conversión registrada.');return;}
      var entries=payments(line),sum=entries.reduce(function(s,p){return s+number(p.monto);},0),paidUf=0;
      if(paid>0&&Math.abs(sum-paid)>1){issues.push(line.label+': los abonos no coinciden con el total abonado.');return;}
      for(var i=0;i<entries.length;i++){
        var p=entries[i],value=number(p.monto);if(value===0)continue;
        var payDay=date(p.fecha),exchange=number(p.valorUf)||rate(quotes[payDay],payDay);
        if(value<0||!exchange||!payDay||payDay>day){issues.push(line.label+': falta fecha o UF válida de un abono parcial.');return;}
        paidUf+=value/exchange;
      }
      var balance=descuento?quantity-paidUf:Math.max(0,quantity-paidUf);
      if(Math.abs(balance)<1e-10)return;
      var type=line.tipo||'otros';if(!groups[type])groups[type]={count:0,uf:0};groups[type].count++;groups[type].uf+=balance;total+=balance;
    });
    // Keep full precision through all additions; round CLP only once for display.
    return {date:day,rate:todayRate||null,provider:todayQuote&&todayQuote.proveedor||'',offline:!!(todayQuote&&todayQuote.offline),sale:original,
      saleToday:todayRate&&original.uf?Math.round(original.uf*todayRate):null,
      pendingUf:issues.length?null:total,pendingClp:!issues.length&&todayRate?Math.round(total*todayRate):null,
      groups:groups,issues:issues,derivedLines:derivedLines,nonCash:nonCash};
  }
  async function prepare(record,plan,lines,client,day){
    var queries=[day].concat(dates(lines).filter(function(d){return d!==day;})),quotes={};
    await Promise.all(queries.map(async function(d){try{var q=await client.get(d);if(rate(q,d))quotes[d]=q;}catch(e){/* Missing rates remain explicit in the report. */}}));
    return build(record,plan,lines,day,quotes);
  }
  return {build:build,prepare:prepare,dates:dates};
});
