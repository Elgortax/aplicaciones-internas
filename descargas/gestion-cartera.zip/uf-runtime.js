(function(root){
  'use strict';
  var KEY='CarteraUFPorFechaV2',FRESH_MS=6*60*60*1000,MAX_AGE_MS=30*24*60*60*1000;
  function validDate(date){
    return /^\d{4}-\d{2}-\d{2}$/.test(date||'')&&!isNaN(Date.parse(date))&&new Date(date).toISOString().slice(0,10)===date;
  }
  function dayChile(date){return new Date(date===undefined?Date.now():date).toLocaleDateString('sv-SE',{timeZone:'America/Santiago'});}
  function createClient(options){
    options=options||{};
    var fetcher=options.fetch||root.fetch.bind(root),now=options.now||Date.now,timeout=options.timeoutMs||6000;
    var storage=options.storage,cache=Object.create(null),pending=new Map(),downloads=new Map();
    if(storage===undefined){try{storage=root.localStorage;}catch(e){storage=null;}}
    function valid(entry,date){return entry&&entry.fecha===date&&validDate(date)&&typeof entry.valor==='number'&&Number.isFinite(entry.valor)&&entry.valor>0&&['indicadores.cl','mindicador.cl'].includes(entry.proveedor)&&Number.isFinite(entry.savedAt)&&entry.savedAt<=now()+60000&&now()-entry.savedAt<MAX_AGE_MS;}
    try{var stored=JSON.parse(storage&&storage.getItem(KEY)||'{}');Object.keys(stored).forEach(function(date){if(valid(stored[date],date))cache[date]=stored[date];});}catch(e){}
    function peek(date){var e=cache[date];return valid(e,date)?Object.assign({},e):null;}
    function persist(entry){
      cache[entry.fecha]=entry;
      var dates=Object.keys(cache).filter(function(date){return valid(cache[date],date);}).sort(function(a,b){return cache[b].savedAt-cache[a].savedAt;}).slice(0,62);
      var next=Object.create(null);dates.forEach(function(date){next[date]=cache[date];});cache=next;
      try{if(storage)storage.setItem(KEY,JSON.stringify(cache));}catch(e){}
    }
    async function download(url){
      if(downloads.has(url))return downloads.get(url);
      var promise=downloadBounded(url).finally(function(){downloads.delete(url);});
      downloads.set(url,promise);return promise;
    }
    async function downloadBounded(url){
      var controller=new AbortController(),timer;
      try{
        var network=(async function(){
          // Solo se consulta una serie pública: no salen fichas, cuentas ni credenciales.
          var response=await fetcher(url,{signal:controller.signal,cache:'no-cache',credentials:'omit',referrerPolicy:'no-referrer'});
          if(!response.ok)throw new Error('uf/http');
          return response.json();
        })();
        // 3 s por fuente: la segunda se intenta incluso si la primera queda colgada.
        var expiry=new Promise(function(_,reject){timer=setTimeout(function(){controller.abort();reject(new Error('uf/timeout'));},timeout/2);});
        return await Promise.race([network,expiry]);
      }finally{clearTimeout(timer);}
    }
    function readValue(data,date,primary){
      if(!data||!Array.isArray(data.serie)||
        (primary?(data.indicador!=='uf'||data.unidad!=='pesos'||data.anio!==Number(date.slice(0,4))):data.codigo!=='uf'))throw new Error('uf/invalid-response');
      var matching=data.serie.filter(function(item){
        if(!item||typeof item.fecha!=='string')return false;
        // Una fecha YYYY-MM-DD ya es un día calendario; NO convertirla de UTC a Chile.
        if(primary||validDate(item.fecha))return item.fecha===date;
        return /^\d{4}-\d{2}-\d{2}T/.test(item.fecha)&&!isNaN(Date.parse(item.fecha))&&dayChile(item.fecha)===date;
      });
      if(!matching.length)throw new Error('uf/date-unavailable');
      var valor=matching[0].valor;
      if(typeof valor!=='number'||!Number.isFinite(valor)||valor<=0||matching.some(function(item){return item.valor!==valor;}))throw new Error('uf/invalid-value');
      return {fecha:date,valor:valor,savedAt:now(),proveedor:primary?'indicadores.cl':'mindicador.cl'};
    }
    async function request(date){
      var entry;
      try{
        var data=await download('demo://uf/history/'+date.slice(0,4)+'.json');
        entry=readValue(data,date,true);
      }catch(primaryError){
        var backup=await download('demo://uf/day/'+date.split('-').reverse().join('-'));
        entry=readValue(backup,date,false);
      }
      persist(entry);return Object.assign({},entry,{source:'network'});
    }
    function get(date,force){
      if(!validDate(date))return Promise.reject(new Error('uf/invalid-date'));
      var cached=peek(date);
      if(cached&&!force&&now()-cached.savedAt<FRESH_MS)return Promise.resolve(Object.assign(cached,{source:'cache'}));
      if(pending.has(date))return pending.get(date);
      var promise=request(date).catch(function(error){
        var fallback=peek(date);
        if(fallback)return Object.assign(fallback,{source:'cache',offline:true});
        throw error;
      }).finally(function(){pending.delete(date);});
      pending.set(date,promise);return promise;
    }
    return {get:get,peek:peek,today:function(){return dayChile(now());}};
  }
  var api={createClient:createClient,validDate:validDate,dayChile:dayChile};
  if(typeof module==='object'&&module.exports)module.exports=api;
  else {root.CarteraUF=createClient();}
})(typeof window==='object'?window:globalThis);
