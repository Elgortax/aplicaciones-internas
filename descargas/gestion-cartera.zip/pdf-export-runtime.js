(function(root){
  'use strict';

  function parseDelimitedLine(line){
    var cells=[],value='',quoted=false;
    line=String(line||'');
    for(var i=0;i<line.length;i++){
      var ch=line[i];
      if(ch==='"'){
        if(quoted&&line[i+1]==='"'){value+='"';i++;}
        else quoted=!quoted;
      }else if(ch===';'&&!quoted){cells.push(value);value='';}
      else value+=ch;
    }
    cells.push(value);
    return cells;
  }

  function cleanCell(value){
    if(value===null||value===undefined)return '';
    if(value instanceof Date)return value.toLocaleDateString('es-CL');
    if(typeof value==='number')return value.toLocaleString('es-CL',{maximumFractionDigits:2});
    return String(value).replace(/[\r\n\t]+/g,' ').trim();
  }

  function clipped(doc,value,width){
    var str=cleanCell(value);
    if(doc.getTextWidth(str)<=width)return str;
    var low=0,high=str.length;
    while(low<high){
      var middle=Math.ceil((low+high)/2);
      if(doc.getTextWidth(str.slice(0,middle)+'…')<=width)low=middle;
      else high=middle-1;
    }
    return str.slice(0,low)+'…';
  }

  function identityColumns(headers){
    var selected=[];
    ['proyecto','cliente','nombre cliente','n°','nro lote','lote','cotizacion','cotización'].forEach(function(label){
      var index=headers.findIndex(function(header){return String(header||'').toLocaleLowerCase('es-CL')===label;});
      if(index>=0&&selected.indexOf(index)<0&&selected.length<2)selected.push(index);
    });
    if(!selected.length&&headers.length>8)selected.push(0);
    return selected.sort(function(a,b){return a-b;});
  }

  function columnPanels(headers){
    var ids=identityColumns(headers);
    if(headers.length<=9)return [headers.map(function(_,index){return index;})];
    var remaining=headers.map(function(_,index){return index;}).filter(function(index){return ids.indexOf(index)<0;});
    var capacity=9-ids.length;
    var panels=[];
    for(var i=0;i<remaining.length;i+=capacity)panels.push(ids.concat(remaining.slice(i,i+capacity)));
    return panels;
  }

  function downloadTablePDF(config){
    config=config||{};
    var jsPDF=root.jspdf&&root.jspdf.jsPDF;
    if(!jsPDF){if(typeof root.toast==='function')root.toast('No se pudo cargar el generador PDF. Intenta recargar la página.','error');return false;}
    var headers=Array.isArray(config.headers)?config.headers:[];
    var rows=Array.isArray(config.rows)?config.rows:[];
    if(!headers.length){if(typeof root.toast==='function')root.toast('No hay columnas para exportar.','error');return false;}
    var title=String(config.title||'Reporte');
    var filename=String(config.filename||'reporte.pdf').replace(/[^\w.áéíóúÁÉÍÓÚñÑ-]+/g,'_');
    if(!/\.pdf$/i.test(filename))filename+='.pdf';
    var doc=config.doc||new jsPDF({orientation:'landscape',unit:'mm',format:'a3',compress:true});
    var clientFields=root.CarteraClientesInforme&&root.CarteraClientesInforme.fields||[];
    var wrapped=headers.filter(function(h){var k=String(h).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');return clientFields.some(function(f){return f[2].indexOf(k)>=0;});});
    if(wrapped.length)config=Object.assign({},config,{wrapColumns:Array.from(new Set((config.wrapColumns||[]).concat(wrapped)))});
    var pageWidth=doc.internal.pageSize.getWidth(),pageHeight=doc.internal.pageSize.getHeight();
    var left=12,right=12,top=12,bottom=15,headerHeight=12,rowHeight=7.2;
    var panels=columnPanels(headers),page=config.doc?doc.internal.getNumberOfPages():0,generatedAt=new Date().toLocaleString('es-CL');
    if(config.wrapColumns)panels=panels.map(function(columns){return columns.slice().sort(function(a,b){return a-b;});});
    panels.forEach(function(columns,panelIndex){
      var weights=columns.map(function(index){
        var label=String(headers[index]||'');
        if(config.wrapColumns&&config.wrapColumns.indexOf(label)>=0){
          if(label==='Correo')return 2;
          if(label==='Cliente')return 1.8;
          return 1.1;
        }
        return Math.max(1,Math.min(1.8,label.length/12));
      });
      var totalWeight=weights.reduce(function(sum,weight){return sum+weight;},0);
      var widths=weights.map(function(weight){return (pageWidth-left-right)*weight/totalWeight;});
      var y=0,tableStart=0;
      function startPage(){
        if(page)doc.addPage();
        page++;
        y=top;
        doc.setFillColor(27,58,107);doc.rect(left,y,pageWidth-left-right,13,'F');
        doc.setTextColor(255,255,255);doc.setFont('helvetica','bold');doc.setFontSize(11);
        doc.text(clipped(doc,title,pageWidth-left-right-6),left+3,y+8);
        y+=18;
        doc.setTextColor(77,91,111);doc.setFont('helvetica','normal');doc.setFontSize(8);
        doc.text(rows.length+' registros · '+generatedAt+' · Columnas '+(panelIndex+1)+'/'+panels.length,left,y);
        y+=6;
        if(config.summary){
          var summary=config.summary,hasNote=!!summary.note;
          doc.setFillColor(234,240,248);doc.rect(left,y,pageWidth-left-right,hasNote?24:19,'F');
          doc.setTextColor(27,58,107);doc.setFont('helvetica','normal');doc.setFontSize(9);
          doc.text(cleanCell(summary.label),left+3,y+5.5);
          doc.setFont('helvetica','bold');doc.setFontSize(13);
          doc.text(cleanCell(summary.value),left+3,y+13);
          if(hasNote){doc.setFont('helvetica','normal');doc.setFontSize(8);doc.text(cleanCell(summary.note),left+3,y+20);}
          y+=hasNote?29:24;
        }
        doc.setFillColor(234,240,248);doc.rect(left,y,pageWidth-left-right,headerHeight,'F');
        doc.setTextColor(27,58,107);doc.setFont('helvetica','bold');doc.setFontSize(7.5);
        var x=left;
        columns.forEach(function(index,slot){doc.text(clipped(doc,headers[index],widths[slot]-4),x+2,y+7.5);x+=widths[slot];});
        y+=headerHeight;
        tableStart=y;
        doc.setTextColor(30,43,64);doc.setFont('helvetica','normal');doc.setFontSize(7.5);
      }
      startPage();
      if(!rows.length){doc.text('No hay registros con los filtros actuales.',left+2,y+6);}
      rows.forEach(function(row,rowIndex){
        var cells=columns.map(function(index,slot){
          return config.wrapColumns&&config.wrapColumns.indexOf(headers[index])>=0
            ?doc.splitTextToSize(cleanCell(row&&row[index]),widths[slot]-4)
            :[clipped(doc,row&&row[index],widths[slot]-4)];
        });
        var lineCount=Math.max.apply(null,[1].concat(cells.map(function(lines){return lines.length;}))),offset=0;
        var height=Math.max(rowHeight,4+lineCount*3.2);
        if(y+height>pageHeight-bottom&&y>tableStart)startPage();
        // Incluso un contacto excepcionalmente largo continúa en otra página sin cortarse.
        while(offset<lineCount){
          var count=Math.min(lineCount-offset,Math.max(1,Math.floor((pageHeight-bottom-y-4)/3.2)));
          height=Math.max(rowHeight,4+count*3.2);
          if(rowIndex%2===1){doc.setFillColor(247,249,252);doc.rect(left,y,pageWidth-left-right,height,'F');}
          var x=left;
          cells.forEach(function(lines,slot){
            lines.slice(offset,offset+count).forEach(function(line,lineIndex){doc.text(line,x+2,y+4.8+lineIndex*3.2);});
            x+=widths[slot];
          });
          y+=height;offset+=count;
          if(offset<lineCount)startPage();
        }
      });
    });
    for(var number=1;number<=page;number++){
      doc.setPage(number);doc.setTextColor(112,127,149);doc.setFont('helvetica','normal');doc.setFontSize(8);
      doc.text('Gestión de cartera · Página '+number+' de '+page,pageWidth-right,pageHeight-7,{align:'right'});
    }
    doc.save(filename);
    if(typeof root.toast==='function')root.toast('PDF descargado: '+rows.length+' registros.','success');
    return true;
  }

  function downloadDelimitedPDF(lines,title,filename,options){
    var table=(lines||[]).map(parseDelimitedLine);
    return downloadTablePDF(Object.assign({},options||{},{title:title,filename:filename,headers:table[0]||[],rows:table.slice(1)}));
  }

  // Reporte de escrituras: las once columnas de la plantilla en una sola tabla,
  // texto completo con ajuste de líneas y color semántico independiente del tema.
  function downloadEscriturasPDF(config){
    config=config||{};
    var notify=function(message,type){if(typeof root.toast==='function')root.toast(message,type);};
    var jsPDF=root.jspdf&&root.jspdf.jsPDF;
    if(!jsPDF){notify('No se pudo cargar el generador PDF. Intenta recargar la página.','error');return false;}
    var headers=config.headers||[],rows=config.rows||[],firmadas=config.firmadas||[],totales=config.totales;
    if(headers.length!==11||!rows.length){notify('No hay escrituras para exportar.','info');return false;}
    if(!totales||!['firmado','agendado','total'].every(function(key){return typeof totales[key]==='number'&&Number.isFinite(totales[key]);})){
      notify('No se pudieron calcular los totales. Recarga la página.','error');return false;
    }
    try{
      var doc=new jsPDF({orientation:'landscape',unit:'mm',format:'a3',compress:true});
      var pageWidth=doc.internal.pageSize.getWidth(),pageHeight=doc.internal.pageSize.getHeight();
      var left=12,right=12,bottom=15,available=pageWidth-left-right;
      var weights=[28,17,24,42,15,76,31,45,32,49,37];
      var widths=weights.map(function(w){return w*available/396;});
      var pad=2.4,lineHeight=4.1,fontSize=10,pages=0,y=0,tableStart=0;
      var signed=firmadas.filter(function(value){return value===true;}).length;
      var generated=new Date().toLocaleString('es-CL',{timeZone:'America/Santiago'});
      var green=[228,244,232],text=[30,43,64];
      function startPage(){
        if(pages)doc.addPage();pages++;
        doc.setFont('helvetica','bold');doc.setFontSize(16);doc.setTextColor(27,58,107);
        doc.text('Monitor de Escrituras',left,17);
        doc.setFont('helvetica','normal');doc.setFontSize(10);doc.setTextColor.apply(doc,text);
        var context=doc.splitTextToSize(cleanCell(config.periodo)+' - '+cleanCell(config.proyecto),available);
        doc.text(context,left,24);y=25+context.length*4.2;
        doc.setFontSize(9);
        doc.text(rows.length+' escrituras: '+signed+' firmadas y '+(rows.length-signed)+' agendadas. Montos en CLP.',left,y);
        y+=6;doc.setFillColor.apply(doc,green);doc.rect(left,y-3,4,4,'F');
        doc.text('Verde claro: escritura firmada',left+6,y);y+=5;
        var boxWidth=(available-8)/3;
        [
          {label:'Monto firmado (CLP)',value:totales.firmado,color:green},
          {label:'Monto agendado (CLP)',value:totales.agendado,color:[255,246,221]},
          {label:'Total Monto a Pagar (CLP)',value:totales.total,color:[234,240,248]}
        ].forEach(function(total,index){
          var bx=left+index*(boxWidth+4);
          doc.setFillColor.apply(doc,total.color);doc.rect(bx,y,boxWidth,18,'F');
          doc.setTextColor.apply(doc,text);doc.setFont('helvetica','normal');doc.setFontSize(10);
          doc.text(total.label,bx+3,y+5.5);
          doc.setFont('helvetica','bold');doc.setFontSize(13);
          doc.text('$'+total.value.toLocaleString('es-CL',{maximumFractionDigits:0}),bx+3,y+13);
        });
        y+=23;
        if(totales.sinMonto){
          doc.setFont('helvetica','normal');doc.setFontSize(9);doc.setTextColor.apply(doc,text);
          doc.text(totales.sinMonto+' registros sin Monto a Pagar. Los totales suman solo los montos informados.',left,y);
          y+=6;
        }
        doc.setFont('helvetica','bold');doc.setFontSize(fontSize);
        var labels=headers.map(function(header,index){return doc.splitTextToSize(cleanCell(header),widths[index]-pad*2);});
        var height=Math.max.apply(null,labels.map(function(lines){return lines.length;}))*lineHeight+pad*2;
        doc.setFillColor(27,58,107);doc.rect(left,y,available,height,'F');doc.setTextColor(255,255,255);
        var x=left;
        labels.forEach(function(lines,index){doc.text(lines,x+pad,y+pad+3.1,{lineHeightFactor:lineHeight/(fontSize*25.4/72)});x+=widths[index];});
        y+=height;tableStart=y;doc.setFont('helvetica','normal');doc.setFontSize(fontSize);doc.setTextColor.apply(doc,text);
      }
      startPage();
      rows.forEach(function(row,index){
        var lines=headers.map(function(_,col){return doc.splitTextToSize(cleanCell(row[col]),widths[col]-pad*2);});
        var lineCount=Math.max(1,Math.max.apply(null,lines.map(function(value){return value.length;})));
        var height=Math.max(10,lineCount*lineHeight+pad*2);
        // Mantener una fila junta cuando cabe en una página nueva.
        if(y+height>pageHeight-bottom&&y>tableStart)startPage();
        var offset=0;
        while(offset<lineCount){
          var capacity=Math.floor((pageHeight-bottom-y-pad*2)/lineHeight);
          if(capacity<1||pageHeight-bottom-y<10){startPage();continue;}
          var count=Math.min(capacity,lineCount-offset),blockHeight=Math.max(10,count*lineHeight+pad*2);
          doc.setFillColor.apply(doc,firmadas[index]===true?green:index%2?[247,249,252]:[255,255,255]);
          doc.rect(left,y,available,blockHeight,'F');
          var x=left;
          lines.forEach(function(cell,col){
            var part=cell.slice(offset,offset+count);
            if(part.length)doc.text(part,col===10?x+widths[col]-pad:x+pad,y+pad+3.1,
              {align:col===10?'right':'left',lineHeightFactor:lineHeight/(fontSize*25.4/72)});
            x+=widths[col];
          });
          y+=blockHeight;doc.setDrawColor(218,225,231);doc.setLineWidth(0.15);doc.line(left,y,pageWidth-right,y);
          offset+=count;if(offset<lineCount)startPage();
        }
      });
      if(config.clientTable)return downloadTablePDF({doc:doc,title:'Escrituras · Datos de clientes',filename:config.filename,headers:config.clientTable.headers,rows:config.clientTable.rows});
      for(var page=1;page<=pages;page++){
        doc.setPage(page);doc.setTextColor(90,106,123);doc.setFont('helvetica','normal');doc.setFontSize(8);
        doc.text('Gestión de cartera - Generado '+generated+' (Chile)',left,pageHeight-7);
        doc.text('Página '+page+' de '+pages,pageWidth-right,pageHeight-7,{align:'right'});
      }
      var filename=String(config.filename||'Escrituras.pdf').replace(/[^\w.áéíóúÁÉÍÓÚñÑ-]+/g,'_');
      if(!/\.pdf$/i.test(filename))filename+='.pdf';
      doc.save(filename);notify('PDF descargado: '+rows.length+' escrituras.','success');return true;
    }catch(error){
      if(root.console)root.console.error('Error al generar el PDF de escrituras:',error);
      notify('No se pudo generar el PDF. Inténtalo de nuevo.','error');return false;
    }
  }

  function downloadDisponibilidadPDF(report,filename){
    var notify=typeof root.toast==='function'?root.toast:function(){};
    var Constructor=root.jspdf&&root.jspdf.jsPDF;
    if(!Constructor){notify('No se pudo cargar PDF. Recarga la página e inténtalo de nuevo.','error');return false;}
    try{
      var isClient=report.kind==='client';
      var doc=new Constructor({orientation:'landscape',unit:'mm',format:isClient?'a4':'a3'});
      var width=doc.internal.pageSize.getWidth(),height=doc.internal.pageSize.getHeight(),margin=12,available=width-margin*2,y=0,pages=0;
      var fontSize=9,lineHeight=4,pad=2;
      var colors={'Firmado':[227,245,233],'Reservado':[255,249,220],'Solicitud pendiente':[255,236,216],'Bloqueado':[253,234,234],'Bloqueo comercial':[239,233,252]};
      function money(value,currency){return value===null||value===undefined?'Sin dato':(currency==='UF'?'UF ':'$ ')+Number(value).toLocaleString('es-CL',{maximumFractionDigits:currency==='UF'?4:0});}
      function date(iso){return iso?iso.slice(8,10)+'/'+iso.slice(5,7)+'/'+iso.slice(0,4):'—';}
      function pageTitle(section){
        if(pages)doc.addPage();pages++;
        doc.setFont('helvetica','bold');doc.setFontSize(17);doc.setTextColor(27,58,107);doc.text('Disponibilidad '+(isClient?'Cliente':'Comercial')+' · '+section,margin,18);
        doc.setFont('helvetica','normal');doc.setFontSize(9);doc.setTextColor(47,62,80);
        var projectCount=new Set(report.rows.map(function(row){return row.project;})).size;
        var scope=doc.splitTextToSize(report.scope+' · '+report.rows.length+' lotes · '+projectCount+' proyectos',available);
        doc.text(scope,margin,25);y=27+scope.length*4;
        var notes=doc.splitTextToSize(report.note,available);doc.text(notes,margin,y);y+=notes.length*4+5;
      }
      function table(section,headers,rows,weights,fillForRow,rightColumns){
        var widths=weights.map(function(weight){return available*weight/weights.reduce(function(a,b){return a+b;},0);}),tableStart;
        function startPage(){
          pageTitle(section);doc.setFont('helvetica','bold');doc.setFontSize(fontSize);
          var labels=headers.map(function(text,index){return doc.splitTextToSize(String(text),widths[index]-pad*2);});
          var h=Math.max.apply(null,labels.map(function(lines){return lines.length;}))*lineHeight+pad*2;
          doc.setFillColor(27,58,107);doc.rect(margin,y,available,h,'F');doc.setTextColor(255,255,255);
          var x=margin;labels.forEach(function(lines,index){doc.text(lines,x+pad,y+pad+3,{lineHeightFactor:lineHeight/(fontSize*25.4/72)});x+=widths[index];});
          y+=h;tableStart=y;doc.setFont('helvetica','normal');doc.setTextColor(27,44,62);
        }
        startPage();
        rows.forEach(function(row,index){
          var lines=headers.map(function(_,col){return doc.splitTextToSize(String(row[col]===null||row[col]===undefined?'':row[col]),widths[col]-pad*2);});
          var lineCount=Math.max(1,...lines.map(function(cell){return cell.length;})),rowHeight=Math.max(10,lineCount*lineHeight+pad*2);
          if(y+rowHeight>height-16&&y>tableStart)startPage();
          var offset=0;
          while(offset<lineCount){
            var capacity=Math.floor((height-16-y-pad*2)/lineHeight);
            if(capacity<1||height-16-y<10){startPage();continue;}
            var count=Math.min(capacity,lineCount-offset),h=Math.max(10,count*lineHeight+pad*2),x=margin;
            doc.setFillColor.apply(doc,fillForRow(index)||[255,255,255]);doc.rect(margin,y,available,h,'F');
            lines.forEach(function(cell,col){
              var part=cell.slice(offset,offset+count),right=rightColumns.indexOf(col)>=0;
              if(part.length)doc.text(part,right?x+widths[col]-pad:x+pad,y+pad+3,{align:right?'right':'left',lineHeightFactor:lineHeight/(fontSize*25.4/72)});
              x+=widths[col];
            });
            y+=h;doc.setDrawColor(218,225,231);doc.setLineWidth(0.15);doc.line(margin,y,width-margin,y);
            offset+=count;if(offset<lineCount)startPage();
          }
        });
      }
      function area(value){return value===null||value===undefined?'Sin dato':Number(value).toLocaleString('es-CL',{maximumFractionDigits:10});}
      if(isClient){
        var clientRows=report.rows.map(function(r){return [r.project,r.lot,r.status,area(r.totalArea),area(r.easementArea),area(r.usableArea),money(r.listPrice,r.currency)+(r.listPrice!==null&&r.currency==='CLP'?' CLP':'')];});
        table('Detalle de lotes',report.detailHeaders,clientRows,[52,16,35,35,33,35,43],function(i){return colors[report.rows[i].status]||(i%2?[247,249,252]:null);},[3,4,5,6]);
      }else{
      var totals=Array(11).fill(0);totals[0]='TOTAL GENERAL';
      var summary=report.summary.map(function(item){
        var c=item.counts,row=[item.project,c.total,c.fir,item.signedAmount,c.res,item.reservedAmount,c.pen,c.bn,c.bc,c.disp,item.missingSales];
        for(var i=1;i<11;i++)totals[i]+=row[i];return row;
      });
      summary.push(totals);summary=summary.map(function(row){return row.map(function(value,col){return col===3||col===5?money(value,'CLP'):value;});});
      table('Resumen por proyecto',report.summaryHeaders,summary,[62,20,23,45,25,45,39,29,35,29,37],function(i){return i===summary.length-1?[220,232,242]:i%2?[247,249,252]:null;},[1,2,3,4,5,6,7,8,9,10]);
      var detail=report.rows.map(function(r){return [r.project,r.lot,r.status,r.client||'—',r.rut||'—',r.sale===null?(r.client?'Sin dato':'—'):money(r.sale,'CLP'),money(r.listPrice,r.currency),r.currency||'—',date(r.reservationDate),date(r.signatureDate),r.detail||'—'];});
      table('Detalle de lotes',report.detailHeaders.slice(0,11),detail,[42,14,33,66,28,32,29,18,25,25,84],function(i){return colors[report.rows[i].status]||(i%2?[247,249,252]:null);},[5,6]);
      var lotInfo=report.rows.map(function(r){return [r.project,r.lot,r.status,area(r.totalArea),area(r.easementArea),area(r.usableArea),money(r.listPrice,r.currency),r.currency||'—',r.rol||'Sin dato'];});
      table('Superficies y ROL por lote',['Proyecto','Lote','Disponibilidad','Superficie total (m²)','Servidumbre (m²)','Superficie útil (m²)','Precio lista','Moneda lista','ROL'],lotInfo,[64,20,44,40,40,40,46,30,42],function(i){return colors[report.rows[i].status]||(i%2?[247,249,252]:null);},[3,4,5,6]);
      }
      if(!isClient&&report.clientTable&&report.clientTable.rows.length)return downloadTablePDF({doc:doc,title:'Disponibilidad Comercial · Datos de clientes',filename:filename,headers:report.clientTable.headers,rows:report.clientTable.rows});
      for(var page=1;page<=pages;page++){
        doc.setPage(page);doc.setFont('helvetica','normal');doc.setFontSize(8);doc.setTextColor(90,106,123);
        doc.text('Gestión de cartera · Generado '+report.generated+' (Chile)',margin,height-7);
        doc.text('Página '+page+' de '+pages,width-margin,height-7,{align:'right'});
      }
      doc.save(filename||'Disponibilidad.pdf');notify('PDF descargado: '+report.rows.length+' lotes.','success');return true;
    }catch(error){if(root.console)root.console.error('PDF disponibilidad:',error);notify('No se pudo generar el PDF. Inténtalo de nuevo.','error');return false;}
  }

  root.downloadDisponibilidadPDF=downloadDisponibilidadPDF;
  root.downloadEscriturasPDF=downloadEscriturasPDF;
  root.downloadTablePDF=downloadTablePDF;
  root.downloadDelimitedPDF=downloadDelimitedPDF;
  if(typeof module!=='undefined'&&module.exports)module.exports={parseDelimitedLine:parseDelimitedLine,columnPanels:columnPanels,downloadTablePDF:downloadTablePDF,downloadEscriturasPDF:downloadEscriturasPDF,downloadDisponibilidadPDF:downloadDisponibilidadPDF};
})(typeof window!=='undefined'?window:globalThis);
