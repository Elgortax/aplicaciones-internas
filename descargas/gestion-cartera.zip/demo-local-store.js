/* Adaptador local de compatibilidad. NO contiene el SDK de Firebase ni usa red. */
(function () {
  'use strict';
  if(location.protocol!=='file:' && !(['127.0.0.1','localhost','[::1]'].includes(location.hostname))) {
    document.documentElement.innerHTML='<h1>Esta copia solo se puede abrir localmente.</h1>';
    throw new Error('DEMO_LOCAL_ONLY');
  }
  const clone=DemoSeed.clone, dbName='gestion-cartera-demo-20261123-v1', prefix='gestion-cartera-demo-20261123:';
  // Todas las preferencias y caches tienen su propio espacio, incluso en localhost.
  const originalGet=Storage.prototype.getItem,originalSet=Storage.prototype.setItem,originalRemove=Storage.prototype.removeItem;
  Storage.prototype.getItem=function(k){return originalGet.call(this,prefix+k);};
  Storage.prototype.setItem=function(k,v){return originalSet.call(this,prefix+k,v);};
  Storage.prototype.removeItem=function(k){return originalRemove.call(this,prefix+k);};
  let handle, docs={}, queue=Promise.resolve(); const listeners=new Set();
  const user={uid:'demo-admin',email:'admin@example.invalid',emailVerified:true,displayName:'Administrador Demo',
    getIdToken:async()=> 'DEMO_LOCAL_ONLY'};
  function fail(error){document.dispatchEvent(new CustomEvent('demo-storage-error',{detail:String(error.message||error)}));}
  // Una sola pestaña editora por perfil evita que dos copias en memoria se pisen.
  const exclusive=navigator.locks?new Promise((resolve,reject)=>{
    navigator.locks.request(dbName,{ifAvailable:true},lock=>{
      if(!lock){reject(new Error('Ya hay una demo abierta en otra pestaña. Ciérrala y recarga esta.'));return;}
      resolve();return new Promise(()=>{});
    }).catch(reject);
  }):Promise.resolve();
  const ready=exclusive.then(()=>new Promise((resolve,reject)=>{
    const request=indexedDB.open(dbName,1);
    request.onupgradeneeded=()=>request.result.createObjectStore('documents');
    request.onerror=()=>reject(request.error);
    request.onsuccess=()=>{
      handle=request.result; handle.onversionchange=()=>handle.close();
      const tx=handle.transaction('documents','readwrite'), store=tx.objectStore('documents');
      const all=store.getAll(),keys=store.getAllKeys();
      all.onsuccess=()=>{keys.onsuccess=load; if(keys.readyState==='done')load();};
      let loaded=false;
      function load(){if(loaded)return;loaded=true;
        if(!all.result.length){docs=clone(DemoSeed.docs);Object.keys(docs).forEach(k=>store.put(docs[k],k));}
        else keys.result.forEach((k,i)=>docs[k]=all.result[i]);
      }
      tx.oncomplete=()=>resolve(); tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||new Error('Almacenamiento cancelado'));
    };
  }));
  ready.catch(fail);
  function at(obj,key){return key.split('.').reduce((v,k)=>v==null?undefined:v[k],obj);}
  const sentinel=(op,args=[])=>({__demoOp:op,args});
  function value(v,old){
    if(v&&v.__demoOp){switch(v.__demoOp){case 'time':return new Date().toISOString();case 'inc':return (Number(old)||0)+v.args[0];case 'union':return [...new Map([...(old||[]),...v.args].map(x=>[JSON.stringify(x),x])).values()];case 'remove':return (old||[]).filter(x=>!v.args.some(y=>JSON.stringify(x)===JSON.stringify(y)));case 'delete':return undefined;}}
    if(Array.isArray(v))return v.map(x=>value(x));
    if(v&&typeof v==='object')return Object.fromEntries(Object.entries(v).map(([k,x])=>[k,value(x,old&&old[k])]).filter(([,x])=>x!==undefined));
    return v;
  }
  function merge(base,patch){const out=clone(base||{});Object.entries(patch).forEach(([k,v])=>{
    if(v&&typeof v==='object'&&!Array.isArray(v)&&!v.__demoOp)out[k]=merge(out[k],v);
    else {const next=value(v,out[k]);if(next===undefined)delete out[k];else out[k]=next;}
  });return out;}
  function patch(base,fields){const out=clone(base||{});Object.entries(fields).forEach(([path,v])=>{const parts=path.split('.');let dst=out;parts.slice(0,-1).forEach(k=>{dst=dst[k]||(dst[k]={});});const key=parts.at(-1),next=value(v,dst[key]);if(next===undefined)delete dst[key];else dst[key]=next;});return out;}
  function snap(path,source=docs){return {id:path.split('/').pop(),ref:new Ref(path),exists:Object.hasOwn(source,path),metadata:{hasPendingWrites:false,fromCache:false},data:()=>clone(source[path]??null),get:k=>at(source[path],k)};}
  function notify(){listeners.forEach(l=>{const signature=JSON.stringify(l.ref.result());if(l.last!==signature){l.last=signature;queueMicrotask(()=>{if(listeners.has(l))try{l.callback(l.ref.snapshot());}catch(e){l.error?.(e);}});}});}
  function enqueue(work){const result=queue.then(()=>ready).then(work);queue=result.catch(()=>{});return result.catch(e=>{fail(e);throw e;});}
  async function commit(ops){
    if(!ops.length)return;
    const next=clone(docs),paths=new Set();
    ops.forEach(([type,ref,payload,opt])=>{const path=ref.path;paths.add(path);
      if(type==='delete')delete next[path];
      else if(type==='update'){if(!Object.hasOwn(next,path))throw new Error('Documento local inexistente: '+path);next[path]=patch(next[path],payload);}
      else next[path]=opt&&opt.merge?merge(next[path],payload):value(payload,next[path]);
    });
    await new Promise((resolve,reject)=>{const tx=handle.transaction('documents','readwrite'),store=tx.objectStore('documents');paths.forEach(p=>Object.hasOwn(next,p)?store.put(next[p],p):store.delete(p));tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||new Error('No se pudo guardar localmente'));});
    docs=next;notify();document.dispatchEvent(new Event('demo-saved'));
  }
  class Ref {
    constructor(path,collection=false,filters=[],ordering=[],count=Infinity){this.path=path;this.id=path.split('/').pop();this.isCollection=collection;this.filters=filters;this.ordering=ordering;this.count=count;}
    doc(id){return new Ref(this.path+'/'+(id||('local-'+crypto.randomUUID())));}
    collection(id){return new Ref(this.path+'/'+id,true);}
    where(field,op,target){return new Ref(this.path,true,[...this.filters,[field,op,target]],this.ordering,this.count);}
    orderBy(field,direction='asc'){return new Ref(this.path,true,this.filters,[...this.ordering,[field,direction]],this.count);}
    limit(count){return new Ref(this.path,true,this.filters,this.ordering,count);}
    result(){if(!this.isCollection)return docs[this.path]??null;
      let list=Object.keys(docs).filter(p=>p.startsWith(this.path+'/')&&p.split('/').length===this.path.split('/').length+1);
      list=list.filter(p=>this.filters.every(([f,op,t])=>{const v=f==='__name__'?p.split('/').pop():at(docs[p],f);switch(op){case '==':return JSON.stringify(v)===JSON.stringify(t);case '!=':return v!==t;case 'in':return t.includes(v);case 'array-contains':return Array.isArray(v)&&v.includes(t);case '>':return v>t;case '>=':return v>=t;case '<':return v<t;case '<=':return v<=t;default:throw new Error('Filtro local no compatible: '+op);}}));
      list.sort((a,b)=>{for(const [f,d]of this.ordering){const av=at(docs[a],f),bv=at(docs[b],f);if(av!==bv)return (av>bv?1:-1)*(d==='desc'?-1:1);}return a.localeCompare(b);});
      return list.slice(0,this.count).map(p=>[p,docs[p]]);
    }
    snapshot(){if(!this.isCollection)return snap(this.path);const list=this.result().map(([p])=>snap(p));return {docs:list,size:list.length,empty:!list.length,metadata:{hasPendingWrites:false,fromCache:false},forEach:fn=>list.forEach(fn)};}
    async get(){await ready;await queue;return this.snapshot();}
    onSnapshot(options,callback,error){if(typeof options==='function'){error=callback;callback=options;}const l={ref:this,callback,error,last:null};listeners.add(l);ready.then(notify).catch(error||fail);return ()=>listeners.delete(l);}
    set(data,opt){return enqueue(()=>commit([['set',this,data,opt]]));}
    update(data){return enqueue(()=>commit([['update',this,data]]));}
    delete(){return enqueue(()=>commit([['delete',this]]));}
    async add(data){const ref=this.doc();await ref.set(data);return ref;}
  }
  function writer(){const ops=[];const w={set:(...args)=>{ops.push(['set',...args]);return w;},update:(...args)=>{ops.push(['update',...args]);return w;},delete:ref=>{ops.push(['delete',ref]);return w;},commit:()=>enqueue(()=>commit(ops))};return {w,ops};}
  const db={collection:path=>new Ref(path,true),doc:path=>new Ref(path),batch:()=>writer().w,
    runTransaction:fn=>enqueue(async()=>{const {w,ops}=writer();w.get=async ref=>snap(ref.path);const result=await fn(w);await commit(ops);return result;})};
  const auth={currentUser:user,setPersistence:async()=>{},signOut:async()=>{},onAuthStateChanged:fn=>{let active=true;ready.then(()=>{if(active)fn(user);});return ()=>active=false;}};
  const firestore=()=>db;
  firestore.FieldValue={serverTimestamp:()=>sentinel('time'),increment:n=>sentinel('inc',[n]),arrayUnion:(...xs)=>sentinel('union',xs),arrayRemove:(...xs)=>sentinel('remove',xs),delete:()=>sentinel('delete')};
  firestore.FieldPath={documentId:()=>'__name__'};
  window.firebase={firestore,auth:()=>auth}; // Compatibilidad de nombres, NO SDK ni servicio remoto.
  // Denegar conexiones incluso si una función antigua intenta iniciarlas.
  const blocked=()=>Promise.reject(Object.assign(new Error('Función externa desactivada en la demo local.'),{code:'demo-offline'}));
  window.fetch=async(url,options)=>{
    const address=String(url);
    if(address.startsWith('demo://uf/history/')){
      const year=Number(address.match(/(\d{4})/)?.[1]);const serie=[];
      for(let d=new Date(Date.UTC(year,0,1));d.getUTCFullYear()===year;d.setUTCDate(d.getUTCDate()+1)){
        const fecha=d.toISOString().slice(0,10);serie.push({fecha,valor:DemoSeed.uf(fecha)});
      }
      return new Response(JSON.stringify({indicador:'uf',unidad:'pesos',anio:year,serie}),{status:200,headers:{'Content-Type':'application/json'}});
    }
    if(address.startsWith('demo://uf/day/')){const fecha=address.split('/').pop().split('-').reverse().join('-');return new Response(JSON.stringify({codigo:'uf',serie:[{fecha,valor:DemoSeed.uf(fecha)}]}),{status:200});}
    if(address.startsWith('demo://service/')&&!/delete|Password|AuthUser|Mfa/i.test(address)){
      return new Response(JSON.stringify({ok:true,simulated:true,status:'demo',message:'Acción simulada localmente. No se enviaron mensajes.'}),{status:200,headers:{'Content-Type':'application/json'}});
    }
    return blocked();
  };
  window.XMLHttpRequest=function(){throw new Error('Red desactivada en demo');};
  window.WebSocket=window.EventSource=function(){throw new Error('Red desactivada en demo');};
  try{navigator.sendBeacon=()=>false;}catch(_){}
  const nativeOpen=window.open.bind(window);
  window.open=function(url,...args){if(url&&!/^(?:about:blank|blob:)/.test(String(url))){const target=new URL(String(url),location.href);if(!target.href.startsWith(new URL('.',location.href).href)){alert('Esta demo abre archivos locales de la demostración.');return null;}}return nativeOpen(url,...args);};
  document.addEventListener('click',event=>{const a=event.target.closest?.('a[href]');if(a&&/^(?:https?:|mailto:|tel:|\/\/)/i.test(a.getAttribute('href'))){event.preventDefault();alert('Enlace externo desactivado en la demo.');}},true);
  document.addEventListener('submit',event=>event.preventDefault(),true);
  window.DemoLocal={ready,db,auth,user,prefix,clone,
    exportData:async()=>{await ready;await queue;return {format:'cartera-demo-ficticia-v1',exportedAt:new Date().toISOString(),documents:clone(docs)};},
    replaceData:async data=>{if(data?.format!=='cartera-demo-ficticia-v1'||!data.documents?.['cartera/state']?.state)throw new Error('No es un respaldo de esta demo.');await ready;await enqueue(async()=>{await new Promise((resolve,reject)=>{const tx=handle.transaction('documents','readwrite'),s=tx.objectStore('documents');s.clear();Object.entries(data.documents).forEach(([k,v])=>s.put(v,k));tx.oncomplete=resolve;tx.onabort=()=>reject(tx.error);});docs=clone(data.documents);});},
    clearCaches:()=>{[localStorage,sessionStorage].forEach(store=>{for(let i=store.length-1;i>=0;i--){const k=store.key(i);if(k.startsWith(prefix))originalRemove.call(store,k);}});},
    reset:async()=>{await DemoLocal.replaceData({format:'cartera-demo-ficticia-v1',documents:DemoSeed.docs});DemoLocal.clearCaches();location.reload();}
  };
})();
