(function(root,factory){
  'use strict';
  var api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.CarteraConciliacionAudit=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  function number(value){
    if(value==null||value==='')return 0;
    return typeof value==='number'?value:Number(value);
  }
  function money(value){return '$'+Math.abs(value).toLocaleString('es-CL',{maximumFractionDigits:0});}
  function key(row){return JSON.stringify([String(row.registroId||''),row.tipo,row.idx==null?null:row.idx]);}
  function analyze(rows,getLine){
    var items=[],counts={sobrepago:0,saldo:0,detalle:0,estado:0,invalido:0};
    (rows||[]).forEach(function(row){
      var line=getLine?getLine(row):(row.linea||{});
      var rawAmount=number(row.monto),rawPaid=number(line.montoAbonado);
      var payments=Array.isArray(line.abonos)?line.abonos:[];
      var rawDetail=payments.reduce(function(total,payment){return total+number(payment&&payment.monto);},0);
      var descuento=row.tipo==='prontopago';
      var valid=Number.isFinite(rawAmount)&&Number.isFinite(rawPaid)&&(descuento?rawAmount<=0:rawAmount>=0)&&rawPaid>=0;
      var validDetail=payments.every(function(payment){var amount=number(payment&&payment.monto);return Number.isFinite(amount)&&amount>=0;});
      var amount=Number.isFinite(rawAmount)?Math.round(rawAmount):null;
      var paid=Number.isFinite(rawPaid)?Math.round(rawPaid):null;
      var detail=payments.length&&Number.isFinite(rawDetail)?Math.round(rawDetail):null;
      var balance=valid?amount-paid:null;
      var detailDifference=valid&&validDetail&&payments.length?paid-detail:null;
      var issues=[];
      function add(type,message){issues.push({type:type,message:message});counts[type]++;}
      if(!valid||!validDetail)add('invalido','Hay un monto negativo o inválido. Revisa la línea y sus abonos.');
      if(valid&&!descuento){
        if(balance<0)add('sobrepago','Abono superior a lo pactado: '+money(balance)+' a favor. Revisa su aplicación o devolución con los comprobantes.');
        else if(line.estado==='Pagado'&&balance>0)add('saldo','Marcado como Pagado, pero faltan '+money(balance)+' para cubrir lo pactado. Revisa el estado y los comprobantes.');
        if(amount>0&&balance<=0&&(line.estado==='Por Cobrar'||line.estado==='Mora'||!line.estado)){
          add('estado','El monto abonado cubre la línea, pero su estado sigue pendiente. Confirma el pago antes de cambiarlo.');
        }
      }
      if(detailDifference!==null&&detailDifference!==0){
        add('detalle','El Monto abonado registrado y la suma de sus abonos difieren en '+money(detailDifference)+'. Esto puede generar diferencias entre pantalla y Excel.');
      }
      if(!issues.length)return;
      items.push({key:key(row),registroId:String(row.registroId||''),tipo:row.tipo,idx:row.idx==null?null:row.idx,
        proyecto:row.proyecto||'',lote:row.name||'',cliente:row.cliente||'',linea:row.label||'',
        estado:line.estado||'Por Cobrar',monto:amount,abonado:paid,detalle:detail,saldo:balance,
        diferenciaDetalle:detailDifference,issues:issues});
    });
    return {items:items,counts:counts,linesReviewed:(rows||[]).length};
  }
  return {analyze:analyze,key:key};
});
