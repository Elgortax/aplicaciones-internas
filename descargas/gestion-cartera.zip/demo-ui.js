(function(){
  'use strict';
  const note=()=>toast('Solo demostración: no hay cuentas, correos ni servicios externos conectados.','info');
  const blockedNames=['openAccountSecurity','openNuevoUsuario','saveUsuario','openResetPass','confirmResetPass','createFirebaseAuthUser','deleteUser','openSecurityMfa','openMfaSetup','deleteAllRecords','deleteAllDesistimientos','executeBulkDelete','borrarDatosPorVista'];
  blockedNames.forEach(name=>{window[name]=note;});
  document.querySelectorAll('[onclick="openAccountSecurity()"]') .forEach(el=>el.remove());
  // Las exportaciones de demostración se distinguen de documentos comerciales.
  if(window.XLSX){const write=XLSX.writeFile;XLSX.writeFile=function(book,name,...args){return write.call(this,book,'DEMO_'+name,...args);};}
  if(window.jspdf){const Original=jspdf.jsPDF;function DemoPDF(...args){const doc=new Original(...args);let stamped=false;
    function mark(){if(stamped)return;stamped=true;const total=doc.internal.getNumberOfPages();for(let p=1;p<=total;p++){doc.setPage(p);doc.setFontSize(6);doc.setTextColor(110,110,110);doc.text('DEMO LOCAL - DATOS FICTICIOS - SIN VALIDEZ COMERCIAL',doc.internal.pageSize.getWidth()/2,doc.internal.pageSize.getHeight()-2,{align:'center'});}}
    const save=doc.save,output=doc.output;doc.save=function(name,...rest){mark();return save.call(this,'DEMO_'+name,...rest);};doc.output=function(...args){mark();return output.apply(this,args);};return doc;}
    Object.assign(DemoPDF,Original);DemoPDF.prototype=Original.prototype;jspdf.jsPDF=DemoPDF;
  }
  window.doLogout=()=>toast('No hay sesión que cerrar: esta copia es local y no requiere contraseña.','info');
  window.restablecerDatosPrueba=async()=>{
    if(!confirm('¿Volver a los ejemplos ficticios iniciales? Se perderán SOLO los cambios de esta demo. Descarga antes un respaldo local si quieres conservarlos.'))return;
    try{await DemoLocal.reset();}catch(e){toast('No se pudo restablecer la demo: '+e.message,'error');}
  };
  window.demoBackup=async()=>{
    try {
      if(stateDirty)await saveStateNow();
      const data=await DemoLocal.exportData(),a=document.createElement('a');
      const url=URL.createObjectURL(new Blob([JSON.stringify(data)],{type:'application/json'}));
      a.href=url;a.download='Respaldo-Demo-'+new Date().toISOString().slice(0,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),10000);
    }catch(e){toast('No se pudo respaldar la demo: '+e.message,'error');}
  };
  window.demoRestore=()=>{
    const input=document.createElement('input');input.type='file';input.accept='.json';
    input.onchange=async()=>{
      if(!input.files[0]||!confirm('¿Reemplazar los datos locales por este respaldo de la demo? No uses respaldos reales de la empresa.'))return;
      try{const data=JSON.parse(await input.files[0].text());await DemoLocal.replaceData(data);DemoLocal.clearCaches();location.reload();}
      catch(e){toast('No se pudo restaurar: '+e.message,'error');}
    };input.click();
  };
  window.deleteReg=async id=>{
    const r=state.registros.find(r=>r.id===id);if(!r||!confirm('¿Eliminar esta ficha ficticia y sus planes de pago SOLO de la demo? Puedes descargar un respaldo antes de eliminar.'))return;
    try{state.registros=state.registros.filter(r=>r.id!==id);state.conciliaciones=state.conciliaciones.filter(r=>r.registroId!==id);state.conciliacionesContables=state.conciliacionesContables.filter(r=>r.registroId!==id);state.validacionesReserva=state.validacionesReserva.filter(r=>r.registroId!==id);
      await saveStateImmediate();if(r.cotizacionId)await liberarCotizacionDeReserva(r.cotizacionId);closeModal('modal-reserva');populateFilters();renderAll();toast('Ficha de prueba eliminada localmente.','success');
    }catch(e){toast('No se pudo eliminar: '+e.message,'error');}
  };
  window.deleteManagedEntity=async(type,id)=>{
    const backup=await DemoLocal.exportData();
    Object.keys(backup.documents).filter(k=>k.startsWith('demo_papelera/')).forEach(k=>delete backup.documents[k]);
    await fbDb.collection('demo_papelera').doc('eliminacion-'+Date.now()).set({tipo:type,id,documents:backup.documents});
    if(type==='cotizacion'){
      if(state.registros.some(r=>r.cotizacionId===id))throw new Error('La cotización tiene una ficha vinculada. Elimina primero la ficha de prueba.');
      await fbDb.collection('cotizaciones').doc(id).delete();
    }else if(type==='visita'){
      const docs=await fbDb.collection('visitas_propias').get();const batch=fbDb.batch();let total=0;
      docs.forEach(d=>{const data=d.data();if(Array.isArray(data.items)){const items=data.items.filter(v=>v.id!==id);total+=items.length;batch.set(d.ref,{...data,items});}});
      batch.set(fbDb.collection('visitas_propias').doc('_meta'),{total,version:Date.now()},{merge:true});await batch.commit();
    }else {
      const names={conciliacion:'conciliaciones',conciliacionContable:'conciliacionesContables',validacion:'validacionesReserva'};const key=names[type];
      if(!key)throw new Error('Esta operación de servidor no se simula en la demo.');
      state[key]=(state[key]||[]).filter(r=>r.id!==id);await saveStateImmediate();
    }
    return {ok:true,recoveryId:'respaldo-local-en-demo_papelera'};
  };
  window.demoInfo=()=>window.open('./COMO_FUNCIONA.html','_blank');
  window.demoSwitchProfile=async id=>{
    const profile=state.usuarios.find(u=>u.id===id);if(!profile)return;
    if(stateDirty)await saveStateImmediate();
    Object.assign(DemoLocal.user,{uid:profile.uid,email:profile.email,displayName:profile.nombre});
    localStorage.setItem('demo-profile',id);enterAppWithProfile(DemoLocal.user,profile);
    toast('Perfil de demostración: '+profile.nombre,'info');
  };
  const bar=document.createElement('div');bar.id='demo-bar';bar.innerHTML='<div class="demo-heading"><div class="demo-mark">G</div><div><small>GESTIÓN DE CARTERA</small><strong id="demo-page-title">Panel de operaciones</strong></div><span class="demo-local">DEMO LOCAL</span></div><span id="demo-save-status">Datos de ejemplo · guardado local</span><div class="demo-tools"><select id="demo-profile" aria-label="Perfil de demostración" onchange="demoSwitchProfile(this.value)"></select><details><summary>Datos de prueba</summary><div><button onclick="demoBackup()">Respaldar pruebas</button><button onclick="demoRestore()">Restaurar respaldo</button><button onclick="restablecerDatosPrueba()">Restablecer ejemplos</button></div></details><a href="COMO_FUNCIONA.html" target="_blank" rel="noopener">Guía de uso</a></div>';
  document.body.prepend(bar);
  const profileSelect=document.getElementById('demo-profile');DemoSeed.state.usuarios.forEach(profile=>profileSelect.add(new Option(profile.rol+' · '+profile.nombre,profile.id)));
  const intro=document.createElement('section');intro.className='demo-intro';intro.id='demo-intro';intro.innerHTML='<div><small>VISIÓN GENERAL</small><h1>El ciclo completo de tu cartera.</h1><p>Desde la primera visita hasta la escritura y la conciliación de pagos. Recorre la misma operación con proyectos y clientes de ejemplo.</p></div><div class="demo-intro-stats"><div><strong>4</strong><span>proyectos de ejemplo</span></div><div><strong>96</strong><span>lotes en catálogo</span></div><div><strong>64</strong><span>fichas para explorar</span></div><div><strong>32</strong><span>planes de pago</span></div></div>';
  document.querySelector('.main').prepend(intro);
  function updateView(){
    const active=document.querySelector('.tab-panel.active'),id=active?.id.replace(/^panel-/,'');
    const button=id&&document.getElementById('tbtn-'+id);
    document.getElementById('demo-page-title').textContent=button?.querySelector('.snav-label')?.textContent||'Panel de operaciones';
    intro.hidden=id!=='graficos';
  }
  const observer=new MutationObserver(updateView);document.querySelectorAll('.tab-panel').forEach(panel=>observer.observe(panel,{attributes:true,attributeFilter:['class']}));
  document.addEventListener('demo-saved',()=>{document.getElementById('demo-save-status').textContent='Guardado en este navegador';});
  document.addEventListener('demo-storage-error',()=>{const status=document.getElementById('demo-save-status');status.textContent='No se pudo guardar localmente. Descarga un respaldo.';status.style.color='#fee2e2';});
  window.addEventListener('error',()=>{if(!window.__demoReady)document.getElementById('demo-save-status').textContent='No terminó de cargar. Consulta LEEME.txt.';});
  // Evitar mensajes de sincronización remota engañosos en una copia sin red.
  const status=document.getElementById('shared-data-sync');if(status){status.title='Almacenamiento local de demostración';status.setAttribute('aria-label',status.title);}
  document.addEventListener('DOMContentLoaded',async()=>{
    try {
      await DemoLocal.ready;
      await loadCloudState();
      const config=(await fbDb.doc('cotizador/config').get()).data();
      if(config)aplicarConfigCentral(config);
      const selected=state.usuarios.find(u=>u.id===localStorage.getItem('demo-profile'))||state.usuarios.find(u=>u.id==='demo-admin')||DemoSeed.state.usuarios[0];
      Object.assign(DemoLocal.user,{uid:selected.uid,email:selected.email,displayName:selected.nombre});
      profileSelect.value=selected.id;enterAppWithProfile(DemoLocal.user,selected);
      const brand=document.querySelector('.sb-name');if(brand)brand.textContent='Gestión de Cartera';
      const subtitle=document.querySelector('.sb-sub');if(subtitle)subtitle.textContent='Comercial · Legal · Finanzas';
      await ensureVisitasLoaded(true);
      if(puedeVerVista('graficos'))setTab('graficos',document.getElementById('tbtn-graficos'));
      updateView();
      window.__demoReady=true;
      toast('Demo local lista. Todos los clientes y montos son ficticios.','info');
    }catch(e){console.error('No se pudo abrir la demo local:',e);document.getElementById('demo-save-status').textContent=String(e.message||'No se pudo abrir el almacenamiento local. Usa Chrome o Edge sin modo privado.');}
  });
})();
