(function(root){
  'use strict';
  var goal=1000000000;
  var prefix='cartera:team-goal:v1:';
  var shown=Object.create(null),timer=null,checking=false,dialog=null,activeKey='';

  function currentMonth(){
    var parts=new Intl.DateTimeFormat('en-CA',{timeZone:'America/Santiago',year:'numeric',month:'2-digit'}).formatToParts(new Date());
    var values={};parts.forEach(function(part){values[part.type]=part.value;});
    return values.year+'-'+values.month;
  }
  function context(){
    if(typeof currentUser==='undefined'||!currentUser||typeof currentFirebaseUser==='undefined'||!currentFirebaseUser||!currentFirebaseUser.uid)return null;
    if(typeof stateLoadedFromCloud==='undefined'||!stateLoadedFromCloud||typeof SNAPSHOT_MODE!=='undefined'&&SNAPSHOT_MODE)return null;
    if(typeof stateDirty!=='undefined'&&stateDirty||typeof cloudSaveInFlight!=='undefined'&&cloudSaveInFlight)return null;
    // Use the confirmed portfolio, never a form draft or the Dashboard filters.
    if(typeof cloudBaselineState==='undefined'||!cloudBaselineState||!Array.isArray(cloudBaselineState.registros))return null;
    var month=currentMonth();
    return {month:month,key:prefix+encodeURIComponent(currentFirebaseUser.uid)+':'+month,records:cloudBaselineState.registros};
  }
  function seen(key){
    if(shown[key])return true;
    try{return localStorage.getItem(key)==='1';}catch(e){return false;}
  }
  function reached(info){
    var total=info.records.reduce(function(sum,record){
      if(getEstado(record)!=='Firmado'||ymFromDate(record.fechaFirma)!==info.month)return sum;
      var price=Number(record.precio);
      return sum+(Number.isFinite(price)?price:0);
    },0);
    return total>goal;
  }
  function visible(element){
    return !!element&&element.getClientRects().length>0&&getComputedStyle(element).visibility!=='hidden';
  }
  function canShow(){
    if(document.visibilityState!=='visible'||!visible(document.getElementById('app'))||visible(document.getElementById('login-screen')))return false;
    if(dialog&&dialog.open)return false;
    var field=document.activeElement;
    if(field&&(field.matches('input,textarea,select')||field.isContentEditable))return false;
    return !Array.from(document.querySelectorAll('.modal-overlay,.cot-modal-overlay,[role="dialog"],dialog[open]')).some(visible);
  }
  function close(){
    if(dialog&&dialog.open)dialog.close();
    activeKey='';
  }
  function ensureDialog(){
    if(dialog)return dialog;
    dialog=document.createElement('dialog');
    dialog.id='team-goal-dialog';dialog.className='team-goal-dialog';
    dialog.setAttribute('aria-labelledby','team-goal-title');
    dialog.setAttribute('aria-describedby','team-goal-message');
    dialog.innerHTML='<button type="button" class="team-goal-close" aria-label="Cerrar celebración">×</button>'+
      '<div class="team-goal-brand">Grupo Tierras de Chile</div>'+
      '<div class="team-goal-symbol" aria-hidden="true">🎉</div>'+
      '<p class="team-goal-month" id="team-goal-month"></p>'+
      '<h2 id="team-goal-title">¡Lo logramos, equipo!</h2>'+
      '<div id="team-goal-message"><p class="team-goal-milestone">Superamos los <strong>$1.000 millones</strong><span>en ventas firmadas este mes</span></p>'+
      '<p class="team-goal-thanks">Gracias por el esfuerzo, la dedicación y las ganas que cada uno pone todos los días. Cada llamada, cada visita y cada gestión nos ayudó a alcanzar esta meta.</p>'+
      '<p class="team-goal-together">Esto es gracias a todos.<br><strong>El logro es de todo el equipo.</strong> ❤️</p>'+
      '<p class="team-goal-celebrate">¡Celebremos juntos y vamos por más! 🚀</p></div>'+
      '<button type="button" class="team-goal-button" autofocus>¡Vamos por más!</button>';
    dialog.querySelector('.team-goal-close').addEventListener('click',close);
    dialog.querySelector('.team-goal-button').addEventListener('click',close);
    dialog.addEventListener('close',function(){activeKey='';});
    document.body.appendChild(dialog);
    return dialog;
  }
  function showIfEligible(expectedKey){
    var info=context();
    if(!info||info.key!==expectedKey||seen(info.key)||!canShow()||!reached(info))return false;
    var popup=ensureDialog();
    popup.querySelector('#team-goal-month').textContent=monthLabelLong(info.month);
    popup.showModal();activeKey=info.key;
    shown[info.key]=true;
    try{localStorage.setItem(info.key,'1');}catch(e){}
    return true;
  }
  async function check(){
    var info=context();
    if(activeKey&&(!info||info.key!==activeKey))close();
    if(checking||!info||seen(info.key)||!canShow()||!reached(info))return false;
    checking=true;
    try{
      // Serialize tabs sharing this browser so only one presents the celebration.
      if(navigator.locks)return await navigator.locks.request(info.key,{ifAvailable:true},function(lock){return lock?showIfEligible(info.key):false;});
      return showIfEligible(info.key);
    }catch(error){console.warn('No se pudo mostrar la celebración de la meta.',error);return false;}
    finally{checking=false;}
  }
  function checkSoon(){
    if(timer)clearTimeout(timer);
    timer=setTimeout(function(){timer=null;check();},1600);
  }
  document.addEventListener('visibilitychange',checkSoon);
  root.addEventListener('focus',checkSoon);
  root.addEventListener('storage',function(event){if(event.key&&event.key.indexOf(prefix)===0)checkSoon();});
  // Retry after closing a ficha, and handle a month rollover without a reload.
  setInterval(check,15000);
  root.CarteraTeamGoal={check:check,checkSoon:checkSoon,close:close};
  checkSoon();
})(window);
