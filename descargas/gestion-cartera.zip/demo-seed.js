/* Ejemplos inventados. No se importan fichas, usuarios ni documentos de la empresa. */
(function(){
  'use strict';
  const clone=v=>JSON.parse(JSON.stringify(v)),today=new Date(),year=today.getFullYear(),month=today.getMonth();
  const day=(d,offset=0)=>{const v=new Date(year,month+offset,d,12);return v.getFullYear()+'-'+String(v.getMonth()+1).padStart(2,'0')+'-'+String(v.getDate()).padStart(2,'0');};
  const uf=date=>Math.round((40000+(Date.parse(String(date).slice(0,10)+'T12:00:00Z')-Date.UTC(year,0,1,12))/86400000*3.37)*100)/100;
  const iso=day(1)+'T12:00:00.000Z',money=n=>'$'+Math.round(n).toLocaleString('es-CL');
  const users=[['admin','Administrador Demo','Administrador'],['gerencia','Gerencia Demo','Gerencia'],['ventas','Ejecutiva Ventas Demo','Ej. Adm. Ventas'],
    ['terreno1','Teresa Terreno Demo','Terreno'],['terreno2','Tomas Terreno Demo','Terreno'],['remoto1','Renata Remoto Demo','Remoto'],['remoto2','Rafael Remoto Demo','Remoto'],
    ['legal1','Laura Legal Demo','Legal'],['legal2','Lucia Legal Demo','Legal'],['contable','Camila Contabilidad Demo','Ejecutivo Contable']]
    .map(([id,nombre,rol])=>({id:'demo-'+id,uid:'demo-'+id,nombre,rol,user:id,email:id+'@example.invalid',activo:true}));
  const projects=['Bosque Aurora','Valle del Horizonte','Reserva Los Arrayanes','Costa Serena'];
  const cfg={DB:{},PIE_PCT_DB:{},PIE_FIJO_DB:{},PIE_CUOTAS_DB:{},MAX_CUOTAS_DB:{},DESCUENTOS_DB:{},ASIG_DB:{},VENDEDOR_PROY_DB:{},
    VENDEDORES_DB:users.filter(u=>['Administrador','Remoto'].includes(u.rol)).map(u=>({id:u.id,nombre:u.nombre,cargo:u.rol,gestionUserId:u.id})),
    VENDEDORES_PROY_DB:users.filter(u=>u.rol==='Terreno').map(u=>({id:u.id,nombre:u.nombre})),folioActual:0};
  const records=[],quotes=[],plans=[],accounting=[],validations=[],visits=[],contacts={},docs={};
  const state={usuarios:users,permisos:null,motivos:['Cambio de decisión','Problema financiero','Cambio de producto'],motivosRescil:['Acuerdo entre las partes','Cambio de proyecto','Otro'],
    formasPago:['Vale Vista','Transferencia','Contado'],acompanantes:['Acompañante Demo'],agentesAdmVentas:[users[2].nombre],agentesTerreno:[users[3].nombre,users[4].nombre],
    agentesRemoto:[users[5].nombre,users[6].nombre],agentesAbogados:[users[7].nombre,users[8].nombre],presupuestos:[],leads:[],lotes:{},lotesBloqueados:{},dashboardPortfolioProjects:null,
    proyectos:projects,estados:['Reservado','Firmado','Desistido','Agenda Postergada','Resciliación'],
    estadosReserva:['Nueva Reserva','Revisión Documentos','Agendado','Solicitud de Borradores','Modificación de Borradores','Con Observación','Borradores Listos','Borradores Enviados'],
    registros:records,conciliaciones:plans,conciliacionesContables:accounting,validacionesReserva:validations,correlativoReserva:64};
  projects.forEach((project,p)=>{
    const pid='proyecto-demo-'+(p+1),lots={};
    for(let j=1;j<=24;j++)lots[String(j)]={mts:5000+j*20,servidumbre:j%3===0?200:0,utiles:5000+j*20-(j%3===0?200:0),moneda:p>=2?'UF':'CLP',precio:p>=2?850+j*12:27000000+p*7500000+j*450000};
    cfg.DB[pid]={nombre:project,lotes:lots};cfg.PIE_PCT_DB[pid]=20;cfg.PIE_CUOTAS_DB[pid]=4;cfg.MAX_CUOTAS_DB[pid]=36;cfg.DESCUENTOS_DB[pid]={contado:5,credito:3};
    cfg.ASIG_DB[pid]=users.filter(u=>u.rol==='Remoto'||u.rol==='Administrador').map(u=>u.id);cfg.VENDEDOR_PROY_DB[pid]=[users[3].id,users[4].id];
    state.lotesBloqueados[project]={'17':{tipo:'normal',lote:'17',motivo:'Lote de ejemplo bloqueado'},'18':{tipo:'comercial',lote:'18',motivo:'Bloqueo comercial de demostración'}};
    state.leads.push({id:'demo-lead-'+p,proyecto:project,presupuestoLead:180+p*30,leadsAcumulados:140+p*20,contactadoPct:.85,visitaProgramadaPct:.5,visitaConcretadaPct:.7,reservaPct:.3,firmaPct:.7});
    for(let j=1;j<=16;j++){
      const n=p*16+j,id='demo-ficha-'+n,quoteId='demo-cotizacion-'+n,lot=lots[String(j)],currency=lot.moneda;
      const status=j<=5?'Reservado':j<=11?'Firmado':j<=13?'Desistido':j<=15?'Resciliación':'Agenda Postergada';
      const signed=status==='Firmado'||status==='Resciliación';
      const saleDate=signed?day(8+j%7,-((p*6+j-6+12)%12)):day(2+j%10);
      const rate=uf(saleDate),amount=currency==='UF'?Math.round(lot.precio*rate):lot.precio;
      const reserve=200000,contra=Math.round(amount*.2)-reserve,contraEsc=Math.round(amount*.3),balance=amount-reserve-contra-contraEsc;
      const remote=users[5+p%2],terrain=users[3+p%2],lawyer=users[7+p%2];
      const draft=['Nueva Reserva','Solicitud de Borradores','Con Observación','Borradores Listos','Agendado'][j-1]||(status==='Firmado'?'Borradores Enviados':'Revisión Documentos');
      const name='Cliente de Ejemplo '+String(n).padStart(2,'0');
      const r={id,numReserva:n,name:String(j),proyecto:project,cliente:name,rut:'DEMO-'+String(n).padStart(4,'0'),
        telefono:'',correo:'cliente'+n+'@example.invalid',email:'cliente'+n+'@example.invalid',comuna:['Santiago','Providencia','Viña del Mar','La Serena'][p],region:p===3?'Coquimbo':p===2?'Valparaíso':'Metropolitana',
        direccion:'Dirección de ejemplo '+n,nacionalidad:'Chilena',profesion:'Ocupación de ejemplo',estadoCivil:j%2?'Soltero/a':'Casado/a',edad:30+n%25,hijos:n%3,
        estado:status,estadoReserva:draft,precio:amount,moneda:currency,precioUf:currency==='UF'?lot.precio:0,valorUf:currency==='UF'?rate:0,fechaTipoCambio:currency==='UF'?saleDate:'',
        fechaReserva:signed?day(2,-((p*6+j-6+12)%12)):day(2+j%10),fechaFirma:signed?saleDate:j===5?day(26):'',horaAgenda:j===5?'11:30':signed?'10:00':'',
        terreno:terrain.nombre,remoto:remote.nombre,admVentas:users[2].nombre,abogada:lawyer.nombre,notaria:'Notaría de Ejemplo '+(p+1),formaPago:'Vale Vista',acompanante:'Acompañante Demo',
        etapaLegal:status==='Firmado'?(j===9||j===11?'Escritura':'Promesa'):'',fechaEscritura:j===9||j===11?saleDate:'',horaEscritura:j===9||j===11?'12:00':'',
        estadoEscritura:j===6?'Solicitud Borradores CV':j===7?'Con Observación':j===8?'Borradores Listos':'',
        fechaAgendaEscritura:status==='Firmado'&&j<=8?day(25+j-6):'',horaAgendaEscritura:'15:00',notariaEscritura:'Notaría de Ejemplo '+(p+1),ejecutivoNotaria:'Ejecutivo Notaría Demo',valorValeVista:contraEsc,
        desistMot:status==='Desistido'?'Cambio de decisión':status==='Resciliación'?'Acuerdo entre las partes':'',desistFecha:j>=12&&j<=15?day(12+j%8):'',
        desistEstado:status==='Desistido'?(j===13?'pendiente':'aprobada'):'',estadoPrevioDesist:status==='Desistido'?'Reservado':'',rescilEstado:status==='Resciliación'?(j===15?'pendiente':'aprobada'):'',
        desistAprobadoPor:j===12?users[0].nombre:'',rescilAprobadoPor:j===14?users[0].nombre:'',
        cotizacionId:quoteId,cotizacionFolio:'COT-DEMO-'+String(n).padStart(4,'0'),montoReservaCotizacion:reserve,totalPagoCuotasCotizacion:balance,
        fechaVisita:day(1+j%10),horaVisita:'10:30',prioridad:j===2?'Alta':j===3?'Media':'',estadoReunion:'Realizada',
        fechaReunion:day(3+j%16),horaReunion:j%3===0?'16:00':j%2?'10:00':'11:30',
        reuniones:[{id:'demo-reunion-'+n,fecha:day(3+j%16),hora:j%3===0?'16:00':j%2?'10:00':'11:30',abogada:lawyer.nombre,estado:'Realizada'}],
        obs:'Ejemplo ficticio para recorrer el flujo de la aplicación.',obsHistorial:[],actividad:[{ts:day(1)+' 09:00',user:users[0].nombre,msg:'Ficha ficticia creada para demostración.'}],adjuntos:[]};
      records.push(r);contacts[id]={registroId:id,rut:r.rut,correo:r.correo,telefono:'',direccion:r.direccion,comuna:r.comuna,region:r.region,nacionalidad:r.nacionalidad,profesion:r.profesion,estadoCivil:r.estadoCivil};
      quotes.push({id:quoteId,timestamp:saleDate+'T12:00:00.000Z',fecha:saleDate,folioNum:n,folioCompleto:r.cotizacionFolio,nombre:name,rut:r.rut,correo:r.correo,telefono:'',
        proyecto:project,lote:String(j),moneda:currency,mts:lot.mts+' m²',servidumbre:lot.servidumbre+' m²',utiles:lot.utiles+' m²',
        precioLista:currency==='UF'?lot.precio+' UF':money(amount),precioMoneda:currency==='UF'?lot.precio+' UF':money(amount),precioVenta:money(amount),precioNeto:money(amount),totalPagar:money(amount),tipoCambio:currency==='UF'?rate:'',fechaUF:currency==='UF'?saleDate:'',
        reserva:money(reserve),pie:money(contra),pieTotal:money(contra),pieModoCalculo:'automatico',pieCuotasModo:'total',pieEnCuotas:false,
        contraEscritura:money(contraEsc),pagarContraEsc:money(contraEsc),saldoNeto:money(balance),saldoConDesc:money(balance),saldoCuotas:money(balance),
        ctdCuotas:'12',valorCuota:money(Math.round(balance/12)),fechaPrimeraCuota:day(5,1),condicionPago:'credito',totalDescuento:'0%',desc1:'0',desc2:'0',desc3:'0',interesCuota:'0',interesContraEsc:'0',
        vendedorId:remote.id,vendedor:remote.nombre,vendedorCargo:'Remoto',vendedorProyecto:terrain.nombre,reservaCreada:true,reservaId:id,
        ocupacion:r.profesion,estadoCivil:r.estadoCivil,direccion:r.direccion,comuna:r.comuna,region:r.region,nacionalidad:r.nacionalidad,fechaVisita:r.fechaVisita,horaVisita:r.horaVisita});
      if(status==='Reservado'||status==='Firmado')validations.push({id:'demo-validacion-'+n,registroId:id,proyecto:project,name:String(j),cliente:name,rut:r.rut,precio:amount,monto:reserve,fechaReserva:r.fechaReserva,
        medioPago:'Transferencia',banco:'Banco de Ejemplo',nroDocumento:'DEMO-'+n,estado:j%3===0?'Pendiente':'Validado',fechaValidacion:day(3),documentos:[],actividad:[]});
      if(signed){
        const line=(monto,fecha,estado)=>({monto,fecha,estado,valorUf:rate,valorUfPago:rate,montoUf:monto/rate,equivalenteUf:Math.round(monto/rate*100000000)/100000000});
        const cuotas=Array.from({length:12},(_,k)=>line(k===11?balance-Math.round(balance/12)*11:Math.round(balance/12),day(5,k-2),k<2?'Pagado':'Por Cobrar'));
        const plan={id:'demo-plan-'+n,registroId:id,proyecto:project,name:String(j),cliente:name,rut:r.rut,precio:amount,precioUf:r.precioUf,terreno:terrain.nombre,remoto:remote.nombre,fechaFirma:saleDate,moneda:currency,valorUf:rate,fechaTipoCambio:saleDate,
          reserva:line(reserve,r.fechaReserva,'Pagado'),contraPromesa:line(contra,saleDate,'Pagado'),contraEscritura:line(contraEsc,day(16,2),'Por Cobrar'),
          pieDiferido:{cantidad:0,rows:[]},diferidas:{cantidad:0,rows:[]},cuotas:{cantidad:12,rows:cuotas},obs:'Plan de pago ficticio. Puede editar sus cuotas y probar Prontopago.'};
        plans.push(plan);
        const account=(l,paid)=>({estado:paid?'Pagado':'Por Cobrar',medioPago:paid?'Transferencia':'',banco:paid?'Banco de Ejemplo':'',nroDocumento:paid?'DEMO-'+n:'',
          fechaDeposito:paid?l.fecha:'',montoAbonado:paid?l.monto:0,titularPago:paid?name:'',rutPago:'',nroCuentaCliente:'',valorUf:rate,fechaTipoCambio:l.fecha});
        accounting.push({id:'demo-cc-'+n,planPagoId:plan.id,registroId:id,proyecto:project,name:String(j),cliente:name,rut:r.rut,precio:amount,terreno:terrain.nombre,remoto:remote.nombre,moneda:currency,fechaConciliacion:day(1),
          lineas:{reserva:account(plan.reserva,true),contraPromesa:account(plan.contraPromesa,true),contraEscritura:account(plan.contraEscritura,false),pieDiferido:[],diferidas:[],cuotas:cuotas.map((l,k)=>account(l,k<2))},actividad:[],obs:'Conciliación de demostración.'});
      }
    }
  });
  for(let i=0;i<4;i++){const q=clone(quotes[i*16]);Object.assign(q,{id:'demo-cotizacion-libre-'+i,folioNum:65+i,folioCompleto:'COT-DEMO-'+(65+i),nombre:'Prospecto de Ejemplo '+(i+1),rut:'DEMO-LIBRE-'+i,lote:'19',reservaCreada:false,reservaId:''});quotes.push(q);}
  cfg.folioActual=quotes.length;
  for(let i=0;i<96;i++){
    const p=i%4,offset=-Math.floor(i/8),remote=users[5+p%2],terrain=users[3+p%2];
    visits.push({id:'demo-visita-'+i,source:'gestion',proyecto:projects[p],cliente:'Visitante de Ejemplo '+(i+1),rut:'',telefono:'',correo:'visita'+i+'@example.invalid',
      fechaVisita:i<4?day(Math.min(today.getDate()+i,28)):day(3+i%21,offset),horaVisita:['10:00','11:30','15:00','16:00'][i%4],estado:i<4?'Agenda Visita':i%3===0?'Visita No Concretada':'Visita Concretada',
      remoto:remote.nombre,terreno:terrain.nombre,medio:['Web','Redes sociales','Referido'][i%3],observacion:'Visita ficticia, sin avisos externos.',creadoAt:iso,fechaCreacion:day(1,offset)});
  }
  Object.assign(docs,{'cartera/state':{state,stateRevision:1},'cotizador/config':cfg,'visitas_propias/demo':{items:visits},'visitas_propias/_meta':{total:visits.length,version:1},'cartera/observaciones_migracion_v1':{version:1}});
  quotes.forEach(q=>{const clean=clone(q);delete clean.id;docs['cotizaciones/'+q.id]=clean;});
  plans.forEach((p,i)=>docs['conciliaciones/'+p.id]={data:p,position:i});
  accounting.forEach((c,i)=>docs['conciliaciones_contables/'+c.id]={data:c,position:i});
  validations.forEach((v,i)=>docs['validaciones_reserva/'+v.id]={data:v,position:i});
  Object.keys(contacts).forEach(id=>docs['contactos_registros/'+id]=contacts[id]);
  window.DemoSeed={state,docs,config:cfg,createdAt:iso,clone,uf,counts:{projects:4,lots:96,records:64,quotes:68,plans:plans.length,visits:96}};
})();
