(() => {
  "use strict";

  const STORAGE_KEY = "gtdch-gestion-oficina-demo-v1";
  const MODULES = {
    usuarios: {
      title: "Personas", singular: "persona", icon: "people", color: "#197265",
      columns: [["cargo","Cargo / correo"],["departamento","Departamento"],["responsable","Responsable"],["telefono","Teléfono"],["estado","Estado"]],
      fields: [
        ["name","Nombre","text",true],["rut","RUT"],["fechaNacimiento","Fecha de nacimiento","date"],["cargo","Cargo"],
        ["departamento","Departamento","select",["Administración Ventas","Comercial","Contabilidad","Directorio","Finanzas","Marketing","Operaciones","Proyectos","RRHH","TI","Venta Remota"]],
        ["responsable","Responsable","person"],["telefono","Teléfono"],["email","Correo","email"],
        ["estado","Estado","select",["Activo","Inactivo","Sin estado"]],["notas","Notas internas","textarea"]
      ]
    },
    licencias: {
      title: "Licencias", singular: "licencia", icon: "key", color: "#6a56a5",
      columns: [["area","Área"],["asignadoA","Asignado a"],["costo","Costo mensual"],["cargo","Cargo"],["estado","Estado"]],
      fields: [["name","Nombre","text",true],["area","Área"],["asignadoA","Asignado a","person"],["costo","Costo mensual","number"],["cargo","Cargo"],["estado","Estado","select",["Asignado","Disponible","Dar de Baja","Dado de baja"]],["notas","Notas","textarea"]]
    },
    microsoft365: {
      title: "Microsoft 365", singular: "cuenta", icon: "grid", color: "#3379a8",
      columns: [["email","Correo"],["contexto","Empresa / contexto"],["licencias","Licencias"],["recursos","Equipo / línea"],["estado","Estado"]],
      fields: [["name","Nombre de cuenta","text",true],["email","Correo","email"],["contexto","Empresa / contexto"],["estado","Estado","select",["Activo","Inactivo","Dar de Baja"]],["pin","PIN"],["licencias","Licencias asignadas"],["recursos","Equipos o líneas"],["notas","Notas","textarea"]]
    },
    equipos: {
      title: "Equipos", singular: "equipo", icon: "monitor", color: "#6b58a8",
      columns: [["tipo","Tipo"],["marca","Marca"],["modelo","Modelo"],["serie","Número de serie"],["asignadoA","Asignado a"],["estado","Estado"]],
      fields: [["name","Nombre","text",true],["estado","Estado","select",["Disponible","En Uso","Mantenimiento","Dado de baja"]],["tipo","Tipo de equipo","select",["PC - Torre","Notebook","Monitor","Teléfono Móvil","Tablet","Otro"]],["marca","Marca"],["modelo","Modelo"],["serie","Número de serie"],["asignadoA","Asignado a","person"],["area","Área"],["fechaCompra","Fecha de compra","date"],["verificado","Verificado","checkbox"],["notas","Notas","textarea"]]
    },
    lineas: {
      title: "Líneas", singular: "línea", icon: "phone", color: "#be525a",
      columns: [["proveedor","Proveedor"],["asignadoA","Asignado a"],["marca","Empresa / marca"],["conectado","Conectado"],["estadoLinea","Estado de línea"],["estadoAsignacion","Asignación"]],
      fields: [["name","Número","text",true],["estadoLinea","Estado de línea","select",["Activo","Inactivo","Bloqueado"]],["estadoAsignacion","Estado de asignación","select",["Disponible","Asignado","Dar de Baja","Dado de baja","Bloqueado"]],["proveedor","Proveedor","select",["WOM","Entel"]],["tipoAsignacion","Tipo de asignación","select",["Persona","Marca / proyecto"]],["asignadoA","Asignado a","assignment"],["marca","Empresa / marca"],["conectado","Conectado","select",["Respond","Meta","Oficina"]],["notas","Notas","textarea"]]
    }
  };

  const ICONS = {
    home:'<path d="m3.5 10.8 8.5-7 8.5 7"/><path d="M5.5 9.5v10h13v-10M9.5 19.5v-6h5v6"/>',
    people:'<circle cx="9" cy="8" r="3.2"/><path d="M3.5 19c.4-4 2.2-6 5.5-6s5.1 2 5.5 6M15.5 6.3a3 3 0 0 1 0 5.5M16.3 14c2.6.5 3.9 2.1 4.2 5"/>',
    key:'<circle cx="8.3" cy="12" r="4.1"/><path d="M12.4 12h8.1M17 12v3M19.5 12v2"/>',
    grid:'<path d="M4 4.5h7v7H4zM13 4.5h7v7h-7zM4 13.5h7v7H4zM13 13.5h7v7h-7z"/>',
    monitor:'<rect x="3.5" y="4.5" width="17" height="11" rx="1.5"/><path d="M8 19.5h8M10 15.5l-.7 4M14 15.5l.7 4"/>',
    phone:'<path d="M8.3 3.8 6.1 5.2c-1.1.7-1.3 2.1-.8 3.3 2 4.8 5.5 8.3 10.3 10.3 1.2.5 2.6.3 3.3-.8l1.4-2.2-4-2-1.7 1.7c-2.6-1.3-4.7-3.4-6-6l1.7-1.7-2-4Z"/>',
    clock:'<path d="M4 12a8 8 0 1 0 2.3-5.7L4 8.6M4 4v4.6h4.6M12 7.8V12l3 1.8"/>',
    sparkles:'<path d="m12 3 1.2 3.8L17 8l-3.8 1.2L12 13l-1.2-3.8L7 8l3.8-1.2L12 3ZM18.5 13l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8.8-2.2ZM5.5 14l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7.7-2Z"/>',
    refresh:'<path d="M20 11a8 8 0 1 0-2.3 5.7L20 14.4M20 20v-5.6h-5.6"/>',
    menu:'<path d="M4 7h16M4 12h16M4 17h16"/>',search:'<circle cx="10.7" cy="10.7" r="6.2"/><path d="m15.3 15.3 4.2 4.2"/>',
    plus:'<path d="M12 5v14M5 12h14"/>',download:'<path d="M12 3v12m0 0 4-4m-4 4-4-4M5 19h14"/>',filter:'<path d="M4 6h16M7 12h10M10 18h4"/>',
    check:'<path d="m5 12 4 4 10-10"/>',edit:'<path d="m4 20 4.2-1 10.7-10.7a2 2 0 0 0-2.8-2.8L5.4 16.2 4 20ZM14.7 6.8l2.8 2.8"/>',
    paperclip:'<path d="m9 12.5 5.8-5.8a3 3 0 0 1 4.2 4.2l-7.2 7.2a5 5 0 0 1-7.1-7.1l7-7"/>',
    alert:'<path d="M12 3 2.8 19h18.4L12 3Z"/><path d="M12 9v4M12 16.5v.1"/>',
    link:'<path d="M10 13a5 5 0 0 0 7.5.5l2-2a5 5 0 0 0-7.1-7.1l-1.1 1.1M14 11a5 5 0 0 0-7.5-.5l-2 2a5 5 0 0 0 7.1 7.1l1.1-1.1"/>',
    shield:'<path d="M12 3 5 6v5c0 4.6 2.7 8 7 10 4.3-2 7-5.4 7-10V6l-7-3Z"/><path d="m9 12 2 2 4-4"/>',
    database:'<ellipse cx="12" cy="5.5" rx="7.5" ry="3"/><path d="M4.5 5.5v6c0 1.7 3.4 3 7.5 3s7.5-1.3 7.5-3v-6M4.5 11.5v6c0 1.7 3.4 3 7.5 3s7.5-1.3 7.5-3v-6"/>',
    eye:'<path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"/><circle cx="12" cy="12" r="2.5"/>'
  };

  const SEED = {"items":[{"id":"demo-usuarios-1","module":"usuarios","name":"Alba Demo","group":"Activos","fields":{"rut":"DEMO-001","fechaNacimiento":"1990-01-01","cargo":"Ejecutiva comercial","departamento":"Venta Remota","responsable":"Alba Demo","telefono":"","email":"persona1@example.invalid","estado":"Activo","notas":"Registro ficticio para mostrar las asignaciones."},"connections":[{"id":"c1","name":"Inversiones Vicaper","email":"contacto@example.invalid","licenses":["Microsoft 365 Empresa Estándar","Respond.io"],"equipments":["68 - Notebook"],"line":"Sin teléfono","pin":"0068","status":"Activo"}]},{"id":"demo-usuarios-2","module":"usuarios","name":"Bruno Demo","group":"Activos","fields":{"rut":"DEMO-002","fechaNacimiento":"1990-01-01","cargo":"Ejecutiva comercial","departamento":"Venta Remota","responsable":"Alba Demo","telefono":"","email":"persona2@example.invalid","estado":"Activo","notas":"Registro ficticio para mostrar las asignaciones."},"connections":[{"id":"c2","name":"Inversión Agrícola","email":"contacto@example.invalid","licenses":["Microsoft 365 Empresa Básico"],"equipments":["09 - Teléfono","Equipo demo 28"],"line":"Sin teléfono","pin":"0009","status":"Activo"},{"id":"c3","name":"Reserva Porma","email":"contacto@example.invalid","licenses":["Microsoft 365 Empresa Básico"],"equipments":[],"line":"Sin teléfono","pin":"","status":"Activo"}]},{"id":"demo-usuarios-3","module":"usuarios","name":"Celeste Demo","group":"Activos","fields":{"rut":"DEMO-003","fechaNacimiento":"1990-01-01","cargo":"Administrador TI","departamento":"TI","responsable":"Alba Demo","telefono":"","email":"persona3@example.invalid","estado":"Activo","notas":"Registro ficticio para mostrar las asignaciones."},"connections":[{"id":"c4","name":"Inversiones Vicaper","email":"contacto@example.invalid","licenses":["Microsoft 365 Empresa Estándar","Adobe","Work Management"],"equipments":["Equipo demo 24","60 - Monitor","Equipo demo 25"],"line":"Sin teléfono","pin":"0060","status":"Activo"}]},{"id":"demo-usuarios-4","module":"usuarios","name":"Darío Demo","group":"Activos","fields":{"rut":"DEMO-004","fechaNacimiento":"1990-01-01","cargo":"Arquitecto","departamento":"Proyectos","responsable":"Alba Demo","telefono":"","email":"persona4@example.invalid","estado":"Activo","notas":"Registro ficticio para mostrar las asignaciones."},"connections":[{"id":"c5","name":"Inversiones Vicaper","email":"contacto@example.invalid","licenses":["Microsoft 365 Empresa Estándar","Work Management"],"equipments":["Equipo demo 23"],"line":"Sin teléfono","pin":"0021","status":"Activo"}]},{"id":"demo-usuarios-5","module":"usuarios","name":"Eva Demo","group":"Activos","fields":{"rut":"DEMO-005","fechaNacimiento":"1990-01-01","cargo":"Jefa RRHH","departamento":"RRHH","responsable":"Alba Demo","telefono":"","email":"persona5@example.invalid","estado":"Activo","notas":"Registro ficticio para mostrar las asignaciones."},"connections":[{"id":"c6","name":"Inversiones Vicaper","email":"contacto@example.invalid","licenses":["Microsoft 365 Empresa Estándar"],"equipments":["Equipo demo 27"],"line":"Sin teléfono","pin":"0044","status":"Activo"}]},{"id":"demo-usuarios-6","module":"usuarios","name":"Félix Demo","group":"Activos","fields":{"rut":"DEMO-006","fechaNacimiento":"1990-01-01","cargo":"Ejecutiva comercial","departamento":"Venta Remota","responsable":"Alba Demo","telefono":"","email":"persona6@example.invalid","estado":"Activo","notas":"Registro ficticio para mostrar las asignaciones."},"connections":[{"id":"c7","name":"Inversiones Vicaper","email":"contacto@example.invalid","licenses":["Microsoft 365 Empresa Básico"],"equipments":["Equipo demo 26","34 - Notebook"],"line":"Sin teléfono","pin":"0034","status":"Activo"}]},{"id":"demo-usuarios-7","module":"usuarios","name":"Gala Demo","group":"Activos","fields":{"rut":"DEMO-007","fechaNacimiento":"1990-01-01","cargo":"Analista contable","departamento":"Contabilidad","responsable":"Alba Demo","telefono":"","email":"persona7@example.invalid","estado":"Activo","notas":"Registro ficticio para mostrar las asignaciones."},"connections":[]},{"id":"demo-usuarios-8","module":"usuarios","name":"Hugo Demo","group":"Inactivos","fields":{"rut":"DEMO-008","fechaNacimiento":"1990-01-01","cargo":"Ex colaborador","departamento":"Operaciones","responsable":"Alba Demo","telefono":"","email":"persona8@example.invalid","estado":"Inactivo","notas":"Registro ficticio para mostrar las asignaciones."},"connections":[]},{"id":"demo-licencias-9","module":"licencias","name":"Microsoft 365 Empresa Estándar","group":"Asignadas","fields":{"area":"TI","asignadoA":"Alba Demo","costo":18.6,"cargo":"Ejecutiva comercial","estado":"Asignado"}},{"id":"demo-licencias-10","module":"licencias","name":"Adobe Creative Cloud","group":"Asignadas","fields":{"area":"Marketing","asignadoA":"Celeste Demo","costo":24.9,"cargo":"Administrador TI","estado":"Asignado"}},{"id":"demo-licencias-11","module":"licencias","name":"Respond.io","group":"Asignadas","fields":{"area":"Venta Remota","asignadoA":"Bruno Demo","costo":39,"cargo":"Ejecutiva comercial","estado":"Asignado"}},{"id":"demo-licencias-12","module":"licencias","name":"Work Management","group":"Asignadas","fields":{"area":"Proyectos","asignadoA":"Darío Demo","costo":12,"cargo":"Arquitecto","estado":"Asignado"}},{"id":"demo-licencias-13","module":"licencias","name":"Microsoft 365 Empresa Básico","group":"Disponibles","fields":{"area":"TI","asignadoA":"Alba Demo","costo":7.2,"cargo":"","estado":"Disponible"}},{"id":"demo-licencias-14","module":"licencias","name":"Canva Pro","group":"Disponibles","fields":{"area":"Marketing","asignadoA":"Alba Demo","costo":14.9,"cargo":"","estado":"Disponible"}},{"id":"demo-licencias-15","module":"licencias","name":"Defontana","group":"Asignadas","fields":{"area":"Contabilidad","asignadoA":"Gala Demo","costo":22,"cargo":"Analista contable","estado":"Asignado"}},{"id":"demo-licencias-16","module":"licencias","name":"CRM Monday","group":"Por revisar","fields":{"area":"Comercial","asignadoA":"Hugo Demo","costo":16,"cargo":"","estado":"Dado de baja"}},{"id":"demo-microsoft365-17","module":"microsoft365","name":"Cuenta de ejemplo 17","group":"Cuentas activas","fields":{"email":"cuenta17@example.invalid","contexto":"Cuenta de demostración","licencias":"Microsoft 365 Empresa Estándar","recursos":"Recursos de ejemplo","estado":"Activo","pin":""}},{"id":"demo-microsoft365-18","module":"microsoft365","name":"Cuenta de ejemplo 18","group":"Cuentas activas","fields":{"email":"cuenta18@example.invalid","contexto":"Cuenta de demostración","licencias":"Microsoft 365 Empresa Básico","recursos":"Recursos de ejemplo","estado":"Activo","pin":""}},{"id":"demo-microsoft365-19","module":"microsoft365","name":"Cuenta de ejemplo 19","group":"Cuentas activas","fields":{"email":"cuenta19@example.invalid","contexto":"Cuenta de demostración","licencias":"Microsoft 365 Empresa Estándar","recursos":"Recursos de ejemplo","estado":"Activo","pin":""}},{"id":"demo-microsoft365-20","module":"microsoft365","name":"Cuenta de ejemplo 20","group":"Cuentas activas","fields":{"email":"cuenta20@example.invalid","contexto":"Cuenta de demostración","licencias":"Microsoft 365 Empresa Básico","recursos":"Recursos de ejemplo","estado":"Activo","pin":""}},{"id":"demo-microsoft365-21","module":"microsoft365","name":"Cuenta de ejemplo 21","group":"Cuentas de respaldo","fields":{"email":"cuenta21@example.invalid","contexto":"Cuenta de demostración","licencias":"Sin licencia","recursos":"Recursos de ejemplo","estado":"Activo","pin":""}},{"id":"demo-microsoft365-22","module":"microsoft365","name":"Cuenta de ejemplo 22","group":"Cuentas inactivas","fields":{"email":"cuenta22@example.invalid","contexto":"Cuenta de demostración","licencias":"Sin licencia","recursos":"Recursos de ejemplo","estado":"Dar de Baja","pin":""}},{"id":"demo-equipos-23","module":"equipos","name":"Equipo demo 23","group":"En uso","fields":{"tipo":"PC - Torre","marca":"NC","modelo":"MS-7D46","serie":"DEMO-23","asignadoA":"Darío Demo","area":"Proyectos","estado":"En Uso","fechaCompra":"2024-01-15","verificado":true}},{"id":"demo-equipos-24","module":"equipos","name":"Equipo demo 24","group":"En uso","fields":{"tipo":"PC - Torre","marca":"Inversiones Vicaper","modelo":"MS-7D46","serie":"DEMO-24","asignadoA":"Celeste Demo","area":"TI","estado":"En Uso","fechaCompra":"2024-03-02","verificado":true}},{"id":"demo-equipos-25","module":"equipos","name":"Equipo demo 25","group":"En uso","fields":{"tipo":"Teléfono Móvil","marca":"Motorola","modelo":"Moto G34 5G","serie":"DEMO-25","asignadoA":"Celeste Demo","area":"TI","estado":"En Uso","fechaCompra":"2024-03-02","verificado":true}},{"id":"demo-equipos-26","module":"equipos","name":"Equipo demo 26","group":"En uso","fields":{"tipo":"Monitor","marca":"Caixun","modelo":"C22X3F","serie":"DEMO-26","asignadoA":"Félix Demo","area":"Venta Remota","estado":"En Uso","fechaCompra":"2023-08-12","verificado":true}},{"id":"demo-equipos-27","module":"equipos","name":"Equipo demo 27","group":"En uso","fields":{"tipo":"Notebook","marca":"Lenovo","modelo":"ThinkPad E14","serie":"DEMO-27","asignadoA":"Eva Demo","area":"RRHH","estado":"En Uso","fechaCompra":"2024-06-20","verificado":true}},{"id":"demo-equipos-28","module":"equipos","name":"Equipo demo 28","group":"En uso","fields":{"tipo":"Notebook","marca":"HP","modelo":"ProBook 440","serie":"DEMO-28","asignadoA":"Bruno Demo","area":"Venta Remota","estado":"En Uso","fechaCompra":"2023-11-01","verificado":true}},{"id":"demo-equipos-29","module":"equipos","name":"Equipo demo 29","group":"Disponibles","fields":{"tipo":"Monitor","marca":"Samsung","modelo":"S22F350","serie":"DEMO-29","asignadoA":"Alba Demo","area":"TI","estado":"Disponible","fechaCompra":"2021-05-10","verificado":false}},{"id":"demo-equipos-30","module":"equipos","name":"Equipo demo 30","group":"Mantenimiento","fields":{"tipo":"Notebook","marca":"Acer","modelo":"Aspire 5","serie":"DEMO-30","asignadoA":"Alba Demo","area":"TI","estado":"Mantenimiento","fechaCompra":"2022-03-18","verificado":false}},{"id":"demo-lineas-31","module":"lineas","name":"Línea demo 31","group":"Líneas activas","fields":{"proveedor":"WOM","asignadoA":"Alba Demo","tipoAsignacion":"Persona","marca":"Inversiones Vicaper","conectado":"Equipo demo","estadoLinea":"Activo","estadoAsignacion":"Asignado"}},{"id":"demo-lineas-32","module":"lineas","name":"Línea demo 32","group":"Líneas activas","fields":{"proveedor":"WOM","asignadoA":"Bruno Demo","tipoAsignacion":"Persona","marca":"Reserva Porma","conectado":"Equipo demo","estadoLinea":"Activo","estadoAsignacion":"Asignado"}},{"id":"demo-lineas-33","module":"lineas","name":"Línea demo 33","group":"Líneas activas","fields":{"proveedor":"WOM","asignadoA":"Bruno Demo","tipoAsignacion":"Persona","marca":"Inversión Agrícola","conectado":"Equipo demo","estadoLinea":"Activo","estadoAsignacion":"Asignado"}},{"id":"demo-lineas-34","module":"lineas","name":"Línea demo 34","group":"Líneas activas","fields":{"proveedor":"WOM","asignadoA":"Celeste Demo","tipoAsignacion":"Persona","marca":"Inversiones Vicaper","conectado":"Equipo demo","estadoLinea":"Activo","estadoAsignacion":"Asignado"}},{"id":"demo-lineas-35","module":"lineas","name":"Línea demo 35","group":"Líneas activas","fields":{"proveedor":"WOM","asignadoA":"Alba Demo","tipoAsignacion":"Marca / proyecto","marca":"Tierra Magna","conectado":"Equipo demo","estadoLinea":"Activo","estadoAsignacion":"Asignado"}},{"id":"demo-lineas-36","module":"lineas","name":"Línea demo 36","group":"Gestión de Oficina","fields":{"proveedor":"WOM","asignadoA":"Alba Demo","tipoAsignacion":"Marca / proyecto","marca":"Vicaper","conectado":"Equipo demo","estadoLinea":"Activo","estadoAsignacion":"Disponible"}},{"id":"demo-lineas-37","module":"lineas","name":"Línea demo 37","group":"Líneas inactivas","fields":{"proveedor":"WOM","asignadoA":"Alba Demo","tipoAsignacion":"Persona","marca":"Tierra Magna","conectado":"Equipo demo","estadoLinea":"Inactivo","estadoAsignacion":"Dado de baja"}},{"id":"demo-lineas-38","module":"lineas","name":"Línea demo 38","group":"Líneas inactivas","fields":{"proveedor":"Entel","asignadoA":"Alba Demo","tipoAsignacion":"Persona","marca":"Inversiones Vicaper","conectado":"Equipo demo","estadoLinea":"Inactivo","estadoAsignacion":"Bloqueado"}}],"updates":[{"id":"evento-demo-39","itemId":"demo-usuarios-1","creator":"Equipo Demo","action":"Adjuntó un documento","text":"Actualización de la ficha de ejemplo.","date":"2026-11-18T14:30:00","attachment":null},{"id":"evento-demo-40","itemId":"demo-equipos-25","creator":"Equipo Demo","action":"Actualizó un equipo","text":"Actualización de la ficha de ejemplo.","date":"2026-11-17T10:15:00"},{"id":"evento-demo-41","itemId":"demo-lineas-37","creator":"Equipo Demo","action":"Cambió el estado","text":"Actualización de la ficha de ejemplo.","date":"2026-11-15T17:05:00"},{"id":"evento-demo-42","itemId":"demo-licencias-13","creator":"Equipo Demo","action":"Detectó disponibilidad","text":"Actualización de la ficha de ejemplo.","date":"2026-11-14T09:40:00"},{"id":"evento-demo-43","itemId":"demo-usuarios-2","creator":"Equipo Demo","action":"Actualizó conexiones","text":"Actualización de la ficha de ejemplo.","date":"2026-11-12T12:20:00"},{"id":"evento-demo-44","itemId":"demo-microsoft365-22","creator":"Equipo Demo","action":"Solicitó revisión","text":"Actualización de la ficha de ejemplo.","date":"2026-11-10T16:10:00"}]};

  const $ = id => document.getElementById(id);
  const clone = value => JSON.parse(JSON.stringify(value));
  const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
  const icon = (name, cls="") => `<svg${cls ? ` class="${cls}"` : ""} viewBox="0 0 24 24" aria-hidden="true">${ICONS[name] || ICONS.home}</svg>`;
  const initials = value => String(value || "?").split(/\s+/).filter(Boolean).slice(0,2).map(x => x[0]).join("").toUpperCase();
  const money = value => value === "" || value == null ? "—" : new Intl.NumberFormat("es-CL",{style:"currency",currency:"USD",maximumFractionDigits:1}).format(Number(value));
  const formatDate = value => value ? new Intl.DateTimeFormat("es-CL",{day:"2-digit",month:"short",year:"numeric"}).format(new Date(value)) : "—";
  const relativeDate = value => {
    const days = Math.round((Date.now() - new Date(value).getTime()) / 86400000);
    if(days <= 0) return "Hoy"; if(days === 1) return "Ayer"; if(days < 30) return `Hace ${days} días`;
    return formatDate(value);
  };
  const statusTone = value => {
    const v = String(value || "").toLowerCase();
    if(/baja|inactivo|bloqueado|mantenimiento|detenido/.test(v)) return "red";
    if(/activo|asignado|disponible|en uso|verificado/.test(v)) return "green";
    if(/respond|meta|oficina/.test(v)) return "blue";
    return "orange";
  };
  const statusOf = item => item.fields.estado || item.fields.estadoLinea || item.fields.estadoAsignacion || "Sin estado";
  const normalize = value => String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase();
  const itemById = id => state.data.items.find(item => item.id === id);
  const itemsFor = module => state.data.items.filter(item => item.module === module);
  const updatesFor = id => state.data.updates.filter(update => update.itemId === id).sort((a,b) => new Date(b.date)-new Date(a.date));

  function loadData(){
    try { const saved = localStorage.getItem(STORAGE_KEY); return saved ? JSON.parse(saved) : clone(SEED); }
    catch { return clone(SEED); }
  }
  function persist(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(state.data)); }

  const state = {data:loadData(),view:"dashboard",search:"",status:"Todos",filters:{},filterOpen:false,expanded:new Set(),detailId:null};

  function hydrateIcons(root=document){
    root.querySelectorAll("[data-icon]").forEach(node => { node.innerHTML = icon(node.dataset.icon); });
  }

  function updateCounts(){
    Object.keys(MODULES).forEach(key => { const node = $(`nav-count-${key}`); if(node) node.textContent = itemsFor(key).length; });
  }

  function navigate(view){
    state.view = view; state.search = ""; state.status = "Todos"; state.filters = {};
    $("global-search").value = "";
    document.querySelectorAll(".nav-item").forEach(button => button.classList.toggle("active",button.dataset.view === view));
    $("dashboard-view").hidden = view !== "dashboard";
    $("table-view").hidden = !MODULES[view];
    $("activity-view").hidden = view !== "actividad";
    $("guide-view").hidden = view !== "guia";
    $("add-button").hidden = !MODULES[view];
    $("view-title").textContent = view === "dashboard" ? "Buenos días, Alexis" : view === "actividad" ? "Actividad de la oficina" : view === "guia" ? "Cómo funciona" : MODULES[view]?.title || "Gestión de Oficina";
    $("eyebrow").textContent = view === "guia" ? "GUÍA DE LA SOLUCIÓN" : view === "actividad" ? "TRAZABILIDAD" : "CONTROL DE GESTIÓN";
    $("global-search").placeholder = MODULES[view] ? `Buscar en ${MODULES[view].title}` : "Buscar en la oficina";
    closeMobileMenu(); render();
  }

  function render(){
    updateCounts();
    if(state.view === "dashboard") renderDashboard();
    else if(MODULES[state.view]) renderTable();
    else if(state.view === "actividad") renderActivity();
    else if(state.view === "guia") renderGuide();
    hydrateIcons();
  }

  function renderDashboard(){
    const counts = Object.fromEntries(Object.keys(MODULES).map(key => [key,itemsFor(key).length]));
    const activePeople = itemsFor("usuarios").filter(x => x.fields.estado === "Activo").length;
    const availableAssets = itemsFor("equipos").filter(x => x.fields.estado === "Disponible").length;
    const availableLicenses = itemsFor("licencias").filter(x => x.fields.estado === "Disponible").length;
    const lowLines = itemsFor("lineas").filter(x => /baja|bloqueado/i.test(x.fields.estadoAsignacion)).length;
    const statData = [
      ["usuarios","Personas activas",activePeople,"Fichas y responsables","#e5f5ed","#23705d"],
      ["licencias","Licencias",counts.licencias,"Asignaciones y costos","#fff3d8","#916714"],
      ["microsoft365","Microsoft 365",counts.microsoft365,"Cuentas administradas","#e8f3fb","#3379a8"],
      ["equipos","Equipos",counts.equipos,"Inventario conectado","#efebfb","#6956a5"],
      ["lineas","Líneas",counts.lineas,"Telefonía y canales","#fdebed","#b94a53"]
    ];
    const latest = [...state.data.updates].sort((a,b)=>new Date(b.date)-new Date(a.date)).slice(0,5);
    $("dashboard-view").innerHTML = `
      <section class="hero">
        <div class="hero-copy"><span class="hero-kicker"><span></span> DATOS CONECTADOS EN UN SOLO LUGAR</span><h2>Tu oficina, <em>finalmente clara.</em></h2><p>Personas, accesos, equipos y líneas unidos en una vista simple para saber qué existe, quién lo usa y qué necesita atención.</p><div class="hero-actions"><button class="primary-button" data-go="usuarios">Ver personas</button><button class="secondary-button" data-go="guia">Conocer la solución</button></div></div>
        <div class="hero-visual"><div class="orbit"><div class="orbit-line"></div><div class="orbit-core">${icon("database")}</div><span class="orbit-dot one">${icon("people")}</span><span class="orbit-dot two">${icon("key")}</span><span class="orbit-dot three">${icon("phone")}</span><span class="orbit-dot four">${icon("monitor")}</span></div></div>
      </section>
      <section class="stats-grid">${statData.map(([key,label,value,sub,bg,color])=>`<article class="stat-card" style="color:${color}"><span class="stat-icon" style="background:${bg}">${icon(MODULES[key].icon)}</span><strong>${value}</strong><span>${esc(label)} · ${esc(sub)}</span></article>`).join("")}</section>
      <section class="dashboard-grid">
        <article class="panel"><div class="panel-head"><div><h3>Tableros conectados</h3><p>La información operativa que antes estaba separada.</p></div><button class="text-button" data-go="guia">Ver cobertura</button></div><div class="module-list">${Object.entries(MODULES).map(([key,m])=>`<div class="module-row"><span class="module-symbol" style="background:${m.color}16;color:${m.color}">${icon(m.icon)}</span><div><strong>${m.title}</strong><small>${counts[key]} registros demostrativos</small></div><button data-go="${key}">Abrir</button></div>`).join("")}</div></article>
        <article class="panel"><div class="panel-head"><div><h3>Actividad reciente</h3><p>Cambios, notas y documentos en contexto.</p></div><button class="text-button" data-go="actividad">Ver todo</button></div><div class="activity-mini">${latest.map(update=>{const item=itemById(update.itemId);return `<div class="activity-mini-item"><span class="activity-avatar">${initials(update.creator)}</span><div><strong>${esc(item?.name||"Registro")}</strong><p>${esc(update.action)} · ${esc(update.text)}</p></div><time>${relativeDate(update.date)}</time></div>`}).join("")}</div></article>
      </section>
      <section class="insight-strip"><article class="insight-card insight-green"><span>${icon("monitor")}</span><div><strong>${availableAssets} equipo disponible</strong><small>Listo para ser reasignado</small></div></article><article class="insight-card insight-gold"><span>${icon("key")}</span><div><strong>${availableLicenses} licencias disponibles</strong><small>Evita compras innecesarias</small></div></article><article class="insight-card insight-red"><span>${icon("alert")}</span><div><strong>${lowLines} líneas requieren revisión</strong><small>Baja o bloqueo registrado</small></div></article></section>`;
  }

  function searchable(item){ return normalize([item.name,item.group,...Object.values(item.fields||{}),...(item.connections||[]).flatMap(c=>[c.name,c.email,...(c.licenses||[]),...(c.equipments||[])])].join(" ")); }
  function filteredItems(){
    return itemsFor(state.view).filter(item => {
      if(state.search && !searchable(item).includes(normalize(state.search))) return false;
      if(state.status !== "Todos" && statusOf(item) !== state.status) return false;
      return Object.entries(state.filters).every(([key,value]) => !value || value === "Todos" || String(item.fields[key] ?? "Sin información") === value);
    });
  }
  function filterOptions(key){ return [...new Set(itemsFor(state.view).map(item=>String(item.fields[key]||"Sin información")))].sort((a,b)=>a.localeCompare(b,"es")); }

  function renderTable(){
    const module = MODULES[state.view];
    const all = itemsFor(state.view); const filtered = filteredItems();
    const statuses = ["Todos",...new Set(all.map(statusOf))];
    $("status-chips").innerHTML = statuses.map(status=>`<button class="status-chip${state.status===status?" active":""}" type="button" data-status="${esc(status)}">${esc(status)}</button>`).join("");
    $("record-count").textContent = `${filtered.length} de ${all.length} registros`;
    $("active-filter-count").hidden = Object.values(state.filters).filter(v=>v&&v!=="Todos").length === 0;
    $("active-filter-count").textContent = Object.values(state.filters).filter(v=>v&&v!=="Todos").length;
    $("filter-panel").hidden = !state.filterOpen;
    $("filter-panel").innerHTML = `<div class="filter-panel-head"><strong>Filtros de ${module.title}</strong><button type="button" id="clear-filters">Limpiar filtros</button></div><div class="filter-grid">${module.columns.slice(0,6).map(([key,label])=>`<div class="filter-field"><label>${esc(label)}</label><select data-filter-key="${key}"><option>Todos</option>${filterOptions(key).map(value=>`<option${state.filters[key]===value?" selected":""}>${esc(value)}</option>`).join("")}</select></div>`).join("")}</div>`;
    $("data-head").innerHTML = `<tr><th>Nombre</th>${module.columns.map(([,label])=>`<th>${esc(label)}</th>`).join("")}<th></th></tr>`;
    const groups = [...new Set(filtered.map(item=>item.group||"Sin grupo"))];
    $("data-body").innerHTML = groups.map(group=>{
      const rows = filtered.filter(item=>(item.group||"Sin grupo")===group);
      return `<tr class="group-row"><td colspan="${module.columns.length+2}"><span class="group-line" style="--module-color:${module.color}"></span>${esc(group)}<span class="group-count">${rows.length} registros</span></td></tr>${rows.map(renderRow).join("")}`;
    }).join("");
    $("empty-state").hidden = filtered.length > 0;
    $("table-view").querySelector(".table-scroll").hidden = filtered.length === 0;
  }

  function renderRow(item){
    const module = MODULES[item.module]; const expanded = state.expanded.has(item.id); const hasConnections = item.module === "usuarios" && item.connections?.length;
    const main = `<tr class="record-row" data-id="${item.id}"><td class="name-cell">${hasConnections?`<button class="expand-button" type="button" data-expand="${item.id}" aria-label="${expanded?"Ocultar":"Mostrar"} conexiones">${expanded?"−":"+"}</button>`:""}<button class="name-button" type="button" data-open="${item.id}">${esc(item.name)}</button><small>${updatesFor(item.id).length?`${updatesFor(item.id).length} actualizaciones`:(hasConnections?`${item.connections.length} subelementos`:"Sin comentarios")}</small></td>${module.columns.map(([key])=>`<td>${renderCell(item,key)}</td>`).join("")}<td><div class="row-actions"><button class="row-button" type="button" data-open="${item.id}">Abrir</button><button class="row-button" type="button" data-edit="${item.id}">Editar</button></div></td></tr>`;
    if(!expanded || !hasConnections) return main;
    return main + item.connections.map(connection=>`<tr class="subitem-row"><td class="subitem-name"><strong>${esc(connection.name)}</strong><span class="cell-sub">Subelemento conectado</span></td><td><span class="cell-main">${esc(connection.email||"—")}</span></td><td><div class="tag-list">${(connection.licenses||[]).map(x=>`<span class="tag">${esc(x)}</span>`).join("")||"—"}</div></td><td><span class="cell-main">${esc(connection.line||"—")}</span></td><td><span class="cell-main">${esc((connection.equipments||[]).join(", ")||"—")}</span></td><td><span class="badge ${statusTone(connection.status)}">${esc(connection.status)}</span></td><td colspan="${Math.max(1,module.columns.length-5)}"></td></tr>`).join("");
  }

  function renderCell(item,key){
    const value = item.fields[key];
    if(key === "estado" || key.startsWith("estado")) return `<span class="badge ${statusTone(value)}">${esc(value||"Sin definir")}</span>`;
    if(key === "conectado" && value) return `<span class="badge blue">${esc(value)}</span>`;
    if(key === "asignadoA" || key === "responsable") return value && value !== "Sin asignar" ? `<span class="relation-chip"><span class="chip-avatar">${initials(value)}</span>${esc(value)}</span>` : `<span class="cell-sub">Sin asignar</span>`;
    if(key === "costo") return `<span class="cell-main">${money(value)}</span>`;
    if(key === "cargo" && item.module === "usuarios") return `<span class="cell-main">${esc(value||"—")}</span><span class="cell-sub">${esc(item.fields.email||"")}</span>`;
    if(key === "verificado") return value ? `<span class="badge green">Verificado</span>` : `<span class="badge orange">Pendiente</span>`;
    return `<span class="cell-main">${esc(value||"—")}</span>`;
  }

  function renderActivity(){
    const updates = [...state.data.updates].sort((a,b)=>new Date(b.date)-new Date(a.date)).filter(update=>!state.search||normalize([itemById(update.itemId)?.name,update.creator,update.action,update.text].join(" ")).includes(normalize(state.search)));
    $("activity-view").innerHTML = `<section class="activity-hero"><div><h2>Todo cambio deja huella</h2><p>Notas, documentos y movimientos reunidos para entender qué pasó y cuándo.</p></div><span class="hero-badge">${icon("clock")}</span></section><section class="activity-feed">${updates.map(update=>{const item=itemById(update.itemId);return `<article class="activity-item"><span class="activity-dot">${icon(update.attachment?"paperclip":"edit")}</span><div><strong>${esc(item?.name||"Registro eliminado")}<span class="activity-tag">${esc(MODULES[item?.module]?.title||"Sistema")}</span></strong><p>${esc(update.creator)} · ${esc(update.action)}<br>${esc(update.text)}</p></div><time>${relativeDate(update.date)}</time></article>`}).join("")||`<div class="empty-state"><h2>Sin actividad</h2><p>No hay resultados para tu búsqueda.</p></div>`}</section>`;
  }

  function renderGuide(){
    $("guide-view").innerHTML = `
      <section class="guide-hero"><div class="guide-hero-copy"><strong>GESTIÓN DE OFICINA</strong><h2>Una fuente confiable para administrar la oficina.</h2><p>La aplicación reemplaza tableros separados por un sistema conectado, visual y fácil de consultar.</p></div><span class="hero-badge">${icon("sparkles")}</span></section>
      <section class="guide-grid">
        <article class="guide-card"><h3>El problema que resuelve</h3><p>Evita buscar la misma información en varios tableros, planillas, correos o conversaciones.</p><div class="problem-list">
          <div class="problem-item"><span>${icon("alert")}</span><div><strong>Información dispersa</strong><small>Unifica personas, cuentas, licencias, equipos y líneas.</small></div></div>
          <div class="problem-item"><span>${icon("eye")}</span><div><strong>Poca visibilidad</strong><small>Muestra responsables, estados y recursos relacionados.</small></div></div>
          <div class="problem-item"><span>${icon("link")}</span><div><strong>Relaciones manuales</strong><small>Conecta la ficha de cada persona con todos sus accesos.</small></div></div>
        </div></article>
        <article class="guide-card"><h3>Qué cubre</h3><p>Los procesos administrativos y tecnológicos clave de la oficina.</p><div class="coverage-grid">${Object.entries(MODULES).map(([,m])=>`<div class="coverage-item"><span style="background:${m.color}15;color:${m.color}">${icon(m.icon)}</span><strong>${m.title}</strong><small>${m.singular === "persona" ? "Fichas, cargos y responsables" : m.singular === "licencia" ? "Costos, estados y asignación" : m.singular === "cuenta" ? "Cuentas, PIN y conexiones" : m.singular === "equipo" ? "Inventario, modelo y serie" : "Proveedor, canal y asignación"}</small></div>`).join("")}</div></article>
        <article class="guide-card full"><h3>Cómo funciona</h3><p>Cada registro se administra con el mismo recorrido simple.</p><div class="steps"><div class="step"><strong>Busca o filtra</strong><small>Encuentra cualquier persona o recurso por nombre, estado, marca o responsable.</small></div><div class="step"><strong>Abre la ficha</strong><small>Consulta todos los datos importantes y las conexiones relacionadas.</small></div><div class="step"><strong>Actualiza</strong><small>Edita estados, reasigna recursos y agrega comentarios o documentos.</small></div><div class="step"><strong>Revisa la trazabilidad</strong><small>La actividad reciente explica qué cambió y mantiene el contexto.</small></div></div></article>
        <article class="guide-card full"><h3>Prueba esta demo</h3><p>Todo funciona localmente en este computador. Puedes crear y editar registros, abrir fichas, adjuntar archivos pequeños, usar filtros y exportar un respaldo. Ningún cambio afecta el sistema real.</p><div class="demo-actions"><button class="primary-button" data-go="usuarios">Explorar personas</button><button class="secondary-button" data-go="lineas">Revisar líneas</button><button class="secondary-button" data-action="export">Exportar demo</button><button class="secondary-button" data-action="reset">Restablecer datos</button></div></article>
      </section>`;
  }

  function fieldOptions(type, options){
    if(Array.isArray(options)) return options;
    if(type === "person" || type === "assignment") return ["Sin asignar",...itemsFor("usuarios").map(item=>item.name),"ChatBot Tierra Magna","Bosque del Tabo","Grupo Tierras de Chile","Hacienda Las Tranqueras"];
    return [];
  }

  function openRecord(moduleKey,id=""){
    const module = MODULES[moduleKey]; const item = id ? itemById(id) : null;
    $("record-id").value = id; $("record-form").dataset.module = moduleKey;
    $("record-kicker").textContent = item ? `EDITAR ${module.singular.toUpperCase()}` : `NUEVA ${module.singular.toUpperCase()}`;
    $("record-title").textContent = item ? item.name : `Agregar ${module.singular}`;
    $("record-fields").innerHTML = module.fields.map(([key,label,type="text",options])=>renderField(key,label,type,options,item)).join("");
    $("record-error").hidden = true; $("record-dialog").showModal();
  }

  function renderField(key,label,type,options,item){
    const value = key === "name" ? item?.name || "" : item?.fields?.[key] ?? "";
    const full = type === "textarea" || key === "name" || key === "notas";
    if(type === "select" || type === "person" || type === "assignment"){
      const values = fieldOptions(type,options);
      if(value && !values.includes(String(value))) values.unshift(String(value));
      return `<div class="field${full?" full":""}"><label for="field-${key}">${esc(label)}</label><select id="field-${key}" name="${key}"${options===true?" required":""}><option value="">Sin definir</option>${values.map(option=>`<option value="${esc(option)}"${String(value)===String(option)?" selected":""}>${esc(option)}</option>`).join("")}</select></div>`;
    }
    if(type === "checkbox") return `<label class="checkbox-field"><input type="checkbox" name="${key}"${value?" checked":""}> ${esc(label)}</label>`;
    if(type === "textarea") return `<div class="field full"><label for="field-${key}">${esc(label)}</label><textarea id="field-${key}" name="${key}">${esc(value)}</textarea></div>`;
    return `<div class="field${full?" full":""}"><label for="field-${key}">${esc(label)}</label><input id="field-${key}" name="${key}" type="${type}" value="${esc(value)}"${options===true?" required":""}></div>`;
  }

  function saveRecord(event){
    event.preventDefault(); const form = event.target; const moduleKey = form.dataset.module; const module = MODULES[moduleKey]; const id = $("record-id").value; const existing = id ? itemById(id) : null; const data = new FormData(form); const name = String(data.get("name")||"").trim();
    if(!name){ $("record-error").textContent = "Escribe un nombre antes de guardar."; $("record-error").hidden = false; return; }
    const fields = {...(existing?.fields||{})};
    module.fields.forEach(([key,,type])=>{ if(key === "name") return; fields[key] = type === "checkbox" ? data.has(key) : String(data.get(key)||"").trim(); if(type === "number" && fields[key] !== "") fields[key] = Number(fields[key]); });
    if(existing){ existing.name = name; existing.fields = fields; }
    else { state.data.items.push({id:`${moduleKey}-${Date.now()}`,module:moduleKey,name,group:defaultGroup(moduleKey,fields),fields,connections:moduleKey==="usuarios"?[]:undefined}); }
    const record = existing || state.data.items[state.data.items.length-1];
    state.data.updates.push({id:`u-${Date.now()}`,itemId:record.id,creator:"Alexis Rodríguez",action:existing?"Editó el registro":"Creó el registro",text:existing?"La información de la ficha fue actualizada.":"Nuevo registro creado en la versión demo.",date:new Date().toISOString()});
    persist(); $("record-dialog").close(); render(); toast(existing?"Registro actualizado":"Registro creado",`${name} se guardó correctamente.`);
  }

  function defaultGroup(module,fields){
    if(module === "usuarios") return fields.estado === "Inactivo" ? "Inactivos" : "Activos";
    if(module === "licencias") return fields.estado === "Disponible" ? "Disponibles" : fields.estado?.toLowerCase().includes("baja") ? "Por revisar" : "Asignadas";
    if(module === "microsoft365") return fields.estado?.toLowerCase().includes("baja") ? "Cuentas inactivas" : "Cuentas activas";
    if(module === "equipos") return fields.estado || "Sin estado";
    if(module === "lineas") return fields.estadoLinea === "Inactivo" ? "Líneas inactivas" : "Líneas activas";
    return "General";
  }

  function openDetail(id){
    const item = itemById(id); if(!item) return; state.detailId = id; const module = MODULES[item.module];
    $("detail-kicker").textContent = item.module === "usuarios" ? "FICHA CONECTADA" : `DETALLE DE ${module.singular.toUpperCase()}`;
    $("detail-title").textContent = item.name; $("detail-subtitle").textContent = `${module.title} · ${item.group}`;
    $("detail-edit").dataset.edit = id;
    const visibleFields = module.fields.filter(([key])=>key!=="name" && item.fields[key] !== "" && item.fields[key] != null && key!=="notas");
    const notes = updatesFor(id);
    $("detail-content").innerHTML = `<div class="detail-summary">${visibleFields.map(([key,label,type])=>`<div class="summary-field"><small>${esc(label)}</small><strong>${type==="checkbox"?(item.fields[key]?"Sí":"No"):key==="costo"?money(item.fields[key]):esc(item.fields[key]||"—")}</strong></div>`).join("")}</div>${item.module==="usuarios"?renderConnections(item):""}${item.fields.notas?`<section class="detail-section"><div class="detail-section-head"><div><h3>Notas internas</h3><p>Información relevante de la ficha.</p></div></div><div class="note-card"><p>${esc(item.fields.notas)}</p></div></section>`:""}${renderNotes(item,notes)}`;
    hydrateIcons($("detail-dialog")); $("detail-dialog").showModal();
  }

  function renderConnections(person){
    const resources = state.data.items.filter(item=>item.module!=="usuarios" && normalize(item.fields.asignadoA) === normalize(person.name));
    return `<section class="detail-section"><div class="detail-section-head"><div><h3>Accesos y recursos relacionados</h3><p>Conexiones de la persona en todos los tableros.</p></div><span class="badge green">${person.connections.length + resources.length} conexiones</span></div><div class="connections">${person.connections.map(c=>`<article class="connection-card"><header><h4>${esc(c.name)}</h4><span class="badge ${statusTone(c.status)}">${esc(c.status)}</span></header><p>${esc(c.email||"Sin correo")} ${c.pin?`· PIN ${esc(c.pin)}`:""}</p><div class="tag-list">${[...(c.licenses||[]),...(c.equipments||[]),c.line].filter(Boolean).map(x=>`<span class="tag">${esc(x)}</span>`).join("")}</div></article>`).join("")}${resources.slice(0,4).map(r=>`<article class="connection-card"><header><h4>${esc(r.name)}</h4><span class="badge ${statusTone(statusOf(r))}">${esc(statusOf(r))}</span></header><p>${esc(MODULES[r.module].title)} vinculado directamente</p><div class="tag-list"><span class="tag">${esc(r.fields.tipo||r.fields.proveedor||r.fields.area||r.fields.marca||"Recurso")}</span></div></article>`).join("")}</div></section>`;
  }

  function renderNotes(item,notes){
    return `<section class="detail-section"><div class="detail-section-head"><div><h3>Comentarios y documentos</h3><p>Actualizaciones guardadas en esta ficha.</p></div></div><form class="note-composer" data-note-form="${item.id}"><textarea name="note" placeholder="Escribe una actualización, clave o comentario..."></textarea><div class="composer-row"><label class="file-label">${icon("paperclip")}<span data-file-label>Adjuntar archivo</span><input type="file" name="attachment" accept=".pdf,.doc,.docx,.xls,.xlsx,.png,.jpg,.jpeg,.txt"></label><button class="primary-button" type="submit">Guardar en la ficha</button></div></form><div class="notes-list">${notes.map(note=>`<article class="note-card"><header><strong>${esc(note.creator)} · ${esc(note.action)}</strong><time>${formatDate(note.date)}</time></header><p>${esc(note.text)}</p>${note.attachment?renderAttachment(note.attachment):""}</article>`).join("")||`<article class="note-card"><p>Aún no hay actualizaciones en esta ficha.</p></article>`}</div></section>`;
  }

  function renderAttachment(attachment){
    const content = `${icon("paperclip")} ${esc(attachment.name)} · ${Math.max(1,Math.round((attachment.size||0)/1024))} KB`;
    return attachment.dataUrl ? `<a class="attachment-chip" href="${attachment.dataUrl}" download="${esc(attachment.name)}">${content}</a>` : `<span class="attachment-chip">${content}</span>`;
  }

  async function saveNote(event){
    const form = event.target.closest("[data-note-form]"); if(!form) return; event.preventDefault(); const itemId = form.dataset.noteForm; const note = String(new FormData(form).get("note")||"").trim(); const file = form.elements.attachment.files[0];
    if(!note && !file){ toast("Falta información","Escribe un comentario o adjunta un archivo."); return; }
    if(file && file.size > 2*1024*1024){ toast("Archivo muy grande","En la demo se aceptan archivos de hasta 2 MB."); return; }
    const attachment = file ? {name:file.name,size:file.size,type:file.type,dataUrl:await fileToDataUrl(file)} : null;
    state.data.updates.push({id:`u-${Date.now()}`,itemId,creator:"Alexis Rodríguez",action:attachment?"Adjuntó un archivo":"Agregó un comentario",text:note||attachment.name,date:new Date().toISOString(),attachment});
    persist(); openDetail(itemId); toast("Actualización guardada","La ficha fue actualizada en la demo.");
  }
  const fileToDataUrl = file => new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(file);});

  function exportData(){
    const blob = new Blob([JSON.stringify({exportado:new Date().toISOString(),proyecto:"Gestión de Oficina Demo",...state.data},null,2)],{type:"application/json"}); const url=URL.createObjectURL(blob); const a=document.createElement("a");a.href=url;a.download=`gestion-oficina-demo-${new Date().toISOString().slice(0,10)}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);toast("Respaldo exportado","Se descargó una copia JSON de la demo.");
  }
  function resetDemo(){ state.data=clone(SEED);persist();state.expanded.clear();$("confirm-dialog").close();render();toast("Demo restablecida","Los datos originales volvieron a cargarse."); }
  function clearFilters(){ state.filters={};state.status="Todos";renderTable();hydrateIcons(); }
  function toast(title,message){
    const node=document.createElement("div");node.className="toast";node.innerHTML=`${icon("check")}<p><strong>${esc(title)}</strong>${esc(message)}</p>`;$("toast-region").append(node);setTimeout(()=>node.remove(),3400);
  }
  function openMobileMenu(){ $("sidebar").classList.add("open");$("mobile-overlay").classList.add("open"); }
  function closeMobileMenu(){ $("sidebar").classList.remove("open");$("mobile-overlay").classList.remove("open"); }

  document.addEventListener("click",event=>{
    const nav=event.target.closest("[data-view]"); if(nav){navigate(nav.dataset.view);return;}
    const go=event.target.closest("[data-go]"); if(go){navigate(go.dataset.go);return;}
    const close=event.target.closest("[data-close]"); if(close){$(close.dataset.close).close();return;}
    const open=event.target.closest("[data-open]"); if(open){openDetail(open.dataset.open);return;}
    const edit=event.target.closest("[data-edit]"); if(edit){const item=itemById(edit.dataset.edit);if($("detail-dialog").open)$("detail-dialog").close();openRecord(item.module,item.id);return;}
    const expand=event.target.closest("[data-expand]"); if(expand){state.expanded.has(expand.dataset.expand)?state.expanded.delete(expand.dataset.expand):state.expanded.add(expand.dataset.expand);renderTable();return;}
    const status=event.target.closest("[data-status]"); if(status){state.status=status.dataset.status;renderTable();return;}
    const action=event.target.closest("[data-action]"); if(action?.dataset.action==="export"){exportData();return;} if(action?.dataset.action==="reset"){$("confirm-dialog").showModal();return;}
    if(event.target.closest("#filter-toggle")){state.filterOpen=!state.filterOpen;renderTable();hydrateIcons();return;}
    if(event.target.closest("#clear-filters")||event.target.closest("#clear-empty-filters")){clearFilters();return;}
  });
  document.addEventListener("change",event=>{
    const filter=event.target.closest("[data-filter-key]"); if(filter){state.filters[filter.dataset.filterKey]=filter.value;renderTable();hydrateIcons();return;}
    if(event.target.matches("[data-note-form] input[type=file]")){const label=event.target.closest("label").querySelector("[data-file-label]");label.textContent=event.target.files[0]?.name||"Adjuntar archivo";}
  });
  document.addEventListener("submit",event=>{ if(event.target.id==="record-form")saveRecord(event); else if(event.target.closest("[data-note-form]"))saveNote(event); });
  $("global-search").addEventListener("input",event=>{state.search=event.target.value;if(MODULES[state.view])renderTable();else if(state.view==="actividad")renderActivity();hydrateIcons();});
  $("add-button").addEventListener("click",()=>openRecord(state.view));
  $("export-button").addEventListener("click",exportData);
  $("reset-demo").addEventListener("click",()=>$("confirm-dialog").showModal());
  $("confirm-reset").addEventListener("click",resetDemo);
  $("menu-button").addEventListener("click",openMobileMenu);$("mobile-close").addEventListener("click",closeMobileMenu);$("mobile-overlay").addEventListener("click",closeMobileMenu);
  document.addEventListener("keydown",event=>{if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==="k"){event.preventDefault();$("global-search").focus();}if(event.key==="Escape")closeMobileMenu();});
  document.querySelectorAll("dialog").forEach(dialog=>dialog.addEventListener("click",event=>{if(event.target===dialog)dialog.close();}));

  hydrateIcons(); render();
})();
