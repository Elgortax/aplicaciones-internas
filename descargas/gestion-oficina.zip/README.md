# Gestión de Oficina — versión demo

Demo interactiva y aislada de la aplicación **Gestión de Oficina** de Tierras de Chile.

## Abrir la demo

Haz doble clic en **ABRIR DEMO.bat** o abre `index.html` con el navegador.

La demo funciona completamente en el navegador y guarda los cambios en este computador. No necesita credenciales y no modifica los datos del sistema real.

## Qué problema resuelve

Antes, la información administrativa estaba repartida entre distintos tableros y fuentes. Eso dificultaba responder preguntas simples:

- ¿Qué equipos y líneas tiene asignados una persona?
- ¿Qué licencias están disponibles o deben darse de baja?
- ¿Qué cuenta de Microsoft 365 corresponde a cada equipo?
- ¿Quién es responsable de un recurso?
- ¿Qué cambió y cuándo?

Gestión de Oficina centraliza esa información y conserva las relaciones entre personas, accesos y recursos.

## Qué cubre

### Personas

Fichas de colaboradores con cargo, departamento, responsable, contacto y estado. Cada ficha muestra sus cuentas, licencias, equipos, líneas, comentarios y documentos relacionados.

### Licencias

Control de software, costos mensuales, disponibilidad, asignación y estados de baja.

### Microsoft 365

Cuentas administradas, contexto o empresa, PIN, licencias y recursos vinculados.

### Equipos

Inventario de computadores, monitores y teléfonos con tipo, marca, modelo, número de serie, usuario, área y verificación.

### Líneas

Números telefónicos con proveedor, responsable o marca, empresa, canal conectado (Respond, Meta u Oficina), estado de línea y estado de asignación.

### Actividad

Historial de comentarios, archivos y cambios para mantener la trazabilidad de cada ficha.

## Cómo funciona

1. Selecciona un módulo desde el menú lateral.
2. Busca por cualquier dato o combina filtros.
3. Abre una ficha para consultar la información y sus relaciones.
4. Usa **Editar** para actualizar el registro.
5. Usa **Agregar** para crear uno nuevo.
6. En una ficha puedes guardar comentarios y adjuntar archivos de hasta 2 MB.
7. El botón de descarga genera un respaldo JSON de la demo.
8. **Restablecer demo** recupera los datos demostrativos originales.

## Seguridad de esta versión

- Utiliza datos demostrativos y no contiene contraseñas reales.
- No se conecta a Firebase ni a monday.com.
- No realiza cambios en la aplicación publicada.
- Los cambios se almacenan solo en el navegador mediante `localStorage`.

## Archivos

- `index.html`: estructura de la aplicación.
- `styles.css`: diseño visual y adaptación para móvil.
- `app.js`: datos demostrativos y funcionamiento interactivo.
- `ABRIR DEMO.bat`: acceso directo para iniciar la demo.

