(function(global){
  'use strict';
  const ASSETS='archivos/evaluador-proyectos/vendor/';
  const CENTERS={arica:[-18.45,-69.8],tarapaca:[-20.2,-69.3],antofagasta:[-23.6,-69.4],atacama:[-27.3,-70.0],coquimbo:[-30.3,-71.0],valparaiso:[-32.9,-71.3],metropolitana:[-33.5,-70.7],ohiggins:[-34.4,-71.1],maule:[-35.5,-71.6],nuble:[-36.65,-72.1],biobio:[-37.25,-72.6],araucania:[-38.7,-72.5],losrios:[-40,-72.6],loslagos:[-41.7,-73.0],aysen:[-46,-73],magallanes:[-53.1,-71.0]};
  let api,main,clusters,mainLayers,currentLayer='normal',loading,lastSignature='',lastProjects=[],focusId=null,focusTimer,dialog,editorMap,editorLayers,editorMarker,editorContext=null,requestId=0,lastSearchAt=0,mobileLayoutApplied=false;
  const markers=new Map(),cache=new Map();
  const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toLowerCase();
  function communeKey(name){const key=norm(name).replace(/^comuna (de |del )?/,'').replace(/[^a-z0-9]/g,'');return ({llayllay:'llaillay',marchigue:'marchihue',aisen:'aysen',sanvicentedetaguatagua:'sanvicente',sanfranciscodemostazal:'mostazal',puertonatales:'natales',lacalera:'calera',rapanui:'isladepascua'})[key]||key;}
  function communes(region){return global.EvaluatorCommunes?.[region]||[];}
  function canonicalCommune(region,name){return name?communes(region).find(c=>communeKey(c)===communeKey(name))||'':'';}
  function coords(location){
    if(!location||typeof location.lat!=='number'||typeof location.lng!=='number')return null;
    return Number.isFinite(location.lat)&&Number.isFinite(location.lng)&&Math.abs(location.lat)<=90&&Math.abs(location.lng)<=180?[location.lat,location.lng]:null;
  }
  function el(tag,text,className){const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(className)n.className=className;return n;}
  function button(text,fn){const b=el('button',text);b.type='button';b.addEventListener('click',fn);return b;}
  function loadScript(src){return new Promise((resolve,reject)=>{const s=document.createElement('script');s.src=src;s.onload=resolve;s.onerror=()=>{s.remove();reject(new Error('No se pudo cargar el mapa. Revisa tu conexión y vuelve a intentarlo.'));};document.head.append(s);});}
  function loadCss(name){if(document.querySelector('link[data-geo-style="'+name+'"]'))return;const link=el('link');link.rel='stylesheet';link.href=ASSETS+name;link.dataset.geoStyle=name;document.head.append(link);}
  async function load(){
    if(global.L&&global.L.markerClusterGroup)return global.L;
    if(!loading)loading=(async()=>{loadCss('leaflet.css');loadCss('MarkerCluster.css');loadCss('MarkerCluster.Default.css');if(!global.L)await loadScript(ASSETS+'leaflet.js');if(!global.L.markerClusterGroup)await loadScript(ASSETS+'leaflet.markercluster.js');return global.L;})().catch(e=>{loading=null;throw e;});
    return loading;
  }
  function satelliteLayer(){
    const images=new Map();
    function fetchTile(z,x,y){
      const url='https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/'+z+'/'+y+'/'+x+'?blankTile=false';
      if(!images.has(url)){
        const promise=new Promise((resolve,reject)=>{const img=new Image();img.crossOrigin='anonymous';img.onload=()=>resolve(img);img.onerror=()=>reject(new Error('Imagen no disponible'));img.src=url;});
        images.set(url,promise);if(images.size>192)images.delete(images.keys().next().value);
      }
      return images.get(url);
    }
    const Imagery=L.GridLayer.extend({sourceZoomAt:function(point){
      if(!this._map||!this.getContainer())return null;const z=this._tileZoom,p=this._map.project(point,z);const key=z+'/'+Math.floor(p.x/256)+'/'+Math.floor(p.y/256);
      const tile=this.getContainer().querySelector('canvas[data-geo-tile-key="'+key+'"][data-source-zoom]');return tile?Number(tile.dataset.sourceZoom):null;
    },createTile:function(c,done){
      const tile=el('canvas');tile.width=256;tile.height=256;tile.dataset.geoSatellite='';tile.dataset.geoTileKey=c.z+'/'+c.x+'/'+c.y;
      // Missing high-resolution tiles must use the correct quadrant of their
      // nearest available parent, instead of Esri's gray "no data" image.
      (async()=>{for(let z=c.z;z>=Math.max(0,c.z-6);z--){
        const factor=2**(c.z-z),x=Math.floor(c.x/factor),y=Math.floor(c.y/factor);
        try{const img=await fetchTile(z,x,y);const size=256/factor;tile.getContext('2d').drawImage(img,(c.x-x*factor)*size,(c.y-y*factor)*size,size,size,0,0,256,256);tile.dataset.sourceZoom=String(z);done(null,tile);return;}catch(e){if(z===Math.max(0,c.z-6))done(e,tile);}
      }})();return tile;
    }});
    return new Imagery({maxZoom:19,tileSize:256,noWrap:true,attribution:'Imágenes &copy; <a href="https://www.arcgis.com/home/item.html?id=10df2279f9684e4a9f6a7f08febac2a9" target="_blank" rel="noopener">Esri</a>, Vantor, Earthstar Geographics y GIS User Community'});
  }
  function layers(map){
    const normal=L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,maxNativeZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>'});
    const imagery=satelliteLayer(),satellite=global.EvaluatorSatellite?global.EvaluatorSatellite.create(map,imagery):imagery;
    L.control.scale({imperial:false,position:'bottomleft'}).addTo(map);
    [normal,imagery].forEach(layer=>{layer.on('tileerror',()=>{if(map===main)document.getElementById('geoMapMessage').textContent='No se pudieron cargar algunas imágenes. Revisa la conexión o cambia de vista; tus puntos siguen guardados.';});});
    return {normal,satellite};
  }
  function changeLayer(map,collection,key){Object.values(collection).forEach(l=>{if(map.hasLayer(l))map.removeLayer(l);});collection[key].addTo(map);}
  function icon(color){const safe=/^#[\da-f]{3,8}$/i.test(color||'')?color:'#275d7b';return L.divIcon({className:'geo-pin-wrap',html:'<span class="geo-pin" style="--geo-color:'+safe+'"></span>',iconSize:[28,35],iconAnchor:[14,31],popupAnchor:[0,-28]});}
  function fit(){
    if(!main)return;
    const points=lastProjects.map(p=>coords(p.ubicacion)).filter(Boolean);
    if(points.length)main.fitBounds(L.latLngBounds(points),{padding:[45,45],maxZoom:15,animate:false});
    else {const region=document.getElementById('mapFilterRegion').value;const c=CENTERS[region];if(c)main.setView(c,8);else main.fitBounds([[-55.9,-76.5],[-17.4,-66]],{padding:[15,15]});}
  }
  function focus(id){
    focusId=id;clearTimeout(focusTimer);if(!main)return;
    // Wait for markercluster to finish the preceding fit/filter animation.
    focusTimer=setTimeout(()=>{if(focusId!==id)return;const marker=markers.get(id);if(!marker)return;main.stop();clusters.zoomToShowLayer(marker,()=>{if(focusId===id){marker.openPopup();focusId=null;}});},350);
  }
  function popup(p){
    const d=api.describe(p),box=el('div',undefined,'geo-popup');box.append(el('strong',p.nombre||'Sin nombre'),el('p',d.status),el('p',p.direccion||p.ubicacion?.label||[p.comuna,p.region].filter(Boolean).join(', ')));
    const dl=el('dl');[['Lotes',d.lotes],['Inventario',d.inventario],['Venta estimada',d.venta],['Utilidad',d.utilidad]].forEach(([key,value])=>{const cell=el('div');cell.append(el('dt',key),el('dd',value));dl.append(cell);});box.append(dl,button('Abrir proyecto',()=>api.onOpen(p.id)));return box;
  }
  function setup(config){
    api=config;
    const region=document.getElementById('mapFilterRegion'),comuna=document.getElementById('mapFilterComuna');
    if(region.dataset.geoBound)return;region.dataset.geoBound='1';
    api.regions.forEach(r=>{const o=el('option',r.nombre);o.value=r.id;region.append(o);});
    region.addEventListener('change',()=>{comuna.value='';api.onFilter(region.value);});
    comuna.addEventListener('change',()=>api.onFilter(region.value));
    document.getElementById('geoFit').addEventListener('click',fit);
    document.getElementById('geoExpand').addEventListener('click',()=>{const panel=document.getElementById('geoMapPanel'),b=document.getElementById('geoExpand');const expanded=panel.classList.toggle('geo-expanded');b.textContent=expanded?'Reducir mapa':'Ampliar mapa';b.setAttribute('aria-expanded',String(expanded));setTimeout(()=>main?.invalidateSize(),0);});
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&document.getElementById('geoMapPanel').classList.contains('geo-expanded'))document.getElementById('geoExpand').click();});
    document.querySelectorAll('[data-geo-layer]').forEach(b=>b.addEventListener('click',()=>{currentLayer=b.dataset.geoLayer;document.querySelectorAll('[data-geo-layer]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));if(main)changeLayer(main,mainLayers,currentLayer);}));
    matchMedia('(max-width:800px)').addEventListener('change',mobileLayout);
  }
  function mobileLayout(){
    if(!matchMedia('(max-width:800px)').matches){mobileLayoutApplied=false;return;}
    if(mobileLayoutApplied||!document.getElementById('viewMap').classList.contains('active'))return;
    mobileLayoutApplied=true;
    if(!document.getElementById('appRoot').classList.contains('sidebar-collapsed'))document.getElementById('btnSidebarCollapse').click();
  }
  function filter(projects,region){
    const regionSelect=document.getElementById('mapFilterRegion'),communeSelect=document.getElementById('mapFilterComuna');
    const changed=regionSelect.value!==(region||'');regionSelect.value=region||'';
    const current=changed?'':communeSelect.value;
    const subset=projects.filter(p=>!region||p.region===region);
    const names=new Map();(region?communes(region):Object.values(global.EvaluatorCommunes||{}).flat()).forEach(name=>names.set(norm(name),name));
    (api?.getProjects()||projects).filter(p=>!region||p.region===region).forEach(p=>{const name=canonicalCommune(p.region,p.comuna)||(p.comuna||'').trim();if(name)names.set(norm(name),name);});
    communeSelect.replaceChildren();const all=el('option','Todas las comunas');all.value='';communeSelect.append(all);
    [...names].sort((a,b)=>a[1].localeCompare(b[1],'es')).forEach(([key,label])=>{const o=el('option',label);o.value=key;communeSelect.append(o);});
    communeSelect.value=names.has(current)?current:'';
    return subset.filter(p=>!communeSelect.value||communeKey(p.comuna)===communeKey(communeSelect.value));
  }
  async function render(projects,region){
    mobileLayout();
    lastProjects=projects;
    const placed=projects.filter(p=>coords(p.ubicacion)),pending=projects.filter(p=>!coords(p.ubicacion));
    document.getElementById('geoMapSummary').textContent=projects.length+' proyectos · '+placed.length+' con ubicación · '+pending.length+' pendientes de ubicar';
    const details=document.getElementById('geoPending');details.hidden=!pending.length;
    document.getElementById('geoPendingSummary').textContent=pending.length+' proyectos sin ubicación exacta · incluidos en los indicadores';
    const pendingList=document.getElementById('geoPendingList');pendingList.replaceChildren();
    pending.forEach(p=>{const b=button((p.nombre||'Sin nombre')+' · '+(api.canEdit()?'Ubicar':'Ver proyecto'),()=>api.canEdit()?openEditor(p,{save:()=>api.onSave(p),canEdit:api.canEdit}):api.onOpen(p.id));pendingList.append(b);});
    const signature=JSON.stringify([region,document.getElementById('mapFilterComuna').value,projects.map(p=>[p.id,coords(p.ubicacion)])]);
    const message=document.getElementById('geoMapMessage');message.textContent=!projects.length?'No hay proyectos con estos filtros.':!placed.length?'Agrega la dirección o marca la ubicación de un proyecto para verlo en el mapa.':'';
    try{
      await load();
      if(lastProjects!==projects)return;
      if(!main){main=L.map('projectGeoMap',{maxZoom:19,minZoom:3,scrollWheelZoom:true}).setView([-35.5,-71.5],5);mainLayers=layers(main);changeLayer(main,mainLayers,currentLayer);clusters=L.markerClusterGroup({showCoverageOnHover:false,maxClusterRadius:45,spiderfyOnMaxZoom:true}).addTo(main);new ResizeObserver(()=>main.invalidateSize({pan:false})).observe(document.getElementById('projectGeoMap'));}
      clusters.clearLayers();markers.clear();
      placed.forEach(p=>{const d=api.describe(p);const marker=L.marker(coords(p.ubicacion),{icon:icon(d.color),title:p.nombre||'Proyecto',alt:p.nombre||'Proyecto'});marker.bindPopup(popup(p));marker.bindTooltip(()=>el('span',p.nombre||'Proyecto'),{direction:'top',offset:[0,-24]});markers.set(p.id,marker);clusters.addLayer(marker);});
      main.invalidateSize({pan:false});if(signature!==lastSignature){lastSignature=signature;fit();}if(focusId)focus(focusId);
    }catch(e){message.replaceChildren(el('span',e.message+' '),button('Reintentar',()=>render(lastProjects,document.getElementById('mapFilterRegion').value)));}
  }
  function refreshProject(root,p){
    const box=root.querySelector('[data-geo-editor]');if(!box)return;
    const address=box.querySelector('[data-geo-address]');if(document.activeElement!==address)address.value=p.direccion||'';
    const point=coords(p.ubicacion);box.querySelector('[data-geo-location-status]').textContent=point?(p.ubicacion.precision==='street'?'Calle ubicada (punto aproximado). Ajusta el punto para señalar el acceso al predio.':'Ubicación guardada. Puedes verla o ajustar el punto para señalar el acceso al predio.'):'Sin ubicación exacta. Busca la dirección o marca el punto en el mapa.';
    box.querySelector('[data-geo-view]').disabled=!point;box.querySelector('[data-geo-remove]').disabled=!point||!box._geo.canEdit();
  }
  function bindProject(root,p,options){
    const comuna=root.querySelector('[data-f="comuna"]');if(!comuna)return;
    const row=el('tr'),cell=el('td');cell.colSpan=2;
    const box=el('section',undefined,'geo-editor');box.dataset.geoEditor='';box._geo=options;
    const label=el('label','Dirección o referencia del predio');const input=el('input');input.type='text';input.placeholder='Calle y número, camino, kilómetro o sector';input.value=p.direccion||'';input.dataset.geoAddress='';input.maxLength=400;input.disabled=!options.canEdit();label.append(input);
    input.addEventListener('input',()=>{if(!options.canEdit())return;p.direccion=input.value;p.ubicacion=null;options.save();refreshProject(root,p);});
    const actions=el('div',undefined,'geo-editor-actions');
    const locate=button('Buscar dirección / ubicar',()=>openEditor(p,{...options,save:()=>{options.save();refreshProject(root,p);const reg=root.querySelector('[data-f="region"]');const com=root.querySelector('[data-f="comuna"]');reg.value=p.region||'';com.value=p.comuna||'';return options.sync?.();}}));locate.disabled=!options.canEdit();
    const view=button('Ver en mapa',options.showMap);view.dataset.geoView='';
    const remove=button('Quitar punto',()=>{if(!options.canEdit())return;p.ubicacion=null;options.save();refreshProject(root,p);});remove.dataset.geoRemove='';
    actions.append(locate,view,remove);const status=el('p',undefined,'geo-location-status');status.dataset.geoLocationStatus='';status.setAttribute('aria-live','polite');box.append(label,actions,status);cell.append(box);row.append(cell);comuna.closest('tr').after(row);refreshProject(root,p);
  }
  function makeDialog(){
    dialog=el('dialog',undefined,'geo-dialog');dialog.setAttribute('aria-labelledby','geoDialogTitle');
    dialog.innerHTML=`<div class="geo-dialog-header"><div><h2 id="geoDialogTitle">Ubicar proyecto</h2><p data-geo-project-name></p></div><button type="button" data-geo-close aria-label="Cerrar ubicación">Cerrar</button></div>
      <div class="geo-dialog-body"><div class="geo-region-row"><label>Región del proyecto<select data-geo-region><option value="">Selecciona la región</option></select></label><label>Comuna<select data-geo-commune aria-describedby="geoCommuneHelp" disabled><option value="">Primero selecciona una región</option></select></label></div><p class="geo-help" id="geoCommuneHelp" data-geo-commune-help></p>
      <div class="geo-search-row"><label>Dirección o referencia<input data-geo-query type="text" maxlength="400" placeholder="Calle y número, camino o sector"></label><button type="button" class="geo-primary" data-geo-search>Buscar en el mapa</button></div>
      <p class="geo-help">Escribe la dirección y presiona Buscar en el mapa o Enter. Usaremos la comuna para ubicarla. Después revisa el punto y guarda.</p>
      <p data-geo-status role="status" aria-live="polite"></p><details class="geo-search-options" data-geo-options hidden><summary data-geo-options-summary>Ver resultados</summary><div data-geo-results></div></details>
      <div class="geo-search-alternative" data-geo-alternative hidden><a data-geo-google target="_blank" rel="noopener noreferrer">Buscar esta dirección en Google Maps ↗</a><p class="geo-help">Se abre otra pestaña para consultar la dirección. La búsqueda externa no guarda ni mueve el punto de este proyecto.</p></div>
      <div class="geo-layer-switch" role="group" aria-label="Vista para ubicar"><button type="button" data-geo-editor-layer="normal" aria-pressed="true">Normal</button><button type="button" data-geo-editor-layer="satellite" aria-pressed="false">Satelital</button></div>
      <div class="geo-editor-map" data-geo-editor-map aria-label="Selecciona la ubicación del predio"></div>
      <p class="geo-help">Puedes arrastrar el punto o hacer clic en el acceso al predio para ajustar su ubicación. Si la búsqueda solo encuentra la calle, te lo indicaremos.</p>
      <details class="geo-manual-coordinates" data-geo-advanced><summary>Opcional: ingresar coordenadas</summary><div class="geo-coordinate-row"><label>Latitud<input data-geo-lat type="number" step="any" min="-90" max="90" placeholder="Ej.: -37.470746"></label><label>Longitud<input data-geo-lng type="number" step="any" min="-180" max="180" placeholder="Ej.: -72.351686"></label><button type="button" data-geo-coordinates>Usar coordenadas</button></div></details>
      <p class="geo-help">La región y la comuna se guardan con el proyecto y se usan en los filtros e indicadores.</p>
      <p class="geo-help">Búsqueda: <a href="https://photon.komoot.io/" target="_blank" rel="noopener">Photon</a> · Datos © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>.</p></div>
      <div class="geo-dialog-footer"><p>La ubicación se guarda con el proyecto y se sincroniza con tu espacio.</p><button type="button" data-geo-cancel>Cancelar</button><button type="button" class="geo-primary" data-geo-save disabled>Guardar ubicación</button></div>`;
    document.body.append(dialog);
    const q=s=>dialog.querySelector(s);
    q('[data-geo-close]').onclick=q('[data-geo-cancel]').onclick=()=>dialog.close();
    dialog.addEventListener('close',()=>{requestId++;if(editorContext)editorContext.controller?.abort();editorContext=null;if(editorMap){editorMap.remove();editorMap=null;editorMarker=null;}q('[data-geo-results]').replaceChildren();});
    q('[data-geo-search]').onclick=search;
    q('[data-geo-query]').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();search();}});
    q('[data-geo-query]').addEventListener('input',()=>resetSearch(true,'Presiona Buscar en el mapa o Enter para ubicar esta dirección.'));
    q('[data-geo-coordinates]').onclick=()=>{const latText=q('[data-geo-lat]').value,lngText=q('[data-geo-lng]').value;const point={lat:Number(latText),lng:Number(lngText)};if(!latText.trim()||!lngText.trim()||!coords(point)){q('[data-geo-status]').textContent='Ingresa una latitud entre −90 y 90 y una longitud entre −180 y 180.';return;}setPoint(point,'manual');if(editorMap)editorMap.setView(coords(point),16);};
    ['[data-geo-lat]','[data-geo-lng]'].forEach(selector=>q(selector).addEventListener('input',()=>{q('[data-geo-save]').disabled=true;q('[data-geo-status]').textContent='Presiona Usar coordenadas para confirmar el nuevo punto.';}));
    q('[data-geo-save]').onclick=async()=>{
      const ctx=editorContext;if(!ctx||!ctx.options.canEdit()||!coords(ctx.point))return;
      if(api&&!api.getProjects().includes(ctx.project)){q('[data-geo-status]').textContent='El proyecto cambió o ya no está disponible. Cierra y vuelve a abrirlo.';return;}
      const region=q('[data-geo-region]').value,commune=canonicalCommune(region,q('[data-geo-commune]').value);
      if(!region||!commune){q('[data-geo-status]').textContent='Completa la región y la comuna para que el proyecto aparezca en los filtros correctos.';return;}
      ctx.project.direccion=q('[data-geo-query]').value.trim();ctx.project.region=region;ctx.project.comuna=commune;
      ctx.project.ubicacion={...ctx.point,label:ctx.label||ctx.project.direccion,source:ctx.source||'manual',precision:ctx.precision||'approximate',updatedAt:new Date().toISOString()};
      q('[data-geo-save]').disabled=true;q('[data-geo-status]').textContent='Guardando ubicación…';
      try{await ctx.options.save();if(ctx===editorContext)dialog.close();}catch(e){if(ctx===editorContext){q('[data-geo-status]').textContent='La ubicación quedó en este navegador, pero no pudo sincronizarse. Revisa la conexión y vuelve a guardar.';q('[data-geo-save]').disabled=false;}}
    };
    q('[data-geo-region]').addEventListener('change',()=>{fillCommunes(q('[data-geo-region]').value);resetSearch(editorContext?.source==='photon','Selecciona una comuna de esta región y busca la dirección.');if(editorMap&&!editorContext?.point){const c=CENTERS[q('[data-geo-region]').value];if(c)editorMap.setView(c,9);}});
    q('[data-geo-commune]').addEventListener('change',()=>resetSearch(editorContext?.source==='photon','Comuna actualizada. Presiona Buscar en el mapa para usarla en la búsqueda.'));
    dialog.querySelectorAll('[data-geo-editor-layer]').forEach(b=>b.onclick=()=>{dialog.querySelectorAll('[data-geo-editor-layer]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));if(editorMap)changeLayer(editorMap,editorLayers,b.dataset.geoEditorLayer);});
  }
  function fillCommunes(region,current='',keepLegacy=false){
    const select=dialog.querySelector('[data-geo-commune]'),names=communes(region),selected=canonicalCommune(region,current);
    select.replaceChildren();const placeholder=el('option',!region?'Primero selecciona una región':'Selecciona la comuna');placeholder.value='';select.append(placeholder);select.disabled=!names.length;
    names.forEach(name=>{const option=el('option',name);option.value=name;select.append(option);});
    if(current&&!selected&&keepLegacy){const legacy=el('option',current+' (comuna guardada; revisar)');legacy.value=current;legacy.disabled=true;select.append(legacy);}
    select.value=selected||(keepLegacy?current:'');
    dialog.querySelector('[data-geo-commune-help]').textContent=names.length?names.length+' comunas disponibles en esta región.':region?'No se pudo cargar la lista de comunas. Recarga la página.':'Selecciona una región para ver todas sus comunas.';
  }
  function updateExternalSearch(){
    if(!dialog)return;const q=s=>dialog.querySelector(s),query=q('[data-geo-query]').value.trim();
    const area=q('[data-geo-commune]').value,region=api?.regions.find(r=>r.id===q('[data-geo-region]').value)?.nombre;
    const terms=[query];[area,region,'Chile'].forEach(v=>{if(v&&!norm(query).includes(norm(v)))terms.push(v);});
    const url=new URL('https://www.google.com/maps/search/');url.searchParams.set('api','1');url.searchParams.set('query',terms.join(', '));
    q('[data-geo-google]').href=url.href;q('[data-geo-alternative]').hidden=query.length<3;
  }
  function resetSearch(clearPoint,message){
    requestId++;editorContext?.controller?.abort();if(!dialog)return;
    const q=s=>dialog.querySelector(s);q('[data-geo-search]').disabled=false;q('[data-geo-results]').replaceChildren();q('[data-geo-options]').hidden=true;
    if(clearPoint&&editorContext){editorContext.point=null;editorContext.label='';editorContext.precision=null;if(editorMarker){editorMarker.remove();editorMarker=null;}q('[data-geo-lat]').value='';q('[data-geo-lng]').value='';q('[data-geo-save]').disabled=true;}
    if(message)q('[data-geo-status]').textContent=message;updateExternalSearch();
  }
  function setPoint(point,source,label,precision){
    if(!editorContext||!coords(point))return;
    if(source==='manual')resetSearch(false);
    editorContext.point={lat:point.lat,lng:point.lng};editorContext.source=source;editorContext.label=label||'';editorContext.precision=precision||(source==='manual'?'manual':'approximate');
    dialog.querySelector('[data-geo-lat]').value=point.lat.toFixed(6);dialog.querySelector('[data-geo-lng]').value=point.lng.toFixed(6);dialog.querySelector('[data-geo-save]').disabled=false;
    dialog.querySelector('[data-geo-status]').textContent=source==='photon'?(precision==='street'?'Calle ubicada. El punto es aproximado: ajústalo hasta la entrada antes de guardar.':'Resultado encontrado. Confirma o ajusta el punto antes de guardar.'):'Punto seleccionado. Confirma la región y la comuna y guarda la ubicación.';
    if(editorMap){if(editorMarker)editorMarker.setLatLng(coords(point));else {editorMarker=L.marker(coords(point),{draggable:true,icon:icon('#276a86'),title:'Arrastra para ajustar la ubicación'}).addTo(editorMap);editorMarker.on('dragend',()=>{const ll=editorMarker.getLatLng();setPoint({lat:ll.lat,lng:ll.lng},'manual');});}}
  }
  async function openEditor(project,options){
    if(!options.canEdit())return;
    if(!dialog)makeDialog();if(dialog.open)dialog.close();
    const q=s=>dialog.querySelector(s);const ctx=editorContext={project,options,point:coords(project.ubicacion)?{lat:project.ubicacion.lat,lng:project.ubicacion.lng}:null,source:project.ubicacion?.source,label:project.ubicacion?.label,precision:project.ubicacion?.precision};
    q('[data-geo-project-name]').textContent=project.nombre||'Proyecto';q('[data-geo-query]').value=project.direccion||'';q('[data-geo-results]').replaceChildren();
    const reg=q('[data-geo-region]');reg.replaceChildren();const empty=el('option','Selecciona la región');empty.value='';reg.append(empty);(api?.regions||[]).forEach(r=>{const o=el('option',r.nombre);o.value=r.id;reg.append(o);});reg.value=project.region||'';fillCommunes(reg.value,project.comuna||'',true);updateExternalSearch();
    q('[data-geo-lat]').value=ctx.point?.lat??'';q('[data-geo-lng]').value=ctx.point?.lng??'';q('[data-geo-save]').disabled=!ctx.point;q('[data-geo-search]').disabled=false;
    q('[data-geo-options]').hidden=true;q('[data-geo-options]').open=false;q('[data-geo-advanced]').open=false;
    q('[data-geo-status]').textContent='No necesitas coordenadas: busca tu dirección para ver el punto en el mapa.';dialog.showModal();q('[data-geo-query]').focus();
    try{await load();if(editorContext!==ctx||!dialog.open)return;editorMap=L.map(q('[data-geo-editor-map]'),{maxZoom:19,minZoom:3}).setView(coords(ctx.point)||CENTERS[project.region]||[-35.5,-71.5],ctx.point?16:project.region?9:5);editorLayers=layers(editorMap);changeLayer(editorMap,editorLayers,'normal');dialog.querySelectorAll('[data-geo-editor-layer]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.geoEditorLayer==='normal')));editorMap.on('click',e=>setPoint({lat:e.latlng.lat,lng:e.latlng.lng},'manual'));if(ctx.point)setPoint(ctx.point,ctx.source||'manual',ctx.label,ctx.precision);setTimeout(()=>editorMap?.invalidateSize(),50);
    }catch(e){if(editorContext===ctx)q('[data-geo-status]').textContent=e.message+' También puedes ingresar coordenadas.';}
  }
  function regionFor(state){return state?(api?.regions||[]).find(r=>norm(state).includes(norm(r.nombre))||norm(r.nombre).includes(norm(state))):null;}
  const streetKey=s=>norm(s).replace(/^(calle|avenida|av\.?|pasaje|pje\.?)\s+/,'').replace(/[.,]/g,'').replace(/\s+/g,' ');
  function addressParts(query,commune){
    let address=query.split(',')[0].trim();
    if(commune&&norm(address).endsWith(' '+norm(commune)))address=address.slice(0,-commune.length).trim();
    // Keep numbers that are part of a road name or kilometre reference intact.
    const numbered=!/\bkm\b|kil[oó]metr|^(?:ruta|carretera)\s+[a-z]?[-\s]?\d+$/i.test(address)&&address.match(/^(.+?)\s+(?:n[°ºo.]?\s*|#\s*)?(\d+[a-z]?(?:-\d+)?)$/i);
    return {street:numbered?numbered[1]:address,number:numbered?numbered[2]:''};
  }
  function searchResult(f,parts,commune,region){
    const p=f.properties,foundRegion=regionFor(p.state);
    const areas=[p.district,p.city,p.town,p.village,p.locality,...(['city','district','locality'].includes(p.type)?[p.name]:[])].filter(Boolean);
    const areaMatch=!!commune&&areas.some(a=>communeKey(a)===communeKey(commune));
    const regionMatch=!region||foundRegion?.id===region;
    const isStreet=p.type==='street';
    const streetMatch=streetKey(p.street||(isStreet?p.name:''))===streetKey(parts.street);
    const exactNumber=!!parts.number&&norm(p.housenumber)===norm(parts.number)&&streetMatch;
    const nameMatch=norm(p.name)===norm(parts.street)&&!parts.number;
    const label=[p.name,[p.street,p.housenumber].filter(Boolean).join(' '),p.district,p.city||p.town||p.village,p.state].filter((v,i,a)=>v&&a.indexOf(v)===i).join(', ');
    const score=(areaMatch?100:0)+(regionMatch?40:0)+(exactNumber?30:streetMatch&&isStreet?20:nameMatch?15:0);
    return {f,p,label,areas,foundRegion,areaMatch,regionMatch,isStreet,streetMatch,exactNumber,nameMatch,score};
  }
  async function search(){
    const ctx=editorContext;if(!ctx)return;const q=s=>dialog.querySelector(s),query=q('[data-geo-query]').value.trim();
    if(query.length<3){q('[data-geo-status]').textContent='Escribe una dirección, camino o sector (al menos 3 caracteres).';return;}
    resetSearch(true);const id=++requestId;ctx.controller=new AbortController();const controller=ctx.controller;
    const commune=q('[data-geo-commune]').value.trim(),region=q('[data-geo-region]').value,parts=addressParts(query,commune);
    q('[data-geo-search]').disabled=true;q('[data-geo-status]').textContent='Buscando dirección'+(commune?' en '+commune:' en Chile')+'…';
    const current=()=>id===requestId&&ctx===editorContext&&!controller.signal.aborted;
    const timeout=setTimeout(()=>controller.abort(),20000);
    async function lookup(term){
      const fullQuery=commune&&!norm(term).includes(norm(commune))?term+', '+commune:term;
      const key=norm(fullQuery)+'|'+region;if(cache.has(key))return cache.get(key);
      const delay=Math.max(0,1200-(Date.now()-lastSearchAt));if(delay)await new Promise(resolve=>setTimeout(resolve,delay));if(!current())return [];
      lastSearchAt=Date.now();const url=new URL(global.EVALUATOR_MAP_CONFIG?.geocoderUrl||'https://photon.komoot.io/api/');
      url.searchParams.set('q',fullQuery);url.searchParams.set('limit','15');url.searchParams.set('countrycode','CL');
      const center=CENTERS[region];if(center){url.searchParams.set('lat',center[0]);url.searchParams.set('lon',center[1]);url.searchParams.set('zoom','7');}
      const response=await fetch(url,{signal:controller.signal});if(!response.ok)throw new Error('search');const data=await response.json();
      const features=(data.features||[]).filter(f=>f.properties&&f.geometry?.type==='Point'&&Array.isArray(f.geometry.coordinates)&&coords({lng:f.geometry.coordinates[0],lat:f.geometry.coordinates[1]})&&(!f.properties.countrycode||String(f.properties.countrycode).toUpperCase()==='CL'));
      cache.set(key,features);if(cache.size>100)cache.delete(cache.keys().next().value);return features;
    }
    try{
      let features=await lookup(query);if(!current())return;
      const relevant=r=>r.regionMatch&&(!commune||r.areaMatch)&&(r.exactNumber||r.isStreet&&r.streetMatch||r.nameMatch);
      let results=features.map(f=>searchResult(f,parts,commune,region));
      // Some addresses are indexed only as streets, without individual house numbers.
      if(parts.number&&!results.some(relevant)){
        q('[data-geo-status]').textContent='Buscando la calle para acercarte a la dirección…';
        const streets=await lookup(parts.street);if(!current())return;
        const seen=new Set(features.map(f=>f.properties.osm_type+':'+f.properties.osm_id+':'+f.geometry.coordinates.join(',')));
        features=features.concat(streets.filter(f=>{const key=f.properties.osm_type+':'+f.properties.osm_id+':'+f.geometry.coordinates.join(',');if(seen.has(key))return false;seen.add(key);return true;}));
        results=features.map(f=>searchResult(f,parts,commune,region));
      }
      if(!current())return;results.sort((a,b)=>b.score-a.score);
      const candidates=results.filter(relevant),automatic=candidates[0]&&(commune||candidates.length===1)?candidates[0]:null;
      const select=r=>{
        if(ctx!==editorContext||id!==requestId)return;
        const {f,p,label}=r;setPoint({lat:f.geometry.coordinates[1],lng:f.geometry.coordinates[0]},'photon',label,r.isStreet?'street':r.exactNumber?'address':'place');
        if(r.foundRegion)q('[data-geo-region]').value=r.foundRegion.id;
        const selectedRegion=q('[data-geo-region]').value;
        const area=(r.areaMatch&&r.regionMatch?canonicalCommune(selectedRegion,commune):'')||r.areas.map(name=>canonicalCommune(selectedRegion,name)).find(Boolean)||'';
        fillCommunes(selectedRegion,area);updateExternalSearch();
        let message;
        if(r.isStreet)message='Encontramos '+(p.name||p.street)+(q('[data-geo-commune]').value?' en '+q('[data-geo-commune]').value:'')+(parts.number?', pero no el número '+parts.number:'')+'. El punto es aproximado: arrástralo hasta la entrada y guarda.';
        else if(parts.number&&!r.exactNumber)message=(p.housenumber?'Este resultado corresponde al número '+p.housenumber+', no al '+parts.number+'.':'No encontramos el número '+parts.number+' en este resultado.')+' Revisa la referencia y ajusta el punto hasta la entrada antes de guardar.';
        else message=(r.exactNumber?'Dirección encontrada: ':'Referencia encontrada: ')+label+'. Revisa el punto y guarda la ubicación.';
        q('[data-geo-status]').textContent=message;
        q('[data-geo-results]').querySelectorAll('button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.result===String(results.indexOf(r)))));
        q('[data-geo-options]').open=false;q('[data-geo-options-summary]').textContent='Ver otras coincidencias ('+results.length+')';
        if(editorMap){editorMap.invalidateSize();const e=p.extent;if(r.isStreet&&Array.isArray(e)&&e.length===4&&e.every(Number.isFinite))editorMap.fitBounds([[e[1],e[0]],[e[3],e[2]]],{padding:[35,35],maxZoom:17});else editorMap.setView(coords(ctx.point),r.isStreet||p.housenumber?17:16);}
      };
      q('[data-geo-options]').hidden=!results.length;q('[data-geo-options]').open=!!results.length;
      q('[data-geo-options-summary]').textContent='Seleccionar una coincidencia ('+results.length+')';
      results.forEach((r,i)=>{const suffix=r.isStreet?' · Calle (punto aproximado)':parts.number&&!r.exactNumber?' · Referencia, no coincide el número':'';const b=button(r.label+suffix,()=>select(r));b.dataset.result=String(i);b.setAttribute('aria-pressed','false');q('[data-geo-results]').append(b);});
      q('[data-geo-status]').textContent=results.length?'Revisa las coincidencias y elige la dirección y comuna correctas.':'No encontramos esa dirección. Revisa la comuna o busca solo el nombre de la calle; también puedes marcar la entrada en el mapa.';
      if(automatic)select(automatic);
    }catch(e){if(ctx===editorContext&&id===requestId)q('[data-geo-status]').textContent='La búsqueda no está disponible ahora. Vuelve a intentarlo o marca la entrada en el mapa.';}
    finally{clearTimeout(timeout);if(ctx===editorContext&&id===requestId)q('[data-geo-search]').disabled=false;}
  }
  global.EvaluatorGeo={setup,filter,render,bindProject,refreshProject,focus,coords};
})(window);
