(function(global){
  'use strict';
  const ASSETS='/evaluador-proyectos/vendor/';
  const IMAGERY='https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer';
  const REFERENCE='https://basemaps.arcgis.com/arcgis/rest/services/World_Basemap_v2/VectorTileServer';
  const STYLE='https://www.arcgis.com/sharing/rest/content/items/30d6b8271e1849cd9c3042060001f425/resources/styles/root.json';
  const ATTRIBUTION='Calles: <a href="https://www.arcgis.com/home/item.html?id=30d6b8271e1849cd9c3042060001f425" target="_blank" rel="noopener" title="Esri, TomTom, Garmin, FAO, NOAA, USGS, OpenStreetMap contributors y GIS User Community">Esri, TomTom, &copy; OpenStreetMap y colaboradores</a>';
  let libraries,referenceStyle;const dateCache=new Map();
  function script(src){return new Promise((resolve,reject)=>{const s=document.createElement('script');s.src=src;s.onload=resolve;s.onerror=()=>{s.remove();reject(new Error('No se pudo cargar la capa de calles.'));};document.head.append(s);});}
  async function json(url,signal){const response=await fetch(url,{signal});if(!response.ok)throw new Error('Servicio no disponible');const data=await response.json();if(data.error)throw new Error('Servicio no disponible');return data;}
  async function loadReference(){
    if(!libraries)libraries=(async()=>{if(!document.querySelector('[data-geo-maplibre-css]')){const css=document.createElement('link');css.rel='stylesheet';css.href=ASSETS+'maplibre-gl.css';css.dataset.geoMaplibreCss='';document.head.append(css);}if(!global.maplibregl)await script(ASSETS+'maplibre-gl.js');if(!L.maplibreGL)await script(ASSETS+'leaflet-maplibre-gl.js');})().catch(e=>{libraries=null;throw e;});
    await libraries;
    if(!referenceStyle)referenceStyle=(async()=>{
      const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),15000);
      try{
        const [style,metadata]=await Promise.all([json(STYLE,controller.signal),json(REFERENCE+'?f=json',controller.signal)]);
        // ArcGIS advertises display zooms beyond its cooked tiles. Overzoom the
        // native vector level so roads and text remain sharp at parcel scale.
        style.sources.esri={type:'vector',tiles:[REFERENCE+'/tile/{z}/{y}/{x}.pbf'],minzoom:metadata.minLOD??0,maxzoom:metadata.maxLOD??16,attribution:ATTRIBUTION};
        style.layers=style.layers.filter(layer=>layer.type==='line'||layer.type==='symbol');
        style.layers.forEach(layer=>{const fonts=layer.layout?.['text-font'];if(Array.isArray(fonts)&&fonts.every(f=>typeof f==='string')&&fonts.length>1)layer.layout['text-font']=[fonts[0]];});
        return style;
      }finally{clearTimeout(timeout);}
    })().catch(e=>{referenceStyle=null;throw e;});
    return referenceStyle;
  }
  function captureDate(attributes){
    const raw=String(attributes.SRC_DATE||'');let year,month,day;
    if(/^\d{8}$/.test(raw)){year=+raw.slice(0,4);month=+raw.slice(4,6);day=+raw.slice(6,8);}
    else {const match=String(attributes.SRC_DATE2||'').match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);if(!match)return '';[,month,day,year]=match.map(Number);}
    const date=new Date(Date.UTC(year,month-1,day));if(year<1900||date.getUTCFullYear()!==year||date.getUTCMonth()!==month-1||date.getUTCDate()!==day)return '';
    return new Intl.DateTimeFormat('es-CL',{day:'2-digit',month:'2-digit',year:'numeric',timeZone:'UTC'}).format(date);
  }
  function create(map,imagery){
    const satellite=L.layerGroup([imagery]);let active=false,destroyed=false,labels=null,referenceRequest=0,dateRequest=0,dateController,dateViewed=false;
    const pane=map.getPane('geoStreetLabels')||map.createPane('geoStreetLabels');pane.style.zIndex='350';pane.style.pointerEvents='none';
    const toolbar=document.createElement('div');toolbar.className='geo-satellite-tools';toolbar.hidden=true;
    toolbar.innerHTML='<div class="geo-satellite-actions"><label><input type="checkbox" data-geo-streets checked> Calles y nombres</label><button type="button" data-geo-image-date>Fecha de esta zona</button><a data-geo-compare-imagery target="_blank" rel="noopener noreferrer">Comparar en Google Maps ↗</a></div><p data-geo-streets-status role="status" aria-live="polite"></p><p data-geo-imagery-status role="status" aria-live="polite">La fecha de las fotos varía según la zona. Acerca el mapa para consultar la imagen del terreno.</p>';
    map.getContainer().after(toolbar);const q=s=>toolbar.querySelector(s),checkbox=q('[data-geo-streets]'),labelStatus=q('[data-geo-streets-status]'),dateStatus=q('[data-geo-imagery-status]'),dateButton=q('[data-geo-image-date]');
    function updateComparison(){const center=map.getCenter(),url=new URL('https://www.google.com/maps/@');url.search=new URLSearchParams({api:'1',map_action:'map',center:center.lat.toFixed(6)+','+center.lng.toFixed(6),zoom:String(Math.round(map.getZoom())),basemap:'satellite'});q('[data-geo-compare-imagery]').href=url.href;}
    function removeLabels(){referenceRequest++;if(labels){if(map.hasLayer(labels))map.removeLayer(labels);labels=null;}labelStatus.textContent='';}
    async function showLabels(){
      if(!active||!checkbox.checked||destroyed||labels)return;
      const id=++referenceRequest;labelStatus.textContent='Cargando calles y nombres…';
      try{
        const style=await loadReference();if(id!==referenceRequest||!active||!checkbox.checked||destroyed)return;
        const layer=L.maplibreGL({style:JSON.parse(JSON.stringify(style)),pane:'geoStreetLabels',interactive:false,attributionControl:{customAttribution:ATTRIBUTION},className:'geo-street-labels',maxZoom:22,renderWorldCopies:false});
        labels=layer;layer.addTo(map);const gl=layer.getMaplibreMap();
        gl.on('load',()=>{if(labels===layer&&active){layer.getContainer().dataset.geoStreetsLoaded='true';labelStatus.textContent='';}});
        gl.on('error',()=>{if(labels===layer&&active)labelStatus.textContent='Algunas calles no pudieron cargarse. Desactiva y activa Calles y nombres para reintentar.';});
      }catch(e){if(id===referenceRequest&&active&&!destroyed){if(labels)removeLabels();labelStatus.textContent='No se pudieron cargar las calles. Puedes seguir usando la imagen o cambiar a Normal.';}}
    }
    function cancelDate(){dateRequest++;dateController?.abort();dateController=null;dateButton.disabled=false;}
    async function showDate(){
      if(!active||destroyed)return;cancelDate();const id=dateRequest,center=map.getCenter();dateViewed=true;
      if(map.getZoom()<12){dateStatus.textContent='Acerca más el mapa al terreno para consultar la fecha de captura.';return;}
      const zoom=imagery.sourceZoomAt(center);if(zoom===null){dateStatus.textContent='Espera a que cargue la imagen y vuelve a consultar su fecha.';return;}
      const key=[center.lat.toFixed(6),center.lng.toFixed(6),zoom].join('|');dateButton.disabled=true;dateStatus.textContent='Consultando la fecha de captura en el centro del mapa…';
      dateController=new AbortController();const controller=dateController,timeout=setTimeout(()=>controller.abort(),12000);
      try{
        let data=dateCache.get(key);
        if(!data){
          // Identify at the actual raster tile's zoom, including parent-tile
          // fallback, rather than claiming metadata from a missing close-up.
          const point=L.CRS.EPSG3857.project(center),half=40075016.68557849/(256*2**zoom)*50.5;
          const url=new URL(IMAGERY+'/identify');url.search=new URLSearchParams({f:'json',geometry:point.x+','+point.y,geometryType:'esriGeometryPoint',sr:'3857',layers:'visible:5,6,7,8,9,10,11,12,13,14,15,16,17,18',tolerance:'0',mapExtent:[point.x-half,point.y-half,point.x+half,point.y+half].join(','),imageDisplay:'101,101,96',returnGeometry:'false'});
          data=await json(url,controller.signal);dateCache.set(key,data);if(dateCache.size>50)dateCache.delete(dateCache.keys().next().value);
        }
        if(id!==dateRequest||!active||destroyed)return;
        const captures=[...new Set((data.results||[]).map(result=>{const a=result.attributes||{},date=captureDate(a);return date?date+(a.NICE_DESC?' · '+a.NICE_DESC:''):'';}).filter(Boolean))];
        dateStatus.textContent=captures.length?'Centro del mapa · '+(captures.length===1?'Fecha de captura: ':'Fechas de captura: ')+captures.join('; ')+'. La antigüedad puede cambiar en otras zonas.':'El proveedor no informa una fecha de captura para este punto y nivel de zoom.';
      }catch(e){if(id===dateRequest&&active&&!destroyed)dateStatus.textContent='No se pudo consultar la fecha. Puedes volver a intentarlo; la imagen sigue disponible.';}
      finally{clearTimeout(timeout);if(id===dateRequest)dateButton.disabled=false;}
    }
    checkbox.addEventListener('change',()=>checkbox.checked?showLabels():removeLabels());dateButton.addEventListener('click',showDate);
    const moved=()=>{if(!active)return;updateComparison();cancelDate();if(dateViewed)dateStatus.textContent='La zona o el zoom cambió. Presiona Fecha de esta zona para consultar la imagen actual.';};
    map.on('moveend',moved);
    satellite.on('add',()=>{active=true;toolbar.hidden=false;updateComparison();showLabels();});
    satellite.on('remove',()=>{active=false;toolbar.hidden=true;removeLabels();cancelDate();dateViewed=false;dateStatus.textContent='La fecha de las fotos varía según la zona. Acerca el mapa para consultar la imagen del terreno.';});
    map.on('unload',()=>{destroyed=true;active=false;referenceRequest++;cancelDate();map.off('moveend',moved);toolbar.remove();});
    return satellite;
  }
  global.EvaluatorSatellite={create};
})(window);
