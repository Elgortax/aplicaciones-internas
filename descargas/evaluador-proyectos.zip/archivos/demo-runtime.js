(function(){
  'use strict';
  const DEMO_ID='vicaper-evaluador-demo-v1';
  const requested=new URLSearchParams(location.search).get('espacio');
  const selected=requested==='individual'?'individual':'principal';
  const workspace='demo-'+selected;
  const storageKey='loteo_eval_v3_'+workspace;
  const clone=value=>JSON.parse(JSON.stringify(value));
  const seed=window.VICAPER_DEMO_SEED[selected];
  function read(){
    try{const data=JSON.parse(localStorage.getItem(storageKey));if(data&&data.config&&Array.isArray(data.proyectos))return data;}catch(e){}
    return clone(seed);
  }
  function save(data){localStorage.setItem(storageKey,JSON.stringify(data));}
  try{if(!localStorage.getItem(storageKey))save(clone(seed));}catch(e){}
  function snapshot(value,id){return {id,exists:value!==undefined,data:()=>value===undefined?undefined:clone(value)};}
  function collection(name){
    if(name!=='config'&&name!=='proyectos')throw Error('Colección fuera de la demo');
    return {
      get:()=>Promise.resolve({forEach:callback=>read().proyectos.forEach(p=>callback(snapshot(p,p.id)))}),
      doc:id=>({
        get:()=>{const state=read();return Promise.resolve(snapshot(name==='config'?state.config:state.proyectos.find(p=>p.id===id),id));},
        set:value=>{const state=read();if(name==='config')state.config=clone(value);else{const index=state.proyectos.findIndex(p=>p.id===id);if(index<0)state.proyectos.push(clone(value));else state.proyectos[index]=clone(value);}save(state);return Promise.resolve();},
        delete:()=>{const state=read();if(name==='proyectos')state.proyectos=state.proyectos.filter(p=>p.id!==id);save(state);return Promise.resolve();}
      })
    };
  }
  function firestore(){return {collection};}
  firestore.FieldValue={serverTimestamp:()=>new Date().toISOString()};
  window.firebase={firestore};
  window.VICAPER_AUTH={uid:DEMO_ID,email:'demo@ejemplo.local',role:'editor',profile:{nombre:'Equipo Demo'},workspaceId:workspace};
  window.VICAPER_EVALUATOR_WORKSPACE=workspace;
  window.VICAPER_EVALUATOR_WORKSPACES={'demo-principal':'admin','demo-individual':'admin'};
  window.VICAPER_EVALUATOR_ROOT=()=>({collection});
  window.VICAPER_DEMO={id:DEMO_ID,workspace,storageKey,read,seed:clone(seed)};
  // Serve only the page's own source from the packaged copy, including file mode.
  // Normalize line endings so the published HTML export finds its insertion point.
  // All other requests retain their browser implementation.
  {
    const OriginalXHR=window.XMLHttpRequest;
    window.XMLHttpRequest=function(){
      const native=new OriginalXHR();let localSource=false;
      const originalOpen=native.open.bind(native),originalSend=native.send.bind(native);
      native.open=function(method,url,...args){localSource=method==='GET'&&String(url)===location.href;return localSource?undefined:originalOpen(method,url,...args);};
      native.send=function(...args){
        if(!localSource)return originalSend(...args);
        if(!window.VICAPER_DEMO_HTML_SOURCE){if(native.onerror)native.onerror(new Error('La fuente de la demo no está disponible'));return;}
        Object.defineProperty(native,'responseText',{value:window.VICAPER_DEMO_HTML_SOURCE.replace(/\r\n/g,'\n')});
        if(native.onload)native.onload();
      };
      return native;
    };
  }
  document.addEventListener('DOMContentLoaded',()=>{
    document.getElementById('appRoot').style.display='';
    const wrap=document.getElementById('workspaceSwitcher'),select=document.getElementById('workspaceSelect');
    wrap.style.display='flex';
    select.replaceChildren(...[['principal','Equipo Demo'],['individual','Espacio individual']].map(([id,label])=>{const option=document.createElement('option');option.value=id;option.textContent=label;option.selected=id===selected;return option;}));
    select.addEventListener('change',async()=>{if(window.VICAPER_FLUSH_EVALUATOR)await window.VICAPER_FLUSH_EVALUATOR();const url=new URL(location.href);url.searchParams.set('espacio',select.value);location.assign(url.href);});
  });
})();
