(function (global) {
  "use strict";

  var money = new Intl.NumberFormat("es-CL", { maximumFractionDigits: 0 });
  var number1 = new Intl.NumberFormat("es-CL", { minimumFractionDigits: 1, maximumFractionDigits: 1 });

  function n(value) {
    value = Number(value);
    return Number.isFinite(value) ? value : 0;
  }

  function esc(value) {
    return String(value == null ? "" : value).replace(/[&<>"']/g, function (char) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char];
    });
  }

  function clp(value) {
    var amount = Math.round(n(value));
    return (amount < 0 ? "-$" : "$") + money.format(Math.abs(amount));
  }

  function compact(value) {
    var amount = n(value);
    var absolute = Math.abs(amount);
    if (absolute >= 1000000) return (amount < 0 ? "-$" : "$") + money.format(Math.round(absolute / 1000000)) + " MM";
    return clp(amount);
  }

  function pct(value) {
    return number1.format(n(value)) + "%";
  }

  function month(value) {
    var current = Math.max(1, Math.round(n(value) || 1));
    return "M" + current;
  }

  function share(amount, total) {
    return total ? n(amount) / total * 100 : 0;
  }

  function normalize(input) {
    var data = Object.assign({
      mode: "internal",
      projectName: "Proyecto sin nombre",
      location: "Ubicación no informada",
      company: "Tierras de Chile",
      scenarioLabel: "Escenario base",
      lots: 0,
      hectares: 0,
      saleTotal: 0,
      saleMonths: 0,
      horizonMonths: 0,
      landCost: 0,
      landCostBasis: "",
      commercialCost: 0,
      worksCost: 0,
      netProfit: 0,
      resultAmount: 0,
      resultLabel: "Resultado total",
      resultPct: 0,
      resultPctLabel: "Rentabilidad estimada",
      annualReturnPct: 0,
      annualReturnYears: 0,
      remainingReturnPct: 0,
      remainingReturnMonths: 0,
      pvp: 0,
      unitSalePrice: 0,
      waterUnit: 0,
      waterIncome: 0,
      buildingIncome: 0,
      extraIncomeTotal: 0,
      piePct: 0,
      pieAmount: 0,
      balanceAmount: 0,
      balanceWithInterest: 0,
      annualInterestRate: 0,
      interestPerLot: 0,
      interestIncome: 0,
      installments: 0,
      installmentAmount: 0,
      scenarios: [],
      timeline: [],
      alerts: [],
      glossary: [],
      disclaimer: "Modelo de estimación para análisis y negociación. Las cifras son referenciales y deben validarse antes de asumir compromisos."
    }, input || {});

    ["lots", "hectares", "saleTotal", "saleMonths", "horizonMonths", "landCost", "commercialCost", "worksCost", "netProfit", "resultAmount", "resultPct", "annualReturnPct", "annualReturnYears", "remainingReturnPct", "remainingReturnMonths", "pvp", "unitSalePrice", "waterUnit", "waterIncome", "buildingIncome", "extraIncomeTotal", "piePct", "pieAmount", "balanceAmount", "balanceWithInterest", "annualInterestRate", "interestPerLot", "interestIncome", "installments", "installmentAmount"].forEach(function (key) {
      data[key] = n(data[key]);
    });
    data.saleMonths = Math.max(0, Math.ceil(data.saleMonths));
    data.horizonMonths = Math.max(data.saleMonths, Math.ceil(data.horizonMonths || data.saleMonths));
    data.scenarios = Array.isArray(data.scenarios) ? data.scenarios.slice(0, 3) : [];
    data.timeline = Array.isArray(data.timeline) ? data.timeline.slice(0, 6) : [];
    data.alerts = Array.isArray(data.alerts) ? data.alerts.slice(0, 3) : [];
    return data;
  }

  function returnBreakdown(data) {
    var parts = [];
    var fullYears = Math.max(0, Math.floor(data.annualReturnYears));
    var remainingMonths = Math.max(0, data.remainingReturnMonths);
    if (fullYears > 0) {
      parts.push(pct(data.annualReturnPct) + ' anual · años 1 a ' + money.format(fullYears));
    }
    if (remainingMonths > 0) {
      var roundedMonths = Math.round(remainingMonths * 10) / 10;
      var monthsLabel = Math.abs(roundedMonths - Math.round(roundedMonths)) < 1e-9
        ? money.format(Math.round(roundedMonths))
        : number1.format(roundedMonths);
      parts.push(pct(data.remainingReturnPct) + ' · ' + monthsLabel + (roundedMonths === 1 ? ' mes final' : ' meses finales'));
    }
    return parts.length ? parts.join('<br>') : 'Según el escenario seleccionado';
  }

  function distributionItems(data) {
    var margin = n(data.netProfit);
    return [
      { label: "Costo del predio", description: "Valor considerado para adquirir o remunerar el terreno" + (data.landCostBasis ? " · Precio informado: " + data.landCostBasis : ""), amount: data.landCost, tone: "land" },
      { label: "Comercialización", description: "Marketing, corretaje, administración y costos comerciales", amount: data.commercialCost, tone: "commercial" },
      { label: "Habilitación y obras", description: "Urbanización, estudios, caminos, servicios y otros trabajos", amount: data.worksCost, tone: "works" },
      { label: data.mode === "broker" ? "Margen neto del propietario" : "Ganancia neta proyectada", description: data.mode === "broker" ? "Utilidad adicional sobre el valor del terreno" : "Resultado después de terreno, comercialización y obras", amount: margin, tone: margin >= 0 ? "profit" : "risk" }
    ];
  }

  function flowRows(data) {
    return distributionItems(data).map(function (row) {
      var rowShare = share(row.amount, data.saleTotal);
      return '<div class="es-flow-row ' + row.tone + '">' +
        '<div><strong>' + esc(row.label) + '</strong><small>' + esc(row.description) + '</small></div>' +
        '<div class="es-flow-value"><b>' + compact(row.amount) + '</b><span>' + pct(rowShare) + '</span></div>' +
      '</div>';
    }).join("");
  }

  function segmentBar(data) {
    var colors = ["#57728e", "#92a4b7", "#c9a32a", data.netProfit >= 0 ? "#9b6c00" : "#b8412b"];
    var values = distributionItems(data).map(function (item) { return Math.max(0, item.amount); });
    return values.map(function (value, index) {
      return '<i style="width:' + Math.max(0, share(value, data.saleTotal)).toFixed(2) + '%;background:' + colors[index] + '"></i>';
    }).join("");
  }

  function onePesoDistribution(data) {
    var items = distributionItems(data);
    return '<div class="es-one-peso" data-section="one-peso">' +
      '<img src="/assets/1-peso-chileno-1976.jpg" alt="Moneda chilena de un peso de 1976" style="display:block;width:76px;height:76px;border-radius:50%;object-fit:cover;border:1px solid #b6a17b;box-shadow:0 4px 10px rgba(71,57,34,.25)">' +
      '<div class="es-coin-arrow"><span>SE REPARTE EN</span><b>→</b></div>' +
      '<div class="es-peso-items">' + items.map(function (item) {
        return '<div class="' + item.tone + '"><strong>' + pct(share(item.amount, data.saleTotal)) + '</strong><span>' + esc(item.label) + '</span></div>';
      }).join('') + '</div></div>';
  }

  function detailedDistribution(data) {
    var items = distributionItems(data);
    var colors = ["#57728e", "#ef6b3b", "#2aa876", data.netProfit >= 0 ? "#d49a00" : "#b8412b"];
    return '<div class="es-distribution-detail" data-section="distribution-detail">' +
      '<div class="es-distribution-bar">' + items.map(function (item, index) {
        var itemShare = share(item.amount, data.saleTotal);
        return '<i style="width:' + Math.max(0, itemShare).toFixed(2) + '%;background:' + colors[index] + '"><small>' + pct(itemShare) + '</small></i>';
      }).join('') + '</div>' +
      '<div class="es-distribution-cards">' + items.map(function (item) {
        return '<div class="' + item.tone + '"><b>' + compact(item.amount) + '</b><span>' + esc(item.label) + ' · ' + pct(share(item.amount, data.saleTotal)) + '</span></div>';
      }).join('') + '</div></div>';
  }

  function paymentJourney(data) {
    var receiver = data.mode === "broker" ? "EL PROPIETARIO RECIBE" : "RESULTADO ESTIMADO";
    var sourceDetail = "Venta de " + money.format(data.lots) + " lotes" + (data.extraIncomeTotal > 0 ? " + ingresos adicionales" : "");
    var resultDetail = data.mode === "broker" ? "valor del predio + margen neto" : "resultado después de costos";
    return '<div class="es-flow" data-section="payment-journey">' +
      '<div><div class="es-flow-source"><b>EL CLIENTE PAGA</b><strong>' + compact(data.saleTotal) + '</strong><span>' + esc(sourceDetail) + '</span></div><div class="es-segments">' + segmentBar(data) + '</div></div>' +
      '<div class="es-flow-arrow">→</div>' +
      '<div class="es-flow-rows">' + flowRows(data) + '</div>' +
      '<div class="es-flow-arrow">→</div>' +
      '<div class="es-flow-result"><small>' + receiver + '</small><b>' + compact(data.resultAmount) + '</b><span>' + esc(resultDetail) + '</span><strong>' + pct(data.resultPct) + '</strong></div>' +
    '</div>';
  }

  function scenarios(data) {
    var list = data.scenarios.length ? data.scenarios : [{ label: "Base", result: data.resultAmount, months: data.saleMonths, detail: "Datos actuales del proyecto" }];
    return list.map(function (item, index) {
      return '<tr class="' + (index === 1 || list.length === 1 ? "is-base" : "") + '">' +
        '<td><strong>' + esc(item.label || "Escenario") + '</strong><small>' + esc(item.detail || "") + '</small></td>' +
        '<td>' + compact(item.result) + '</td><td>' + Math.ceil(n(item.months)) + ' meses</td>' +
      '</tr>';
    }).join("");
  }

  function timeline(data) {
    var points = data.timeline.length ? data.timeline : [
      { month: 1, label: "Inicio del proyecto", detail: "Preparación y lanzamiento" },
      { month: Math.max(1, Math.ceil(data.saleMonths / 2)), label: "Venta en régimen", detail: "Avance comercial proyectado" },
      { month: Math.max(1, data.saleMonths), label: "Último lote vendido", detail: "Fin de la colocación" },
      { month: Math.max(1, data.horizonMonths), label: "Último cobro", detail: "Cierre del horizonte" }
    ];
    return points.map(function (item, index) {
      return '<div class="es-time-point ' + esc(item.tone || "") + '"><span>' + month(item.month) + '</span><b>' + esc(item.label) + '</b><small>' + esc(item.detail || "") + '</small>' + (index < points.length - 1 ? '<i></i>' : '') + '</div>';
    }).join("");
  }

  function alerts(data) {
    var list = data.alerts.length ? data.alerts : [
      { tone: "ok", title: "Modelo completo", body: "No se detectaron alertas críticas con los datos actuales." }
    ];
    return list.map(function (item, index) {
      return '<div class="es-alert ' + esc(item.tone || "warn") + '"><b>' + (index + 1) + ' · ' + esc(item.title || "Punto a revisar") + '</b><p>' + esc(item.body || "") + '</p></div>';
    }).join("");
  }

  function glossary(data) {
    var terms = data.glossary.length ? data.glossary : [
      ["PVP unitario", "El precio de venta de cada lote."],
      ["Velocidad de venta", "Cuántos lotes se espera vender por mes."],
      ["Margen bruto", "Venta total menos el valor del terreno, antes de otros gastos."],
      ["Margen neto", "Lo que queda después de descontar todos los costos informados."],
      ["Pie", "La parte que el comprador paga al inicio."],
      ["Caja acumulada", "El dinero disponible que va quedando mes a mes."],
      ["Hito", "Una obra o pago relevante ubicado en un mes del proyecto."],
      ["Escenario", "El mismo negocio con supuestos distintos de precio o velocidad."]
    ];
    return terms.slice(0, 8).map(function (term) {
      return '<div class="es-term"><b>' + esc(term[0]) + '</b><span>' + esc(term[1]) + '</span></div>';
    }).join("");
  }

  function pageTwo(data) {
    var broker = data.mode === "broker";
    var subject = broker ? "usted" : "el proyecto";
    var idea = broker
      ? "Usted aporta el terreno y la empresa se encarga de dividirlo, habilitarlo y venderlo. Con la recaudación se cubren los costos y se le paga el valor acordado más el margen proyectado."
      : "El proyecto transforma el terreno en lotes comercializables, financia sus costos con las ventas y busca obtener una ganancia neta al final del horizonte proyectado.";
    var steps = broker ? [
      ["Se aporta el terreno y se fija su valor", "El predio se valoriza en " + compact(data.landCost) + (data.landCostBasis ? " a partir de " + data.landCostBasis : "") + ". Ese valor se paga con la recaudación según las condiciones acordadas."],
      ["Se divide y se habilita", "Se proyectan " + money.format(data.lots) + " lotes y obras por " + compact(data.worksCost) + "."],
      ["Se vende al ritmo estimado", "A un promedio de " + number1.format(data.lots / Math.max(1, data.saleMonths)) + " lotes al mes, la colocación tomaría cerca de " + data.saleMonths + " meses."],
      ["Cada venta se reparte en el mismo orden", "Se cubren comercialización, obras y pagos del predio; el excedente forma el margen del propietario."],
      ["Al cierre se liquida el saldo", "El resultado estimado para el propietario es " + compact(data.resultAmount) + ", sujeto al cumplimiento del escenario."]
    ] : [
      ["Se adquiere y prepara el terreno", "El costo informado del predio es " + compact(data.landCost) + " y constituye la base de la evaluación."],
      ["Se estructura la habilitación", "Las obras y costos operacionales informados suman " + compact(data.worksCost) + "."],
      ["Se comercializan los lotes", "Se proyectan " + money.format(data.lots) + " lotes a un PVP promedio de " + clp(data.pvp) + "."],
      ["La recaudación cubre los costos", "Los ingresos llegan mediante el pie y las cuotas durante un horizonte de hasta " + data.horizonMonths + " meses."],
      ["Se obtiene el resultado final", "La ganancia neta proyectada es " + compact(data.netProfit) + ", equivalente a " + pct(data.resultPct) + "."]
    ];
    var faq = broker ? [
      ["¿Tengo que poner dinero?", "El modelo supone que el aporte principal es el terreno y que los gastos se financian con la recaudación. Si la caja queda negativa, debe acordarse cómo cubrirla."],
      ["¿Por qué podría convenir más que vender el predio?", "Porque el resultado proyectado incorpora el valor del predio y un margen adicional, a cambio de plazo y riesgo comercial."],
      ["¿Y si se vende más lento?", "El escenario conservador muestra el impacto: normalmente se alarga el plazo y puede cambiar el saldo disponible."],
      ["¿Cuándo empiezo a recibir pagos?", "Depende de la modalidad acordada con el aportante y del inicio de ventas cargado en el modelo."],
      ["¿Cuál es el punto más delicado?", "Los meses con caja baja, las obras sobre presupuesto y cualquier saldo pendiente al cierre."]
    ] : [
      ["¿Cuánto hay que invertir?", "El modelo considera el costo del predio y todos los gastos comerciales y de obras informados."],
      ["¿Cuándo se recupera el dinero?", "El plazo depende del ritmo de ventas, el pie, las cuotas y el calendario de pagos del predio."],
      ["¿Y si se vende más lento?", "El escenario conservador permite revisar cómo se extiende el plazo y cambia la rentabilidad."],
      ["¿La ganancia es segura?", "No. Es una estimación basada en los supuestos actuales y debe actualizarse cuando cambien precios, costos o velocidad."],
      ["¿Qué dato mueve más el resultado?", "Normalmente el PVP, la velocidad de venta y los costos del terreno y las obras."]
    ];

    return '<section class="es-page es-page-two">' +
      '<header class="es-header"><div><h1>Cómo funciona este negocio, explicado paso a paso</h1><p>Guía de lectura del resumen anterior · sin tecnicismos</p></div><span>PÁGINA EXPLICATIVA</span></header>' +
      '<h2>LA IDEA EN UNA FRASE</h2><div class="es-idea">' + esc(idea) + '</div>' +
      '<h2>EL RECORRIDO DEL PROYECTO, EN CINCO PASOS</h2><div class="es-steps">' + steps.map(function (step, index) {
        return '<div class="es-step"><i>' + (index + 1) + '</i><div><b>' + esc(step[0]) + '</b><p>' + esc(step[1]) + '</p></div></div>';
      }).join("") + '</div>' +
      '<h2>LAS PALABRAS DEL INFORME, EN SIMPLE</h2><div class="es-glossary">' + glossary(data) + '</div>' +
      '<h2>LAS PREGUNTAS QUE TODOS HACEN</h2><div class="es-faq">' + faq.map(function (item) {
        return '<div><b>' + esc(item[0]) + '</b><p>' + esc(item[1]) + '</p></div>';
      }).join("") + '</div>' +
      '<footer>' + esc(data.disclaimer) + ' Este documento resume el escenario seleccionado y no constituye una oferta, promesa de venta ni asesoría financiera o legal. Las cifras estimadas varían si cambian los supuestos.</footer>' +
    '</section>';
  }

  function buildHtml(input, options) {
    var data = normalize(input);
    var resultNote = data.mode === "broker"
      ? "valor del predio + margen neto"
      : "después de los costos informados";
    var unitSalePrice = data.unitSalePrice || data.pvp;
    var conditionRows = [["Precio base por lote", clp(data.pvp)]];
    if (data.waterUnit > 0) conditionRows.push(["Venta de agua por lote", clp(data.waterUnit)]);
    conditionRows.push(["Pie inicial (" + pct(data.piePct) + ")", clp(data.pieAmount)]);
    conditionRows.push(["Saldo base financiado", clp(data.balanceAmount)]);
    if (data.annualInterestRate > 0) {
      conditionRows.push(["Tasa de interés anual", pct(data.annualInterestRate)]);
      conditionRows.push(["Interés por lote", clp(data.interestPerLot)]);
      conditionRows.push(["Saldo total con interés", clp(data.balanceWithInterest)]);
    }
    conditionRows.push(["Cuotas mensuales", data.installments > 0 ? money.format(data.installments) + " x " + clp(data.installmentAmount) : "Sin cuotas"]);
    if (data.buildingIncome > 0) conditionRows.push(["Edificación · ingreso aparte", clp(data.buildingIncome)]);
    conditionRows.push(["Recaudación por lote", clp(unitSalePrice)]);
    var subtitle = money.format(data.lots) + " lotes" + (data.hectares ? " · " + number1.format(data.hectares) + " ha" : "") + " · " + data.location + " | " + data.company;
    var returnBreakdownHtml = returnBreakdown(data);
    var saleDetail = money.format(data.lots) + " lotes a " + clp(data.pvp) + " cada uno" + (data.extraIncomeTotal > 0 ? " · adicionales " + compact(data.extraIncomeTotal) : "");

    var html = '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Resumen Ejecutivo · ' + esc(data.projectName) + '</title><style>' + styles() + '</style></head><body>' +
      '<section class="es-page es-page-one">' +
        '<header class="es-header"><div><h1>' + esc(data.projectName) + ' · Resumen Ejecutivo del Negocio</h1><p>' + esc(subtitle) + '</p></div><span>' + esc(data.scenarioLabel.toUpperCase()) + '</span></header>' +
        '<h2>LO ESENCIAL, EN UNA MIRADA</h2><div class="es-kpis">' +
          '<article><small>VENTA TOTAL ESTIMADA</small><b>' + compact(data.saleTotal) + '</b><p>' + esc(saleDetail) + '</p></article>' +
          '<article><small>TIEMPO DE VENTA</small><b>' + money.format(data.saleMonths) + ' meses</b><p>Horizonte total de cobros: ' + money.format(data.horizonMonths) + ' meses</p></article>' +
          '<article class="gold"><small>' + esc(data.resultLabel.toUpperCase()) + '</small><b>' + compact(data.resultAmount) + '</b><p>' + esc(resultNote) + '</p></article>' +
          '<article class="gold"><small>' + esc(data.resultPctLabel.toUpperCase()) + '</small><b>' + pct(data.resultPct) + '</b><p class="es-return-breakdown">' + returnBreakdownHtml + '</p></article>' +
        '</div>' +
        '<h2>DEL PAGO DEL CLIENTE AL RESULTADO DEL PROPIETARIO <em>En qué se reparte la venta / ingreso</em></h2>' +
        paymentJourney(data) +
        '<h2>EN QUÉ SE REPARTE CADA PESO DE LA VENTA <em>Lectura porcentual, sin montos</em></h2>' +
        onePesoDistribution(data) +
        '<div class="es-two-cols"><div><h2>CÓMO SE PAGA CADA LOTE</h2><table class="es-simple-table">' + conditionRows.map(function (row, index) { return '<tr class="' + (index === conditionRows.length - 1 ? "total" : "") + '"><td>' + esc(row[0]) + '</td><td>' + esc(row[1]) + '</td></tr>'; }).join("") + '</table></div>' +
        '<div><h2>LOS TRES ESCENARIOS</h2><table class="es-scenario-table"><thead><tr><th>Escenario</th><th>Resultado</th><th>Plazo</th></tr></thead><tbody>' + scenarios(data) + '</tbody></table></div></div>' +
        '<h2 style="margin-top:10px">LÍNEA DE TIEMPO DEL PROYECTO <em>horizonte total ' + data.horizonMonths + ' meses</em></h2><div class="es-timeline" style="padding:8px 18px 0;transform:scale(.88);transform-origin:top center;margin-bottom:-7px">' + timeline(data) + '</div>' +
        '<h2 style="margin-top:8px">TRES PUNTOS QUE HAY QUE REVISAR ANTES DE FIRMAR</h2><div class="es-alerts" style="transform:scale(.92);transform-origin:top center;margin-bottom:-5px">' + alerts(data) + '</div>' +
        '<footer>' + esc(data.disclaimer) + '</footer>' +
      '</section>' + pageTwo(data) +
      ((options && options.autoPrint === false) ? '' : '<script>window.addEventListener("load",function(){setTimeout(function(){window.focus();window.print();},450);});<\/script>') + '</body></html>';
    return html;
  }

  function styles() {
    return '*{box-sizing:border-box}html,body{margin:0;background:#e8edf3;color:#253346;font-family:Arial,Helvetica,sans-serif}body{padding:20px}.es-page{width:210mm;min-height:297mm;margin:0 auto 18px;background:#fff;padding:12mm 13mm 9mm;position:relative;page-break-after:always}.es-page:last-of-type{page-break-after:auto}.es-header{display:flex;justify-content:space-between;gap:16px;align-items:flex-start;border-bottom:2px solid #183657;padding-bottom:10px;margin-bottom:17px}.es-header h1{font-size:22px;line-height:1.1;color:#183657;margin:0 0 5px}.es-header p{font-size:10px;color:#637184;margin:0}.es-header>span{background:#183657;color:#fff;padding:6px 12px;border-radius:4px;font-size:8px;letter-spacing:1.5px;white-space:nowrap}.es-page h2{font-size:10px;letter-spacing:1.6px;color:#183657;margin:13px 0 8px;padding-bottom:5px;border-bottom:1px solid #d3dce6}.es-page h2 em{font-style:normal;font-weight:400;letter-spacing:0;color:#93a0b0;margin-left:8px}.es-kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.es-kpis article{border:1px solid #d6dee8;border-top:4px solid #183657;border-radius:5px;padding:12px 13px;min-height:92px;background:#fbfcfd}.es-kpis article.gold{border-top-color:#b68100}.es-kpis small{display:block;font-size:7.5px;letter-spacing:.8px;color:#6d7b8d;min-height:19px}.es-kpis b{display:block;font-size:17px;color:#173657;margin:5px 0}.es-kpis .gold b{color:#946700}.es-kpis p{font-size:7.5px;line-height:1.35;color:#728096;margin:0}.es-flow{display:grid;grid-template-columns:130px 20px 1fr 20px 145px;align-items:center;gap:8px;min-height:180px}.es-flow-source,.es-flow-result{padding:16px 10px;border-radius:6px;background:#183657;color:#fff;text-align:center}.es-flow-source>b,.es-flow-result small{display:block;font-size:7px;letter-spacing:1px;color:#bed0e1}.es-flow-source strong,.es-flow-result b{display:block;font-size:17px;margin:6px 0}.es-flow-source span,.es-flow-result span{display:block;font-size:7.5px;line-height:1.4;color:#dce5ee}.es-flow-result{background:#956900}.es-flow-result strong{font-size:9px;display:block;margin-top:9px}.es-flow-arrow{font-size:20px;text-align:center;color:#9aa8b7}.es-flow-rows{display:grid;gap:7px}.es-flow-row{display:flex;align-items:center;justify-content:space-between;gap:12px;border:1px solid #cad5e0;border-left:5px solid #57728e;background:#f3f6f9;border-radius:5px;padding:7px 10px}.es-flow-row.commercial{border-left-color:#92a4b7}.es-flow-row.works{border-left-color:#c9a32a}.es-flow-row.profit{border-left-color:#b68100;background:#fff8e7}.es-flow-row.risk{border-left-color:#b8412b;background:#fff0ed}.es-flow-row strong{font-size:8.5px;color:#183657}.es-flow-row small{display:block;font-size:6.7px;color:#6d7b8d;margin-top:2px}.es-flow-value{text-align:right;min-width:80px}.es-flow-value b{display:block;font-size:9px;color:#183657}.es-flow-value span{font-size:7px;color:#7a8796}.es-segments{display:flex;height:7px;margin-top:12px;background:#dfe6ed}.es-segments i{display:block}.es-one-peso{display:grid;grid-template-columns:82px 58px 1fr;gap:13px;align-items:center;min-height:82px;padding:4px 7px}.es-coin{width:76px;height:76px;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;background:radial-gradient(circle at 35% 30%,#fff2a8 0,#e5b83a 38%,#b77c00 100%);border:4px double #8f6300;box-shadow:inset 0 0 0 3px rgba(255,255,255,.35),0 4px 10px rgba(111,78,0,.18);color:#513600}.es-coin small{font-size:5.4px;letter-spacing:.8px;font-weight:700}.es-coin b{font-size:24px;line-height:1;margin:3px 0}.es-coin span{font-size:5.8px;line-height:1.15;max-width:58px}.es-coin-arrow{text-align:center;color:#8492a3}.es-coin-arrow span{display:block;font-size:5.8px;letter-spacing:.7px}.es-coin-arrow b{display:block;font-size:24px;line-height:1}.es-peso-items{display:grid;grid-template-columns:repeat(4,1fr);gap:7px}.es-peso-items>div{min-height:56px;border:1px solid #d4dde7;border-top:4px solid #57728e;border-radius:5px;padding:8px 7px;background:#f7f9fb;text-align:center}.es-peso-items>div.commercial{border-top-color:#ef6b3b}.es-peso-items>div.works{border-top-color:#2aa876}.es-peso-items>div.profit{border-top-color:#d49a00;background:#fff9e9}.es-peso-items>div.risk{border-top-color:#b8412b;background:#fff0ed}.es-peso-items strong{display:block;font-size:14px;color:#183657}.es-peso-items span{display:block;font-size:6.4px;line-height:1.25;color:#637184;margin-top:4px}.es-distribution-detail{padding:7px 0 1px}.es-distribution-bar{display:flex;height:11px;margin:15px 0 12px;background:#e1e7ed;border-radius:2px;overflow:visible}.es-distribution-bar i{display:block;position:relative;min-width:0}.es-distribution-bar i:first-child{border-radius:2px 0 0 2px}.es-distribution-bar i:last-child{border-radius:0 2px 2px 0}.es-distribution-bar small{position:absolute;left:50%;top:-13px;transform:translateX(-50%);font-size:5.8px;font-style:normal;color:#5e6d7f;white-space:nowrap}.es-distribution-cards{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.es-distribution-cards>div{border:1px solid #d6dee8;border-radius:5px;background:#fbfcfd;padding:7px 9px;min-height:43px}.es-distribution-cards>div.profit{background:#fff9e9}.es-distribution-cards>div.risk{background:#fff0ed}.es-distribution-cards b{display:block;font-size:9px;color:#183657}.es-distribution-cards span{display:block;font-size:6.7px;line-height:1.3;color:#657386;margin-top:3px}.es-two-cols{display:grid;grid-template-columns:1fr 1fr;gap:22px}.es-simple-table,.es-scenario-table{width:100%;border-collapse:collapse;font-size:8.2px}.es-simple-table td,.es-scenario-table td,.es-scenario-table th{border-bottom:1px solid #dce3ea;padding:6px 7px}.es-simple-table td:last-child,.es-scenario-table td:not(:first-child),.es-scenario-table th:not(:first-child){text-align:right;font-weight:700;color:#183657}.es-simple-table tr.total{background:#edf2f7;font-weight:700}.es-scenario-table th{font-size:7px;color:#718094;text-transform:uppercase}.es-scenario-table td small{display:block;font-size:6.8px;color:#92a0af;margin-top:2px;font-weight:400}.es-scenario-table tr.is-base{background:#edf2f7}.es-timeline{display:flex;align-items:flex-start;justify-content:space-between;padding:14px 10px 2px}.es-time-point{width:18%;text-align:center;position:relative}.es-time-point>span{display:inline-flex;align-items:center;justify-content:center;width:27px;height:27px;border-radius:50%;background:#183657;color:#fff;font-size:7px;font-weight:700;position:relative;z-index:2}.es-time-point.warn>span{background:#b68100}.es-time-point.risk>span{background:#b8412b}.es-time-point i{position:absolute;top:13px;left:57%;width:100%;height:2px;background:#b7c3cf}.es-time-point b{display:block;font-size:7.5px;color:#183657;margin-top:5px}.es-time-point small{display:block;font-size:6.5px;line-height:1.3;color:#7b8795;margin-top:2px}.es-alerts{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.es-alert{background:#fff8e9;border-left:4px solid #c69c25;border-radius:3px;padding:9px;min-height:62px}.es-alert.risk{background:#fff0ed;border-color:#b8412b}.es-alert.ok{background:#eef8f1;border-color:#268455}.es-alert b{font-size:8px;color:#6e5100}.es-alert.risk b{color:#9b2d1f}.es-alert.ok b{color:#1e6d46}.es-alert p{font-size:7.2px;line-height:1.4;color:#617084;margin:5px 0 0}.es-page>footer{position:absolute;left:13mm;right:13mm;bottom:7mm;border-top:1px solid #d9e1e8;padding-top:6px;font-size:6.5px;line-height:1.35;color:#99a5b3}.es-page-two .es-header{margin-bottom:13px}.es-idea{border-left:4px solid #183657;background:#edf2f7;padding:15px 18px;font-size:11px;line-height:1.7;color:#35465b}.es-steps{display:grid;gap:9px}.es-step{display:flex;gap:12px;align-items:flex-start}.es-step>i{display:flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:50%;background:#183657;color:#fff;font-style:normal;font-weight:700;font-size:11px;flex:none}.es-step b{font-size:10px;color:#183657}.es-step p{font-size:8.5px;line-height:1.45;color:#5e6b7d;margin:3px 0 0}.es-glossary{display:grid;grid-template-columns:1fr 1fr;gap:8px}.es-term{border:1px solid #d8e0e9;background:#fbfcfd;border-radius:5px;padding:9px 11px;min-height:47px}.es-term b{display:block;font-size:8.5px;color:#183657}.es-term span{display:block;font-size:7.5px;line-height:1.35;color:#687689;margin-top:3px}.es-faq{display:grid;gap:7px}.es-faq b{font-size:8.5px;color:#183657}.es-faq p{font-size:7.5px;line-height:1.4;color:#5d6a7b;margin:2px 0 0}@media print{html,body{background:#fff}body{padding:0}.es-page{margin:0;width:210mm;height:297mm;min-height:297mm;overflow:hidden;box-shadow:none;-webkit-print-color-adjust:exact;print-color-adjust:exact}}@page{size:A4;margin:0}';
  }

  function open(input) {
    var win = global.open("", "_blank", "width=1050,height=820");
    if (!win) {
      global.alert("Tu navegador bloqueó la ventana del resumen. Permite ventanas emergentes y vuelve a intentarlo.");
      return false;
    }
    win.document.open();
    win.document.write(buildHtml(input));
    win.document.close();
    return true;
  }

  global.VicaperExecutiveSummary = { buildHtml: buildHtml, open: open };
})(window);
