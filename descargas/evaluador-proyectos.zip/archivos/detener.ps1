$ErrorActionPreference = 'Stop'
$pidFile = Join-Path $PSScriptRoot 'servidor.pid'
if (-not (Test-Path -LiteralPath $pidFile)) { exit }
$serverId = [int](Get-Content -LiteralPath $pidFile -Raw).Trim()
$serverPath = Join-Path $PSScriptRoot 'demo-server.mjs'
$serverProcess = Get-CimInstance Win32_Process -Filter "ProcessId = $serverId" -ErrorAction SilentlyContinue
if ($serverProcess -and $serverProcess.Name -eq 'node.exe' -and $serverProcess.CommandLine.Contains($serverPath)) { Stop-Process -Id $serverId }
Remove-Item -LiteralPath $pidFile -ErrorAction SilentlyContinue
