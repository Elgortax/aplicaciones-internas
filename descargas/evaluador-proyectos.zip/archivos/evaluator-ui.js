(() => {
  "use strict";

  const TARGETS = [
    "#tabFilterEstado",
    "#tabFilterSubestado",
    "#summaryFilterEstado",
    "#summaryFilterSubestado",
    "#forecastHorizonte",
    "#forecastDesde",
    "#forecastFiltroTipo",
    "#dashFilterEstado",
    "#dashFilterSubestado",
    "#dashFilterRegion",
    "#mapFilterEstado",
    "#mapFilterSubestado",
    ".state-select"
  ].join(",");

  const paths = {
    grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    chart: '<path d="M4 20V10m6 10V4m6 16v-7m4 7H2"/>',
    trend: '<path d="m3 17 6-6 4 4 8-9"/><path d="M15 6h6v6"/>',
    map: '<path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3V6Z"/><path d="M9 3v15m6-12v15"/>',
    pin: '<path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19 13.5v-3l-2-.7-.6-1.4.9-1.9-2.1-2.1-1.9.9-1.4-.6-.7-2h-3l-.7 2-1.4.6-1.9-.9L4.1 6.5 5 8.4l-.6 1.4-2 .7v3l2 .7.6 1.4-.9 1.9 2.1 2.1 1.9-.9 1.4.6.7 2h3l.7-2 1.4-.6 1.9.9 2.1-2.1-.9-1.9.6-1.4 2-.7Z"/>',
    filter: '<path d="M4 6h16M7 12h10M10 18h4"/>',
    clipboard: '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V2h6v2M8 10h8M8 14h8M8 18h5"/>',
    building: '<path d="M4 21V8l8-5 8 5v13M8 21v-5h8v5M8 10h.01M12 10h.01M16 10h.01"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
    wallet: '<path d="M4 6h14a2 2 0 0 1 2 2v11H4a2 2 0 0 1-2-2V6a3 3 0 0 1 3-3h12"/><path d="M15 11h7v5h-7a2.5 2.5 0 0 1 0-5Z"/>',
    database: '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>',
    palette: '<path d="M12 3a9 9 0 1 0 0 18h1.5a2 2 0 0 0 0-4H12a2 2 0 0 1 0-4h5a4 4 0 0 0 4-4c0-3.3-4-6-9-6Z"/><circle cx="7.5" cy="9" r=".8"/><circle cx="10" cy="6.5" r=".8"/><circle cx="14" cy="6.5" r=".8"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20v-2a5 5 0 0 1 5-5h2a5 5 0 0 1 5 5v2M16 5.5a3 3 0 0 1 0 5.8M17 14a5 5 0 0 1 4 4.9V20"/>',
    award: '<circle cx="12" cy="8" r="5"/><path d="m8.5 12-2 9 5.5-3 5.5 3-2-9"/>',
    split: '<path d="M6 3v4c0 3 2 5 5 5h7M15 9l3 3-3 3M6 21v-4c0-3 2-5 5-5"/>',
    printer: '<path d="M6 9V3h12v6M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="7"/>',
    download: '<path d="M12 3v12m-5-5 5 5 5-5M4 21h16"/>',
    upload: '<path d="M12 16V4m-5 5 5-5 5 5M4 21h16"/>',
    refresh: '<path d="M20 7v5h-5M4 17v-5h5"/><path d="M6.1 8A7 7 0 0 1 18 6l2 6M17.9 16A7 7 0 0 1 6 18l-2-6"/>',
    chevron: '<path d="m7 10 5 5 5-5"/>',
    check: '<path d="m5 12 4 4L19 6"/>'
  };

  const svg = name => `<svg class="eval-ui-icon" viewBox="0 0 24 24" aria-hidden="true">${paths[name] || paths.filter}</svg>`;
  const menu = document.createElement("div");
  menu.className = "eval-select-menu";
  menu.setAttribute("role", "listbox");
  document.body.appendChild(menu);

  let active = null;
  let activeIndex = -1;
  let scanQueued = false;

  function cleanLabel(text) {
    return String(text || "")
      .replace(/^[\p{Extended_Pictographic}\uFE0F\u200D\u2600-\u27BF]+\s*/u, "")
      .trim();
  }

  function optionIcon(select, option) {
    const value = String(option?.value || "").toLowerCase();
    const key = `${select.id} ${select.dataset.f || ""}`.toLowerCase();
    if (value === "todos" || value === "todas") return "grid";
    if (value.includes("evaluacion")) return "clipboard";
    if (value.includes("comercial")) return "building";
    if (/region/.test(key)) return "pin";
    if (/horizonte|desde/.test(key)) return "calendar";
    if (/esquemapago/.test(key)) return "wallet";
    return /filter|estado|tipo/.test(key) ? "filter" : "check";
  }

  function isReadOnly(select) {
    return select.disabled || document.body.classList.contains("readonly-mode");
  }

  function syncSelect(select) {
    const wrapper = select.closest(".eval-select");
    if (!wrapper) return;
    const option = select.options[select.selectedIndex];
    const nextLabel = cleanLabel(option?.textContent || "Seleccionar");
    const label = wrapper.querySelector(".eval-select-label");
    if (label.textContent !== nextLabel) label.textContent = nextLabel;
    const nextIcon = optionIcon(select, option);
    const leading = wrapper.querySelector(".eval-select-leading");
    if (leading.dataset.icon !== nextIcon) {
      leading.dataset.icon = nextIcon;
      leading.innerHTML = svg(nextIcon);
    }
    const trigger = wrapper.querySelector(".eval-select-trigger");
    trigger.disabled = isReadOnly(select);
    trigger.title = cleanLabel(option?.textContent || "Seleccionar");
  }

  function enhanceSelect(select) {
    if (!(select instanceof HTMLSelectElement) || select.multiple || select.dataset.evalSelectReady === "1") return;
    select.dataset.evalSelectReady = "1";
    const wrapper = document.createElement("span");
    wrapper.className = "eval-select";
    if (select.id) wrapper.classList.add(`eval-select-${select.id}`);
    select.parentNode.insertBefore(wrapper, select);
    wrapper.appendChild(select);
    select.classList.add("eval-select-native");
    select.tabIndex = -1;

    const trigger = document.createElement("button");
    trigger.type = "button";
    trigger.className = "eval-select-trigger";
    trigger.setAttribute("aria-haspopup", "listbox");
    trigger.setAttribute("aria-expanded", "false");
    trigger.innerHTML =
      '<span class="eval-select-leading"></span>' +
      '<span class="eval-select-label"></span>' +
      `<span class="eval-select-chevron">${svg("chevron")}</span>`;
    wrapper.appendChild(trigger);

    trigger.addEventListener("click", () => active === select ? closeMenu() : openMenu(select));
    trigger.addEventListener("keydown", event => {
      if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        event.preventDefault();
        if (active !== select) openMenu(select);
        moveActive(event.key === "ArrowDown" ? 1 : -1);
      } else if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        if (active === select && activeIndex >= 0) choose(activeIndex);
        else openMenu(select);
      } else if (event.key === "Escape") {
        closeMenu();
      }
    });
    select.addEventListener("change", () => syncSelect(select));
    syncSelect(select);
  }

  function rebuildMenu(select) {
    menu.innerHTML = "";
    activeIndex = select.selectedIndex;
    [...select.options].forEach((option, index) => {
      const item = document.createElement("button");
      item.type = "button";
      item.className = "eval-select-option";
      item.setAttribute("role", "option");
      item.dataset.index = String(index);
      item.disabled = option.disabled;
      item.innerHTML =
        `<span class="option-icon">${svg(optionIcon(select, option))}</span>` +
        `<span>${cleanLabel(option.textContent)}</span>` +
        `<span class="eval-select-check">${svg("check")}</span>`;
      if (option.selected) {
        item.classList.add("is-selected", "is-active");
        item.setAttribute("aria-selected", "true");
      }
      item.addEventListener("mouseenter", () => setActive(index));
      item.addEventListener("click", () => choose(index));
      menu.appendChild(item);
    });
  }

  function positionMenu() {
    if (!active) return;
    const trigger = active.closest(".eval-select")?.querySelector(".eval-select-trigger");
    if (!trigger) return;
    const rect = trigger.getBoundingClientRect();
    const width = Math.max(rect.width, active.id === "tabFilterEstado" ? 218 : 235);
    const safeWidth = Math.min(width, window.innerWidth - 16);
    menu.style.width = `${safeWidth}px`;
    menu.style.left = `${Math.max(8, Math.min(rect.left, window.innerWidth - safeWidth - 8))}px`;
    const desiredHeight = Math.min(menu.scrollHeight, 360);
    const below = window.innerHeight - rect.bottom - 8;
    const openAbove = below < Math.min(desiredHeight, 220) && rect.top > below;
    menu.style.top = openAbove
      ? `${Math.max(8, rect.top - desiredHeight - 7)}px`
      : `${Math.min(window.innerHeight - desiredHeight - 8, rect.bottom + 7)}px`;
  }

  function openMenu(select) {
    if (isReadOnly(select)) return;
    closeMenu(false);
    active = select;
    active.closest(".eval-select")?.classList.add("is-open");
    active.closest(".eval-select")?.querySelector(".eval-select-trigger")?.setAttribute("aria-expanded", "true");
    rebuildMenu(select);
    menu.classList.add("is-visible");
    positionMenu();
    menu.querySelector(".is-selected")?.scrollIntoView({ block: "nearest" });
  }

  function closeMenu(returnFocus = true) {
    if (!active) return;
    const wrapper = active.closest(".eval-select");
    const trigger = wrapper?.querySelector(".eval-select-trigger");
    wrapper?.classList.remove("is-open");
    trigger?.setAttribute("aria-expanded", "false");
    menu.classList.remove("is-visible");
    menu.innerHTML = "";
    active = null;
    activeIndex = -1;
    if (returnFocus) trigger?.focus();
  }

  function setActive(index) {
    activeIndex = index;
    [...menu.children].forEach((item, itemIndex) => item.classList.toggle("is-active", itemIndex === index));
  }

  function moveActive(direction) {
    if (!active || !menu.children.length) return;
    let next = activeIndex;
    do {
      next = (next + direction + menu.children.length) % menu.children.length;
    } while (menu.children[next]?.disabled && next !== activeIndex);
    setActive(next);
    menu.children[next]?.scrollIntoView({ block: "nearest" });
  }

  function choose(index) {
    if (!active || isReadOnly(active) || active.options[index]?.disabled) return;
    const select = active;
    select.selectedIndex = index;
    syncSelect(select);
    closeMenu();
    select.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function polishNavigation() {
    const navIcons = {
      summary: "grid",
      dashboard: "chart",
      map: "map",
      config: "settings"
    };
    document.querySelectorAll(".sb-nav-item[data-view]").forEach(item => {
      const icon = item.querySelector(".sb-nav-icon");
      if (icon && icon.dataset.evalPolished !== "1") {
        icon.dataset.evalPolished = "1";
        icon.innerHTML = svg(navIcons[item.dataset.view] || "grid");
      }
    });
  }

  function headingIcon(text) {
    const value = String(text || "").toLowerCase();
    if (/usuario/.test(value)) return "users";
    if (/apariencia|tema|t[ií]tulo|etiqueta/.test(value)) return "palette";
    if (/respaldo|datos/.test(value)) return "database";
    if (/mapa|regi[oó]n|ubicaci[oó]n/.test(value)) return "map";
    if (/forecast|flujo|venta proyectada/.test(value)) return "trend";
    if (/rentabilidad|resultado|evaluaci[oó]n|ranking/.test(value)) return "award";
    if (/escenario/.test(value)) return "split";
    if (/comercial|pago|pie|costo|gasto/.test(value)) return "wallet";
    if (/inventario|lote|unidad/.test(value)) return "building";
    if (/mercado|empresa|identidad/.test(value)) return "building";
    return "chart";
  }

  function polishPanelIcons() {
    document.querySelectorAll(".panel-head").forEach(head => {
      const badge = head.querySelector(".num");
      const title = head.querySelector("h2")?.textContent || "";
      if (!badge || badge.dataset.evalPolished === "1") return;
      const raw = badge.textContent.trim();
      if (/^\d{1,2}$/.test(raw)) return;
      badge.dataset.evalPolished = "1";
      badge.innerHTML = svg(headingIcon(title));
    });
  }

  function polishButtons() {
    document.querySelectorAll("button").forEach(button => {
      if (button.dataset.evalIconReady === "1" || button.querySelector(".eval-ui-icon")) return;
      const label = cleanLabel(button.textContent);
      let icon = null;
      if (/imprimir|pdf/i.test(label)) icon = "printer";
      else if (/descargar|exportar/i.test(label)) icon = "download";
      else if (/importar|cargar/i.test(label)) icon = "upload";
      else if (/actualizar/i.test(label)) icon = "refresh";
      if (!icon) return;
      button.dataset.evalIconReady = "1";
      button.classList.add("eval-icon-button");
      button.innerHTML = `${svg(icon)}<span>${label}</span>`;
    });
  }

  function scan() {
    scanQueued = false;
    document.querySelectorAll(TARGETS).forEach(enhanceSelect);
    document.querySelectorAll(`${TARGETS.split(",").map(selector => `.eval-select ${selector}`).join(",")}`).forEach(syncSelect);
    polishNavigation();
    polishPanelIcons();
    polishButtons();
  }

  function scheduleScan() {
    if (scanQueued) return;
    scanQueued = true;
    requestAnimationFrame(scan);
  }

  document.addEventListener("click", event => {
    if (active && !menu.contains(event.target) && !active.closest(".eval-select")?.contains(event.target)) {
      closeMenu(false);
    }
  });
  window.addEventListener("resize", () => active && positionMenu());
  window.addEventListener("scroll", event => {
    if (!active) return;
    if (event.target === menu || menu.contains(event.target)) return;
    closeMenu(false);
  }, true);

  new MutationObserver(scheduleScan).observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["class", "disabled"]
  });

  setInterval(() => document.querySelectorAll(".eval-select-native").forEach(syncSelect), 800);
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", scan);
  else scan();
})();
