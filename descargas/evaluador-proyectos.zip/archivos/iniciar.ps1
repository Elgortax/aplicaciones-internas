$ErrorActionPreference = 'Stop'
$demoRoot = Split-Path -Parent $PSScriptRoot
$demoUrl = 'http://127.0.0.1:4387/Abrir%20demo.html'
$healthUrl = 'http://127.0.0.1:4387/demo-health'
$running = $false
try { $health = Invoke-RestMethod -Uri $healthUrl -TimeoutSec 2; $running = $health.application -eq 'vicaper-evaluador-demo-v1' } catch {}
if (-not $running) {
  $nodeCommand = Get-Command node -ErrorAction SilentlyContinue
  if (-not $nodeCommand) { Start-Process -FilePath (Join-Path $demoRoot 'Abrir demo.html'); exit }
  $serverPath = Join-Path $PSScriptRoot 'demo-server.mjs'
  $process = Start-Process -FilePath $nodeCommand.Source -ArgumentList ('"' + $serverPath + '"') -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $PSScriptRoot 'servidor.log') -RedirectStandardError (Join-Path $PSScriptRoot 'servidor-error.log')
  Set-Content -LiteralPath (Join-Path $PSScriptRoot 'servidor.pid') -Value $process.Id
  for ($attempt = 0; $attempt -lt 20; $attempt++) {
    Start-Sleep -Milliseconds 150
    try { $health = Invoke-RestMethod -Uri $healthUrl -TimeoutSec 1; if ($health.application -eq 'vicaper-evaluador-demo-v1') { $running = $true; break } } catch {}
  }
}
if ($running) { Start-Process -FilePath $demoUrl } else { Start-Process -FilePath (Join-Path $demoRoot 'Abrir demo.html') }
