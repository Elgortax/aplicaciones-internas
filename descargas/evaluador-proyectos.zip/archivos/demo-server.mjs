import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const port=4387;
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.gif':'image/gif','.txt':'text/plain; charset=utf-8'};
http.createServer((request,response)=>{
 if(request.method!=='GET'&&request.method!=='HEAD'){response.writeHead(405);response.end();return;}
 const url=new URL(request.url,'http://127.0.0.1:'+port);
 if(url.pathname==='/demo-health'){response.writeHead(200,{'Content-Type':'application/json'});response.end(JSON.stringify({application:'vicaper-evaluador-demo-v1'}));return;}
 let relative;try{relative=decodeURIComponent(url.pathname).replace(/^\/+/, '')||'Abrir demo.html';}catch(e){response.writeHead(400);response.end();return;}
 const file=path.resolve(root,relative);
 if((file!==root&&!file.startsWith(root+path.sep))||!fs.existsSync(file)||!fs.statSync(file).isFile()||/\.(?:ps1|cmd|mjs|pid|log)$/i.test(file)){response.writeHead(404);response.end('Archivo no encontrado');return;}
 response.writeHead(200,{'Content-Type':types[path.extname(file).toLowerCase()]||'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
 if(request.method==='HEAD')response.end();else fs.createReadStream(file).pipe(response);
}).listen(port,'127.0.0.1',()=>console.log('Demo local: http://127.0.0.1:'+port+'/Abrir%20demo.html'));
