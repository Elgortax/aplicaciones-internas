(function(){
  'use strict';
  function ready(){
    const icons={book:'<path d="M4 4h6a3 3 0 0 1 3 3v14a4 4 0 0 0-4-3H4zM20 4h-4a3 3 0 0 0-3 3v14a4 4 0 0 1 4-3h3z"/>',refresh:'<path d="M20 7v5h-5M4 17v-5h5M6 8a7 7 0 0 1 12-2l2 6M18 16a7 7 0 0 1-12 2l-2-6"/>',chart:'<path d="M4 20V10m6 10V4m6 16v-7M2 20h20"/>'};
    const icon=name=>'<svg viewBox="0 0 24 24" aria-hidden="true">'+icons[name]+'</svg>';
    const top=document.createElement('div');top.className='demo-toolbar';
    top.innerHTML='<div class="demo-toolbar-context"><span class="demo-pill">DEMO INTERACTIVA</span><span class="demo-toolbar-caption">Datos ficticios · Cambios guardados en este navegador</span></div><div class="demo-toolbar-actions"><button type="button" id="demoReset">'+icon('refresh')+'Restaurar ejemplos</button><a href="Guía de la demo.html" target="_blank" rel="noopener">'+icon('book')+'Cómo funciona</a></div>';
    document.getElementById('appMain').prepend(top);
    const brand=document.createElement('div');brand.className='demo-brand';brand.innerHTML='<span class="demo-brand-mark">V</span><span>VICAPER<span class="demo-brand-sub">PROJECT INTELLIGENCE</span></span>';
    document.querySelector('.sb-header').prepend(brand);
    const summary=document.getElementById('viewSummary');
    const hero=document.createElement('section');hero.className='demo-hero';
    hero.innerHTML='<div class="demo-hero-copy"><span class="demo-eyebrow">EVALUADOR DE PROYECTOS</span><h1>Del terreno a una<br><em>decisión clara.</em></h1><p>Compara rentabilidad, proyecta tus cobros y encuentra el mejor escenario para cada proyecto.</p><div class="demo-hero-actions"><button type="button" id="demoExplore">'+icon('chart')+'Explorar dashboard</button><a href="Guía de la demo.html" target="_blank" rel="noopener">Conocer la aplicación</a></div></div><div class="demo-hero-visual" aria-hidden="true"><div class="demo-visual-label">UNA VISIÓN COMPLETA</div><div class="demo-visual-caption">Venta. Costos. Resultado.</div><div class="demo-mini-bars"><i style="--bar:92%"></i><i style="--bar:60%"></i><i style="--bar:42%"></i><i style="--bar:25%"></i><i style="--bar:68%"></i></div><div class="demo-visual-bottom"><span>Evaluar</span><span>Comparar</span><span>Decidir</span></div></div>';
    summary.prepend(hero);
    [['viewDashboard','ANÁLISIS DE CARTERA','Los números cuentan la historia.','Rentabilidad, concentración y capacidad de pago, en una sola vista.'],['viewMap','INTELIGENCIA TERRITORIAL','Tu cartera, en el territorio.','Explora ubicaciones, filtra proyectos y analiza su contexto regional.'],['viewConfig','TU ESPACIO DE TRABAJO','Cada detalle, a tu medida.','Indicadores, identidad, costos globales, estados y respaldos.']].forEach(([id,eyebrow,title,text])=>{
      const section=document.createElement('header');section.className='demo-page-title';section.innerHTML='<span class="demo-eyebrow">'+eyebrow+'</span><h1>'+title+'</h1><p>'+text+'</p>';document.getElementById(id).prepend(section);
    });
    document.getElementById('demoExplore').addEventListener('click',()=>document.getElementById('tabDashboardBtn').click());
    const home=document.getElementById('portalBackBtn');home.href='Guía de la demo.html';home.target='_blank';home.rel='noopener';home.textContent='Guía de la aplicación';home.title='Abrir la guía de la demo';
    document.getElementById('demoReset').addEventListener('click',()=>document.getElementById('demoResetDialog').showModal());
    document.getElementById('demoResetCancel').addEventListener('click',()=>document.getElementById('demoResetDialog').close());
    document.getElementById('demoResetConfirm').addEventListener('click',async()=>{
      if(window.VICAPER_FLUSH_EVALUATOR)await window.VICAPER_FLUSH_EVALUATOR();
      localStorage.removeItem(window.VICAPER_DEMO.storageKey);
      localStorage.removeItem('loteo_backup_v2_'+window.VICAPER_DEMO.workspace);
      localStorage.removeItem('evaluador_demo_initial_view');
      location.reload();
    });
    const footer=document.querySelector('footer.note');
    if(footer)footer.innerHTML='Demo local del Evaluador de Proyectos · Los proyectos y personas de esta versión son ficticios.<br>Exporta un respaldo desde Configuración para conservar tus cambios fuera del navegador.';
    const observer=new MutationObserver(()=>{
      if(!document.querySelector('[data-project-view]'))return;
      observer.disconnect();document.getElementById('tabSummaryBtn').click();
    });
    if(document.querySelector('[data-project-view]'))document.getElementById('tabSummaryBtn').click();else observer.observe(document.getElementById('projectViews'),{childList:true});
    document.querySelectorAll('.sb-nav-item').forEach(el=>{el.setAttribute('role','button');el.tabIndex=0;el.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();el.click();}});});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ready);else ready();
})();
