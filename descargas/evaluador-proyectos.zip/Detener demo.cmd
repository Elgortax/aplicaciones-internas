@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0archivos\detener.ps1"
