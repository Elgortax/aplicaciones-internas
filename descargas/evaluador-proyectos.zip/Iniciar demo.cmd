@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0archivos\iniciar.ps1"
